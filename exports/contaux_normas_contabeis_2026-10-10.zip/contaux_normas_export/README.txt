EXPORTAÇÃO — BASE DE CONHECIMENTO CONTAUX / NBCs CFC
Data: 2026-10-10
Total de normas sincronizadas: 277
Com texto integral extraído: 274
Sem texto extraído: 3
Origem: tabela knowledge_base do ambiente Base44 Contaux após sincronização full com CFC.

Estrutura:
- normas/: um Markdown por norma
- manifesto.csv: índice tabular
- manifesto.json: metadados estruturados
