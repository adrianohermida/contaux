# Altera a NBC TA 260, NBC TA 700 e NBC TA 706.

- Código externo: 2026/revisãonbc32
- Fonte: CFC 2026/REVISÃONBC32 — DOU 29/04/2026
- URL fonte: https://www2.cfc.org.br/sisweb/sre/detalhes_sre.aspx?Codigo=2026/REVIS%C3%83ONBC32&arquivo=REVIS%C3%83ONBC32.docx
- Arquivo original: https://www1.cfc.org.br/sisweb/SRE/docs/REVIS%c3%83ONBC32.pdf
- Nome do arquivo: REVISÃONBC32.pdf
- Tags: Contábil, NBC, NBC TA
- Atualizado em: 2026-10-10 14:27:59.491164+00

## Resumo

Altera a NBC TA 260, NBC TA 700 e NBC TA 706.

## Texto integral extraído

SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
1 
 
NORMA BRASILEIRA DE CONTABILIDADE, REVISÃO NBC 32, DE 9 DE ABRIL DE 2026 
                                                                                                        
Aprova a Revisão NBC 32, que altera a NBC 
TA 260, NBC TA 700 e NBC TA 706. 
 
            O CONSELHO FEDERAL DE CONTABILIDADE, no exercício de suas atribuições legais e regimentais 
e com o fundamento no disposto na alínea f do art. 6º do Decreto-Lei nº 9.295, de 27 de maio de 1946, 
em seu artigo 76, alterado pela Lei nº 12.249, de 11 de junho de 2010, faz saber que foi aprovada em seu 
Plenário a Revisão NBC 32, que altera as seguintes Normas Brasileiras de Contabilidade (NBC):  
 
1. Altera  os itens 17 e  A29 e  redação  do  apêndice  2  da  NBC  TA  260  (R2) – que  dispõe  sobre  a 
Comunicação com os responsáveis pela governança, passando a vigorar com a seguinte redação:  
 
Independência do auditor 
 
17. No caso de entidades listadas, o auditor deve comunicar aos responsáveis pela governança: 
  
(a) uma declaração de que a equipe de trabalho e outras pessoas na firma de auditoria, bem 
como  a  própria  firma  e,  quando  aplicável,  as  firmas  da  rede, as  exigências  éticas  relevantes 
relativas à cumpriram os requisitos éticos pertinentes de independência; e  
(...) 
 
Independência do Auditor (itens 16A e 17) 
 
A29.  O auditor deve cumprir com requisitos éticos relevantes, incluindo aqueles relacionados à 
independência relativa à auditoria das demonstrações contábeis, e comunicar aos responsáveis 
pela governança sobre os requisitos que ele aplica. Os requisitos éticos relevantes podem: 
• estabelecer requisitos de independência que são específicos de auditorias de demonstrações 
contábeis  de  determinadas  entidades  especificadas  nos  requisitos  éticos  relevantes,  como, 
por exemplo, os requisitos de independência para auditorias de demonstrações contábeis de 
entidades de interesse público no Brasil no Código de Ética Internacional para Profissionais de 
Contabilidade  (Iesba).  Se  aplicável  nas  circunstâncias  do  trabalho  de  auditoria,  esta  Norma 
requer  que  o  auditor  também  comunique  aos  responsáveis  pela  governança  que  ele  aplica 
esses requisitos de independência. 
• (...) 
 
Apêndice 2 (itens 16 (a), A19 e A20) 
 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
2 
 
Aspectos qualitativos de práticas contábeis  
 
A comunicação exigida pelo item 16 (a) e discutida nos itens A19 e A20 pode incluir assuntos como:  
 
(...) 
 
Estimativas contábeis e divulgações relacionadas: 
 
Para itens para os quais as estimativas são significativas, assuntos discutidos na NBC TA 540 (R2),  
O  apêndice  2  da  NBC  TA  540 – Auditoria  de  Estimativas  Contábeis Inclusive  do  Valor  Justo, e 
Divulgações  Relacionadas incluindo  por  exemplo inclui assuntos  que  o  auditor  pode  considerar 
comunicar com respeito a aspectos qualitativos significativos das práticas contábeis da entidade 
relacionadas às estimativas contábeis e divulgações relacionadas.  
 
o como a administração identifica as transações, eventos e condições que podem gerar a 
necessidade de reconhecimento ou divulgação de estimativas contábeis nas demonstrações 
contábeis; 
o mudanças nas circunstâncias que podem gerar novas estimativas contábeis ou a necessidade 
de revisar as existentes; 
o se a decisão da administração de reconhecer, ou não reconhecer, as estimativas contábeis 
nas demonstrações contábeis está de acordo com a estrutura de relatório financeiro 
aplicável; 
o se houve ou deveria ter havido mudança nos métodos do período anterior para elaborar as 
estimativas contábeis e, em caso afirmativo, por que e qual o desfecho de estimativas 
contábeis em períodos anteriores; 
o processo da administração para fazer estimativas contábeis (por exemplo, quando a 
administração utilizou um modelo), incluindo se a base de mensuração selecionada para a 
estimativa contábil está de acordo com a estrutura de relatório financeiro aplicável; 
o se as premissas significativas usadas pela administração na elaboração da estimativa contábil 
são razoáveis; 
o quando relevante para a razoabilidade das premissas significativas usadas pela 
administração ou para a apropriada aplicação da estrutura de relatório financeiro aplicável, 
a intenção e a capacidade da administração de realizar ações específicas; 
o riscos de distorção relevante; 
o indicadores de possível tendenciosidade pela administração; 
o como a administração considerou premissas ou desfechos alternativos e por que os rejeitou 
ou como a administração tratou de outra forma a incerteza de estimativa ao elaborar a 
estimativa contábil; 
o divulgação de incerteza de estimativa nas demonstrações contábeis.  
           

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
3 
 
2. Altera os itens 24, 28, 50, A22, A26, A34, A35, A35A, A36, A37, A38 e A39 e a redação do Apêndice 
da  NBC  TA  700 – que  dispõe  sobre  a  formação  da  opinião  e  emissão  do  relatório  do  auditor 
independente sobre as demonstrações contábeis, passando a vigorar com a seguinte redação:  
24. A seção “Opinião” do relatório do auditor também deve:  
 
(..) 
 
(d) fazer referência às notas explicativas, incluindo o resumo das principais as políticas contábeis 
materiais e outras informações elucidativas; 
 
(...) 
 
28. O relatório do auditor deve incluir uma seção, logo após a seção “Opinião”, com o título “Base 
para opinião”, que (ver item A32): 
 
(...) 
 
(c) inclua a declaração de que o auditor é independente da entidade, de acordo com as exigências 
éticas relevantes relacionadas os requisitos éticos pertinentes relacionados com a auditoria, e que 
ele atendeu às outras responsabilidades éticas do auditor, de acordo com esses requisitos. 
  
(i)  A declaração deve identificar a jurisdição de origem dos requisitos éticos pertinentes ou 
referir-se ao Código de Ética Internacional para Profissionais da Contabilidade (Iesba) Código 
de Ética Profissional do Contador; e (ver itens A34, A35, A36 e A37) 
(ii)  Se  os  requisitos éticos relevantes pertinentes requererem  que  o  auditor  divulgue 
publicamente  que  ele  aplicou  os  requisitos  de  independência  específicos  de  auditorias  de 
demonstrações  contábeis  de  determinadas  entidades,  a  declaração  deve  indicar  que  o 
auditor  é  independente  da  entidade,  de  acordo  com os  requisitos  de  independência 
aplicáveis às auditorias dessas entidades; e  
 
(...) 
 
50. Se o auditor, por exigência de lei ou regulamento, for requerido a utilizar uma forma ou um 
texto específico para elaborar o seu relatório, ele pode se referir às normas de auditoria brasileiras 
ou internacionais se incluir, no mínimo, cada um dos seguintes elementos (ver itens A70 e A71): 
 
(...) 
         
(e)  uma  declaração  de  que  o auditor  é  independente  da entidade, de  acordo  com as  exigências 
éticas relevantes os requisitos éticos pertinentes relacionados com a auditoria, e que ele atendeu 
às cumpriu com as outras responsabilidades éticas do auditor, de acordo com esses requisitos. 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
4 
 
 
(i) A  declaração  deve  incluir  a  identificação  da  jurisdição  de  origem das  exigências 
éticas  relevantes dos  requisitos  éticos  pertinentes  (Código  de  Ética  Profissional  do 
Contador) ou fazer referência ao Código de Ética do International Ethics Standards Board 
for Accountants (Iesba) da Federação Internacional de Contadores (Ifac);  
 
(ii) Se  os  requisitos  éticos relevantes pertinentes requererem  que  o  auditor  divulgue 
publicamente que ele aplicou os requisitos de independência específicos de auditorias de 
demonstrações  contábeis  de  determinadas  entidades,  a  declaração  deve  indicar  que  o 
auditor  é  independente  da  entidade,  de  acordo  com os  requisitos  de  independência 
aplicáveis às auditorias dessas entidades;  
 
A22.  O  relatório  do  auditor  afirma,  por  exemplo,  que  o  auditor  examinou  as  demonstrações 
contábeis da entidade, que compreendem [especificar o título de cada demonstração contábil que 
compõe o conjunto completo das demonstrações contábeis requeridas pela estrutura de relatório 
financeiro aplicável, especificando a data ou período coberto por cada demonstração contábil] e 
as  notas explicativas  às demonstrações  contábeis,  incluindo o  resumo  das principais as políticas 
contábeis materiais e outras informações elucidativas.  
 
A26.    A  opinião  do  auditor  cobre  o  conjunto  completo  das  demonstrações  contábeis,  conforme 
definido pela estrutura de relatório financeiro aplicável. Por exemplo, no caso de várias estruturas 
para   fins   gerais,   as   demonstrações   contábeis   podem   incluir:   o   balanço   patrimonial;   as 
demonstrações do resultado, do resultado abrangente, das mutações do patrimônio líquido, dos 
fluxos de caixa; e as respectivas notas explicativas, que normalmente compreendem o resumo das 
principais as políticas  contábeis materiais e outras  informações explanatórias elucidativas.  Em 
algumas  jurisdições,  as  informações  adicionais  também  podem  ser  consideradas  como  parte 
integrante das demonstrações contábeis.  
      
Exigências éticas relevantes Requisitos éticos pertinentes (ver item 28 (c)) 
 
A34.  A  identificação  da  jurisdição de  origem  dos  requisitos  éticos  pertinentes  aumenta  a 
transparência desses requisitos com relação a trabalho de auditoria específico. A NBC TA 200, item 
A16, explica que os requisitos éticos pertinentes compreendem as disposições do Código de Ética 
Profissional   do   Contador   e   as   normas   profissionais   emitidas   pelo   Conselho   Federal   de 
Contabilidade  em  conjunto  com  outros  requisitos  de  órgãos  reguladores,  quando  forem  mais 
restritivos.  Quando  os  requisitos  éticos  pertinentes  incluem  os  requisitos  do  Código  de  Ética 
Internacional para Profissionais da Contabilidade (Código de Ética do Ifac), a declaração também 
pode fazer referência ao Código de Ética do Ifac. Se o Código de Ética do Ifac constitui todos os 
requisitos éticos pertinentes para a auditoria, a declaração não precisa identificar a jurisdição de 
origem.  No  Brasil,  a  declaração  acima  somente  fará  referência  ao  Código  de  Ética da  Ifac 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
5 
 
Profissional   do   Contador e   às   normas   profissionais   emitidas   pelo   Conselho   Federal   de 
Contabilidade.  
 
A35.  Em  algumas  jurisdições, as  exigências  éticas  relevantes os  requisitos  éticos  pertinentes 
podem ser de diversas fontes diferentes, como os códigos de ética e regras e requisitos adicionais 
em  lei  e  regulamento.  Quando  a  independência  e outras  exigências  éticas  relevantes outros 
requisitos éticos pertinentes estão incluídas incluídos em um número limitado de fontes, o auditor 
pode  optar  por  identificar  as  fontes  relevantes  (por  exemplo,  o  nome  do  código,  regra  ou 
regulamento aplicável na jurisdição, ou pode fazer referência ao termo normalmente entendido e 
que  resume  adequadamente  essas  fontes  (por  exemplo,  requisitos  de  independência  para 
auditorias de entidades privadas na jurisdição X).  
 
A35A. Os requisitos éticos relevantes pertinentes podem:  
 
• Estabelecer   requisitos   de   independência   específicos   de   auditorias   de   demonstrações 
contábeis   de   determinadas   entidades   especificadas   nos   requisitos   éticos relevantes 
pertinentes,   como,   por   exemplo,   os   requisitos   de   independência   para   auditorias   de 
demonstrações  contábeis  de  entidades  de  interesse  público  no  Código Iesba de  Ética 
Profissional   do   Contador.   Os   requisitos   éticos relevantes pertinentes podem   também 
requerer  ou  incentivar  que  o  auditor  determine  se  é  apropriado  aplicar  esses  requisitos  de 
independência a auditorias de demonstrações contábeis de outras entidades que não aquelas 
especificadas nos requisitos éticos relevantes pertinentes;  
 
• Requerer que o auditor divulgue publicamente que ele aplicou os requisitos de independência 
específicos  de  auditoras  de  demonstrações  contábeis  de  determinadas  entidades.  Por 
exemplo, o Código Iesba Código de Ética Profissional do Contador requer que, quando uma 
firma aplicar os requisitos de independência para entidades de interesse público na condução 
de  uma  auditoria de demonstrações  contábeis de  uma  entidade,  a firma  divulgue  esse  fato 
publicamente,   a   menos   que   essa  divulgação  resulte   na  divulgação  de   planos   futuros 
confidenciais da entidade.  
 
A36. Leis ou regulamentos, normas de auditoria nacionais ou termos de um trabalho de auditoria 
também   podem   requerer   que   o   auditor   forneça,   no   relatório   do   auditor   independente, 
informações  mais  específicas  sobre  as  fontes  dos  requisitos  éticos relevantes pertinentes, 
incluindo   aquelas   relacionadas   com   independência,   que   se   aplicaram   à   auditoria   das 
demonstrações contábeis.  
 
A37. Ao determinar a quantidade de informações a ser incluída no relatório do auditor quando há 
múltiplas fontes de exigências éticas relevantes requisitos éticos pertinentes relacionados com a 
auditoria   das   demonstrações   contábeis,   é   importante   conseguir   um   equilíbrio   entre   a 
transparência e o risco de obscurecer outras informações úteis no relatório do auditor.  

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
6 
 
 
A38. Em auditoria de grupo, para a qual houver múltiplas fontes de exigências éticas relevantes 
requisitos   éticos   pertinentes,   incluindo aquelas   relacionadas aqueles   relacionados com 
independência,  a  referência  à  jurisdição  no  relatório  do  auditor  está  normalmente  relacionada 
com as exigências éticas relevantes os requisitos éticos pertinentes que são aplicáveis ao auditor 
do  grupo.  Isso  acontece  porque,  na  auditoria  de  grupo,  os  auditores  de  componentes  também 
estão sujeitos aos requisitos éticos pertinentes para a auditoria do grupo (ver itens A56 a A57 e 
A66 a A68 da NBC TA 600).  
 
A39. As normas de auditoria não estabelecem requisitos de independência ou éticos específicos 
para auditores, incluindo auditores de componentes, e, desse modo, não estendem, ou de outra 
forma  prevalecem  sobre  os  requisitos  de  independência  do  Código  de  Ética  Profissional  do 
Contador e nas normas profissionais emitidas pelo Conselho Federal de Contabilidade às quais o 
auditor do grupo está sujeito. As normas de auditoria também não requerem que os auditores de 
componentes,  em  todos  os  casos,  submetam-se  aos mesmos  requisitos  de  independência 
específicos aplicáveis ao auditor do grupo. Consequentemente, as exigências éticas relevantes os 
requisitos éticos pertinentes, incluindo aquelas relacionadas com a independência, na situação de 
auditoria de grupo, podem ser complexas. Os itens 25 e 27 da NBC TA 600 fornecem orientação 
para  auditores  sobre  como  trabalhar  com  as  informações  financeiras  de  componentes  para  a 
auditoria  de  grupo,  incluindo  as  situações  em  que  o  auditor  do  componente  não  cumpre  os 
requisitos de independência que são relevantes para a auditoria do grupo.  
 
Apêndice (ver item A19) 
        
Exemplos de relatório do auditor independente sobre as demonstrações contábeis 
        
(...) 
 
Exemplo  1:  Relatório  do  auditor  independente  sobre  demonstrações  contábeis  de  entidade 
listada
(1)
, elaboradas de acordo com a estrutura de apresentação adequada 
 
(...) 
• Os  requisitos  éticos  pertinentes  que  se  aplicam  à  auditoria  compõem  o  Código  de  Ética 
Profissional  do  Contador  e  as  normas  profissionais  emitidas  pelo  Conselho  Federal  de 
Contabilidade juntamente com os requisitos éticos relacionados com a auditoria na jurisdição, 
e  o  auditor  refere-se  a  ambos.  O  código  Iesba e  os  requisitos  éticos  relacionados  com  a 
auditoria  na  jurisdição. Essas  normas  incluem  os  requisitos  de  independência  aplicáveis  a 
auditorias  de  demonstrações  contábeis  de  entidades  de  interesse  público.  Elas  também 
requerem que o auditor divulgue publicamente que os requisitos de independência aplicáveis 
a auditorias de demonstrações contábeis de entidades de interesse público foram aplicados.   
 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
7 
 
RELATÓRIO DO AUDITOR INDEPENDENTE SOBRE AS DEMONSTRAÇÕES CONTÁBEIS
(1)(2)
 
Aos acionistas da Companhia ABC [ou outro destinatário apropriado] 
Opinião 
Examinamos as demonstrações contábeis da Companhia ABC (Companhia), que compreendem o 
balanço patrimonial em 31 de dezembro de 20X1 e as respectivas demonstrações do resultado, do 
resultado abrangente, das mutações do patrimônio líquido e dos fluxos de caixa para o exercício 
findo  nessa  data,  bem  como  as  correspondentes  notas  explicativas,  incluindo o  resumo  das 
principais as políticas contábeis materiais e outras informações elucidativas.  
(...) 
Base para opinião
(3)
 
Nossa auditoria foi conduzida de acordo com as normas brasileiras e internacionais de auditoria. 
Nossas responsabilidades, em conformidade com tais normas, estão descritas na seção a seguir, 
intitulada “Responsabilidades do auditor pela auditoria das demonstrações contábeis”. Somos 
independentes em relação à companhia Companhia, de acordo com os princípios éticos relevantes 
previstos  no Código  de  Ética  Profissional  do  Contador  e  as  normas  profissionais emitidas pelo 
Conselho Federal de Contabilidade, conforme aplicável aplicáveis a auditorias de demonstrações 
contábeis  de  entidades  de  interesse  público no  Brasil,  juntamente  com  os  requisitos  éticos 
pertinentes para a nossa auditoria das demonstrações contábeis de entidades de interesse público 
em [jurisdição]. Nós também cumprimos com as demais responsabilidades éticas, de acordo com 
essas normas.  
(...) 
Responsabilidade da administração e da governança pelas demonstrações contábeis
(2)(4) 
A  administração  é  responsável  pela  elaboração  e  adequada  apresentação  das  demonstrações 
contábeis de acordo com as práticas contábeis adotadas no Brasil
(3)(5)
 
(...)
 
Responsabilidade do auditor pela auditoria das demonstrações contábeis 
(...) 
Como  parte  da  auditoria  realizada  de  acordo  com  as  normas  brasileiras  e  internacionais  de 
auditoria,  exercemos  julgamento  profissional  e  mantemos  ceticismo  profissional  ao  longo  da 
auditoria. Além disso
(4)(6)
: 
(...) 
• Obtemos entendimento dos controles internos relevantes para a auditoria para planejarmos 
procedimentos  de  auditoria  apropriados  às  circunstâncias,  mas,  não,  com  o  objetivo  de 
expressarmos opinião sobre a eficácia dos controles internos da companhia
(5)(7)
. 
(...) 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
8 
 
Fornecemos  também  aos  responsáveis  pela  governança  declaração  de  que  cumprimos  com as 
exigências éticas relevantes os requisitos éticos pertinentes, incluindo os requisitos aplicáveis de 
independência,  e  comunicamos  todos  os  eventuais  relacionamentos  ou  assuntos  que  poderiam 
afetar,  consideravelmente, nossa  independência,  incluindo,  quando aplicável,  as ações  tomadas 
para eliminar as ameaças ou as respectivas salvaguardas aplicadas.  
(...) 
(1) No Brasil, este exemplo é aplicável para entidades listadas e entidades classificadas como entidades de interesse 
público exceto pelo item referenciado em 
(8)
. 
(1)(2) No  caso  de  o  relatório  cobrir  outros  aspectos  legais  e  regulatórios,  é  necessário  incluir  um  subtítulo  para 
especificar a primeira parte do relatório, “Relatório do auditor sobre as demonstrações contábeis” e, no final do 
relatório, outro subtítulo para a segunda parte, “Relatório sobre outros requisitos legais e regulatórios.” 
(3) Para entidades que não são de interesse público, e o relatório do auditor independente seja sobre demonstrações 
contábeis elaboradas de acordo com a estrutura de apresentação adequada, o texto desta seção pode ser adaptado 
para o seguinte formato: 
“Nossa  auditoria  foi  conduzida  de  acordo  com  as  normas  brasileiras  e  internacionais  de  auditoria.  Nossas 
responsabilidades, em conformidade com tais normas, estão descritas na seção a seguir, intitulada “Responsabilidades 
do auditor pela auditoria das demonstrações contábeis”. Somos independentes em relação à Companhia de acordo 
com os princípios éticos relevantes previstos no Código de Ética Profissional do Contador e nas normas profissionais 
emitidas  pelo  Conselho  Federal  de  Contabilidade,  aplicáveis  a  auditorias  de  demonstrações  contábeis  no  Brasil,  e 
cumprimos  com  as  demais  responsabilidades  éticas  de  acordo  com  essas  normas.  Acreditamos  que  a  evidência  de 
auditoria obtida é suficiente e apropriada para fundamentar a nossa opinião.” 
(2)(4) Em todos esses exemplos de relatório do auditor, os termos “administração” e “responsáveis pela governança” 
podem precisar ser substituídos por outros termos mais apropriados no contexto da estrutura legal de determinada 
jurisdição. 
(3)(5) Quando a responsabilidade da administração é elaborar as demonstrações contábeis que apresentem uma visão 
verdadeira e justa, esta sentença pode ser lida: “A administração é responsável pela elaboração de demonstrações 
contábeis  que  apresentem  uma  visão verdadeira  e  justa  de  acordo  com  as práticas  contábeis  adotadas no  Brasil  e, 
para isso ,...” 
(4)(6) O  item  41  (b)  desta  norma  explica  que  a  descrição  das  responsabilidades  do  auditor  independente  pode  ser 
localizada no apêndice do relatório do auditor. O item 41 (c) explica que, quando expressamente permitida por lei, 
regulamento ou normas de auditoria nacionais, pode ser feita uma referência ao sítio da autoridade competente que 
contém a descrição das responsabilidades do auditor em vez de incluir esse material no relatório do auditor, desde 
que o sítio se trate da descrição das responsabilidades do auditor acima e não seja inconsistente com ela. Essa opção 
não é permitida no Brasil.  
(5)(7) Essa sentença deve ser modificada, conforme adequado, nas circunstâncias em que o auditor também tem a 
responsabilidade de expressar uma opinião sobre a eficácia dos controles internos com a auditoria das demonstrações 
contábeis.  
 
Exemplo  2:  Relatório  do  auditor  sobre  demonstrações  contábeis  consolidadas  de  entidade 
listada 
(1)
, elaboradas de acordo com a estrutura de apresentação adequada. 
 
Para fins deste exemplo, são consideradas as seguintes características:   
 
(...) 
 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
9 
 
• Os requisitos éticos pertinentes relevantes que se aplicam à auditoria são aqueles da jurisdição 
compõem o Código de Ética Profissional do Contador e as normas profissionais emitidas pelo 
Conselho  Federal  de  Contabilidade. Os  requisitos  éticos  relacionados  com  a  auditoria  na 
jurisdição. Essas  normas  incluem  os  requisitos  de  independência  aplicáveis  a  auditorias  de 
demonstrações  contábeis  de  entidades de  interesse  público. Elas  também  requerem  que  o 
auditor  divulgue  publicamente  que  os  requisitos  de  independência  aplicáveis  a  auditorias  de 
demonstrações contábeis de determinadas entidades de interesse público foram aplicados.  
 
(...) 
 
RELATÓRIO    DO    AUDITOR    INDEPENDENTE    SOBRE    AS    DEMONSTRAÇÕES    CONTÁBEIS 
CONSOLIDADAS 
(1)(2)  
 
Aos acionistas da Companhia ABC [ou outro destinatário apropriado] 
 
Opinião 
 
Examinamos  as  demonstrações  contábeis  consolidadas  da  Companhia  ABC  (Companhia)  e  suas 
controladas, que compreendem o balanço patrimonial consolidado em 31 de dezembro de 20x1 e 
as respectivas demonstrações consolidadas do resultado, do resultado abrangente, das mutações 
do  patrimônio  líquido  e  dos  fluxos  de  caixa  para  o  exercício  findo  nessa  data,  bem  como  as 
correspondentes  notas  explicativas,  incluindo o  resumo  das  principais as políticas  contábeis 
materiais e outras informações elucidativas.  
 
Base para opinião
(3)
 
 
Nossa auditoria foi conduzida de acordo com as normas brasileiras e internacionais de auditoria. 
Nossas responsabilidades, em conformidade com tais normas, estão descritas na seção a seguir, 
intitulada “Responsabilidades do auditor pela auditoria das demonstrações contábeis.” Somos 
independentes  em  relação  à companhia Companhia e  às  suas  controladas,  de  acordo  com  os 
requisitos princípios éticos relevantes previstos no Código de Ética Profissional do Contador e as 
normas profissionais emitidas pelo Conselho Federal de Contabilidade, aplicáveis a para auditorias 
de  demonstrações  contábeis  de  entidades  de  interesse  público em  [jurisdição] no  Brasil,  e.  Nós 
também cumprimos com as demais responsabilidades éticas, de acordo com esses requerimentos 
essas  normas.  Acreditamos  que  a  evidência  de  auditoria  obtida  é  suficiente  e  apropriada  para 
fundamentar a nossa opinião. 
 
Responsabilidades   da   administração   e   da   governança   pelas   demonstrações   contábeis 
consolidadas 
(2)(4) 
 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
10 
 
A  administração  é  responsável  pela  elaboração  e  adequada  apresentação  das  demonstrações 
contábeis  consolidadas  de  acordo  com  as  práticas  contábeis  adotadas  no  Brasil
(3)(5)
 e  pelos 
controles   internos   que   ela   determinou   como   necessários   para   permitir   a   elaboração   de 
demonstrações  contábeis  livres  de  distorção  relevante,  independentemente  se  causada  por 
fraude ou erro. 
(...) 
 
Responsabilidades do auditor pela auditoria das demonstrações contábeis consolidadas 
 
(...) 
 
Como  parte  da  auditoria  realizada  de  acordo  com  as  normas  brasileiras  e  internacionais  de 
auditoria,  exercemos  julgamento  profissional  e  mantemos  ceticismo  profissional  ao  longo  da 
auditoria. Além disso
(4)(6)
: 
 
(...) 
 
• Obtemos  entendimento  dos  controles  internos  relevantes  para  a  auditoria  para  planejarmos 
procedimentos  de  auditoria  apropriados  nas  circunstâncias,  mas,  não,  com  o  objetivo  de 
expressarmos  opinião  sobre  a  eficácia  dos  controles  internos  da  companhia  e  de  suas 
controladas 
(5)(7)
 
 
(...) 
 
• Planejamos  e  executamos  a  auditoria  do  grupo  para  obter Obtemos evidência  de  auditoria 
apropriada  e  suficiente  referente  às  informações  financeiras  das  entidades  ou atividades 
unidades de negócio do grupo como base para formar uma para expressar uma opinião sobre 
as   demonstrações   contábeis consolidadas do   grupo.   Somos   responsáveis   pela   direção, 
supervisão e revisão do trabalho de auditoria executado para os propósitos da de desempenho 
da auditoria do grupo e, consequentemente, pela opinião de auditoria.  
 
(...) 
 
Fornecemos  também  aos  responsáveis  pela  governança  declaração  de  que  cumprimos  com as 
exigências éticas relevantes os requisitos éticos pertinentes, incluindo os requisitos aplicáveis de 
independência,  e  comunicamos  todos  os  eventuais  relacionamentos  ou  assuntos  que  poderiam 
afetar, consideravelmente, nossa independência, incluindo, quando aplicável, as respectivas ações 
tomadas para eliminar as ameaças ou as salvaguardas aplicadas.
(8)
  
 
(1) No Brasil, este exemplo é aplicável para entidades listadas e entidades classificadas como entidades de interesse 
público exceto pelo item referenciado em 
(8)
. 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
11 
 
(1)(2) No  caso  de  o  relatório  cobrir  outros  aspectos  legais  e  regulatórios,  é  necessário  incluir  um  subtítulo  para 
especificar a primeira parte do relatório, “Relatório do auditor sobre as demonstrações contábeis” e, no final do 
relatório, outro subtítulo para a segunda parte, “Relatório sobre outros requisitos legais e regulatórios.” 
(3) Para entidades que não são de interesse público, e o relatório do auditor independente seja sobre demonstrações 
contábeis elaboradas de acordo com a estrutura de apresentação adequada, o texto desta seção pode ser adaptado 
para o seguinte formato: 
“Nossa  auditoria  foi  conduzida  de  acordo  com  as  normas  brasileiras  e  internacionais  de  auditoria.  Nossas 
responsabilidades, em conformidade com tais normas, estão descritas na seção a seguir, intitulada “Responsabilidades 
do auditor pela auditoria das demonstrações contábeis”. Somos independentes em relação à Companhia de acordo 
com os princípios éticos relevantes previstos no Código de Ética Profissional do Contador e nas normas profissionais 
emitidas  pelo  Conselho  Federal  de  Contabilidade,  aplicáveis  a  auditorias  de  demonstrações  contábeis  no  Brasil,  e 
cumprimos  com  as  demais  responsabilidades  éticas  de  acordo  com  essas  normas.  Acreditamos  que  a  evidência  de 
auditoria obtida é suficiente e apropriada para fundamentar a nossa opinião.” 
(2)(4) Em todos esses exemplos de relatório do auditor, os termos “administração” e “responsáveis pela governança” 
podem precisar ser substituídos por outros termos mais apropriados no contexto da estrutura legal de determinada 
jurisdição. 
(3)(5) Quando a responsabilidade da administração é elaborar as demonstrações contábeis que apresentem uma visão 
verdadeira e justa, esta sentença pode ser lida: “A administração é responsável pela elaboração de demonstrações 
contábeis  que  apresentem  uma  visão verdadeira  e  justa  de  acordo  com  as práticas  contábeis  adotadas no  Brasil  e, 
para isso ,...” 
(4)(6) O  item  41  (b)  desta  norma  explica  que  a  descrição  das  responsabilidades  do  auditor  independente  pode  ser 
localizada no apêndice do relatório do auditor. O item 41 (c) explica que, quando expressamente permitida por lei, 
regulamento ou normas de auditoria nacionais, pode ser feita uma referência ao sítio da autoridade competente que 
contém a descrição das responsabilidades do auditor em vez de incluir esse material no relatório do auditor, desde 
que o sítio se trate da descrição das responsabilidades do auditor acima e não seja inconsistente com ela. Essa opção 
não é permitida no Brasil.  
(5)(7) Essa sentença deve ser modificada, conforme adequado, nas circunstâncias em que o auditor também tem a 
responsabilidade de expressar uma opinião sobre a eficácia dos controles internos com a auditoria das demonstrações 
contábeis.  
       
Exemplo 3: Relatório do auditor sobre demonstrações contábeis consolidadas de entidade não 
listada, elaboradas de acordo com a estrutura de apresentação adequada. (modelo não aplicável 
no Brasil) 
 
(...) 
 
Para fins deste exemplo, são consideradas as seguintes circunstâncias: 
 
(...) 
 
• As  exigências  éticas  relevantes Os  requisitos  éticos  pertinentes que  se  aplicam  à  auditoria 
compõem o Código de Ética Profissional do Contador e as normas profissionais emitidas pelo 
Conselho Federal de Contabilidade.  
 
(...) 
 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
12 
 
RELATÓRIO DO AUDITOR INDEPENDENTE SOBRE AS DEMONSTRAÇÕES CONTÁBEIS 
 
Aos acionistas da Companhia ABC [ou outro destinatário apropriado] 
 
Opinião 
Examinamos as demonstrações contábeis da Companhia ABC (Companhia), que compreendem o 
balanço patrimonial em 31 de dezembro de 20X1 e as respectivas demonstrações do resultado, do 
resultado abrangente, das mutações do patrimônio líquido e dos fluxos de caixa para o exercício 
findo  nessa  data,  bem  como  as  correspondentes  notas  explicativas, incluindo o  resumo  das 
principais as políticas contábeis materiais e outras informações elucidativas. 
 
(...) 
 
Base para opinião  
 
Nossa auditoria foi conduzida de acordo com as normas brasileiras e internacionais de auditoria. 
Nossas responsabilidades, em conformidade com tais normas, estão descritas na seção a seguir, 
intitulada “Responsabilidades do auditor pela auditoria das demonstrações contábeis”. Somos 
independentes em relação à Companhia, de acordo com os princípios éticos relevantes previstos 
no  Código  de  Ética  Profissional  do  Contador  e  nas  normas  profissionais  emitidas  pelo  Conselho 
Federal  de  Contabilidade, aplicáveis  a  auditorias  de  demonstrações  contábeis  no  Brasil,  e 
cumprimos com  as  demais  responsabilidades  éticas  de  acordo  com  essas  normas.  Acreditamos 
que a evidência de auditoria obtida é suficiente e apropriada para fundamentar nossa opinião.   
 
Exemplo  4:  Relatório  do  auditor  sobre  demonstrações  contábeis  de  entidade  não  listada, 
elaboradas de acordo com a estrutura de conformidade para fins gerais 
(...) 
 
Para fins deste exemplo, são consideradas as seguintes circunstâncias: 
 
(...) 
 
• As  exigências  éticas  relevantes Os requisitos  éticos  pertinentes  que  se  aplicam  à  auditoria 
compõem o Código de Ética Profissional do Contador e as normas profissionais emitidas pelo 
Conselho Federal de Contabilidade.  
 
RELATÓRIO DO AUDITOR INDEPENDENTE SOBRE AS DEMONSTRAÇÕES CONTÁBEIS 
 
Aos acionistas da Companhia ABC [ou outro destinatário apropriado] 
 
Opinião 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
13 
 
 
Examinamos as demonstrações contábeis da Companhia ABC (Companhia), que compreendem o 
balanço patrimonial em 31 de dezembro de 20X1 e as respectivas demonstrações do resultado, do 
resultado abrangente, das mutações do patrimônio líquido e dos fluxos de caixa para o exercício 
findo  nessa  data,  bem  como  as  correspondentes  notas  explicativas,  incluindo o  resumo  das 
principais as políticas contábeis materiais e outras informações elucidativas.  
 
(...) 
 
Base para opinião  
 
Nossa auditoria foi conduzida de acordo com as normas brasileiras e internacionais de auditoria. 
Nossas responsabilidades, em conformidade com tais normas, estão descritas na seção a seguir, 
intitulada “Responsabilidades do auditor pela auditoria das demonstrações contábeis”. Somos 
independentes em relação à Companhia, de acordo com os princípios éticos relevantes previstos 
no  Código  de  Ética  Profissional  do  Contador  e  nas  normas  profissionais  emitidas  pelo  Conselho 
Federal  de  Contabilidade, aplicáveis  a  auditorias  de  demonstrações  contábeis  no  Brasil,  e 
cumprimos com  as  demais responsabilidades éticas  de  acordo  com  essas  normas.  Acreditamos 
que a evidência de auditoria obtida é suficiente e apropriada para fundamentar nossa opinião.   
 
3. Altera  os  Apêndices  1  (ver  os  itens  4  e  A4)  e  Apêndice  2  (ver  o  item  4)  da  NBC  TA  706 – que 
dispõe  sobre  Parágrafos  de  Ênfase  e  Parágrafos  de  outros  assuntos  no  Relatório  do  Auditor 
Independente, passando a vigorar com a seguinte redação: 
       
Apêndice 1 (ver os itens 4 e A4) 
 
Lista de normas de auditoria que contêm exigências para parágrafos de ênfase 
                
Este apêndice identifica itens em outras normas de auditoria que requerem do auditor a inclusão 
de parágrafo de ênfase no seu relatório em certas circunstâncias. A lista a seguir não substitui a 
consideração das exigências, aplicação relacionada e outros materiais explicativos nas normas de 
auditoria.  
 
(...) 
 
• NBC TA 560 – Eventos Subsequentes, itens 12(b) e item 16;  
 
(...) 
 
Apêndice 2 (ver item 4) 
 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
14 
 
Lista de normas de auditoria que contêm exigências para parágrafos de outros assuntos 
                  
Este apêndice identifica itens em outras normas de auditoria que requerem do auditor a inclusão 
de  parágrafo  de outros  assuntos no  seu  relatório  em  certas  circunstâncias.  A  lista  a  seguir  não 
substitui a consideração das exigências, aplicação relacionada e outros materiais explicativos nas 
normas de auditoria.  
 
(...) 
 
• NBC TA 560 – Eventos Subsequentes, itens 12(b) item 16;  
• NBC  TA  710 – Informações  Comparativas – Valores  Correspondentes  e  Demonstrações 
Contábeis Comparativas, itens 13, 14, 16, 17 e 19; 
• NBC TA 720 – Responsabilidades do Auditor em Relação a Outras Informações item 10 (a)  
 
Essas alterações serão incorporadas em suas respectivas normas e entrarão em vigor na data de 
sua  publicação,  devendo  ser  aplicada  aos  relatórios  de  auditoria  referentes  aos  exercícios  ou 
períodos que se iniciarem em, ou após, 15 de dezembro de 2024.  
 
          Brasília, 9 de abril de 2026. 
 
 
CONTADOR JOAQUIM DE ALENCAR BEZERRA FILHO 
Presidente 
 
Ata CFC nº 1.131/2026
