# Altera a NBCPG12 (R3) Educação Prof. Continuada.

- Código externo: 2018/revisaonbc02
- Fonte: CFC 2018/REVISAONBC02 — DOU 12/12/2018 (REVOGADA)
- URL fonte: https://www2.cfc.org.br/sisweb/sre/detalhes_sre.aspx?Codigo=2018/REVISAONBC02&arquivo=REVISAONBC02%20.doc
- Arquivo original: https://www1.cfc.org.br/sisweb/SRE/docs/REVISAONBC02%20.pdf
- Nome do arquivo: REVISAONBC02 .pdf
- Tags: Contábil, NBC, Revogada
- Atualizado em: 2026-10-10 14:27:53.79805+00

## Resumo

Altera a NBCPG12 (R3) Educação Prof. Continuada.

## Texto integral extraído

NBC PG 12 (R3) – EDUCAÇÃO PROFISSIONAL CONTINUADA 
 
 
A  letra  R  mais  o  número  que  identifica  sua  alteração  (R1,  R2,  R3,  ...)  foram  adicionados  à  sigla  da  norma  para 
identificarem  o  número  da  consolidação  e  facilitarem  a  pesquisa  no  site  do  CFC.  A  citação  desta  norma  em  outras 
normas  é  identificada  pela  sua  sigla  sem  referência  a  R1,  R2,  R3,  pois  essas  referências  são  sempre  da  norma  em 
vigor, para que, em cada alteração da norma, não haja necessidade de se ajustarem as citações em outras normas. 
 
Sumário Item 
CONCEITOS E OBJETIVOS 1 – 3 
CAMPO DE APLICAÇÃO E OBRIGAÇÕES DOS PROFISSIONAIS 4 – 21  
COMISSÃO DE EDUCAÇÃO PROFISSIONAL CONTINUADA (CEPC/CFC) 22 – 26  
CONSELHOS REGIONAIS DE CONTABILIDADE  27 – 32  
CAPACITADORAS   33 – 35  
EVENTOS DE EDUCAÇÃO PROFISSIONAL CONTINUADA  36 – 41  
DISPOSIÇÕES GERAIS 42 – 44B 
VIGÊNCIA 45 
ANEXO I – DIRETRIZES  PARA  CREDENCIAMENTO  DE  CAPACITADORAS  E 
DE     CURSOS/EVENTOS E     DOCUMENTAÇÃO     PARA     CONTROLE     E 
FISCALIZAÇÃO 
 
ANEXO II – TABELAS DE PONTUAÇÃO  
ANEXO III – RELATÓRIO DE ATIVIDADES  
 
 
 
Conceitos e objetivos 
 
1. A  presente  Norma  tem  por  objetivo  regulamentar  o  Programa  de  Educação  Profissional 
Continuada  (PEPC)  para  os  profissionais  da  contabilidade;  visa  também  definir  as  ações 
que o Conselho Federal de Contabilidade (CFC) e os Conselhos Regionais de Contabilidade 
(CRCs)  devem  desenvolver  para  viabilizar,  controlar  e  fiscalizar  o  seu  cumprimento. 
(Renumerado de 2 para 1 pela NBC PG 12 (R2))  
 
1. A  presente  norma  tem  por  objetivo  regulamentar  o  Programa  de  Educação  Profissional 
Continuada  (PEPC),  instituído  pela  Lei  n.°  12.249/2010,  que  alterou  o  Decreto-Lei  n.° 
9.295/1946  para  os  profissionais  da  contabilidade;  visa  também  definir  as  ações  que  o 
Conselho  Federal  de  Contabilidade  (CFC)  e  os  Conselhos  Regionais  de  Contabilidade 
(CRCs) devem desenvolver para viabilizar, controlar e fiscalizar o seu cumprimento. (Alterado 
pela Revisão NBC 02) 
 
2. Educação Profissional Continuada (EPC) é a atividade formal e reconhecida pelo Conselho 
Federal de Contabilidade (CFC), que visa manter, atualizar e expandir os conhecimentos e 
competências  técnicas  e  profissionais,  as  habilidades  multidisciplinares  e  a  elevação  do 
comportamento social, moral e ético dos profissionais da contabilidade como características 
indispensáveis à qualidade dos serviços prestados e ao pleno atendimento das normas que 
regem o exercício da profissão contábil. 
 
2.   Educação Profissional Continuada (EPC) é a atividade que visa manter, atualizar e expandir 
os conhecimentos e competências técnicas e profissionais, as habilidades multidisciplinares 
e  a  elevação  do  comportamento  social,  moral  e  ético  dos  profissionais  da  contabilidade, 
como   características   indispensáveis   à   qualidade   dos   serviços   prestados   e   ao   pleno 

atendimento das normas que regem o exercício da profissão contábil. (Alterado e renumerado de 
1 para 2 pela NBC PG 12 (R2)) 
 
3. O Programa de Educação Profissional Continuada tem como diretrizes básicas: 
(a) fomentar a EPC dos profissionais da contabilidade; 
(b)  criar   cadastros   de   qualificação   técnica   como   forma   de   incentivar   a Educação 
Profissional Continuada; (Eliminada pela NBC PG 12 (R1)) 
(c)  ampliar  parcerias  com  entidades  regulatórias  e  fiscalizatórias  com  o  objetivo  de  apoio 
ao PEPC; 
(c) ampliar parcerias com entidades de classe, regulatórias e fiscalizatórias com o objetivo 
de apoio ao PEPC; (Alterada pela NBC PG 12 (R2)) 
(d)  estabelecer  uniformidade  de  critérios  para  a  estrutura  das  atividades  de  qualificação 
profissional no âmbito do Sistema CFC/CRCs; 
(e)  estabelecer  que  a  capacitação  pode  ser  executada  pelo  próprio  Sistema  CFC/CRCs, 
por  entidades  capacitadoras  reconhecidas  ou  pelo  próprio  profissional  em  atividades 
previstas nesta norma; 
(e)  estabelecer  que  a  capacitação  possa  ser  executada  pelo  próprio  Sistema  CFC/CRCs, 
por  entidades  capacitadoras  reconhecidas  ou  pelo  próprio  profissional  em  atividades 
previstas nesta norma; (Alterada pela NBC PG 12 (R2)) 
(f)  fomentar  a  ampliação  do  universo  de  capacitadoras  credenciadas  para  possibilitar  o 
atendimento das necessidades de eventos de educação continuada. 
 
Campo de aplicação e obrigações dos profissionais 
 
4. A EPC é obrigatória para todos os profissionais da contabilidade que: 
(a) estejam inscritos no Cadastro Nacional de Auditores Independentes (CNAI), exercendo, 
ou não, a atividade de auditoria independente; 
(a)  estejam  inscritos  no  Cadastro  Nacional  de  Auditores  Independentes  (CNAI)  do  CFC, 
exercendo, ou não, a atividade de auditoria independente; (Alterada pela NBC PG 12 (R2)) 
(b)  estejam  registrados  na  Comissão  de  Valores  Mobiliários  (CVM),  inclusive  sócios, 
exercendo, ou  não,  atividade  de  auditoria  independente,  responsáveis  técnicos  e 
demais profissionais que exerçam cargos de direção ou gerência técnica, nas firmas de 
auditoria registradas na CVM;  
(c)  exercem atividades de auditoria independente nas instituições financeiras e nas demais 
entidades autorizadas a funcionar pelo Banco Central do Brasil (BCB); 
(c)  exercem atividades de auditoria independente nas instituições financeiras e nas demais 
entidades  autorizadas  a  funcionar  pelo  Banco  Central  do  Brasil  (BCB),  na  função  de 
responsável  técnico,  diretor,  gerente,  supervisor  e  qualquer  outro  integrante,  com 
função de gerência, da equipe envolvida nos trabalhos de auditoria; (Alterada pela NBC PG 
12 (R1)) 
(d)  exercem    atividades    de    auditoria    independente    nas    sociedades    seguradoras, 
resseguradoras, de capitalização e nas entidades abertas de previdência complementar 
reguladas pela Superintendência de Seguros Privados (Susep); 
(d)  exercem    atividades    de    auditoria    independente    nas    sociedades    seguradoras, 
resseguradoras, de capitalização e nas entidades abertas de previdência complementar 
reguladas   pela   Superintendência   de   Seguros   Privados   (Susep),   na   função   de 
responsável  técnico,  diretor,  gerente,  supervisor  e  qualquer  outro  integrante,  com 
função de gerência, da equipe envolvida nos trabalhos de auditoria; (Alterada pela NBC PG 
12 (R1)) 
(d)  exercem    atividades    de    auditoria    independente    nas    sociedades    seguradoras, 
resseguradoras,  de  capitalização, nas  entidades  abertas  de  previdência  complementar 
reguladas  pela Superintendência  de  Seguros  Privados  (Susep)  e  nas  entidades  de 
previdência  complementar  reguladas  pela  Superintendência  Nacional  de  Previdência 
Complementar (Previc) na função de responsável técnico, diretor, gerente, supervisor e 
qualquer  outro  integrante,  com  função  de  gerência,  da  equipe  envolvida  nos  trabalhos 
de auditoria; (Alterada pela NBC PG 12 (R2)) 

(d)  exercem    atividades    de    auditoria    independente    nas    sociedades    seguradoras, 
resseguradoras,  de  capitalização,  nas  entidades  abertas  de  previdência complementar 
reguladas   pela   Superintendência   de   Seguros   Privados   (Susep)   na   função   de 
responsável  técnico,  diretor,  gerente,  supervisor  e  qualquer  outro  integrante,  com 
função de gerência, da equipe envolvida nos trabalhos de auditoria; (Alterada pela Revisão 
NBC 02) 
 
(d1) exercem atividades de auditoria independente nas Entidades Fechadas de Previdência 
Complementar   (EFPC)   reguladas   pela   Superintendência   Nacional   de   Previdência 
Complementar  (Previc),  na  função  de  responsável  técnico  pela  auditoria  independente 
ou   exercendo   as   funções   de   gerência/chefia   no   processo   de   elaboração   das 
demonstrações contábeis; (Incluído pela Revisão NBC 08) 
 
(e)  exercem  atividades  de  auditoria  independente  de entidades não  mencionadas  nas 
alíneas  (b),  (c)  e  (d)  como  sócios,  responsáveis  técnicos  ou  em  cargo de  direção  ou 
gerência técnica de firmas de auditoria;  
(e)  exercem  atividades  de  auditoria  independente  de  entidades  não  mencionadas  nas 
alíneas  (b),  (c)  e  (d),  como  sócio,  responsável  técnico  ou  em  cargo  de  direção  ou 
gerência técnica de firmas de auditoria e de demais organizações contábeis que tenham 
em seu objeto social a atividade de auditoria independente; (Alterada pela NBC PG 12 (R1)) 
(e)  exercem  atividades  de  auditoria  independente  de  entidades  não  mencionadas  nas 
alíneas  (b),  (c)  e  (d),  como  sócio,  responsável  técnico  ou  em  cargo  de  direção  ou 
gerência  técnica  de  firmas  de  auditoria  e  de  organizações  contábeis.  Estão  incluídas 
nessa  obrigação  as  organizações  contábeis  que  tenham  explicitamente  em  seu  objeto 
social a previsão de atividade de auditoria independente; (Alterada pela Revisão NBC 02) 
 
(e)  exercem  atividades  de  auditoria  independente  de  entidades  não  mencionadas  nas 
alíneas (b), (c), (d) e (d1), como sócio, responsável técnico ou em cargo de direção ou 
gerência  técnica  de  firmas  de  auditoria  e  de  organizações  contábeis.  Estão  incluídas 
nessa  obrigação  as  organizações  contábeis  que  tenham  explicitamente  em  seu  objeto 
social a previsão de atividade de auditoria independente. (Alterada pela Revisão NBC 08) 
 
(f)  que  sejam  responsáveis  técnicos  pelas  demonstrações  contábeis,  ou  que  exerçam 
funções  de  gerência/chefia  na  área  contábil  das  empresas  sujeitas  à  contratação  de 
auditoria  independente  pela  (CVM),  pelo  (BCB),  pela  (SUSEP)  ou  consideradas  de 
grande porte nos termos da Lei n.º 11.638/07 (sociedades de grande porte). 
(f)  sejam responsáveis técnicos pelas demonstrações contábeis, ou que exerçam funções 
de  gerência/chefia  no  processo  de  elaboração  das  demonstrações  contábeis  das 
empresas  sujeitas  à  contratação  de  auditoria  independente  pela  CVM,  pelo  BCB,  pela 
Susep ou consideradas de grande porte nos termos da Lei n.º 11.638/2007 (Sociedades 
de Grande Porte). (Alterada pela NBC PG 12 (R1)) 
(f)  sejam responsáveis técnicos pelas demonstrações contábeis, ou que exerçam funções 
de  gerência/chefia  no  processo  de  elaboração  das  demonstrações  contábeis  das 
empresas,  reguladas  e/ou  supervisionadas  pela  CVM,  pelo  BCB,  pela  Susep,  pela 
Previc,  e,  ainda,  das  sociedades  consideradas  de  grande  porte  nos  termos  da  Lei  n.º 
11.638/2007; (Alterada pela NBC PG 12 (R2)) 
(f)  sejam responsáveis técnicos pelas demonstrações contábeis, ou que exerçam funções 
de  gerência/chefia  no  processo  de  elaboração  das  demonstrações  contábeis  das 
empresas,  reguladas  e/ou  supervisionadas  pela  CVM,  pelo  BCB,  pela  Susep,  pela 
Previc,  e,  ainda,  das  sociedades  consideradas  de  grande  porte  nos  termos  da  Lei  n.º 
11.638/2007,  e  também  as  entidades  sem  finalidade  de  lucros  que  se  enquadrem  nos 
limites monetários da citada lei; (Alterada pela NBC PG 12 (R3)) 
Responsáveis técnicos 
(f)  sejam responsáveis técnicos pelas demonstrações contábeis, ou que exerçam funções 
de  gerência/chefia  no  processo  de  elaboração  das  demonstrações  contábeis  das 
empresas,  reguladas  e/ou  supervisionadas  pela  CVM,  pelo  BCB,  pela Susep  e,  ainda, 
das  sociedades  consideradas  de  grande  porte  nos  termos  da  Lei  n.º  11.638/2007,  e 

também   as   entidades   sem   finalidade   de   lucros   que   se   enquadrem   nos   limites 
monetários da citada lei; (Alterada pela Revisão NBC 02) 
(g)  estejam  inscritos  no  Cadastro  Nacional  de  Peritos  Contábeis  (CNPC). (Incluída  pela  NBC 
PG 12 (R2)) (Eliminada pela Revisão NBC 02) 
(h)  sejam  responsáveis  técnicos  pelas  demonstrações  contábeis  das  sociedades  e  das 
entidades de direito privado com ou sem finalidade de lucros que tiverem, no exercício 
social anterior, receita total, igual ou superior a R$ 78 milhões e que não se enquadram 
na alínea (f). (Incluída pela Revisão NBC 02) 
(i)  sejam responsáveis técnicos pelas demonstrações contábeis, ou que exerçam funções 
de  gerência/chefia  no  processo  de  elaboração  das  demonstrações  contábeis  das 
empresas   reguladas   e/ou   supervisionadas   pela   Superintendência   Nacional   de 
Previdência Complementar (Previc). (Incluída pela Revisão NBC 02) 
Peritos contábeis 
(j)  estejam  inscritos  no  Cadastro  Nacional  de  Peritos  Contábeis  (CNPC)  do  CFC. (Incluída 
pela Revisão NBC 02) 
 
5.  As  disposições  desta Norma não  se  aplicam  aos  profissionais  que  compõem  o  quadro 
técnico  da  firma  de  auditoria  que  exercem  função  de  especialista.  Para  fins  desta Norma, 
entende-se   como   especialista   o   indivíduo   ou   empresa   que   detenha   habilidades, 
conhecimento  e  experiência  em  áreas  específicas  não  relacionadas  à  contabilidade  ou  à 
auditoria das demonstrações contábeis, exceto os sócios da firma de auditoria.  
 
6.  O  auditor independente  pessoa  física  e  os  sócios  que  representam  as  firmas de  auditoria 
independente  na  CVM,  nos  termos  do  inciso  IX  do art.  6º  da  Instrução  CVM  n.º  308/99, 
podem responder, solidariamente   pelo   não   cumprimento   da   presente Norma,   pelos 
contadores referidos na alínea (b) do item 4 desta Norma. (Eliminado pela NBC PG 12 (R1)) 
 
7.  Os profissionais referidos  no  item 4 devem  cumprir,  no  mínimo, 40 (quarenta) pontos  de 
Educação  Profissional  Continuada  por  ano-calendário,  conforme  Tabelas  de  Pontuação 
constantes no Anexo II desta Norma. 
 
7.   Os  profissionais  referidos  no  item  4  devem  cumprir,  no  mínimo,  40  (quarenta)  pontos  de 
Educação Profissional Continuada por ano-calendário. (Alterado pela NBC PG 12 (R2)) 
 
7.   Os  profissionais  referidos  no  item  4  devem cumprir, no  mínimo,  40  (quarenta) pontos  de 
Educação Profissional Continuada por ano-calendário. Dessa pontuação anual no mínimo 8 
(oito)   pontos   devem   ser   cumpridos   com   atividades   de   aquisição   de   conhecimento, 
constantes da Tabela I, do Anexo II. (Alterado pela Revisão NBC 02) 
 
7A.  Os  profissionais  obrigados  ao  cumprimento  da  educação  continuada  que  se  enquadrarem 
em  mais  de  uma  das  alíneas  do  item  4  devem  cumprir  a  pontuação  exigida  para  cada 
categoria/habilitação. (Incluído pela Revisão NBC 02) 
 
7B.  Por deliberação da Câmara de Desenvolvimento Profissional A pontuação exigida no item 7 
poderá sofrer alterações em caso de força maior, cabendo ao Plenário do Conselho Federal 
de  Contabilidade  homologar  sobre  a  nova  pontuação  a  ser  exigida. (Incluído  pela  Revisão  NBC 
08) 
 
8. No  cumprimento  da  pontuação  da  Educação  Profissional  Continuada,  o profissional deve 
observar  a  diversificação  e  a  adequação  das  atividades  ao  seu  nível  de  experiência  e 
atuação profissional. 
 
9.  Da pontuação anual exigida no item 7, no mínimo 20% (vinte por cento) deve ser cumprida 
com atividades de aquisição de conhecimento, constantes da Tabela I, do Anexo II. 
 
9.  Da pontuação anual exigida no item 7, no mínimo 8 (oito) pontos devem ser cumpridos com 
atividades de aquisição de conhecimento, constantes da Tabela I, do Anexo II. (Alterado pela 
NBC PG 12 (R1)) (Eliminado pela Revisão NBC 02) 

 
10. Os  contadores  referidos  no  item  4, alíneas  (a), (b), (c) e (d),  aprovados  em  Exame  de 
Qualificação Técnica específico, devem cumprir, dentro do total de pontos anuais, o mínimo 
exigido pelo órgão regulador respectivo. 
 
10. Somente os contadores referidos no item 4, alíneas (a), (b), (c) e (d), aprovados em Exame 
de  Qualificação  Técnica  específico,  devem  cumprir,  dentro  do  total  de  pontos  anuais, o 
mínimo exigido pelo órgão regulador respectivo. (Alterado pela Revisão NBC 02) 
 
10.  Somente  os  contadores  referidos  no  item  4,  alíneas  (a),  (b),  (c),  (d)  e  (d1),  aprovados  em 
Exame de Qualificação Técnica específico, devem cumprir, dentro do total de pontos anuais, 
o mínimo exigido pelo respectivo órgão regulador. (Alterada pela Revisão NBC 08) 
 
 
11. Os  contadores  referidos  no  item  4, alíneas (a), (b), (c), (d) e (e), devem  cumprir  o  exigido 
nesta Norma a partir do ano subsequente ao de início das suas atividades de auditoria ou da 
obtenção do seu registro no CNAI. 
 
11.    Os  profissionais  referidos  no  item  4  que,  no  decorrer  do  exercício,  se  enquadrarem  nas 
exigências  desta  norma  devem  cumprir  a  EPC  a  partir  do  ano  subsequente  ao  de  seu 
enquadramento. (Alterado pela NBC PG 12 (R2)) 
 
12. Os profissionais referidos no item 4, alínea (f), devem cumprir o exigido nesta Norma a partir 
do ano subsequente ao da investidura na função de gerência/chefia ou do ano subsequente 
ao que assumiram a responsabilidade técnica pelas demonstrações contábeis. (Eliminado pela 
NBC PG 12 (R2)) 
 
13. Os profissionais sujeitos ao cumprimento desta Norma que, por motivos comprovadamente 
justificados, estejam impedidos de exercer a profissão por período superior a 60 (sessenta) 
dias,  devem cumprir a EPC  proporcionalmente  aos  meses  trabalhados  no  ano.  São 
consideradas justificativas válidas para este fim:  
(a)  licença-maternidade;  
(b)  enfermidades;  
(c)  acidente de trabalho;  
(d)  outras situações a   critério   da Comissão   de   Educação   Profissional   Continuada 
(CEPC/CFC).  
(d) outras   situações,   julgadas   pertinentes,   a   critério   da   Comissão   de   Educação 
Profissional Continuada (CEPC/CFC). (Alterada pela Revisão NBC 08) 
 
         
13A.  No  caso  de  enfermidades  impeditivas  do  exercício  profissional, por  período  superior  a  3 
(três)  anos  consecutivos,  e  não  tendo  cumprido  a  pontuação  exigida  nesta  norma,  a 
CEPC/CFC pode determinar a baixa do CNAI. (Incluído pela NBC PG 12 (R1)) 
 
13A.  No  caso  de  enfermidades  impeditivas  do  exercício  profissional,  por  período  superior  a  3 
(três)  anos  consecutivos,  e  não  tendo  cumprido  a  pontuação  exigida  nesta  norma,  a 
CEPC/CFC pode determinar a baixa do CNAI e do CNPC. (Alterado pela NBC PG 12 (R3)) 
 
14.  Para os devidos fins e comprovação das situações relacionadas nas alíneas (a), (b), (c) e (d) 
do  item  13,  os  profissionais  interessados  devem apresentar  ao  CRC  de  sua  jurisdição,  até 
31  de  janeiro  do  exercício  subsequente, todos  os  documentos de  comprovação  quanto  ao 
eventual  não  cumprimento  do  programa  de  EPC,  visando  sua  análise pela CEPC,  para  o 
acolhimento  ou  não  das  justificativas.  Devem  ainda atender  eventual  solicitação  de  outros 
documentos e/ou esclarecimentos adicionais considerados necessários à comprovação dos 
fatos. 
 

14.  Para os devidos fins e comprovação das situações relacionadas nas alíneas (a), (b), (c) e (d) 
do  item  13,  os  profissionais  interessados  devem  apresentar  ao  CRC  de  sua  jurisdição,  até 
31 de janeiro do exercício subsequente, juntamente com o relatório de atividades referido no 
item  17,  todos  os  documentos  de  comprovação  quanto  ao  eventual  não  cumprimento  do 
programa  de  EPC,  visando  a  sua  análise  pela  CEPC,  para  o  acolhimento,  ou  não,  das 
justificativas.  Devem  ainda  atender  a  eventual  solicitação  de  outros  documentos  e/ou 
esclarecimentos adicionais considerados necessários à comprovação dos fatos. (Alterado pela 
NBC PG 12 (R1)) 
 
14. Para os devidos fins e comprovação das situações relacionadas nas alíneas (a), (b), (c) e (d) 
do  item  13,  os  profissionais  interessados  devem  apresentar  ao  CRC  de  sua  jurisdição,  até 
31 de janeiro do exercício subsequente, juntamente com o relatório de atividades referido no 
item  17,  todos  os  documentos  de  comprovação  quanto  ao  eventual  não  cumprimento  do 
programa  de  EPC,  visando  a  sua  análise  pela  CEPC  ou  Câmara  de  Desenvolvimento 
Profissional do CRC, para o acolhimento, ou não, das justificativas. Devem ainda atender a 
eventual  solicitação  de outros  documentos  e/ou  a  esclarecimentos  adicionais  considerados 
necessários à comprovação dos fatos. (Alterado pela Revisão NBC 02) 
 
14. Para os devidos fins e para a comprovação das situações relacionadas nas alíneas (a), 
(b),  (c)  e  (d)  do  item  13,  os  profissionais  interessados  devem  apresentar  no  Sistema 
Web EPC do CFC/CRCs, até 31 de janeiro do exercício subsequente, juntamente com o 
relatório  de  atividades  referido  no  item  17,  todos  os  documentos  de  comprovação 
quanto ao eventual não cumprimento do programa de EPC, visando a sua análise pela 
CEPC  ou  pela  Câmara  de  Desenvolvimento  Profissional  do  CRC,  para  o  acolhimento, 
ou  não,  das  justificativas.  Devem  ainda  atender  à  eventual  solicitação  de  outros 
documentos    comprobatórios    e/ou    a    esclarecimentos    adicionais    considerados 
necessários à comprovação dos fatos. (Alterada pela Revisão NBC 08) 
 
 
15.   Cabe  ao  profissional  a  verificação prévia  do  devido  credenciamento no PEPC  da  atividade 
(cursos, eventos) que pretende realizar. 
 
15.   Cabe  ao  profissional  a  verificação  prévia  do  devido  credenciamento  no  PEPC  da  atividade 
(cursos,  eventos)  que  pretende  realizar,  bem  como  dos  pontos  que  serão  atribuídos.  Os 
cursos  de  pós-graduação  oferecidos  por  IES  registrada  no  MEC  estão  dispensados  de 
credenciamento. (Alterado pela NBC PG 12 (R1)) 
 
15.   Cabe  ao  profissional  a  verificação  prévia  do  devido  credenciamento  no  PEPC  da  atividade 
(cursos,  eventos)  que  pretende  realizar,  bem  como  dos  pontos  que  serão  atribuídos.  Os 
cursos  de  pós-graduação  oferecidos  por  IES  registrada  no  MEC  estão  dispensados  de 
credenciamento,  cabendo  ao  profissional  apresentar  declaração  da  IES  comprovando  a 
conclusão e aprovação nas disciplinas cursadas por ano. (Alterado pela Revisão NBC 02) 
 
 16.  Os  profissionais  referidos  no  item  4  são  responsáveis  pelo  lançamento,  preferencialmente 
no sistema web do CFC/CRCs, das informações relativas às atividades que necessitem de 
apreciação para atribuição de pontos.  
 
16.  Os profissionais referidos no item 4 são responsáveis pelo lançamento e acompanhamento, 
preferencialmente  no  sistema web do  CFC/CRCs,  das  informações  relativas  às  atividades 
que necessitem de apreciação para atribuição de pontos. (Alterado pela NBC PG 12 (R1)) 
 
16. Os profissionais referidos no item 4 são responsáveis pelo lançamento e acompanhamento, 
preferencialmente  no  sistema web do  CFC/CRCs,  das  informações  relativas  às  atividades 
que  necessitem  de  apreciação  para  atribuição  de  pontos,  bem  como  das  atividades 
realizadas e que sejam credenciadas por instituição capacitadora. (Alterado pela Revisão NBC 02) 
 
16. É   de   responsabilidade   dos   profissionais   referidos   no   item   4   o   lançamento   e   o  
acompanhamento, no sistema Web EPC do CFC/CRCs, das informações e das respectivas 

documentações  relativas  às  atividades  que  necessitem  de  apreciação  para  atribuição  de 
pontos,  bem  como  das  atividades  realizadas  e  que  sejam  credenciadas  por  instituição 
capacitadora. (Alterada pela Revisão NBC 08) 
 
 
17.  Encerra-se  o cumprimento  das  exigências  estabelecidas  nesta  Norma, pelos  profissionais 
referidos  no  item  4,  com  a  comprovação  da  entrega  do relatório  de  atividades  a  que  se 
refere o Anexo III, no CRC de jurisdição do registro principal do profissional, até o dia 31 de 
janeiro do ano subsequente ao ano-base, em arquivo digital ou impresso, acompanhado de 
cópia  da  documentação  comprobatória  das  atividades,  no  que  se  refere  ao  disposto  nas 
Tabelas II, III e IV do Anexo II desta Norma.  
  
17.  O cumprimento  da  pontuação  exigida  nesta  norma,  pelos  profissionais  referidos  no  item  4, 
deve ser comprovado mediante a entrega do relatório de atividades a que se refere o Anexo 
III, no CRC de jurisdição do registro principal do profissional, até o dia 31 de janeiro do ano 
subsequente  ao  ano-base,  por  meio  digital  ou  impresso,  acompanhado  de  cópia  da 
documentação comprobatória das atividades, no que se refere ao disposto nas Tabelas II, III 
e  IV  do  Anexo  II  desta  norma,  bem  como  das  disciplinas  cursadas  nos cursos  de  pós-
graduação oferecidos por IES registrada no MEC. (Alterado pela NBC PG 12 (R1)) 
 
17.  O  cumprimento  da  pontuação  exigida  nesta  norma,  pelos  profissionais  referidos  no  item  4, 
deve ser comprovado mediante a entrega do relatório de atividades a que se refere o Anexo 
III, no CRC de jurisdição do registro principal do profissional, até o dia 31 de janeiro do ano 
subsequente  ao  ano-base,  por  meio  digital  ou  impresso,  acompanhado  de  cópia  da 
documentação comprobatória das atividades, no que se refere ao disposto nas Tabelas I, II, 
III e IV do Anexo II desta norma, com exceção dos cursos e eventos credenciados. (Alterado 
pela NBC PG 12 (R3)) 
 
17. O  cumprimento  da  pontuação  exigida  nesta  norma,  pelos  profissionais  referidos  no  item  4, 
deve ser comprovado mediante a entrega do relatório de atividades a que se refere o Anexo 
III,  no  CRC  de  jurisdição  do  registro  principal  do  profissional,  por  meio  do  sistema web do 
CFC/CRCs.  Na  ausência  deste,  a  documentação  poderá  ser  protocolada  no  CRC  de 
jurisdição, até o dia 31 de janeiro do ano subsequente ao ano-base, acompanhado de cópia 
da documentação comprobatória das atividades, no que se refere ao disposto nas Tabelas I, 
II,  III  e  IV  do  Anexo  II  desta  norma,  com  exceção  dos  cursos  e  eventos  credenciados. 
(Alterado pela Revisão NBC 02) 
 
17.  O  cumprimento  da  pontuação  exigida  nesta  Norma,  pelos  profissionais referidos  no  item  4, 
deve  ser  comprovado  mediante  a  verificação  das  atividades  constantes  no  relatório  de 
prestação de contas, disponível na área do profissional, e envio mediante Sistema EPC do 
CFC/CRCs.  Nos  casos  em  que  houver  atividades  de  docência,  pós-graduação,  cursos 
realizados  no  exterior,  produção  intelectual,  participação  em  comissões,  orientação  de 
artigos científicos e trabalhos de conclusão de curso e participação em bancas acadêmicas, 
estas devem ser informadas pelo profissional, também via Sistema EPC. O prazo para envio 
do relatório de atividades é 31 de janeiro do ano subsequente ao ano-base. A comprovação 
das referidas atividades devem ser anexadas no sistema EPC, no item “Minhas Atividades”, 
com exceção dos cursos e eventos credenciados. (Alterado pela Revisão NBC 05) 
 
17. O  cumprimento  da  pontuação  exigida  nesta  Norma,  pelos  profissionais referidos  no  item  4, 
deve  ser  comprovado  mediante  a  verificação  das  atividades  constantes  no  relatório  de 
prestação de contas, disponível na área do profissional, e envio mediante Sistema Web EPC 
do  CFC/CRCs.  Nos  casos  em  que  houver  atividades  de  docência,  pós-graduação,  cursos 
realizados  no  exterior,  produção  intelectual,  participação  em  comissões,  orientação  de 
artigos científicos e trabalhos de conclusão de curso e participação em bancas acadêmicas, 
essas devem ser informadas pelo profissional, também via Sistema Web EPC. O prazo para 
o  envio  do  relatório  de  atividades  é  31  de  janeiro  do  ano  subsequente  ao  ano-base.  A 
comprovação das referidas atividades deve ser anexada ao sistema EPC, no item “Minhas 

Atividades”, com exceção dos cursos e dos eventos credenciados. (Alterada  pela  Revisão  NBC 
08) 
 
 
18. O  profissional  em  atividade  em  outro  país,  por  período  igual  ou  superior  a  um  ano  civil 
completo,   deve   comprovar,   a   cada   ano,   o   cumprimento   da   Educação   Profissional 
Continuada  mediante  a  apresentação  das  informações  comprobatórias  das  atividades 
realizadas no exterior, ao CRC de sua jurisdição, até 31 de janeiro do ano seguinte. 
 
18.  O  profissional  que  atua  no  exterior  também  deve  comprovar  o  cumprimento  da  Educação 
Profissional Continuada. (Alterado pela NBC PG 12 (R1)) 
 
19. As  atividades  de  Educação  Profissional  Continuada  realizadas  no  exterior  devem  ser 
comprovadas  no  CRC  de  jurisdição  do  registro  principal,  por  meio  de  declaração  ou 
certificado emitido pela entidade realizadora, traduzido para o idioma português, constando 
a  carga  horária,  o  período  de  realização  e  o  conteúdo  programático.    As  atividades  devem 
ser  inseridas  preferencialmente no sistema  web  do  CFC/CRCs,  tão  logo  tenham  sido 
realizadas,  ou  até  31  de  dezembro  do  ano  de sua realização,  mediante  o  envio  da 
documentação  comprobatória,  de  forma  física  ou  digital,  ao  CRC  da  jurisdição  do  registro 
principal,  observados  os  limites  estabelecidos  nas  tabelas  de  pontuação  constantes  do 
Anexo II. 
 
19.  As  atividades  de  Educação  Profissional  Continuada  realizadas  no  exterior  devem  ser 
comprovadas  no  CRC  de  jurisdição  do  registro  principal,  por  meio  de  declaração  ou 
certificado emitido pela entidade realizadora, traduzido para o idioma português, constando 
a  carga  horária,  o  período  de  realização  e  o  conteúdo  programático.    As  atividades  devem 
ser  inseridas,  preferencialmente,  no  sistema web do  CFC/CRCs,  tão  logo  tenham  sido 
realizadas, e, no máximo, até 31 de janeiro do ano seguinte ao ano-base, mediante o envio 
da documentação comprobatória, de forma física ou digital, ao CRC da jurisdição do registro 
principal, observados  os  limites  estabelecidos  nas  tabelas  de  pontuação  constantes  do 
Anexo II. (Alterado pela NBC PG 12 (R1)) 
 
19.  As  atividades  de  Educação  Profissional  Continuada  realizadas  no  exterior  devem  ser 
cadastradas e comprovadas no Sistema EPC, por meio de declaração ou certificado emitido 
pela  entidade  realizadora,  traduzido  para  o  idioma  português, constando  a  carga  horária,  o 
período de realização e o conteúdo programático.  As atividades devem ser informadas tão 
logo tenham sido realizadas e, no máximo, até 31 de janeiro do ano seguinte ao ano-base. 
(Alterado pela Revisão NBC 05) 
 
19. As  atividades  de  Educação  Profissional  Continuada  realizadas  no  exterior  devem  ser 
cadastradas  e  comprovadas  no  Sistema  Web  EPC,  por  meio  de  declaração  ou  certificado 
emitido  pela  entidade  realizadora,  traduzido  para  o  idioma  português,  constando  a  carga 
horária,  o  período  de  realização  e  o  conteúdo  programático.  As  atividades  devem  ser 
informadas tão logo tenham sido realizadas e, no máximo, até 31 de janeiro do ano seguinte 
ao ano-base. (Alterada pela Revisão NBC 08) 
 
20. No  caso  de  treinamentos  realizados  no  exterior,  que  atribuam  pontuação  válida  para  o 
Programa  de  Educação  Profissional  Continuada  no  país  onde  foram  realizados,  será 
reconhecida  a  mesma  quantidade  de  horas  constantes  do  certificado  respectivo,  não 
dispensadas as formalidades do item 19. 
 
21. Os  documentos  comprobatórios  das  atividades  de  EPC  realizadas  devem  ser  mantidos 
pelos profissionais referidos no item 4 desta Norma pelo período de 5 (cinco) anos, contados 
a  partir  do  primeiro  dia  do  ano  subsequente  à realização  das  atividades. (Eliminado  pela  NBC 
PG 12 (R1)) 
 
Comissão de Educação Profissional Continuada (CEPC/CFC) 
 

22. A Comissão de Educação Profissional Continuada (CEPC/CFC), constituída pelo CFC, tem 
as atribuições especificadas no item 26 desta norma. 
 
23.  Integram a CEPC/CFC o vice-presidente de Desenvolvimento Profissional e Institucional do 
CFC, o diretor Nacional de Desenvolvimento Profissional do IBRACON, os contadores, vice-
presidentes  de  Desenvolvimento  Profissional  dos  cinco  CRCs  que  reúnem  o maior  número 
de  profissionais  com  registro  ativo,  os  diretores  de  Desenvolvimento  Profissional  das  cinco 
Seções  Regionais  do  IBRACON  que  reúnem  o  maior  número  de  profissionais  associados 
ativos  e  4  (quatro)  membros  contadores  indicados  pelo  CFC,  aprovados  pelo  Plenário  do 
CFC, sob a coordenação do primeiro. 
 
23. Integram a CEPC/CFC o vice-presidente de Desenvolvimento Profissional do CFC, o diretor 
Nacional  de  Desenvolvimento  Profissional  do  Ibracon,  os  contadores,  vice-presidentes  de 
Desenvolvimento Profissional dos cinco CRCs que reúnem o maior número de profissionais 
com   registro   ativo,   os   diretores   de   Desenvolvimento   Profissional   das   cinco   Seções 
Regionais  do  Ibracon  que  reúnem  o  maior  número  de  profissionais  associados  ativos  e  4 
(quatro) membros  contadores  indicados  pelo  CFC,  aprovados  pelo  Plenário  do  CFC,  sob  a 
coordenação do primeiro. (Alterado pela Revisão NBC 02) 
 
24.  Em  caso  de  impedimento  do  vice-presidente  de  Desenvolvimento  Profissional de  CRC de 
participar  das  reuniões  da Comissão,  ele  deve  ser  representado  por contador,  membro  da 
CEPC/CRC  ou  conselheiro  integrante  da  Câmara  de  Desenvolvimento  Profissional  do 
Regional. No caso de impedimento do Diretor Regional de Desenvolvimento Profissional do 
IBRACON, ele deve ser representado por outro diretor que compõe a respectiva Diretoria da 
mesma Seção Regional. 
 
25. O mandato dos membros da CEPC/CFC é de dois anos, permitida a recondução. 
 
25A. Os representantes da CVM, BCB, Susep e Previc podem participar das reuniões da CEPC-
CFC  e  CEPC/CRCs,  na  condição  de  observadores,  com  direito  a voz  e sem  direito  a voto, 
desde   que   indiquem,   previamente,   a   cada   reunião,   os   nomes   dos   representantes 
designados. (Incluído pela Revisão NBC 05) 
 
25A. Os representantes dos CRCs, da CVM, do BCB, da Susep e da Previc podem participar das 
reuniões das CEPC-CFC e CEPC/CRCs, na condição de observadores, com direito à voz e 
sem  direito  a  voto,  desde  que  indiquem,  previamente,  a  cada  reunião,  os  nomes  dos 
representantes designados. (Alterado pela Revisão NBC 08) 
 
26. A CEPC/CFC tem as seguintes atribuições: 
(a) estabelecer  o  cronograma  de  reuniões  do  exercício,  o  qual  pode  ser  alterado  em 
decorrência de fatos supervenientes; 
(b) estudar,   de   forma   permanente,   novas   disposições   que   permitam   aprimorar   o 
cumprimento dos objetivos desta Norma, propondo-as à Presidência do CFC; 
(c) propor à Presidência do CFC a ampla e a imediata divulgação de qualquer modificação 
desta Norma; 
(d) estabelecer  e  divulgar  as  diretrizes  e  procedimentos  necessários  para  cumprimento  e 
implementação desta Norma pelos CRCs, pelos profissionais referidos no item 4 e pelas 
capacitadoras; 
(e)  prestar   esclarecimentos   quanto   à   aplicação   desta Norma e deliberar   sobre   o 
atendimento à pontuação anual nos casos omissos; 
(f) homologar ou indeferir, total ou parcialmente, os processos encaminhados pelos CRCs 
no prazo de até 60 (sessenta) dias contados da data do protocolo no CFC; 
(f) analisar  e  decidir  sobre  os  processos  encaminhados  pelos  CRCs,  no  prazo  de  até  60 
(sessenta) dias contados da data do protocolo no CFC; (Alterada pela NBC PG 12 (R1)) 
(f)  analisar  e  decidir  sobre  os  processos  encaminhados  pelos  CRCs,  no  prazo  de  até  60 
(sessenta)  dias  contados  da  data  de  entrada  do  pedido  no  sistema  Web  EPC; (Alterada 
pela Revisão NBC 08) 

 
(g) compilar,  anualmente,  as  informações  de  pontuação  de  cada  um  dos profissionais 
referidos no item 4, alíneas (a), (b), (c) e (d), recebidas dos CRCs, encaminhando-as à 
Presidência  do  CFC  para  comunicação  à  CVM,  ao  IBRACON,  ao  BCB e à  Susep, até 
30 de setembro de cada ano; 
(g) compilar,  anualmente,  as  informações  de  pontuação  de  cada  um  dos  profissionais 
referidos no item 4, alíneas (a), (b), (c) e (d), recebidas dos CRCs, encaminhando-as  à 
CVM, ao Ibracon, ao BCB e à Susep, até 30 de setembro de cada ano; (Alterada pela NBC 
PG 12 (R1)) 
(g)  compilar,  anualmente,  as  informações  de  pontuação  de  cada  um  dos  profissionais 
referidos no item 4, alíneas (a), (b), (c) e (d), recebidas dos CRCs, encaminhando-as à 
CVM até 30 de setembro de cada ano; (Alterada pela NBC PG 12 (R3)) 
(g)  compilar, anualmente, as informações sobre a pontuação de cada um dos profissionais 
referidos   no   item   4,   alíneas  (a),  (b),  (c),   (d),  (d1)   e  (e),   recebidas   dos   CRCs, 
encaminhando-as à CVM até 30 de setembro de cada ano; (Alterada pela Revisão NBC 08) 
(h) julgar  recursos  encaminhados  pelos  profissionais  ou  pelas  capacitadoras  relativos  ao 
PEPC, cientificando o interessado sobre a decisão; 
(h) julgar  recursos,  em  segunda  instância, encaminhados  pelos  profissionais  ou pelas 
capacitadoras  relativos  ao  PEPC,  cientificando  o  interessado  sobre  a  decisão; (Alterada 
pela Revisão NBC 02) 
(i) analisar e emitir opinião sobre os casos especiais ou omissos na presente norma; 
(i)  emitir esclarecimentos, por meio de ofício-circular, no âmbito desta norma; (Alterada pela 
Revisão NBC 02) 
(j)  encaminhar aos CRCs relação dos profissionais referidos no item 4 que não cumpriram 
a  pontuação  mínima  exigida  nos itens 7 e  9,  para  fins  de  abertura  de processo 
administrativo. 
(j)  encaminhar aos  CRCs  a  relação  dos  profissionais  referidos  no  item  4  que  não 
cumpriram  a  pontuação  mínima  exigida  nos  itens  7  e  9,  para  fins  de  abertura  de 
processo administrativo, acompanhada da eventual justificativa que o profissional tenha 
apresentado,  bem  como  da manifestação  da  CEPC/CFC  em  relação  à  justificativa. 
(Alterada pela NBC PG 12 (R1)) 
(j) encaminhar  aos  CRCs  a  relação  dos  profissionais  referidos  no  item  4  que  não 
cumpriram  a  pontuação  mínima  exigida  no  item  7,  para  fins  de  abertura  de  processo 
administrativo,   acompanhada   da   eventual   justificativa   que   o   profissional   tenha 
apresentado,  bem  como  da  manifestação  da  CEPC/CFC  em  relação  à  justificativa. 
(Alterada pela Revisão NBC 02) 
(k) publicar até 30 de junho de cada ano, no DOU, o edital especificando prazo para que os 
profissionais  que  descumpriram  o  PEPC  encaminhem  aos  Conselhos  Regionais  de 
Contabilidade  as  justificativas  de  não  cumprimento.  Adicionalmente,  o  CFC  poderá 
encaminhar, preferencialmente, para o endereço de email indicado pelo profissional na 
base de registro do CFC, a comunicação quanto à publicação do referido edital. (Incluída 
pela Revisão NBC 05) 
(k) publicar até 30 de junho de cada ano, no DOU, edital especificando o prazo para que os 
profissionais que descumpriram o PEPC encaminhem,via sistema Web EPC, ou em sua 
ausência   aos   Conselhos   Regionais   de   Contabilidade   as   justificativas   de   não 
cumprimento.  Adicionalmente,  o  CFC  poderá  encaminhar,  preferencialmente,  para  o 
endereço   de   e-mail   indicado   pelo   profissional   na   base   de   registro   do   CFC, a 
comunicação quanto à publicação do referido edital. (Alterada pela Revisão NBC 08) 
 
 
Conselhos Regionais de Contabilidade 
 
27. Os   CRCs   têm   a   responsabilidade   de   incentivar   a   implementação   de   atividades   de 
capacitação que permitam o cumprimento desta norma. 
 
27. Os  CRCs  têm  a  responsabilidade  de  promover e  incentivar  a  implementação  de  atividades 
de capacitação que permitam o cumprimento desta norma. (Alterado pela Revisão NBC 02) 
 

28. Os  CRCs  que  não  dispuserem  de  CEPC-CRC  terão  suas  atribuições  assumidas pela 
Câmara de Desenvolvimento Profissional. 
 
28.  Os  CRCs  podem  constituir  CEPC,  que  deve  ser  formada  por,  no  mínimo,  5  (cinco) 
contadores,  sendo  pelo  menos  um  indicado  pela  respectiva  Seção  Regional  do  Ibracon, 
cabendo a coordenação a um dos integrantes. (Alterado pela NBC PG 12 (R1)) 
 
29. A CEPC-CRC, quando constituída, deve ser formada por, no mínimo, 3 (três) contadores e 
coordenada por um deles. 
 
29.  Os  CRCs  que  não  dispuserem  de  CEPC  têm  suas  atribuições  assumidas  pela  Câmara  de 
Desenvolvimento Profissional (CDP). (Alterado pela NBC PG 12 (R1)) 
 
30. A CEPC/CRC ou, na falta desta, a CDP do CRC, tem as seguintes atribuições em relação a 
esta Norma: 
(a) receber  os  pedidos  de  credenciamento  das  instituições  a  serem  reconhecidas  como 
capacitadoras   e   emitir seu   parecer,   na   reunião   subsequente,   submetendo-o   à 
apreciação  da  CEPC/CFC  depois  de  aprovado  pela  CDP  e  homologado  pelo  Plenário 
do CRC; 
(a) receber  os  pedidos  de  credenciamento  das  instituições  a  serem  reconhecidas  como 
capacitadoras, os pedidos de credenciamento de cursos, eventos ou outras atividades, 
bem  como  atribuir  pontos  para  o  PEPC,  e  emitir  seu  parecer,  submetendo-o  à 
apreciação  da  CEPC/CFC  depois  de  aprovado  pela  CDP  e  homologado  pelo  Plenário 
do CRC. Os CRCs que possuírem representante na CEPC/CFC ficam dispensados de 
submeter  seus  pareceres  à  apreciação  da  CEPC/CFC,  exceto  quanto  aos  pedidos  de 
credenciamento  de   capacitadora   e  eventos  tais   como   congressos  e  convenções 
nacionais e internacionais; (Alterada pela NBC PG 12 (R2)) 
(a)  receber  os pedidos  de  credenciamento  das  instituições  a  serem  reconhecidas  como 
capacitadoras, os pedidos de credenciamento de cursos, eventos ou outras atividades, 
bem  como  atribuir  pontos  para  o  PEPC,  e  emitir  seu  parecer,  submetendo-o  à 
apreciação  da  CEPC/CFC  depois de  aprovado  pela  CDP  e  homologado  pelo  Plenário 
do  CRC.  Os  CRCs  que  possuírem  representante  na  CEPC/CFC,  bem  como  aqueles 
que    possuírem    estrutura    para    analisar    os    pedidos    de    credenciamento    de 
cursos/eventos,  de  acordo  com  critérios  definidos  pela  CEPC-CFC,  ficam  dispensados 
de  submeter  seus  pareceres  à  apreciação  da  CEPC/CFC,  exceto  quanto  aos  pedidos 
de  credenciamento  de  capacitadora  e  eventos  tais  como  congressos  e  convenções 
nacionais e internacionais; (Alterada pela NBC PG 12 (R3)) 
(a)  receber  os  pedidos  de  credenciamento  das  instituições  a  serem  reconhecidas  como 
capacitadoras, os pedidos de credenciamento de cursos, eventos ou outras atividades, 
bem  como  atribuir  pontos  para  o  PEPC,  e  emitir  seu  parecer,  submetendo-o  à 
apreciação  da  CEPC/CFC  depois de aprovado  pela  CDP  e  homologado  pelo  Plenário 
do  CRC.  Os  CRCs  que  possuírem  representante  na  CEPC/CFC,  bem  como  aqueles 
que    possuírem    autonomia    para    analisar    os    pedidos    de    credenciamento    de 
cursos/eventos,  de  acordo  com  critérios  definidos  pela  CEPC-CFC, ficam  dispensados 
de  submeter  seus  pareceres  à  apreciação  da  CEPC/CFC,  exceto  quanto  aos  pedidos 
de  credenciamento  de  eventos  tais  como  congressos  e  convenções  nacionais  e 
internacionais; (Alterada pela Revisão NBC 02) 
(b) receber,  analisar  e  emitir  parecer,  na  reunião  subsequente,  quanto  ao  pedido  de 
credenciamento de cursos, eventos ou outras atividades, bem como atribuir pontos para 
o PEPC, de acordo com o Anexo II, submetendo-o à apreciação da CEPC/CFC depois 
de  aprovado  pela  CDP  e  homologado  pelo  Plenário  do  CRC; (Eliminada  pela  NBC  PG  12 
(R2)) 
(c) divulgar  aos  profissionais  sob  sua  jurisdição  as  disposições  e  os  procedimentos 
estabelecidos nesta Norma; 
(d) prestar  esclarecimentos  quanto  à  aplicação  desta Norma,  consoante  as  diretivas 
estabelecidas pela CEPC/CFC; 

(e) receber  de  cada  um  dos  profissionais  referidos  no  item  4  o  relatório  anual  sobre  as 
atividades  realizadas,  acompanhado  de  cópia  da  documentação  que  as  comprovem, 
quando for o caso; 
(e) monitorar  a  inclusão,  no  sistema web,  ou  a  entrega  presencial,  quando  for  o  caso,  do 
relatório de atividades dos profissionais referidos no item 4; (Alterada pela Revisão NBC 02) 
(e)  monitorar  a  inclusão,  no  sistema web,  do  relatório  de  atividades  dos  profissionais 
referidos no item 4; (Alterado pela Revisão NBC 05) 
(f) validar, no sistema de controle do PEPC, até o dia  28 de fevereiro do ano subsequente 
ao ano-base, as informações sobre as atividades de EPC das capacitadoras; 
(f) validar,  no  sistema web de  controle  do  PEPC,  até  o  dia  28  de  fevereiro  do  ano 
subsequente   ao   ano-base,   as   informações   sobre   as   atividades   de   EPC   das 
capacitadoras; (Alterada pela Revisão NBC 02) 
(g) validar, no sistema de controle do PEPC, até 31 de março do ano subsequente ao ano-
base, os  dados  constantes  dos  relatórios  de  atividades de  que  trata  o  Anexo  III  desta 
norma; 
(g) validar, no sistema web de controle do PEPC, até 31 de março do ano subsequente ao 
ano-base,  os  dados  constantes  dos  relatórios  de  atividades  de  que  trata  o  Anexo  III 
desta norma; (Alterada pela Revisão NBC 02) 
(h) verificar,  por  meio  da  fiscalização  do  CRC,  a  efetiva  realização  dos  cursos  e  dos 
eventos na forma em que foram homologados; 
(i) aplicar  a  sanção  prevista  no  item  5,  do  Anexo  I,  na  ocorrência  das  situações  ali 
elencadas, assegurados à capacitadora o direito à ampla defesa e ao contraditório. 
(i) aplicar  a  sanção  prevista  no  item  5,  do  Anexo  I,  na  ocorrência  das  situações  ali 
elencadas,  assegurado  à  capacitadora  o  direito  à  ampla  defesa  e  ao  contraditório, 
obrigando-se  a  informar  expressamente  a  CEPC/CFC. Da penalidade  imposta  pela 
CEPC/CRC,  cabe  recurso  à  CEPC/CFC,  no  prazo  de  15  (quinze)  dias  contados  da 
ciência da decisão; (Alterada pela NBC PG 12 (R1)) 
(i) aplicar a sanção prevista no item 5, do Anexo I, informar à CDP quando da ocorrência 
das  situações ali  elencadas e assegurar à  capacitadora  o  direito  à  ampla  defesa  e  ao 
contraditório,  obrigando-se  a  informar  expressamente à CEPC/CFC.  Da  penalidade 
imposta  pela  CEPC/CRC,  cabe  recurso  à  CEPC/CFC,  no  prazo  de  15  (quinze)  dias 
contados da ciência da decisão; e (Alterada pela NBC PG 12 (R2)) 
(i) aplicar  a  sanção  prevista  no  item  35B,  informar  à  CDP  quando  da  ocorrência  das 
situações  ali  elencadas  e  assegurar  à  capacitadora  o  direito  à  ampla  defesa  e  ao 
contraditório,  obrigando-se  a  informar  expressamente  à CEPC/CFC.  Da  penalidade 
imposta  pela  CEPC/CRC,  cabe  recurso  à  CEPC/CFC,  no  prazo  de  15  (quinze)  dias 
contados da ciência da decisão; (Alterada pela Revisão NBC 02) 
(i) aplicar  a  sanção  prevista  no  item  35B,  informar  à  CDP  quando  da  ocorrência  das 
situações  ali elencadas  e  assegurar  à  capacitadora  o  direito  à  ampla  defesa  e  ao 
contraditório,  obrigando-se  a  informar  expressamente  à  CEPC/CFC.  Da  penalidade 
imposta  pela  CEPC/CRC,  cabe  recurso  à  CEPC/CFC,  no  prazo  de  15  (quinze)  dias 
corridos contados da ciência da decisão; (Alterada pela Revisão NBC 08) 
 
(j)  descredenciar  os  cursos  e  eventos  em  que  houver  sido  constatada  a  inobservância 
desta norma. (Incluída pela NBC PG 12 (R1)) 
(j)  descredenciar  os  cursos  e  eventos  em  que  houver  sido  constatada  a  inobservância 
desta  norma e assegurar à  capacitadora  o  direito  à  ampla  defesa  e  ao  contraditório, 
obrigando-se  a  informar  expressamente à CEPC/CFC.  Da  penalidade  imposta  pela 
CEPC/CRC,  cabe  recurso  à  CEPC/CFC,  no  prazo  de  15  (quinze)  dias  contados  da 
ciência da decisão. (Alterada pela NBC PG 12 (R2)) 
(j) descredenciar os cursos e eventos em que for constatada a inobservância desta norma 
e assegurar à capacitadora o direito à ampla defesa e ao contraditório, obrigando-se a 
informar  expressamente  à  CEPC/CFC.  Da  penalidade  imposta  pela  CEPC/CRC,  cabe 
recurso  à  CEPC/CFC,  no  prazo  de  15 (quinze) dias  contados  da ciência  da  decisão;  e 
(Alterada pela Revisão NBC 02) 
(j)  descredenciar  os  cursos  e  eventos  em  que  for  constatada  a  inobservância  desta 
norma  e  assegurar  à  capacitadora o direito  à  ampla  defesa  e  ao  contraditório, 

obrigando-se a informar expressamente à CEPC/CFC. Da penalidade imposta pela 
CEPC/CRC,  cabe  recurso  à  CEPC/CFC,  no  prazo  de  15  (quinze)  dias  corridos 
contados da ciência da decisão; e (Alterada pela Revisão NBC 08) 
(k)  julgar   recursos   em   primeira   instância   encaminhados   pelos  profissionais   ou   pelas 
capacitadoras  relativos  ao  PEPC,  cientificando  o  interessado  sobre  a  decisão. (Incluída 
pela Revisão NBC 02) 
(l)  analisar  as  justificativas  de  não  cumprimento  do  PEPC, conforme  prazo  definido  em 
Edital  específico  e  emitir  seu  parecer,  submetendo-o  à  apreciação  da  CEPC/CFC 
depois  de  aprovado  pela  CDP  e  homologado  pelo  Plenário  do  CRC.  Os  CRCs  que 
possuírem autonomia ficam dispensados de submeter seus pareceres à apreciação da 
CEPC/CFC,  devendo  cientificar  o  interessado  sobre  a  decisão. (Incluída  pela  Revisão  NBC 
05) 
 
31.  Até  30  de  abril  de  cada  ano,  o  CRC  deve  disponibilizar  na internet,  aos  profissionais 
referidos no item 4, a certidão de cumprimento, ou não, da pontuação mínima estabelecida 
na presente Norma. 
 
31. Até 30 de abril de cada ano, o CRC deve disponibilizar na internet e/ou por meio do sistema 
web, aos profissionais referidos no item 4, a certidão de cumprimento, ou não, da pontuação 
mínima estabelecida na presente norma. (Alterado pela Revisão NBC 02) 
 
32. A  certidão  a  que  se  refere  o  item  anterior  não  exime  o  profissional  de  prestar  qualquer 
esclarecimento   ou   comprovação   que   se   faça   necessário   em   decorrência   de   ação 
fiscalizatória. 
 
Capacitadoras 
 
33. Capacitadora  é  a  entidade  que  promove  atividades  de  Educação  Profissional  Continuada 
consoante as diretivas desta Norma. 
 
33.   Capacitadora  é  a  entidade  credenciada  em  Conselho  Regional  de  Contabilidade  que 
promove  atividades  de  Educação  Profissional  Continuada consoante  as  diretivas  desta 
norma. (Alterado pela NBC PG 12 (R2)) 
 
34. São capacitadoras: 
34.   Podem ser capacitadoras: (Alterado pela NBC PG 12 (R2)) 
(a) Conselho Federal de Contabilidade (CFC); 
(b)  Conselhos Regionais de Contabilidade (CRCs); 
(c)  Fundação Brasileira de Contabilidade (FBC); 
(d)  Academia Brasileira de Ciências Contábeis (Abracicon); 
(d)  Academia  Brasileira  de  Ciências  Contábeis  (Abracicon)  e  as  respectivas  Academias 
Estaduais ou regionais; (Alterada pela NBC PG 12 (R1)) 
(e)  IBRACON – Instituto dos Auditores Independentes do Brasil; 
(f)  Instituições de Ensino Superior (IES), credenciadas pelo MEC; 
(g)  Instituições de Especialização ou Desenvolvimento Profissional que ofereçam cursos ao 
público em geral; 
(g)  Entidades de Especialização ou Desenvolvimento Profissional que ofereçam cursos ao 
público em geral; (Alterada pela NBC PG 12 (R1)) 
(h)  Federações, Sindicatos e Associações da classe contábil; 
(h)  Federações,  Sindicatos  e  Associações  da  classe  contábil  e  empresariais; (Alterada pela 
NBC PG 12 (R1)) 
(h)  Federações,  Sindicatos  e  Associações  da  classe  contábil  e  empresariais; (Alterada  pela 
NBC PG 12 (R2)) 
(i)  Firmas de Auditoria Independente; 
(j)  Organizações Contábeis; e 
(j)  Organizações Contábeis (escritórios contábeis e empresas de perícia contábil); (Alterada 
pela Revisão NBC 02) 
(k)  Órgãos Reguladores. 

(l)  Empresas  de  grande  porte, representadas  pelos  seus  Departamentos  de  Treinamento, 
Universidades Corporativas e/ou outra designação; (Incluída pela NBC PG 12 (R1)) 
(m) Universidades  e  Institutos  Corporativos  que  tenham  personalidade  jurídica  própria; e 
(Incluída pela NBC PG 12 (R1)) 
(n)  Serviços Sociais autônomos; e (Incluída pela NBC PG 12 (R2)) 
(o)  Entes   da   administração   pública   tais   como   Tribunais   de   Contas,   Procuradorias, 
Secretaria do Tesouro, entre outros. (Incluída pela Revisão NBC 02) 
 
35. Para   registro   e   controle   das   capacitadoras,   devem   ser   observadas   as   disposições 
estabelecidas no Anexo I desta norma. 
 
35A.  As  capacitadoras  credenciadas  para  fins  desta  norma estão  sujeitas  à  fiscalização  do 
Sistema CFC/CRCs. (Incluído pela Revisão NBC 02) 
 
35B.  As  entidades  identificadas  como  capacitadoras,  inscritas  e  homologadas  no  contexto  do 
Programa de Educação Profissional Continuada, podem ser suspensas temporariamente ou 
descredenciadas   do   PEPC,   pela   CEPC/CRC,   devendo   comunicar   expressamente à 
CEPC/CFC,  se  constatados  um  dos  seguintes  fatos  ou  ocorrências,  isoladamente  ou  em 
conjunto, observado o disposto no item 30, alínea (i), desta norma: 
(a)  não  realizar  no  período de,  pelo  menos,  12  meses  um  curso  homologado  dentro  do 
Programa; 
(b)  deixar   de   cumprir   as   determinações   relativas   ao   item   13   do   anexo   I,   sobre 
documentação, controle e fiscalização. (Incluído pela Revisão NBC 02) 
 
35C.  A  suspensão  temporária  da  capacitadora,  prevista  no  item  35B,  é  de  até  um  ano.  O 
descredenciamento  pode  ser  por  prazo  indeterminado  quando  houver  reincidência  no 
período de 5 anos na aplicação de penalidade de suspensão. (Incluído pela Revisão NBC 02) 
 
35D. A capacitadora ofertante de cursos voltados para o público interno, sob nenhuma hipótese, 
deve promovê-lo para público em geral, sob pena de sofrer as penalidades previstas no item 
35B. (Incluído pela Revisão NBC 02) 
 
Eventos de Educação Profissional Continuada 
 
36. Constituem-se  eventos de  EPC  as  atividades  descritas  nos  itens  seguintes,  desde  que 
aprovadas pela CEPC/CFC, nos termos desta norma.  
 
36. Constituem-se  eventos  de  EPC  as  atividades  descritas  nos  itens  seguintes,  desde  que 
aprovadas pela CEPC/CFC e CEPC/CRCs, nos termos desta norma. (Alterado pela Revisão NBC 
02) 
 
Atividades de Educação Profissional Continuada 
 
37. Aquisição de conhecimento nas modalidades presenciais, a distância e mistas, por meio de: 
37.  Considera-se  aquisição  de  conhecimento  as  atividades  presenciais,  a distância  ou  mistas, 
incluindo autoestudo, estudo dirigido, e-learning e equivalentes, sobre temas que contribuam 
para  a  melhoria  da  performance  do  profissional,  com  conteúdo  de  natureza  técnica  e 
profissional, relacionados ao PEPC, por meio de: (Alterado pela NBC PG 12 (R2)) 
(a) cursos  credenciados;  
(b) eventos credenciados; 
(c) cursos de pós-graduação oferecidos por IES credenciadas pelo MEC:  
(c) conclusão  de  disciplinas  de  cursos  de  pós-graduação  oferecidos  por  IES  credenciadas 
pelo MEC: (Alterada pela NBC PG 12 (R2)) 
(i)  stricto sensu; 
(ii)  lato sensu;  
(d) cursos de extensão devidamente credenciados no PEPC; 

(e)  disciplinas  cursadas  em  outras  graduações  em  áreas  correlatas  ao  curso  de  Ciências 
Contábeis. (Incluída pela NBC PG 12 (R2)) 
(e)  disciplinas  cursadas  em  outras  graduações  em  áreas  correlatas  ao  curso  de  Ciências 
Contábeis,   tais   como:   Administração,   Ciências   Atuariais,   Ciências   Econômicas, 
Estatística, Tecnologia da Informação e Direito. (Alterada pela NBC PG 12 (R3)) 
(f) disciplinas  cursadas  em  graduação  em  Ciências  Contábeis  para  os  profissionais 
registrados como técnicos em contabilidade. (Incluído pela Revisão NBC 08) 
 
38. Docência em disciplinas ou temas relacionados à EPC, conforme a Tabela II do Anexo II. 
 
39. Atuação  em  atividades  relacionadas  ao  Programa  de  Educação  Profissional  Continuada, 
como: 
(a) participante  em  comissões  técnicas  do  CFC,  dos  CRCs,  da  FBC,  da  Abracicon,  do 
IBRACON e outros órgãos reguladores ou profissionais, no Brasil ou no exterior; 
(a) participante  em  comissões  técnicas  do  CFC,  dos  CRCs,  da  FBC,  da  Abracicon, do 
Ibracon e outros órgãos reguladores técnicos ou profissionais, no Brasil ou no exterior; 
(Alterada pela NBC PG 12 (R1)) 
(b) orientador  de tese, dissertação ou monografia. 
 
39.   Atuação  em  atividades  relacionadas  ao  Programa  de  Educação  Profissional  Continuada, 
como: 
39. Atuação   como   participante   em   atividades   relacionadas   ao   Programa   de   Educação 
Profissional Continuada, como: (Alterada pela Revisão NBC 08) 
 
(a) participante  em  comissões  técnicas  do  CFC,  dos  CRCs,  da  FBC,  da  Abracicon,  do 
Ibracon,  outros  órgãos  reguladores  técnicos  ou  profissionais  e  de  entidades  de  classe 
de segmentos específicos, no Brasil ou no exterior;  
(a)  participante  em  comissões  técnicas  e  ou  colegiados  do  CFC,  dos  CRCs,  da  FBC,  da 
Abracicon,   do   Ibracon,   de   outros   órgãos   reguladores/supervisores   técnicos   ou 
profissionais  e  de  entidades  de  classe  de  segmentos  específicos,  no  Brasil  ou  no 
exterior; (Alterada pela Revisão NBC 02) 
(a)  comissões técnicas,  grupos  de  trabalhos  e grupos  de  estudos  técnicos  instituídos  pelo 
CFC,  pelos  CRCs,  pela  FBC,  pela  Abracicon,  pelo  Ibracon  e  por  outros  órgãos 
reguladores/supervisores  técnicos  ou  profissionais,  no  Brasil    e  no  exterior.  Reuniões 
com caráter de gestão, operacionais e institucionais, tais como plenárias e regimentais, 
não serão objeto de pontuação;(Alterada pela Revisão NBC 08) 
(b) orientador de tese, dissertação,  monografia ou artigo científico; 
(c)   participante em bancas acadêmicas. (Alterado pela NBC PG 12 (R2)) 
(c)  bancas acadêmicas de mestrado e doutorado. (Alterada pela Revisão NBC 08) 
 
40. Produção intelectual de forma impressa ou eletrônica relacionada ao PEPC, por meio de: 
(a) publicação de artigos em revistas nacionais e internacionais; 
(b) estudos   e   trabalhos   de   pesquisa apresentados   em   congressos   nacionais   ou 
internacionais; e 
(c) autoria, coautoria e/ou tradução de livros publicados. 
 
40.  Produção intelectual de forma impressa ou eletrônica relacionada ao PEPC, por meio de: 
(a)  matérias publicadas; 
(b)  artigos  técnicos  em  mídia  eletrônica  ou  impressa  de  revistas  regionais,  nacionais  e 
internacionais; 
(c)  estudos   e   trabalhos   de   pesquisa   apresentados   em   congressos   nacionais e 
internacionais; 
(d)  teses ou monografias aprovadas, de conclusão de pós-graduação lato-sensu ou stricto 
sensu; e 
(d)  teses,  dissertações  ou  monografias  aprovadas,  de  conclusão  de  pós-graduação lato 
sensu ou stricto sensu; e (Alterada pela Revisão NBC 02) 
(e)  autoria, coautoria e/ou tradução de livros publicados. (Alterado pela NBC PG 12 (R2)) 

 
41. As  atividades  previstas nos  itens  37 a 40  devem  ser  consideradas,  para efeito  do  disposto 
nos itens 7 e  9,  conforme  a  pontuação  e  limitações  estabelecidas  nas  tabelas  contidas  no 
Anexo II desta Norma. 
 
41. As  atividades  previstas  nos  itens  de  37  a  40  devem  ser  consideradas,  para  efeito  do 
disposto  no  item  7,  conforme  a  pontuação  e  limitações  estabelecidas  nas  tabelas  contidas 
no Anexo II desta norma. (Alterado pela Revisão NBC 02) 
 
Disposições gerais 
 
42. O  descumprimento  das  disposições  desta  Norma  pelos profissionais  referidos  no  item  4 
constitui infração às normas profissionais de contabilidade e ao Código de Ética Profissional 
do  Contador,  a  ser  apurada  em  regular  processo  administrativo  no  âmbito  do  CRC 
respectivo. 
 
42. O  descumprimento  das  disposições  desta  norma  pelos  profissionais  referidos  no  item 4, 
inclusive  a  entrega  do  relatório com  a  comprovação  da  pontuação  mínima  fora  do  prazo 
estabelecido, constitui  infração  às  normas  profissionais  de  Contabilidade  e  ao  Código  de 
Ética Profissional do Contador, a ser apurada em regular processo administrativo no âmbito 
do respectivo CRC. (Alterado pela NBC PG 12 (R1)) 
 
42.    O  descumprimento  das  disposições  desta  norma  pelos  profissionais  referidos  no  item  4, 
inclusive  a  não  comprovação  da  pontuação  mínima  exigida  anualmente  e  a  entrega  de 
forma intempestiva, constitui infração às normas profissionais de Contabilidade e ao Código 
de  Ética  Profissional  do  Contador,  a  ser  apurada  em  regular  processo  administrativo  no 
âmbito do respectivo CRC. (Alterada pela NBC PG 12 (R2)) 
 
42A.  A  relação  dos  profissionais  referidos  no  item  4  que  não  cumpriram  a  pontuação  mínima 
exigida  no  item  7  deve  ser  encaminhada  à  Vice-presidência  de  Fiscalização,  Ética  e 
Disciplina  do  CFC  pela  Vice-presidência  de  Desenvolvimento  Profissional,  para  fins  de 
orientação  aos  CRCs  quanto  à  lavratura  de  auto  de  infração  e  abertura  de  processo  ético 
disciplinar nos Conselhos Regionais de Contabilidade. (Incluído pela Revisão NBC 02) 
 
43.  O  descumprimento  das  disposições  desta  Norma,  pelos  profissionais  referidos  no  item  4, 
alínea (a),  acarretará  a baixa  do  respectivo  CNAI,  conforme  previsto  na  Resolução  CFC  
n.°1.019/05, sem prejuízo do disposto no item 42.  
 
43.   A não  comprovação  da  pontuação  mínima  exigida  anualmente  nos  termos  desta  norma 
pelos  profissionais  referidos  no  item  4,  alínea  (a),  acarreta  a  baixa  do  respectivo  CNAI. 
(Alterado pela NBC PG 12 (R1)) 
 
43.  A não  comprovação  da  pontuação  mínima  exigida,  anualmente,  nos  termos  desta  norma 
pelos  profissionais  referidos  no  item  4,  alíneas  (a)  e  (j),  acarreta  a  baixa  do  CNAI  ou  do 
CNPC, conforme o caso. (Alterado pela Revisão NBC 02) 
 
43A.  No   exercício   em   que   os   profissionais   deixarem   de   se   enquadrar   no   item   4   ficam 
desobrigados do cumprimento do Programa de Educação Profissional Continuada, enquanto 
perdurar essa condição, devendo comunicar esta situação ao CRC de sua jurisdição. (Incluído 
pela NBC PG 12 (R3)) 
 
44.  A  baixa  prevista  no  item  43 e as  providências  previstas  no  item  26, alíneas (g)  e  (j), 
somente  serão  adotadas  após  ser  assegurado  ao  profissional  o  direito  ao  contraditório e  a 
ampla  defesa que  lhe  permita  justificar  o  não  cumprimento  das  obrigações  previstas  nesta 
Norma. (Eliminado pela NBC PG 12 (R2)) 
 

44.  A baixa prevista no item 43 e as providências previstas no item 26, alíneas (g) e (j), somente 
serão  adotadas  após  ser  assegurado  ao  profissional  o  direito  ao  contraditório  e  à  ampla 
defesa que lhe permita justificar o não cumprimento das obrigações previstas nesta norma. 
(Alterado pela NBC PG 12 (R3)) 
44. A baixa prevista no item 43 e as providências previstas no item 26, alíneas (g) e (j), somente 
serão  adotadas  após  ser  assegurado  ao  profissional  o  direito  ao  contraditório  e  à  ampla 
defesa que lhe permita justificar o não cumprimento das obrigações previstas nesta Norma, 
conforme itens 26 (k),30(k) e 26 (h). (Alterado pela Revisão NBC 08) 
 
44A. A EPC pode ser cumprida de forma voluntária para os demais profissionais da contabilidade 
não mencionados no item 4. (Incluído pela NBC PG 12 (R1)) 
 
44B.  O profissional deve manter atualizados os seus dados cadastrais na base de seu registro no 
Conselho Regional de Contabilidade. (Incluído pela Revisão NBC 05) 
 
Vigência 
 
45.  Esta Norma entra em vigor na data de sua publicação, devendo ser aplicada a partir de 1º 
de janeiro de 2021. 
 
Em razão dessas alterações, as disposições não alteradas desta norma são mantidas, e a sigla da 
NBC PG 12 (R2), publicada no DOU, Seção 1, de 21/12/2016, passa a ser NBC PG 12 (R3). 
 
As alterações desta norma entram em vigor na data de sua publicação, produzindo seus efeitos a 
partir de 1º de janeiro de 2018. 
 
Essas alterações, inclusões e exclusões serão incorporadas à NBC PG 12 (R3) e entram em vigor 
na data de sua publicação, produzindo seus efeitos a partir de 1º de janeiro de 2021. 
  
Brasília, 17 de dezembro de 2020. 
 
 
Contador Zulmir Ivânio Breda 
Presidente 
 
Ata CFC n.º 1.070. 
 
 
ANEXO I 
DIRETRIZES PARA CREDENCIAMENTO DE CAPACITADORAS, CREDENCIAMENTOS DE 
CURSOS/EVENTOS E DOCUMENTAÇÃO PARA CONTROLE E FISCALIZAÇÃO 
 
 
Credenciamento da capacitadora 
 
1. As capacitadoras devem solicitar o seu credenciamento à CEPC/CRC da sua jurisdição. 
1. As  capacitadoras  devem  solicitar  o  seu  credenciamento  à  CEPC/CRC  da jurisdição  da  sua 
matriz. (Alterado pela Revisão NBC 08) 
 
2. O  atendimento  dos  requisitos  para  o  credenciamento  da  capacitadora  e  dos  seus  cursos 
deve ser analisado pela CEPC/CRC ou, na sua ausência, pela Câmara de Desenvolvimento 
Profissional e submetido à homologação da CEPC/CFC. 
 
2. O  atendimento  dos  requisitos  para  o  credenciamento  da  capacitadora  e  dos  seus  cursos 
deve ser analisado pela CEPC/CRC ou, na sua ausência, pela Câmara de Desenvolvimento 
Profissional, homologado pelo Plenário do Conselho Regional de Contabilidade e submetido 

à homologação da CEPC/CFC e homologação do Plenário do CFC. (Alterado pela Revisão NBC 
02) 
 
2A. Para  fins  de  treinamento  direcionado  a  público  interno,  as  organizações  contábeis  e  as 
áreas  de  treinamento  das  empresas  de  médio  e  grande  porte  terão  os  seus  pedidos  de 
credenciamentos  analisados  pela  CEPC/CRCs,  conforme  definido  no  item  30(a)  desta 
norma. (Incluído pela Revisão NBC 02) 
 
3.  Para   a   obtenção   de   credenciamento   como   capacitadora,   as   firmas   de   auditoria 
independente  ou  as organizações contábeis  devem  estar  em  situação  regular no  CRC  de 
sua jurisdição. 
 
4.  A   validade   do credenciamento   da   capacitadora   é   por   tempo   indeterminado   e   o 
credenciamento  dos  cursos  e eventos  é  válido  por  dois  exercícios,  desde  que  preservadas 
as  características  do  item  6, alínea (a)  deste  Anexo,  podendo ser  revalidado, se solicitado, 
desde  que  mantidas  as  condições  de  credenciamento  e  aprovadas  pela  CEPC/CRC  da 
respectiva jurisdição. 
 
4.  A   validade   do   credenciamento   da   capacitadora   é   por   tempo   indeterminado   e   o 
credenciamento  dos  cursos  e  eventos  é  válido  até  o  final  do  exercício  seguinte  àquele  do 
credenciamento,  desde  que  preservadas  as  características  do  item  6,  alínea  (a),  deste 
Anexo,  podendo  ser  revalidado,  se  solicitado,  desde  que  mantidas  as  condições  de 
credenciamento  e  aprovadas  pela  CEPC/CRC  da  respectiva  jurisdição. (Alterado  pela  NBC  PG 
12 (R1)) 
 
4. A   validade   do   credenciamento   da   capacitadora   é   por   tempo   indeterminado   e   o 
credenciamento  dos  cursos  e  eventos  é  válido  até  o  final  do  exercício  seguinte  àquele  do 
credenciamento,  desde  que  preservadas  as  características  do  item  6,  alínea  (a),  deste 
Anexo.  Para  revalidação  de  cursos,  deverá ser  efetuado  novo  pedido  de  credenciamento  
atendendo  a  letra  “a”  do  Item  6  desse  anexo  aprovadas  pela  CEPC/CRC  da  respectiva 
jurisdição. (Incluído pela Revisão NBC 08) 
 
5.   As  entidades  identificadas  como  capacitadoras,  inscritas  e  homologadas  no  contexto  do 
Programa  de  Educação  Profissional  Continuada,  poderão  ser  excluídas  do  programa,  se 
constatados um dos seguintes fatos ou ocorrências, isoladamente ou em conjunto: 
 
5.  As  entidades  identificadas  como capacitadoras,  inscritas  e  homologadas  no  contexto do 
Programa de Educação Profissional Continuada, podem ser suspensas temporariamente ou 
descredenciadas   do   PEPC,   pela   CEPC/CRC,   devendo   comunicar   expressamente   à 
CEPC/CFC  se  constatados  um  dos  seguintes  fatos  ou  ocorrências,  isoladamente  ou  em 
conjunto,  observado  o  disposto  no  item  30,  alínea  (i),  desta  norma: (Alterado  pela  NBC  PG  12 
(R1)) 
(a) não realizar a  cada  12  (doze)  meses, pelo  menos, um  curso  homologado  dentro  do 
Programa; 
(b)  deixar   de   cumprir   as   determinações   relativas   ao   item   13 deste   anexo, sobre 
documentação, controle e fiscalização; 
(c)  deixar  de  comunicar  ao  CRC  o  eventual  cancelamento  ou  adiamento  de  evento/curso 
credenciado, no prazo de até 3 (três) dias úteis em relação ao início previsto; 
(d) manter as condições aprovadas para o seu credenciamento, seus cursos e eventos, sob 
pena de suspensão temporária ou descredenciamento pela CEPC-CRC. 
(d) deixar  de  manter  as  condições  aprovadas  para  o  seu  credenciamento,  seus  cursos  e 
eventos. (Alterado pela NBC PG 12 (R1)) (Eliminado pela Revisão NBC 02) 
 
5A.   A  suspensão  temporária  da  capacitadora,  prevista  no  item  5,  é  pelo  prazo  de  um  ano, 
coincidente  com  o  ano  calendário,  sempre  seguinte  ao  ano  da  aplicação  da  penalidade, 
período  no  qual  fica  impedida  de  atuar  no  PEPC.  O  descredenciamento  será definitivo 
quando  houver  reincidência  por  mais  de  duas  vezes  na  aplicação  de  penalidade  de 
suspensão. (Incluído pela NBC PG 12 (R1)) (Eliminado pela Revisão NBC 02) 

 
6.     Compete às capacitadoras: 
6.  As capacitadoras devem: (Alterado pela Revisão NBC 02) 
(a)  preencher  requerimento  de  credenciamento  (disponível  nos  Portais  dos  CRCs)  como 
capacitadora a ser assinado por seu representante legal; 
(a)  preencher requerimento de credenciamento a ser assinado por seu representante legal; 
(Alterada pela Revisão NBC 02) 
(b)  anexar cópia autenticada dos seus atos constitutivos, ou último instrumento consolidado 
e alterações posteriores, em que conste no objeto social a prerrogativa de treinamento 
e/ou capacitação. As firmas de auditoria ficam dispensadas desta exigência relativa ao 
objeto social, somente quando se tratar de cursos voltados ao público interno; 
(b)  anexar   cópia   autenticada   dos   seus   atos   constitutivos,   ou   últimos   instrumentos 
consolidados e alterações posteriores, em que conste no objeto social a prerrogativa de 
treinamento e/ou capacitação; (Alterada pela NBC PG 12 (R1)) 
(ba) as  firmas  de  auditoria  ficam  dispensadas  dessa  exigência  relativa  à  inclusão  da 
atividade de treinamento no objeto social, se não estiver oferecendo cursos voltados ao 
público externo; (Incluída pela NBC PG 12 (R1)) 
(ba) as organizações contábeis (firmas de auditoria, empresas de contabilidade e empresas 
de  perícia  contábil) ficam  dispensadas das  exigências  relativas  aos  itens  6(b)  e (c),  se 
não oferecerem cursos voltados ao público externo; (Alterada pela Revisão NBC 02) 
(bb) as empresa de grande porte, referidas no item 4, alínea (f), desta norma, que possuam 
estruturas   departamentais   dedicadas   ao   desenvolvimento   e   treinamento ficam 
dispensadas  da  exigência  relativa  à  inclusão dessa  atividade  nos  seus  estatutos 
societários, desde que ofereçam cursos voltados ao público interno. Nesse caso, devem 
apresentar  declaração  assinada  pelos  seus  representantes  legais  informando  que  a 
empresa   desenvolve   internamente   um   programa   estruturado   e   específico   de 
desenvolvimento profissional para os seus colaboradores, apontando o responsável que 
deve  representar  a  empresa  (ou  o  grupo  empresarial)  no  Sistema  CFC/CRCs; (Incluída 
pela NBC PG 12 (R1)) 
(bb) as  empresas  referidas  no  item  4,  alíneas  (f e  h),  desta  norma que  possuam  estruturas 
departamentais  dedicadas  ao  desenvolvimento  e  treinamento  ficam  dispensadas  da 
exigência relativa à inclusão dessa atividade nos seus estatutos societários, desde que 
ofereçam cursos voltados ao público interno. Nesse caso, devem apresentar declaração 
assinada  pelos  seus  representantes  legais,  informando  que  a  empresa  desenvolve 
internamente  um  programa  estruturado  e  específico  de  desenvolvimento  profissional 
para os seus colaboradores, apontando o responsável que deve representar a empresa 
(ou o grupo empresarial) no Sistema CFC/CRCs; (Alterada pela Revisão NBC 02) 
(c) anexar histórico da instituição, especificando: 
 (i)  sua experiência e/ou dos instrutores em capacitação; 
(ii)  público-alvo dos cursos.  
(d) inserir no sistema web, com antecedência mínima de 60 (sessenta) dias da data de sua 
realização,  dados  dos  cursos/eventos  a  serem  credenciados  e/ou  revalidados,  como: 
título  do  curso  (quando  em  idioma  estrangeiro constar  também  em  português);  tipo  de 
curso;   área temática;   carga   horária;   conteúdo   programático;   bibliografia   mínima 
atualizada;   frequência   mínima;   cronograma   de   realização;   critério   de   avaliação; 
modalidade; abrangência; público-alvo; nome e currículo dos professores; sem prejuízo 
de  outras  informações que  possam  ser solicitadas  a  critério  da  CEPC,  dos  CRCs  e  do 
CFC. Nos  casos  em  que  o  prazo  acima  não  puder  ser  cumprido,  a  capacitadora  deve 
comunicar  ao  CRC,  com  no  mínimo  5  (cinco)  dias  úteis  de  antecedência  ao  evento,  a 
data  de  sua  realização.  Nesse  caso,  a  capacitadora  tem  até  15  (quinze)  dias  úteis, 
contados  da  data  do  comunicado,  para  cumprir  as  exigências  para  o  pedido  de 
credenciamento do curso/evento; 
(d)  inserir  no  sistema  Web EPC,  com  antecedência  mínima  de 60 (sessenta)  dias  da  data 
de  sua  realização,  dados  dos  cursos/eventos  a  serem  credenciados  e/ou  revalidados, 
como:  título  do  curso  (quando  em  idioma  estrangeiro  constar  também  em  português), 
tipo de curso, área temática, carga horária, conteúdo programático, bibliografia mínima 
atualizada,   frequência   mínima,   cronograma   de   realização,   critério   de   avaliação, 

modalidade, abrangência, público-alvo, nome e currículo dos professores, sem prejuízo 
de outras informações que possam ser solicitadas, a critério da CEPC, dos CRCs e do 
CFC.  Nos  casos  em  que  o  prazo  acima  não  puder  ser  cumprido,  a  capacitadora  deve 
comunicar  ao  CRC,  com  no  mínimo  5  (cinco)  dias  úteis  de  antecedência  ao  evento,  a 
data  de  sua  realização.  Nesse  caso,  a  capacitadora  tem  até  15  (quinze)  dias  úteis, 
contados  da  data  do  comunicado, para  cumprir  as  exigências  para  o  pedido  de 
credenciamento do curso/evento; (Alterada pela Revisão NBC 08) 
 
(e)  informar,  obrigatoriamente,  ao  CRC  respectivo  a  data  de  realização  de  cada  uma  das 
edições, com,  no  mínimo,  5  (cinco)  dias  úteis  de  antecedência,  no  caso  de  cursos 
aprovados para realização de mais de uma edição dentro do prazo de sua validade;  
(f)  dispensar os   cursos   de   pós-graduação   do   prévio   credenciamento no   PEPC.   A 
comprovação  deve  ser  feita  pelo  profissional  mediante  apresentação  de  declaração, 
emitida pela IES, das disciplinas concluídas no ano; (Eliminado pela NBC PG 12 (R1)) 
(g) enviar  à  CEPC/CRC  seus  planos  de  ação  e  datas  para  correção  de  eventuais 
discrepâncias verificadas em ação fiscalizatória no prazo estabelecido;  
(h)  comunicar  aos  participantes somente a  pontuação  de  um  curso  ou  evento  quando  o 
processo de homologação estiver concluído e a pontuação validada pela CEPC-CFC; 
(h)  somente  comunicar  aos  participantes  a  pontuação  do  curso  ou  evento  quando  o 
processo de homologação estiver concluído e a pontuação validada; (Alterada pela NBC PG 
12 (R1)) 
(h)  somente  comunicar  aos  participantes  a  pontuação  do  curso  ou  evento  quando  o 
processo  de  homologação  estiver  concluído  e  a  pontuação  validada,  não  sendo 
permitido solicitar credenciamento de curso já realizado; (Alterada pela Revisão NBC 05) 
(ha) divulgar  a  pontuação  homologada  pelo  CFC/CRCs  que  deve  ser  realizada  de  forma  a 
destacar a pontuação atribuída a cada área de atuação sujeita a educação profissional 
continuada; (Incluída pela Revisão NBC 02) 
(i)  lançar em até 30 (trinta) dias após a data de realização do curso/evento, limitado até 15 
de  janeiro  do  ano  seguinte, preferencialmente por  meio  do  sistema  web,  informações 
dos  professores  e  dos  participantes  que  se  certificaram  em curso/evento.  No  caso  de 
não ter ocorrido curso/evento, a capacitadora deve prestar esta informação.  
(i)  lançar em até 30 (trinta) dias após a data de realização do curso/evento, limitado até 15 
de  janeiro  do  ano  seguinte,  preferencialmente  por  meio  do sistema web,  informações 
dos  professores  e  dos  participantes  que  se  certificaram  em  curso/evento. (Alterada  pela 
NBC PG 12 (R1)) 
(i)  lançar  em  até  30  (trinta)  dias  após  a  data  de  realização  do  curso/evento,  por  meio  do 
sistema web,  informações  dos  professores  e  dos  participantes  que  se  certificaram  em 
curso/evento.  Para  cursos/eventos  credenciados  e  realizados  em  dezembro,  a  data 
limite  para  o  envio  das  informações  será  15  de  janeiro  do  ano  seguinte. (Alterada  pela 
Revisão NBC 05) 
(i)  lançar,  em  até  30  (trinta)  dias  após  a  data  de realização  do  curso/evento,  por  meio  do 
sistema Web EPC, informações dos professores e dos participantes que se certificaram 
em curso/evento. Para cursos/eventos credenciados e realizados em dezembro, a data 
limite  para  o  envio  das  informações  será  15  de  janeiro  do  ano  seguinte. (Alterada  pela 
Revisão NBC 08) 
 
6A.   No   processo   de   avaliação   e   credenciamento   de   Entidades   de   Especialização   ou 
Desenvolvimento Profissional a que se refere o item 34, alínea (g), que ofereçam cursos ao 
público em geral, deve ser considerado que no histórico apresentado conste, pelo menos, 2 
anos   de   experiência   em   desenvolvimento   de   eventos   de   treinamento   em   matérias 
relacionadas   às   Ciências   Contábeis   e/ou a   matérias   correlatas,   como   Economia, 
Administração, Tributos ou Finanças. (Incluído pela NBC PG 12 (R1)) 
 
6A. No   processo   de   avaliação   e   credenciamento   de   entidades   de   especialização   ou 
desenvolvimento profissional a que se refere o item 34, alínea (g), que ofereçam cursos ao 
público em geral, deve ser considerado que no histórico apresentado conste, pelo menos, 2 
anos   de   experiência   em   desenvolvimento   de   eventos   de   treinamento   em   matérias 
relacionadas   às   Ciências   Contábeis   e/ou   a   matérias   correlatas,   como Economia, 

Administração,   Tributos   ou   Finanças,   ou que   tenha   em   seu   quadro   de   instrutores 
profissionais com notório saber. (Alterado pela Revisão NBC 02) 
6B. O  Sistema  CFC/CRCs  poderá  realizar  o  credenciamento  direto  de  cursos  e  eventos,  antes 
da  sua  realização,  conforme  os  prazos  e  demais  exigências  contidas  nesta  Norma, 
promovidos por entidades de renome nacional e internacional, que executem atividades em 
consonância com os objetivos do PEPC. (Incluído pela Revisão NBC 08) 
 
7. Os  cursos  e  os  eventos  já  credenciados  e  homologados  pela  CEPC-CFC,  oferecidos por 
capacitadoras,    desde    que    preservem    as    características    anteriormente    aprovadas 
(programação,  carga  horária,  instrutores),  mantêm  a  pontuação  que  lhes  foram  atribuídas, 
independentemente da unidade da Federação em que forem ministrados.  
 
7. Os  cursos  e os  eventos  já  credenciados  e  homologados  pela  CEPC/CFC,  oferecidos  por 
capacitadoras,    desde    que    preservem    as    características    anteriormente    aprovadas 
(programação,  carga  horária,  instrutores),  mantêm  a  pontuação  que  lhes  foi  atribuída, 
independentemente  da unidade  da  Federação  em  que  forem  ministrados. (Alterado  pela  NBC 
PG 12 (R1)) 
 
7. Os   cursos   e   os   eventos   já   credenciados   e   homologados   pela   CEPC/CFC e   pela 
CEPC/CRCs    dos    Conselhos    Regionais    que    possuem    autonomia,    oferecidos    por 
capacitadoras,    desde    que    preservem    as    características    anteriormente    aprovadas 
(programação,  carga  horária,  instrutores),  mantêm  a  pontuação  que  lhes  foi  atribuída, 
independentemente da unidade da Federação em que forem ministrados. (Alterado pela Revisão 
NBC 02) 
 
7A.  É vedada a modificação de carga horária e conteúdo programático de curso já credenciado. 
(Incluído pela Revisão NBC 05) 
 
8. A CEPC-CRC deve efetuar avaliação prévia da qualificação ou preenchimento de requisitos 
da capacitadora com relação ao cumprimento das exigências desta Norma e da pontuação 
dos cursos e dos eventos, enviando o seu parecer à CEPC-CFC para homologação. O CRC 
deve comunicar a decisão à capacitadora. 
 
8.  A CEPC/CRC deve efetuar avaliação prévia da qualificação ou preenchimento de requisitos 
da capacitadora com relação ao cumprimento das exigências desta norma, enviando o seu 
parecer   à   CEPC/CFC,   para   homologação.   O   CRC   deve   comunicar   a   decisão   à 
capacitadora. (Alterado pela NBC PG 12 (R1)) 
 
9. Para  credenciamento  dos  cursos  ou  eventos  realizados a distância,  são  exigidas  as 
seguintes características mínimas: 
9. Para  credenciamento  dos  cursos  ou  eventos  realizados  na  modalidade  “a  distância”  ou 
“mista”,  são  exigidas  as  seguintes  características  mínimas.  Considera-se  aquisição  de 
conhecimento as atividades presenciais, a distância ou mistas, incluindo autoestudo, estudo 
dirigido, e-learning e  equivalentes,  sobre  temas  que  contribuam  para  a  melhoria  da 
performance do profissional, com conteúdo de natureza técnica e profissional, relacionados 
ao PEPC: (Alterado pela Revisão NBC 02) 
(a) especificação da forma de funcionamento; 
(b) especificação  dos  recursos  que  serão  utilizados  (exemplo:  existência de  fórum,  tutoria 
para esclarecimento de dúvidas, metodologia, entre outros); 
(c) comprovação de aquisição de conhecimentos. 
(c)  controle  de  frequência    ou  comprovação  de  aquisição  de  conhecimentos. (Alterado  pela 
Revisão NBC 08) 
 
10. Para  credenciamento  dos  cursos  realizados  na  modalidade “Autoestudo”,  é  exigido  o 
aproveitamento de, no mínimo, 75% (setenta e cinco por cento). 
10. Para  credenciamento  dos  cursos  que  não  sejam  “online”,  ou  seja,  realizados  nas 
modalidades “Autoestudo”, e-learning  ou  estudo  dirigido,    ou  seja,  aqueles  caracterizados 
pela  ausência  de  interação  com  o  instrutor,  acessados  a  partir  de  gravações,  é  exigida  a 

comprovação  de  aquisição  de  conhecimento  com  o  aproveitamento  de,  no  mínimo,  75% 
(setenta e cinco por cento). (Alterado pela Revisão NBC 08) 
 
Atividade Frequência 
mínima 
Aproveitamento 
mínimo 
Cursos 
presenciais 
75% 75% quando exigido 
pela capacitadora 
Cursos a 
distância 
75% 75% 
Eventos 
presenciais 
75% 75% quando exigido 
pela capacitadora 
Eventos a 
distância 
75% 75% 
 
 
11. Uma vez atendidos os critérios mínimos de avaliação e frequência, as capacitadoras devem 
emitir   aos   participantes   atestados,   diplomas,   certificados   ou   documento   equivalente, 
contendo, no mínimo, as seguintes informações: 
(a) nome da capacitadora; 
(b) nome e número de registro do participante no CRC; 
(b) nome e número de CPF; (Alterado pela Revisão NBC 08) 
(c) nome do curso ou evento e período de realização; (d) duração em horas; 
(e) especificação dos pontos válidos, conforme homologado pela CEPC/CFC; e 
(f)    assinatura  do  diretor  ou  do  representante  legal  da  capacitadora. (Incluída  pela  NBC  PG  12 
(R2)) 
 
Documentação para controle e fiscalização 
 
12. Os   CRCs   devem   manter   à   disposição   dos   interessados   a   relação   atualizada   das 
capacitadoras e dos respectivos cursos e eventos credenciados, no website, quando abertos 
ao público em geral. 
12. Os   CRCs   devem   manter   à   disposição   dos interessados   a   relação   atualizada   das 
capacitadoras  e  dos  respectivos  cursos  e  eventos  credenciados,  no  Sistema  Web  EPC, 
quando abertos ao público em geral. (Alterado pela Revisão NBC 08) 
 
13.  Para os cursos e, no que couber, para os eventos, a capacitadora deve manter em arquivo, 
pelo prazo mínimo de 5 (cinco) anos, os seguintes documentos: 
(a)  processo de credenciamento e realização da atividade. Documentação da apresentação 
do  tema,  programa,  metodologia,  recursos  de  apoio,  bibliografia  e  currículo  do(s) 
instrutor(es), em conformidade com o que foi aprovado pela CEPC/CFC; 
(b) lista de participantes inscritos e listas de presença; 
(b)  listas de presença assinada pelos participantes; (Alterada pela NBC PG 12 (R2)) 
(b)  controle  de  presença  dos  participantes,  tais  como:  listas  de  presenças  assinadas, 
relatórios de sistema; (Alterado pela Revisão NBC 08) 
(c) formulários de avaliação preenchidos pelos participantes; (Eliminada pela NBC PG 12 (R1)) 
(d) nos casos de ensino a distância e autoestudo, devem ser observados os procedimentos 
desta norma e mantidos os seguintes documentos: 
(d) nos  casos  de  ensino  a  distância  ou  misto  e  autoestudo,  devem  ser  observados  os 
procedimentos  desta  norma  e  mantidos  os  seguintes  documentos: (Alterada  pela  Revisão 
NBC 02) 
(d)  nos casos de ensino a distância ou misto, autoestudo e on-line, devem ser observados 
os  procedimentos  desta  Norma  e  mantidos  os  seguintes  documentos: (Alterado  pela 
Revisão NBC 08) 
 
(i) manter  em  arquivo  a norma  escrita  dos  procedimentos  de  cadastramento  do 
participante,   controle   de   inscrição,   emissão   de   senha   de   acesso   e   controle 
eletrônico de entrada e saída do sistema (“logs”); 

 (ii) nas normas escritas, devem ser tratados assuntos como: 
1. forma de funcionamento; 
2. recursos  utilizados  (exemplo:  existência  de fóruns,  tutoria  para  esclarecimento 
de dúvidas, metodologia, entre outros); 
3. comprovação   de   aquisição   de   conhecimento.   Manter   em   arquivo   o(s) 
comprovante(s) (“logs”) de acesso do participante ou qualquer outro documento 
que  certifique  à  capacitadora  que  o  participante esteve “conectado” durante as 
etapas necessárias. 
 
Documentação dos diplomas e certificados 
 
14. A  capacitadora  deve  manter  em  arquivo,  pelo  prazo  mínimo  de  5  (cinco)  anos,  cópia  em 
papel  ou  arquivo  digital  dos  atestados,  diplomas,  certificados ou  documento  equivalente, 
contendo, no mínimo, as seguintes informações: 
(a) nome da capacitadora e número de registro no CFC/CRCs; 
(b) nome do participante e número de seu respectivo registro no CRC; 
(c) nome do expositor e assinatura do diretor ou do representante legal da capacitadora; 
(d) nome do curso e período de realização; 
(e) avaliação do curso pelos participantes; 
(f) duração, em horas; 
(g) especificação dos pontos válidos, conforme homologado pela CEPC/CFC. 
 
15. A CEPC/CRC deve manter um processo para cada capacitadora credenciada, contendo: 
(a) a  documentação  apresentada  para  o  credenciamento  como  capacitadora,  bem  como 
dos cursos e dos eventos, de acordo com os dados inseridos no sistema web; 
(b) parecer da CEPC/CRC; 
(c) parecer da CEPC/CFC; 
(d) cópia da comunicação da decisão; 
(e) relatórios anuais dos cursos ministrados; 
(f) relatório do processo de fiscalização do CRC; 
(f)  relatório de diligência e de documentos colhidos por fiscal do CRC, quando houver, bem 
como da decisão do processo administrativo; (Alterada pela NBC PG 12 (R2)) 
(g)   comunicados   recebidos   e   encaminhados   à   capacitadora   e   outros   documentos 
relacionados ao processo. 
 
 
 
ANEXO II 
TABELAS DE PONTUAÇÃO 
Tabela I – Aquisição de conhecimento 
(observar a determinação contida no item 9 desta Norma) 
Natureza Características Requisitos Atribuição de pontos 
Cursos internos ou externos, 
treinamentos internos e 
reuniões técnicas internas 
das firmas de auditoria 
credenciados (presenciais, a 
distância ou mistos) 
Cursos  que  contribuam  para  a  melhoria 
da performance, com    conteúdo    de 
natureza técnica e profissional, 
relacionados  ao  Programa  de  Educação 
Profissional Continuada. 
 
Cada  hora  vale  1  (um) 
ponto. 
Cursos    de    pós-graduação 
(lato  sensu  e  stricto  sensu) 
oferecidos por IES 
registradas no MEC 
Cursos que  contribuam  para  a  melhoria 
da   performance   do   profissional, com 
conteúdo de natureza técnica e 
profissional, relacionados  ao  Programa 
de Educação Profissional Continuada. 
Mínimo   de   360 
(trezentas e 
sessenta) horas-
aula 
 
5 (cinco) pontos   por 
disciplina concluída. 
 

Demais   cursos e   palestras 
credenciadas  (presenciais  e 
a distância) 
 
Cursos  que  contribuam  para  a  melhoria 
da   performance   do   profissional, com 
conteúdo de natureza técnica e 
profissional, relacionados  ao  Programa 
de Educação Profissional Continuada. 
 
Cada  hora  vale (1) um 
ponto. 
Autoestudo credenciado 
(presenciais, a distância  ou 
mistos) 
Considera-se   o   estudo   dirigido, com 
conteúdo    e    referência    bibliográfica 
indicados pela capacitadora, exigindo-se 
aproveitamento mínimo de 75% (setenta 
e  cinco  por  cento) obtido por  meio  de 
objeto formal  de  avaliação  (instrumento 
presencial ou virtual). 
 
Máximo  de  4  (quatro) 
pontos por curso, 
limitado  a 15 (quinze) 
pontos por ano. 
 
Eventos credenciados, 
como: conferências, 
seminários,  fóruns,  debates, 
encontros, reuniões técnicas, 
painéis, congressos, 
convenções, simpósios 
nacionais e internacionais. 
Eventos que contribuam para a melhoria 
da   performance   do   profissional, com 
conteúdo     de     natureza     técnica e 
profissional, relacionados ao  Programa 
de Educação Profissional Continuada. 
 
Cada  hora  vale 1  (um) 
ponto, limitado   a   15 
(quinze) pontos    por 
evento. 
 
Tabela I – Aquisição de conhecimento (Alterada pela NBC PG 12 (R1)) 
(observar a determinação contida no item 7 desta norma) 
Natureza Características Requisitos 
Atribuição de 
pontos 
Cursos e treinamentos 
internos e reuniões 
técnicas internas das 
firmas de auditoria 
credenciadas 
Cursos e treinamentos 
internos e reuniões 
técnicas internas das 
organizações contábeis 
credenciadas (firmas de 
auditoria independente, 
escritórios contábeis e 
empresas de perícia 
contábil) (Alterado pela 
Revisão NBC 02) 
 
Cursos    que    contribuam    para    a 
melhoria    da performance,    com 
conteúdo   de   natureza   técnica   e 
profissional, relacionados ao PEPC. 
Cursos  a  distância 
por    meio    virtual 
e/ou presencial 
Cursos presenciais 
e/ou    a    distância 
(Alterado  pela  NBC  PG 
12 (R3)) 
Cursos 
presenciais, a 
distância ou 
mistos. (Alterado pela 
Revisão NBC 02) 
1  (um)  ponto  por 
hora. 
Demais cursos e 
palestras credenciadas  
Temas    que    contribuam    para    a 
melhoria da performance do 
profissional, com     conteúdo     de 
natureza    técnica    e    profissional, 
relacionados ao PEPC. 
Cursos e  palestras 
presenciais  e/ou a 
distância 
Cursos e  palestras 
presenciais, a 
distância ou 
mistos. (Alterado pela 
Revisão NBC 02) 
 1  (um)  ponto  por 
hora. 

Cursos de pós-graduação 
(lato    sensu e stricto 
sensu) oferecidos    por 
IES,     reconhecidos no 
MEC 
Cursos  de  graduação  e 
pós-graduação (lato 
sensu e stricto   sensu) 
oferecidos por IES, 
reconhecidos    no    MEC 
(Alterado pela Revisão NBC 02) 
 
Disciplinas  que  contribuam  para  a 
melhoria da performance do 
profissional,    com    conteúdo    de 
natureza    técnica    e    profissional, 
relacionadas ao PEPC. 
Mínimo    de    360 
(trezentos e 
sessenta)     horas-
aula 
 
10   (dez)   pontos 
por disciplina 
concluída. A 
comprovação 
deve ser     feita 
pelo    profissional 
mediante a 
apresentação de 
declaração, 
emitida  pela  IES, 
das disciplinas 
concluídas no 
ano. 
1     ponto     por 
hora,  limitado  a 
10  (dez)  pontos 
por disciplina 
concluída    com 
aprovação. A 
comprovação 
deve   ser   feita 
pelo profissional 
mediante a 
apresentação 
de   declaração, 
emitida pela 
IES, das 
disciplinas 
concluídas     no 
ano. (Alterado  pela 
Revisão NBC 02) 
Autoestudo credenciado 
Considera-se   o   estudo   dirigido,   com 
conteúdo    e    referência    bibliográfica 
indicados   pela   capacitadora,   quando 
houver  a  exigência  do  aproveitamento 
mínimo  de  75%  (setenta  e  cinco  por 
cento), obtido por meio de objeto formal 
de  avaliação  (instrumento  presencial  ou 
virtual). 
Considera-se   o   estudo   dirigido,   com 
conteúdo    e    referência    bibliográfica 
indicados  pelas  capacitadoras,  quando 
houver  a  exigência  do  aproveitamento 
mínimo  de  75%  (setenta  e  cinco  por 
cento), obtido por meio de objeto formal 
de  avaliação  (instrumento  presencial  ou 
virtual). (Alterado pela NBC PG 12 (R2)) 
Cursos    a    distância 
por meio virtual e/ou 
presencial 
Máximo de 4 
(quatro)  pontos  por 
curso, limitado a 20 
(vinte)   pontos   por 
ano. 
 
Autoestudo credenciado 
Considera-se autoestudo, o 
aprendizado    sem    interação    de 
facilitadores,  em  que  o  profissional 
aprende  por  meio  de  material  de 
estudo dirigido (impresso ou online), 
e,  ao  final  do  processo  realiza  uma 
prova   (com,   no   mínimo,   75%   de 
acertos   para   aprovação). (Alterado 
pela NBC PG 12 (R3)) 
Cursos  a  distância 
por    meio    virtual 
(Alterado  pela  NBC  PG 
12 (R3)) 
1  (um)  ponto  por 
hora. (Alterado  pela 
NBC PG 12 (R3)) 
1 (um)  ponto  por 
hora concluída 
com    aprovação. 
(Alterado pela 
Revisão NBC 02) 
 

Eventos credenciados, 
como: conferências; 
seminários; fóruns; 
debates; encontros; 
reuniões técnicas; 
painéis; congressos; 
convenções; simpósios 
nacionais e 
internacionais. 
Eventos   que   contribuam   para   a 
melhoria da performance do 
profissional,     com     conteúdo     de 
natureza    técnica    e    profissional, 
relacionados ao PEPC. 
Eventos 
presenciais   ou   a 
distância com 
controle de 
frequência. 
Eventos 
presenciais, a 
distância ou 
mistos com 
controle de 
frequência. 
(Alterado  pela  Revisão 
NBC 02) 
1     (um) ponto, 
limitado a 20 
(vinte)  pontos  por 
evento. 
 
Tabela I – Aquisição de conhecimento (observar a 
determinação contida no item 7 desta Norma). (Alterado pela 
Revisão NBC 08) 
Natureza Características Requisitos 
Atribuição de 
pontos 
 
 
 
Cursos   e   treinamentos 
internos e reuniões 
técnicas    internas    das 
organizações   contábeis 
credenciadas  (firmas  de 
auditoria   independente, 
escritórios   contábeis   e 
empresas     de     perícia 
contábil). 
 
 
 
Cursos e eventos que 
contribuam  para  a  melhoria  da 
performance,  com  conteúdo  de 
natureza  técnica  e  profissional, 
relacionados ao PEPC. 
 
 
 
Cursos e 
eventos 
presenciais, a 
distância ou 
mistos. 
 
 
 
 
1   (um)   ponto 
por hora. 
 
 
Demais cursos e 
palestras 
credenciadas. 
 
Temas  que  contribuam  para  a 
melhoria    da performance do 
profissional,   com   conteúdo   de 
natureza  técnica  e  profissional, 
relacionados ao PEPC. 
Cursos e 
palestras 
presenciais,       a 
distância ou 
mistos. 
 
 
1   (um)   ponto 
por hora. 

 
 
 
 
 
 
 
 
 
 
 
 
Cursos de graduação e 
pós-graduação (lato 
sensu e stricto sensu) 
oferecidos     por IES, 
reconhecidos pelo 
MEC.  
Disciplinas que contribuam para a 
melhoria    da performance do 
profissional,   com   conteúdo   de 
natureza   técnica   e   profissional, 
relacionadas ao PEPC. 
Mínimo   de 360 
(trezentos e 
sessenta) horas- 
aula. 
10  (dez) pontos 
por   disciplina 
concluída no 
ano com 
aprovação.   A 
comprovação 
deve   ser feita 
pelo profissional 
mediante   a 
apresentação 
de  declaração, 
emitida pela 
IES, das 
disciplinas 
concluídas no 
ano. 
 
 
 
 
 
Autoestudo 
credenciado. 
Considera-se autoestudo, o 
aprendizado   sem   interação   de 
facilitadores, em que o 
profissional aprende por meio de 
material     de     estudo     dirigido 
(impresso  ou  on-line),  e,  ao  final 
do  processo,  realiza  uma  prova 
(com, no mínimo, 75% de 
acertos para aprovação).  
 
 
 
Cursos a 
distância por 
meio virtual. 
 
 
1    (um)    ponto 
por hora 
concluída    com 
aprovação. 
 
 
Eventos  credenciados, 
como: conferências, 
seminários, fóruns, 
debates, encontros, 
painéis, congressos, 
convenções,   simpósios 
nacionais e 
internacionais. 
 
 
 
Eventos  que  contribuam  para  a 
melhoria    da performance do 
profissional, com   conteúdo   de 
natureza  técnica  e  profissional, 
relacionados ao PEPC. 
Eventos 
presenciais, a 
distância ou 
mistos com 
controle de 
frequência. 
 
 
 
 
 
1   (um)   ponto, 
limitado    a    20 
(vinte) pontos 
por evento. 
 
 
 

Tabela II – Docência 
A comprovação de docência deve ser feita mediante apresentação de declaração emitida 
por Instituição de Ensino Superior (IES), contendo disciplina, ementa, carga horária e 
período de realização. 
Natureza Características Atribuição de Pontos 
Pós-graduação (lato sensu e stricto 
sensu) 
Disciplinas  relacionadas  ao  PEPC 
ministradas   por Instituições de 
Ensino Superior credenciadas pelo 
MEC. 
5   (cinco)   pontos   por   disciplina 
ministrada no ano. 
Observação: A disciplina 
ministrada  em  mais  de  uma  turma, 
independente   da instituição e   do 
semestre  letivo, é computada  uma 
única vez no ano. 
Graduação e cursos de extensão 
Cursos ou eventos credenciados 
Participação  como  conferencista, 
palestrante,  painelista,  instrutor  e 
facilitador em eventos nacionais e 
internacionais. 
 
Cada hora vale 1 (um) ponto, 
limitado a 20 (vinte) pontos anuais 
 
 
Tabela II – Docência (Alterada pela NBC PG 12 (R1)) 
A comprovação de docência deve ser feita mediante apresentação de declaração 
emitida por Instituição de Ensino Superior (IES), contendo disciplina, ementa, carga 
horária e período de realização. 
A atribuição total de pontos para a atividade de docência é limitada 
a 20 (vinte) pontos por ano 
Natureza Características Atribuição de Pontos 
Pós-graduação (lato sensu e 
stricto sensu) 
Disciplinas    relacionadas    ao 
PEPC    ministradas    por    IES 
credenciada pelo MEC. 
10   (dez)   pontos   por   disciplina 
ministrada no ano. 
Observação: A disciplina 
ministrada em mais de uma turma, 
independentemente  da  instituição 
e do semestre letivo, é computada 
uma vez no ano. 
1 ponto por hora, limitado a 10 
(dez) pontos por disciplina 
ministrada no ano. 
Observação: A disciplina 
ministrada em mais de uma turma, 
independentemente  da  instituição 
e do semestre letivo, é computada 
uma   vez   no   ano. (Alterado    pela 
Revisão NBC 02) 
Graduação e cursos de extensão 
Graduação. (Alterado pela Revisão 
NBC 05) 
Cursos ou eventos credenciados 
Cursos, inclusive de extensão, 
ou eventos credenciados. 
(Alterado pela Revisão NBC 05)  
Participação como 
conferencista, palestrante, 
painelista, instrutor e facilitador 
em eventos nacionais e 
internacionais. 
 
1 (um) ponto por hora. 
 
 
 
 
 

Tabela III – Atuação como participante 
A comprovação deve ser feita mediante a apresentação de documentação.    
Natureza Características Requisitos Atribuição de Pontos 
 
 
Comissões 
Técnicas e 
Profissionais  no 
Brasil     ou     no 
exterior. 
 
Temas    relacionados    à    Contabilidade,    à 
Auditoria e às normas da profissão contábil: 
(a) Comissões  Técnicas  e  de  Pesquisa  do 
CFC, dos CRCs, do Ibracon, da FBC, da 
Abracicon e outros órgãos reguladores. 
(b) Comissões  Técnicas  e  de  Pesquisa  de 
instituições de reconhecido prestígio. 
(c) Comissões, órgãos     e comitês     de 
orientações  ao  mercado  de  companhias 
abertas. 
 
 
12 (doze) 
meses ou 
proporção. 
 
 
 
Cada  hora  vale  1 (um) ponto, 
limitado a 20 (vinte) pontos por 
ano. 
 
Orientação de 
tese,  dissertação 
ou monografia 
Temas relacionados à Contabilidade, à 
Auditoria e às normas da profissão contábil:  
(a) Doutorado 
(b) Mestrado 
(c) Especialização 
(d) Bacharelado 
 
 
Trabalho 
aprovado 
 
 
(a) 10 (dez) pontos. 
(b) 7 (sete) pontos. 
(c) 4 (quatro) pontos. 
(d) 3 (três) pontos. 
 
Limitado  a  20 (vinte) pontos 
por ano. 
Participação  em 
bancas 
acadêmicas 
Temas relacionados à Contabilidade, à 
Auditoria e às normas da profissão contábil:  
(a) Doutorado 
(b) Mestrado 
 
Trabalho 
aprovado 
 
 
(a) 5 (cinco) pontos. 
(b) 3 (três) pontos.   
 
Limitado a 10 (dez) pontos por 
ano. 
 
Tabela III – Atuação como participante (Alterada pela NBC PG 12 (R1)) 
A atribuição total de pontos para atuação como participante é limitada 
a 20 (vinte) pontos por ano   
A comprovação deve ser feita mediante a apresentação de documentação.    
Natureza Características Requisitos Atribuição de Pontos 
 
 
Comissões 
Técnicas e 
Profissionais 
no Brasil ou no 
exterior. 
Comissões 
Técnicas e 
Profissionais; 
grupos de 
estudo no 
Brasil   ou   no 
exterior. 
(Alterado pela 
Revisão NBC 02) 
 
 
Temas  relacionados  à  Contabilidade,  à 
Auditoria   e   às   normas   da   profissão 
contábil: 
Temas  relacionados  à  Contabilidade,  à 
Auditoria,   à   Perícia   e   às   normas   da 
profissão  contábil: (Alterado  pela  NBC  PG  12 
(R2)) 
(a) Comissões  Técnicas  e  de  Pesquisa 
do  CFC,  dos  CRCs,  do  Ibracon,  da 
FBC,  da  Abracicon  e  outros  órgãos 
reguladores. 
(b) Comissões  Técnicas  e  de  Pesquisa 
de     instituições     de     reconhecido 
prestígio. 
(c) Comissões,   órgãos   e   comitês   de 
orientações ao mercado de 
companhias abertas. 
 
 
12 (doze) 
meses ou 
proporção.  
 
 
1 (um) ponto por hora.  
Orientação   de 
tese, 
dissertação  ou 
monografia. 
Orientação   de 
Temas relacionados à Contabilidade, à 
Auditoria e às normas da profissão 
contábil:  
Temas relacionados à Contabilidade, à 
Auditoria, à Perícia e às normas da 
 
Trabalho 
aprovado. 
Por 
trabalho. 
 
 
(a) 10 (dez) pontos. 
(b) 7 (sete) pontos. 
(c) 4 (quatro) pontos. 

tese, 
dissertação, 
monografia  ou 
artigo 
científico. 
(Alterado pela 
Revisão NBC 05) 
profissão contábil: (Alterado pela NBC PG 12 
(R2)) 
(a) Doutorado 
(b) Mestrado 
(c) Especialização 
(d) Bacharelado 
 
(Alterado    pela 
Revisão     NBC 
05) 
(d) 3 (três) pontos. 
 
. 
Participação 
em bancas 
acadêmicas 
Temas relacionados à Contabilidade, à 
Auditoria e às normas da profissão 
contábil:  
Temas relacionados à Contabilidade, à 
Auditoria, à Perícia e às normas da 
profissão contábil: (Alterado pela NBC PG 12 
(R2)) 
(a) Doutorado 
(b) Mestrado 
 
Trabalho 
aprovado 
 
 
(a) 5 (cinco) pontos. 
(b) 3 (três) pontos.   
 
Limitado a 10 (dez) pontos 
por ano. (Eliminado pela Revisão 
NBC 02) 
 
Tabela III – Atuação como participante. A atribuição total de pontos 
para atuação como participante é limitada a 20 (vinte) pontos por ano. 
(Alterado pela Revisão NBC 08) 
A comprovação deve ser feita mediante a apresentação de documentação. 
Natureza Características Requisitos Atribuição de 
pontos 
 
 
 
Temas relacionados à 
Contabilidade, à Auditoria, à Perícia 
e às normas da profissão contábil: 
  
(a)   Comissões   Técnicas   e   de 
Pesquisa  do  CFC,  dos CRCs,  do 
Ibracon,  da  FBC,  da  Abracicon  e 
de órgãos reguladores. 
  (b)    Comissões    Técnicas    e    de 
Pesquisa de instituições de 
reconhecido   prestígio,   tais   como: 
Fenacon, Sescon/Sescap e 
academias estaduais de 
contabilidade.  
(c)  Comissões,  órgãos  e  comitês 
de orientações   ao   mercado de 
companhias abertas. 
 
 
 
 
 
 
 
 
 
12 (doze) 
meses ou 
proporção. 
 
 
 
 
 
 
 
 
 
Comissões 
 
Técnicas e 
 
Profissionais, 
grupos de 
1 (um) ponto por hora. 
estudo no 
 
Brasil ou no 
 
exterior. 
 
 
 
 
 
Orientação  de 
tese, 
dissertação, 
monografia ou 
artigo 
científico. 
Temas relacionados à 
Contabilidade,     à     Auditoria,     à 
Perícia  e  às  normas  da  profissão 
contábil:  
 
(a) Doutorado. 
(b) Mestrado. 
(c) Especialização. 
(d) Bacharelado. 
 
 
 
Por trabalho.  
 
 
(a) 10 (dez) pontos. 
(b) 7 (sete) pontos. 
(c) 4 (quatro) pontos. 
(d) 3 (três) pontos. 
 
 

Participação 
em bancas 
acadêmicas. 
Temas relacionados à 
Contabilidade,     à     Auditoria,     à 
Perícia  e  às  normas  da  profissão 
contábil:  
 
(a) Doutorado. 
(b) Mestrado. 
 
 
 
Trabalho 
aprovado. 
 
 
(a) 5 (cinco) pontos. 
(b) 3 (três) pontos. 
 
Limitado    a    10 (dez) 
pontos.  
 
Tabela IV – Produção Intelectual 
 A atribuição total de pontos da produção intelectual é limitada  
a 20 (vinte) pontos por ano 
Natureza Características Atribuição de Pontos 
Publicação de  artigos  em 
jornais    e    em    revistas 
nacionais e 
internacionais,   de   forma 
impressa e eletrônica 
Matérias   relacionadas   à   Contabilidade,   à 
Auditoria e à profissão contábil homologadas 
pela CEPC-CFC. 
Até 3 (três) pontos por matéria. 
Artigos  técnicos  publicados  em  revista  ou 
jornal  de  circulação  nacional  e  internacional 
e homologados pela CEPC-CFC. 
Até 7 (sete) pontos por artigo. 
Estudos  ou  trabalhos  de 
pesquisa técnica 
Apresentação  em  congressos  internacionais 
relacionados à  Contabilidade, à auditoria  e  à 
profissão e aprovados pela CEPC-CFC. 
Até  10 (dez) pontos  por  estudo  ou 
trabalho. 
Apresentação  em  congresso  ou  convenções 
nacionais   relacionados   à   Contabilidade,   à 
auditoria  e  à  profissão  contábil  e  que  façam 
parte do PEPC reconhecido pela CEPC-CFC. 
Até  15 (quinze) pontos  por  estudo 
ou trabalho. 
Autoria de livros 
Autoria  de  livros  publicados  relacionados  à 
Contabilidade,   à auditoria   e   à   profissão 
contábil. 
Até 20 (vinte) pontos por obra. 
Coautoria de livros 
Coautoria  de  livros  publicados  relacionados 
à  Contabilidade,  à auditoria  e  à  profissão 
contábil. 
Até 10 (dez) pontos por obra. 
Tradução de livros 
Tradução  e  adaptação  de  livros  publicados 
no  exterior,  relacionados  à  Contabilidade,  à 
auditoria  e à profissão  contábil, aprovados 
pela CEPC-CFC. 
Até 10 (dez) pontos por obra. 
 
Tabela IV – Produção Intelectual (Alterada pela NBC PG 12 (R1)) 
 A atribuição total de pontos da produção intelectual é limitada  
a 20 (vinte) pontos por ano 
Natureza Características Atribuição de Pontos 
Publicação,  no  exercício, 
de  artigos  em  jornais  e 
em  revistas  nacionais  e 
internacionais,  de  forma 
impressa e eletrônica 
Matérias   relacionadas   à   Contabilidade,   à 
Auditoria e à profissão contábil 
homologadas pela CEPC/CFC. 
Matérias   relacionadas   à   Contabilidade,   à 
Auditoria,  à  Perícia e  à  profissão  contábil 
homologadas  pela  CEPC/CFC. (Alterado  pela 
NBC PG 12 (R2)) 
Matérias e artigos relacionados à 
Contabilidade,  à  Auditoria,  à  Perícia  e  à 
profissão contábil homologados pela 
Até   3   (três)   pontos   por 
matéria. 

CEPC/CFC. (Alterado pela Revisão NBC 02) 
Artigos  técnicos  publicados  em  revista  ou 
jornal  de circulação nacional e  internacional 
e homologados pela CEPC/CFC. 
Artigos    técnicos    publicados    em    revista 
qualificada    pela    CAPES    ou    jornal    de 
circulação    nacional    e    internacional    e 
homologados pela  CEPC/CFC. (Alterado  pela 
Revisão NBC 02) 
Até   7 (sete)   pontos   por 
artigo. 
Apresentação, no 
exercício,  de  estudos ou 
trabalhos    de    pesquisa 
técnica. 
Apresentação, no 
exercício,  de  estudos  ou 
trabalhos    de    pesquisa 
técnica e tese, 
dissertação ou 
monografias   aprovadas. 
(Alterado   pela   Revisão   NBC 
05) 
Participação em  congressos  internacionais 
relacionados  à  Contabilidade,  à  Auditoria  e 
à profissão e aprovados pela CEPC/CFC. 
Participação em  congressos  internacionais 
relacionados  à  Contabilidade,  à  Auditoria,  à 
Perícia e   à   profissão   e   aprovados   pela 
CEPC/CFC. (Alterado pela NBC PG 12 (R2)) 
Até  10  (dez)  pontos  por 
estudo ou trabalho. 
Até 15 (quinze) pontos por 
estudo ou trabalho. 
(Alterado pela Revisão NBC 02) 
Participação em congressos ou convenções 
nacionais relacionados  à  Contabilidade,  à 
Auditoria e à profissão contábil e que façam 
parte do PEPC reconhecido pela 
CEPC/CFC. 
Participação em congressos ou convenções 
nacionais  relacionados  à  Contabilidade,  à 
Auditoria,  à  Perícia e  à  profissão  contábil  e 
que façam parte do PEPC reconhecido pela 
CEPC/CFC. (Alterado pela NBC PG 12 (R2)) 
Até 15 (quinze) pontos por 
estudo ou trabalho. 
Até  10  (dez)  pontos  por 
estudo ou trabalho. 
(Alterado pela Revisão NBC 02) 
Autoria de livros 
Autoria   de livro   publicado,   no   exercício, 
relacionados  à  Contabilidade,  à  Auditoria  e 
à    profissão    contábil,    reconhecido    pela 
CEPC/CFC. 
Autoria   de livro   publicado,   no   exercício, 
relacionados  à  Contabilidade,  à  Auditoria,  à 
Perícia e  à  profissão  contábil,  reconhecido 
pela CEPC/CFC. (Alterado pela NBC PG 12 (R2)) 
Até  20  (vinte)  pontos  por 
obra. 
Coautoria de livros 
Coautoria  de livro  publicado  no  exercício, 
relacionados  à  Contabilidade,  à  Auditoria  e 
à profissão contábil. 
Coautoria  de livro  publicado  no  exercício, 
relacionados  à  Contabilidade,  à  Auditoria,  à 
Perícia e  à  profissão  contábil. (Alterado  pela 
NBC PG 12 (R2)) 
Até  10  (dez)  pontos  por 
obra. 
Tradução de livros 
Tradução   e   adaptação,   no   exercício, de 
livros  publicados  no  exterior  relacionados  à 
Contabilidade,   à   Auditoria   e   à   profissão 
contábil, aprovados pela CEPC/CFC. 
Tradução   e   adaptação,   no   exercício,   de 
livros  publicados  no  exterior  relacionados  à 
Contabilidade,  à  Auditoria,  à  Perícia e  à 
profissão contábil, aprovados pela 
CEPC/CFC. (Alterado pela NBC PG 12 (R2)) 
Até  10  (dez)  pontos  por 
obra. 
 
 
Tabela IV – Produção Intelectual (Alterado pela Revisão NBC 08) 
A atribuição total de pontos da produção intelectual é limitada a 20 (vinte) pontos por ano 
Natureza Características Atribuição de pontos 

 
 
Publicação, no 
exercício,  de  artigos  em 
jornais   e   em   revistas 
nacionais e 
internacionais,  de  forma 
impressa e eletrônica. 
 
Matérias     e     artigos    relacionados     à 
Contabilidade,    à    Auditoria,    à 
Perícia   e   à   profissão   contábil, 
homologados pela CEPC/CFC.  
 
Até    3    (três)    pontos    por 
matéria. 
 
*  Artigos  técnicos/científicos  publicados 
em   revista   qualificada   pela   Capes   e 
homologados pela CEPC/CFC. 
a) Classificação A1 e A2. 
b) Classificação B1 a B5. 
c) Classificação C. 
 
Até   15   (quinze)   pontos   por 
artigo. 
 
a)   A1   e   A2   =   15   pontos. 
b)  B1 a B5 = 10 pontos.  
c) C = 5 pontos. 
 
 
 
Apresentação, no 
exercício, de estudos ou 
trabalhos   de   pesquisa 
técnica e tese, 
dissertação ou 
monografias aprovadas.  
Participação em congressos 
internacionais relacionados à 
Contabilidade,  à  Auditoria,  à  Perícia  e  à 
profissão e aprovados pela CEPC/CFC. 
 
Até   15   (quinze)   pontos   por 
estudo ou trabalho.  
 
Participação em congressos ou 
convenções   nacionais   relacionados   à 
Contabilidade,  à  Auditoria,  à  Perícia  e  à 
profissão  contábil  e  que  façam  parte  do 
PEPC reconhecido pela CEPC/CFC.  
 
Até    10    (dez)    pontos    por 
estudo ou trabalho.  
Tese, dissertação ou 
monografias aprovadas. 
Teses,    dissertações    ou    monografias 
aprovadas,     de     conclusão     de     pós-
graduação lato sensu ou stricto sensu. 
(a) Doutorado. 
(b) Mestrado. 
(c) Especialização. 
(d) Bacharelado. 
 
 
(a) 20 (vinte) pontos. 
(b) 14 (quatorze) pontos. 
(c) 6 (seis) pontos. 
(d) 4 (quatro) pontos. 
 
Autoria de livros. 
 
Autoria de livro publicado, no exercício, 
relacionado à Contabilidade, à Auditoria, 
à Perícia e à profissão contábil, 
reconhecido pela CEPC/CFC. 
 
Até 20 (vinte) pontos por 
obra. 

 
 
Coautoria de livros. 
 
Coautoria de livro publicado no exercício, 
relacionado à Contabilidade, à Auditoria, 
à Perícia e à profissão contábil. 
 
Até 10 (dez) pontos por obra. 
 
Tradução de livros. 
Tradução e adaptação, no exercício, de 
livros publicados no exterior, relacionados 
à Contabilidade, à Auditoria, à Perícia e à 
profissão contábil, aprovados 
pela CEPC/CFC. 
 
Até 10 (dez) pontos por obra. 
 
 
 
Observação: 
 
A  pontuação  resultante  da  conversão  das  horas  não  deve  apresentar  fracionamento  inferior  ou 
superior  a  meio  ponto (0,5).  Os  cálculos  decorrentes  do  número  de  horas  cumpridas  pelo 
profissional  devem  ser  “arredondados”  para  maior  ou  menor,  de  acordo  com  a  aproximação. 
(Eliminado pela Revisão NBC 08) 
 
A  CEPC/CFC  poderá emitir  orientação referente à pontuação  de cursos  e eventos por  meio de 
tabela específica de pontuação. (Incluído pela NBC PG 12 (R2)) (Eliminado pela Revisão NBC 02) 
 
 
ANEXO III (Eliminado pela Revisão NBC 05) 
RELATÓRIO DE ATIVIDADES 
 
PROGRAMA DE EDUCAÇÃO PROFISSIONAL CONTINUADA 
Nome:  
CRC Registro n.º 
Estado de origem:   
CPF n.º  
CNAI n.º 
CNPC n.º (Incluído pela NBC PG 12 (R2)) 
Endereço preferencial para comunicação ( ) Com. ( ) Res.:  
Rua/Av.:...................................................................................n.º..............Bairro:........................ 
Cidade:................................................UF:..................................CEP:.................... 
Telefones ( ) Com. ( ) Res.: .......................... Celular: ...........................  
E-mail: ......................................................... 
Função exercida: 
- hipóteses das alíneas (a), (b), (c), (d) e (e) do item 4 desta Norma 
   (  ) Sócio   (   ) Responsável Técnico  (   ) Direção ou Gerência Técnica  
 
- hipóteses das alíneas (a), (b), (c), (d) e (e) do item 4 da NBC PG 12 (R1)    (  ) Sócio   (   ) 
Responsável Técnico  (   ) Direção ou Gerência Técnica (Alterada pela NBC PG 12 (R1)) 
 

- hipóteses das alíneas (a), (b), (c), (d), (e) e (g)  do item 4 da NBC PG 12 (R1)    (  ) Sócio   (   ) 
Responsável Técnico  (   ) Direção ou Gerência Técnica (  ) Perito Contábil (Alterada pela NBC PG 12 (R2))   
 
- hipóteses da alínea (f) do item 4 desta Norma 
   (   ) Responsável Técnico  (   ) Gerente/Chefia na Área Contábil  
 
- hipóteses da alínea (f) do item 4 da NBC PG 12 (R1)  
   (   ) Responsável Técnico  (   ) Gerente/Chefia na Área Contábil (Alterada pela NBC PG 12 (R1)) 
 
- (    ) Realizei atividades de EPC mesmo não estando incluído em nenhuma das situações previstas 
no item 4 da NBC PG 12 (R1). (Incluída pela NBC PG 12 (R1)) 
 
Função exercida: 
 
AUDITORIA INDEPENDENTE: 
- hipóteses das alíneas (a), (b), (c) e (d) do item 4 desta norma: 
(   ) Auditor CNAI;  (   ) Sócio; (   ) Terceirizado firma de auditoria;  (   ) Diretor;  (   ) Gerente; (   ) 
Supervisor;    (   ) Responsável Técnico 
 
ORGANIZAÇÕES CONTÁBEIS QUE POSSUAM A TIVIDADE DE AUDITORIA NO OBJETO SOCIAL 
- hipótese da alínea (e) do item 4 desta norma: 
(   ) Sócio;   (   ) Diretor;  (   ) Gerente; (   ) Supervisor; (   ) Responsável Técnico 
 
DEMAIS ENTIDADES DE GRANDE PORTE E ENTIDADES SEM FINALIDADE DE LUCROS: 
- hipóteses da alínea (f) do item 4 desta norma: 
(   ) Resp. Técnico Demonstrações Contábeis; (   ) Diretor ; (   ) Chefe; (   ) Gerente; (   ) Supervisor   
 
SOCIEDADES E ENTIDADES SEM FINALIDADE DE LUCROS QUE TIVEREM, NO EXERCÍCIO 
SOCIAL ANTERIOR, RECEITA TOTAL, IGUAL OU SUPERIOR A R$ 78 MILHÕES: 
- hipótese da alínea (h) do item 4 desta norma: 
(   ) Resp. Técnico Demonstrações Contábeis. (Incluído pela Revisão NBC 02) 
 
PREVIC: 
- hipótese da alínea (i) do item 4 desta norma: 
(   ) Previc (Incluído pela Revisão NBC 02) 
 
PERITO CONTÁBIL: 
- hipótese da alínea (g) do item 4 desta norma: 
- hipótese da alínea (j) do item 4 desta norma: (Alterado pela Revisão NBC 02) 
 (   ) Perito (CNPC) 
 
VOLUNTÁRIO: 
(    ) Realizei atividades de EPC mesmo não estando incluído em nenhuma das situações previstas no 
item 4 desta norma. (Alterado pela NBC PG 12 (R3)) 
RELATÓRIO DE ATIVIDADES 
Exercício: 1º/1/............... a 31/12/............. 
I. AQUISIÇÃO DE CONHECIMENTOS 

CURSO/EVENTO CAPACITADORA N.º DA 
CAPACITADORA 
DATA OU 
PERÍODO 
CÓDIGO 
DO CURSO 
CRÉDITOS DE 
PONTOS 
            
            
II. DOCÊNCIA 
Atividade que necessita de apreciação para atribuição de pontuação. 
DISCIPLINA CAPACITADORA/ 
INSTITUIÇÃO DE 
ENSINO 
N.º DA 
CAPACITADORA  
DATA OU 
PERÍODO  
CÓDIGO 
DO CURSO 
CRÉDITOS DE 
PONTOS 
            
            
III. ATUAÇÃO COMO PARTICIPANTE (COMISSÕES TÉCNICAS E PROFISSIONAIS) 
Atividade que necessita de apreciação para atribuição de pontuação.  
COMISSÃO/ 
BANCA 
EXAMINADORA 
ENTIDADE 
DATA OU 
PERÍODO 
CRÉDITOS DE PONTOS 
        
        
IV. PRODUÇÃO INTELECTUAL (LIVROS, ARTIGOS E PESQUISAS)  
Atividade que necessita de apreciação para atribuição de pontuação. 
TÍTULO FONTE 
DATA 
PUBLICAÇÃO 
CRÉDITOS DE PONTOS  
        
        
TOTAL DE PONTOS: 
I. Aquisição de Conhecimento: 
II. Docência: 
III. Atuação como participante: 
IV. Produção intelectual: 
 
DECLARO SOB RESPONSABILIDADE QUE SÃO VERDADEIRAS AS INFORMAÇÕES CONTIDAS NESTE DOCUMENTO. 
 
 
...................................................... , .............., de ............................................... de 20XX 
 
 
Assinatura 
 

NORMA BRASILEIRA DE CONTABILIDADE, NBC PG 12 (R3), DE 24 DE NOVEMBRO 
DE 2017 
 
Altera a  NBC  PG  12 (R2) que dispõe 
sobre educação profissional continuada. 
 
 
O CONSELHO FEDERAL DE CONTABILIDADE, no exercício de suas atribuições 
legais  e  regimentais  e  com  fundamento  no disposto na alínea “f” do Art.  6º  do  Decreto-Lei  n.º 
9.295/1946,  alterado  pela  Lei  n.º  12.249/2010,  faz  saber  que  foi  aprovada  em  seu  Plenário  a 
alteração da seguinte Norma Brasileira de Contabilidade (NBC): 
 
1. Altera os itens 4, 13A, 17, 26, 30, 37 e 44; inclui o item 43A; e altera a Tabela I do Anexo 
II  e  o  Anexo  III na NBC  PG  12  (R2) – Educação  Profissional  Continuada,  conforme 
segue: 
 
4. A EPC é obrigatória para todos os profissionais da contabilidade que: 
(a) (...) 
(f)  sejam  responsáveis  técnicos  pelas  demonstrações  contábeis,  ou  que  exerçam  funções  de 
gerência/chefia  no  processo  de  elaboração  das  demonstrações  contábeis  das  empresas, 
reguladas  e/ou  supervisionadas  pela  CVM,  pelo  BCB,  pela  Susep,  pela  Previc,  e,  ainda,  das 
sociedades  consideradas  de  grande  porte  nos  termos  da  Lei  n.º  11.638/2007,  e  também  as 
entidades sem finalidade de lucros que se enquadrem nos limites monetários da citada lei; 
(g) (...) 
 
13A. No caso de enfermidades impeditivas do exercício profissional, por período superior a 3 
(três)   anos   consecutivos,   e   não   tendo   cumprido   a   pontuação   exigida   nesta   norma,   a 
CEPC/CFC pode determinar a baixa do CNAI e do CNPC. 
 
17. O cumprimento da pontuação exigida nesta norma, pelos profissionais referidos no item 4, 
deve  ser  comprovado  mediante  a  entrega  do  relatório  de  atividades  a  que  se  refere  o  Anexo 
III, no CRC de jurisdição do registro principal do profissional, até o dia 31 de janeiro do ano 
subsequente   ao   ano-base,   por   meio   digital   ou   impresso,   acompanhado   de   cópia   da 
documentação comprobatória das atividades, no que se refere ao disposto nas Tabelas I, II, III 
e IV do Anexo II desta norma, com exceção dos cursos e eventos credenciados. 
 
26. A CEPC/CFC tem as seguintes atribuições: 
(...) 
(g) compilar, anualmente, as informações de pontuação de cada um dos profissionais referidos 
no item 4, alíneas (a), (b), (c) e (d), recebidas dos CRCs, encaminhando-as à CVM até 30 de 
setembro de cada ano; 
 
30. A CEPC/CRC ou, na falta desta, a CDP do CRC têm as seguintes atribuições em relação a 
esta norma: 
(a) receber  os  pedidos  de  credenciamento  das  instituições  a  serem  reconhecidas  como 
capacitadoras,  os  pedidos  de  credenciamento  de  cursos,  eventos  ou  outras atividades,  bem 
como  atribuir  pontos  para  o  PEPC,  e  emitir  seu  parecer,  submetendo-o  à  apreciação  da 
CEPC/CFC depois de aprovado pela CDP e homologado pelo Plenário do CRC. Os CRCs que 
possuírem  representante  na  CEPC/CFC, bem  como  aqueles  que  possuírem  estrutura  para 
analisar  os  pedidos  de  credenciamento  de  cursos/eventos,  de  acordo  com  critérios  definidos 
pela CEPC-CFC, ficam dispensados de submeter seus pareceres à apreciação da CEPC/CFC, 

exceto quanto aos pedidos de credenciamento de capacitadora e eventos tais como congressos 
e convenções nacionais e internacionais; 
(b) (...) 
 
37.  Considera-se aquisição de conhecimento as atividades presenciais, a distância ou mistas, 
incluindo autoestudo, estudo dirigido, e-learning e equivalentes, sobre temas que contribuam 
para  a  melhoria  da performance do  profissional,  com  conteúdo  de  natureza  técnica  e 
profissional, relacionados ao PEPC, por meio de: 
(a) (...) 
(e) disciplinas  cursadas  em  outras  graduações  em  áreas  correlatas  ao  curso  de  Ciências 
Contábeis, tais  como: Administração,  Ciências  Atuariais,  Ciências  Econômicas,  Estatística, 
Tecnologia da Informação e Direito. 
 
43A.  No  exercício  em  que  os  profissionais  deixarem  de  se  enquadrar  no  item  4  ficam 
desobrigados  do  cumprimento  do  Programa  de  Educação  Profissional Continuada,  enquanto 
perdurar essa condição, devendo comunicar esta situação ao CRC de sua jurisdição. 
 
44.  A  baixa  prevista  no  item  43  e  as  providências  previstas  no  item  26,  alíneas  (g)  e  (j), 
somente  serão  adotadas  após  ser  assegurado  ao  profissional  o direito  ao  contraditório  e  à 
ampla  defesa  que  lhe  permita  justificar  o  não  cumprimento  das  obrigações  previstas  nesta 
norma. 
 
Em  razão  dessas  alterações,  as  disposições  não  alteradas  desta  norma  são  mantidas,  e  a  sigla  da 
NBC PG 12 (R2), publicada no DOU, Seção 1, de 21/12/2016, passa a ser NBC PG 12 (R3). 
 
As  alterações  desta  norma  entram  em  vigor  na  data  de  sua  publicação,  produzindo  seus  efeitos  a 
partir de 1º de janeiro de 2018. 
  
Brasília, 24 de novembro de 2017. 
 
 
Contador José Martonio Alves Coelho 
Presidente 
 
Ata CFC n.º 1.035. 
 
ANEXO II 
TABELAS DE PONTUAÇÃO 
Tabela I – Aquisição de conhecimento  
(observar a determinação contida no item 9 desta Norma) 
Natureza Características Requisitos 
Atribuição de 
pontos 
Cursos e treinamentos 
internos e reuniões 
técnicas internas das 
firmas de auditoria 
credenciadas  
Cursos    que    contribuam    para    a 
melhoria    da performance,    com 
conteúdo   de   natureza   técnica   e 
profissional, relacionados ao PEPC. 
Cursos 
presenciais e/ou 
a distância 
1   (um)   ponto   por 
hora. 

Demais cursos e palestras 
credenciadas  
Temas    que    contribuam    para    a 
melhoria da performance do 
profissional,    com    conteúdo    de 
natureza    técnica    e    profissional, 
relacionados ao PEPC. 
Cursos e 
palestras 
presenciais e/ou 
a distância 
1   (um)   ponto   por 
hora. 
Cursos de graduação e 
pós-graduação (lato sensu 
e stricto sensu) oferecidos 
por IES, reconhecidos 
pelo MEC 
Disciplinas  que  contribuam  para  a 
melhoria     da performance do 
profissional,    com    conteúdo    de 
natureza   técnica   e   profissional, 
relacionadas ao PEPC. 
Mínimo  de  360 
(trezentos e 
sessenta)  horas-
aula 
 
10  (dez)  pontos  por 
disciplina concluída. 
A comprovação 
deve  ser  feita  pelo 
profissional 
mediante a 
apresentação de 
declaração,   emitida 
pela IES, das 
disciplinas 
concluídas no ano. 
Autoestudo credenciado 
Considera-se autoestudo, o 
aprendizado     sem     interação     de 
facilitadores,  em  que  o  profissional 
aprende  por  meio  de  material  de 
estudo dirigido (impresso ou 
online),   e,   ao   final   do   processo 
realiza     uma     prova     (com,     no 
mínimo,    75%    de acertos    para 
aprovação). 
 
Cursos a 
distância por 
meio virtual 
 
1   (um)   ponto   por 
hora. 
 
Eventos credenciados, 
como: conferências; 
seminários; fóruns; 
debates; encontros; 
reuniões técnicas; painéis; 
congressos;    convenções; 
simpósios     nacionais     e 
internacionais. 
Eventos   que   contribuam   para   a 
melhoria da performance do 
profissional,    com    conteúdo    de 
natureza    técnica    e    profissional, 
relacionados ao PEPC. 
Eventos 
presenciais  ou  a 
distância com 
controle de 
frequência 
1   (um)   ponto por 
hora. 
 
ANEXO III 
RELATÓRIO DE ATIVIDADES 
 
PROGRAMA DE EDUCAÇÃO PROFISSIONAL CONTINUADA 
Nome:  
CRC Registro n.º 
Estado de origem:   
CPF n.º  
CNAI n.º 
CNPC n.º  
CVM n.° 
Endereço preferencial para comunicação ( ) Com. ( ) Res.:  
Rua/Av.:...................................................................................n.º..............Bairro:........................ 
Cidade:................................................UF:..................................CEP:.................... 
Telefones ( ) Com. ( ) Res.: .......................... Celular: ...........................  
E-mail: ......................................................... 
Função exercida: 
 

AUDITORIA INDEPENDENTE: 
- hipóteses das alíneas (a), (b), (c) e (d) do item 4 desta norma: 
(   ) Auditor CNAI;  (   ) Sócio; (   ) Terceirizado firma de auditoria;  (   ) Diretor;  (   ) Gerente; (   ) Supervisor;    
(   ) Responsável Técnico 
 
ORGANIZAÇÕES CONTÁBEIS QUE POSSUAM A TIVIDADE DE AUDITORIA NO OBJETO SOCIAL 
- hipótese da alínea (e) do item 4 desta norma: 
(   ) Sócio;   (   ) Diretor;  (   ) Gerente; (   ) Supervisor; (   ) Responsável Técnico 
 
DEMAIS ENTIDADES DE GRANDE PORTE E ENTIDADES SEM FINALIDADE DE LUCROS: 
- hipóteses da alínea (f) do item 4 desta norma: 
(   ) Resp. Técnico Demonstrações Contábeis; (   ) Diretor ; (   ) Chefe; (   ) Gerente; (   ) Supervisor   
 
PERITO CONTÁBIL: 
- hipótese da alínea (g) do item 4 desta norma: 
 (   ) Perito (CNPC) 
 
VOLUNTÁRIO: 
(    ) Realizei atividades de EPC mesmo não estando incluído em nenhuma das situações previstas no item 4 desta 
norma. 
 
RELATÓRIO DE ATIVIDADES 
Exercício: 1º/1/............... a 31/12/............. 
I. AQUISIÇÃO DE CONHECIMENTOS 
CURSO/EVENTO CAPACITADORA N.º DA 
CAPACITADORA 
DATA OU 
PERÍODO 
CÓDIGO 
DO 
CURSO 
CRÉDITOS 
DE 
PONTOS 
            
            
II. DOCÊNCIA 
Atividade que necessita de apreciação para atribuição de pontuação. 
DISCIPLINA CAPACITADORA/ 
INSTITUIÇÃO DE 
ENSINO 
N.º DA 
CAPACITADORA  
DATA OU 
PERÍODO  
CÓDIGO 
DO 
CURSO 
CRÉDITOS 
DE 
PONTOS 
            
            
III. ATUAÇÃO COMO PARTICIPANTE (COMISSÕES TÉCNICAS E PROFISSIONAIS) 
Atividade que necessita de apreciação para atribuição de pontuação.  
COMISSÃO/ 
BANCA 
EXAMINADORA 
ENTIDADE 
DATA OU 
PERÍODO 
CRÉDITOS DE 
PONTOS 
        
        
IV. PRODUÇÃO INTELECTUAL (LIVROS, ARTIGOS E PESQUISAS)  

Atividade que necessita de apreciação para atribuição de pontuação. 
TÍTULO FONTE 
DATA 
PUBLICAÇÃO 
CRÉDITOS DE 
PONTOS  
        
        
TOTAL DE PONTOS: 
I. Aquisição de Conhecimento: 
II. Docência: 
III. Atuação como participante: 
IV. Produção intelectual: 
 
DECLARO SOB RESPONSABILIDADE QUE SÃO VERDADEIRAS AS INFORMAÇÕES CONTIDAS NESTE 
DOCUMENTO. 
 
 
...................................................... , .............., de ............................................... de 20XX 
 
 
Assinatura
