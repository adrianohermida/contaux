# Aprova a Revisão NBC 15, que altera as seguintes normas

- Código externo: 2022/ revisão nbc15
- Fonte: CFC 2022/ REVISÃO NBC15 — DOU 02/12/2022
- URL fonte: https://www2.cfc.org.br/sisweb/sre/detalhes_sre.aspx?Codigo=2022/%20REVIS%C3%83O%20NBC15&arquivo=RevisaoNBC15.doc
- Arquivo original: https://www1.cfc.org.br/sisweb/SRE/docs/RevisaoNBC15.pdf
- Nome do arquivo: RevisaoNBC15.pdf
- Tags: Contábil, NBC, Revisão NBC
- Atualizado em: 2026-10-10 14:27:56.6521+00

## Resumo

Aprova a Revisão NBC 15, que altera as seguintes normas

## Texto integral extraído

NORMA BRASILEIRA DE CONTABILIDADE, REVISÃO NBC 15, DE 9 DE NOVEMBRO DE 2022 
 
 
Aprova  a  Revisão  NBC 15,  que  altera  as 
seguintes  normas: NBC TR  2400,  NBC  TO 
3000, NBC TO 3400, NBC TO 3420, NBC TSC 
4400,   NBC   TSC  4410, NBC   TA Estrutura 
Conceitual,  NBC  TA  200  (R1),  NBC  TA  220, 
NBC TA 240 (R1), NBC TA 250, NBC TA 260, 
NBC TO 3402, NBC TO 3410, NBC TO 3420, 
NBC TA 600, NBC TA 610, NBC TA 620, NBC 
TA 700,  NBC  TA  720,  NBC  TA  800,  NBC  TA 
805, NBC TA 810 e NBC TO 3000. 
 
 
O CONSELHO  FEDERAL  DE  CONTABILIDADE, no  exercício  de  suas  atribuições  legais  e 
regimentais e com fundamento no disposto na alínea “f” do Art. 6º do Decreto-Lei n.º 9.295/1946, 
alterado pela  Lei  n.º  12.249/2010, faz  saber que  foi  aprovada  em  seu  Plenário  a  Revisão  NBC 15, 
que altera as Normas Brasileiras de Contabilidade (NBC): 
 
1. Inclui  o subtítulo  do  item  4, o  subitem  (iA) e (iv)  do  item  25; altera  o  item  4,  letra  (i)  do 
item  17, 24, 25,  as  letras  (a),  (b)  e (d)  do  item  25, subitem  (i), (ii) e  (iii)  do  item  25, o 
subtítulo do item 27 e o item 27, o subtítulo do item 28 e o item 28, letra (b) do item 94, 
A3, A4, letras (a) e (b) do item A4, A5, A27, A28, letras (a), (b) e (d) do item A28, A29, A30, 
A31,  A32,  A34  e  A151; exclui  o  subtítulo  do  item  A151, na NBC  TR  2400 – Trabalhos de 
Revisão de Demonstrações Contábeis, que passam a vigorar com as seguintes redações: 
 
 
Introdução 
 
Relação  com  a  NBC  PA  01  (Norma  Internacional  de  Gestão  de  Qualidade  (ISQM)  1,  Gestão  de 
Qualidade para Firmas (Pessoas Jurídicas e Físicas) de Auditores Independentes) 
 
4.  O   sistema   de   gestão   de   qualidade   e   as   políticas   ou os procedimentos   são   de 
responsabilidade  do  auditor  independente  (firma  ou  pessoa  física).  A  NBC  PA  01  aplica-se 
aos  trabalhos  de  revisão  das  demonstrações  contábeis  (ver  item  5  do  NBC  PA  01).  As 
disposições  desta  Norma, relacionadas  com  a  gestão  de  qualidade  no  nível  dos  trabalhos 
individuais de revisão, são baseadas no pressuposto de que a firma de auditoria está sujeita 
à NBC PA 01 ou a requisitos que sejam, no mínimo, tão exigentes (ver itens A3 a A5). 
 
17. Para os fins desta Norma, as expressões em itálico apresentadas a seguir têm os seguintes 
significados:  
 
(i) Requisitos   éticos   relevantes – Princípios   de   ética   profissional   e   requisitos   éticos 
aplicáveis  a  profissionais  da  contabilidade  na realização  de  revisões  de  demonstrações 
contábeis. Os  requisitos  éticos  relevantes  normalmente  compreendem  as  disposições  do 
Código  Internacional  de  Ética  para  Profissionais  da  Contabilidade  do  Comitê  Internacional 
de Normas  Éticas  para  Contadores  (incluindo  as Normas  Internacionais de  Independência, 
Código  de Ética  Profissional  do  Contador do  CFC e  as  Normas  Brasileiras de  Contabilidade 

Profissionais)  relacionadas  com  revisões  de  demonstrações  contábeis,  juntamente  com  os 
requisitos nacionais mais restritivos. 
 
Requisitos 
 
Gestão de qualidade no nível do trabalho 
 
24.  O  sócio  do  trabalho  deve  ter  competência  em  termos  de  habilidades  e  técnicas  de 
asseguração   e   de   relatórios   financeiros,   e   capacidade,   incluindo   tempo   suficiente, 
apropriadas para as circunstâncias dos trabalhos (ver item A26). 
 
25.  O sócio do trabalho deve assumir a responsabilidade geral pela (ver itens A27 a A30): 
 
(a) gestão e pelo alcance da qualidade em cada trabalho de revisão para o qual esse sócio 
é  designado,  e  por  estar  suficiente  e  apropriadamente  envolvido  durante  todo  o 
trabalho; 
(b) direção, pela supervisão, pelo planejamento e pela execução do trabalho de revisão, de 
acordo com as normas profissionais e os requisitos legais e regulatórios aplicáveis (ver 
item A31); 
(c) (...) 
(d) observância  das  políticas  ou  dos  procedimentos  de  gestão  de  qualidade  da  firma 
durante a execução do trabalho, incluindo: 
 
(i)  estar  convencido  de  que  foram  seguidas  as  políticas  ou os procedimentos  da  firma 
para  a  aceitação  e  continuidade  de relacionamentos  com  clientes  e  de  trabalhos  de 
revisão,   e   que   as   conclusões   obtidas   são   apropriadas,   inclusive   considerando   a 
existência   de   informações   que   levariam   o   sócio   do   trabalho   a   concluir   que   a 
administração não tem integridade suficiente (ver itens A32 e A33); 
 
(iA)  determinar  que  recursos  suficientes  e  apropriados  para  a  execução  do  trabalho 
foram   designados   ou   disponibilizados   de   maneira   tempestiva   para   a   equipe   de 
trabalho,  levando  em  consideração  a  natureza  e  as  circunstâncias  do  trabalho,  as 
políticas  ou  os  procedimentos  da  firma  e  quaisquer  mudanças  que  possam  surgir 
durante o trabalho; 
 
(ii) estar convencido de que a equipe de trabalho possui coletivamente competência e 
capacidade apropriadas, incluindo tempo suficiente, assim como habilidades, técnicas e 
conhecimentos  em  trabalhos  de  asseguração  e  na  emissão  de  relatórios  financeiros 
para: 
 
a. executar  o  trabalho  de  revisão  de  acordo  com  as  normas  profissionais  e  os 
requisitos legais e regulatórios aplicáveis; e 
b. emitir o relatório que seja apropriado às circunstâncias; 
 
(iii)  assumir  a  responsabilidade  pela  apropriada  documentação  do  trabalho  que  está 
sendo mantida; e 
 
(iv) quando uma revisão da qualidade do trabalho é requerida de acordo com a NBC PA 
01  ou  com  as  políticas  ou  os procedimentos  da  firma,  não  datar  o  relatório  até  a 

conclusão da  revisão  da qualidade  do trabalho  (ver  NBC PA 02,  Revisões da  Qualidade 
do Trabalho). 
 
Cumprimento dos requisitos éticos relevantes 
 
27.  Durante  todo  o  trabalho  de  revisão,  o  sócio responsável  pelo  trabalho  deve  permanecer 
alerta, mediante observação e indagações, conforme necessário, para identificar situações 
de  não  conformidade  com  os  requisitos  éticos,  por  parte  de  membros  da  equipe  de 
trabalho.  Se  assuntos  dessa  natureza  chegarem  ao  conhecimento  do  sócio,  seja  pelo 
sistema  de  gestão  de  qualidade  da  firma  ou  de  outra  forma,  indicando  que  membros  da 
equipe   de   trabalho   não   cumpriram   com   os   requisitos   éticos   pertinentes,   o   sócio 
responsável pelo trabalho, em consulta com os outros pares na firma, determinará a ação 
apropriada. 
 
Monitoramento e remediação 
 
28.  O   sistema   de   gestão   de   qualidade   da   firma   inclui   estabelecer   um   processo   de 
monitoramento e remediação para: 
 
(a) fornecer  informações  relevantes,  confiáveis  e  tempestivas  sobre  o  planejamento,  a 
implementação e a operação do sistema de gestão de qualidade; 
(b) tomar as ações apropriadas para responder às deficiências identificadas, de modo que 
elas sejam corrigidas pela firma tempestivamente. 
 
O  sócio  do  trabalho  deve  considerar  as  informações  obtidas no processo  de  monitoramento  e 
remediação da firma, conforme comunicadas pela firma e, se aplicável, por outras firmas da rede, 
e identificar se as informações poderiam afetar o trabalho de revisão. 
 
Documentação 
(...) 
 
94.  Ao documentar a natureza, a época e a extensão dos procedimentos executados conforme 
estabelecido nesta Norma, o auditor deve evidenciar: 
 
(a) (...) 
(b) quem  revisou  o  trabalho  executado  para  fins  de  gestão  de  qualidade,  e  a data  e  a 
extensão da revisão. 
 
Aplicação e outros materiais explicativos   
 
Alcance (ver itens 1 e 2) 
 
Relacionamento com as normas de qualidade (ver item 4) 
 
A3.  A NBC PA 01 trata das responsabilidades da firma pelo planejamento, pela implementação 
e pela operação  de  um  sistema  de  gestão  de  qualidade  para  trabalhos  de  asseguração, 
incluindo  trabalhos  de  revisão  (ver  item  1  da  NBC  PA  01).  A  NBC  PA  01  trata  também  da 
responsabilidade  da  firma  de  estabelecer  políticas  ou  procedimentos para tratar  dos 
trabalhos que devem ser submetidos a revisões da qualidade (ver item 2(a) da NBC PA 01). 

A  NBC  PA  02 trata  da nomeação  e  elegibilidade  do  revisor da qualidade  do  trabalho,  e da 
execução  e  documentação  da  revisão  da  qualidade  do  trabalho  (ver  item  2(c)  da  NBC  PA 
01). 
 
Um sistema de gestão de qualidade trata dos oito componentes a seguir (ver item 6 da NBC 
PA 01):   
 
(a) avaliação de riscos da firma;  
(b) governança e liderança; 
(c)   requisitos éticos relevantes; 
(d) aceitação e continuidade de relacionamentos com clientes e trabalhos específicos;  
(e) execução do trabalho; 
(f) recursos; 
(g) informações e comunicação; e 
(h) processo de monitoramento e remediação. 
 
As  firmas  ou  os  requisitos  nacionais  podem  usar  terminologia  ou estruturas  diferentes  para 
descrever os componentes do sistema de gestão de qualidade. 
 
A4.  De  acordo  com  a  NBC  PA  01,  o  objetivo  da  firma  é  planejar,  implementar  e  operar  um 
sistema  de  gestão  de  qualidade  para  trabalhos  de  asseguração,  incluindo  revisões de 
demonstrações contábeis, que forneça à firma segurança razoável de que:  
 
(a) a  firma  e  seu  pessoal  cumprem  com  suas  responsabilidades, de  acordo  com  as 
normas  profissionais  e  os  requisitos  legais  e  regulatórios  aplicáveis,  e  conduzem 
trabalhos de acordo com essas normas e requisitos; e 
(b) os  relatórios  de  trabalho  emitidos  pela  firma  ou  pelos  sócios  do  trabalho  são 
apropriados às circunstâncias (ver item 14 da NBC PA 01).  
 
A5.  Os requisitos nacionais que tratam das responsabilidades da firma pelo planejamento, pela 
implementação e pela operação de um sistema de gestão de qualidade são, no mínimo, tão 
exigentes  quanto  a  NBC  PA  01, quando  tratam  dos  requisitos  da  NBC  PA  01, e  impõem 
obrigações à firma, de alcançar o objetivo da NBC PA 01.   
 
A27.  Dentro  do  contexto  do  sistema  de  gestão  de  qualidade  da  firma,  as  equipes  de  trabalho 
têm   a   responsabilidade   de   implementar   as   políticas   ou   os   procedimentos   da   firma 
aplicáveis  ao  trabalho  e  comunicar à firma  as  informações  decorrentes  do  trabalho  de 
revisão  que  devem  ser  comunicadas  segundo  as  políticas  ou  os  procedimentos  da  firma 
para suportar o sistema de gestão de qualidade da firma. 
 
A28. As  ações  do  sócio  do  trabalho  e  as  mensagens apropriadas  para  os  demais  membros  da 
equipe,  no  contexto  em  que  o  sócio  do  trabalho  assume  a  responsabilidade  geral  pela 
gestão  e  pelo  alcance  da  qualidade  no  trabalho,  enfatizam  o  fato  de  que  a  qualidade  é 
essencial na execução do trabalho de revisão e a importância da qualidade do trabalho de 
revisão, considerando:  
 
(a) a  execução  do  trabalho  que  cumpra  com  as  normas  profissionais  e  os  requisitos 
regulatórios e legais; 

(b) o  cumprimento  das  políticas  ou  dos  procedimentos  de  gestão  de  qualidade  da 
firma;   
(c) (...) 
(d) a capacidade da equipe de trabalho de levantar questões, sem medo de represálias. 
 
 
A29.  Normalmente, a equipe de trabalho pode depender do sistema de gestão de qualidade da 
firma, a menos que: 
 
• o  entendimento  ou  a experiência  prática  da  equipe  de  trabalho  indique  que  as 
políticas   ou   os   procedimentos   da   firma   não   tratarão   da   natureza   e   das 
circunstâncias do trabalho de maneira eficaz; ou 
• as  informações  fornecidas  pela  firma  ou  por  outras  partes  sobre  a  eficácia  dessas 
políticas ou desses procedimentos sugiram o contrário. 
 
Por exemplo, a equipe de trabalho pode depender do sistema de gestão de qualidade da firma em 
relação à: 
 
• competência   e   capacidade   do   pessoal, por   meio   do   seu   recrutamento   e 
treinamento formal;  
• independência, por   meio   da   acumulação   e   comunicação   de   informações   de 
independência relevantes;  
• manutenção  de  relacionamentos  com  clientes, por  meio  das  políticas  ou  dos 
procedimentos  da  firma  para aceitação  e  continuidade  de  relacionamentos  com 
clientes e trabalhos de revisão;  
• adesão    aos    requisitos    regulatórios    e    legais, por    meio    de    processos    de 
monitoramento e remediação da firma. 
 
Ao considerar as deficiências (ver item 16(a) da NBC PA 01) identificadas no sistema de gestão de 
qualidade da firma que possam afetar o trabalho de revisão, o sócio do trabalho pode considerar 
as ações corretivas tomadas pela firma para tratar dessas deficiências. 
 
 
A30.  Uma  deficiência  no  sistema  de  gestão  de  qualidade  da  firma  não  indica  necessariamente 
que  o  trabalho  de  revisão  não  foi  realizado  de  acordo  com  as  normas  profissionais  e os 
requisitos legais e regulamentares, ou que o relatório do auditor não foi adequado. 
 
Designação da equipe de trabalho (ver item 25(b)) 
 
A31.  Ao considerar a competência e a capacidade apropriadas da equipe de trabalho como um 
todo,  o  sócio  encarregado  do  trabalho  pode  levar  em  consideração  assuntos  como  se  a 
equipe: 
(...) 
 
• entendesse as políticas ou os procedimentos de gestão de qualidade da firma. 
 
 
Aceitação  e  continuidade  do  relacionamento  com  clientes  e  de  trabalhos  de  revisão  (ver  item 
25(d)(i)) 

 
A32.  A  NBC  PA  01  (ver  item  30  da  NBC  PA  01)  requer  que  a  firma  estabeleça  objetivos  de 
qualidade  que  abordem  a  aceitação  e  a  continuidade  dos  relacionamentos  com  clientes  e 
dos trabalhos de revisão. 
 
Tal informação auxilia o sócio do trabalho a determinar se as políticas ou os procedimentos 
da  firma  para  a  aceitação  e  continuidade do  relacionamento  com  o  cliente  e de trabalhos 
de revisão foram seguidos, e se as conclusões obtidas são apropriadas. Esse processo pode 
incluir informações sobre:  
 
(...) 
 
Aceitação e continuidade do relacionamento com clientes e de trabalhos de revisão (ver item 29) 
 
A34.  Ao   longo   do   trabalho,   o   auditor   deve   analisar   a   aceitação   e   continuidade   dos 
relacionamentos   com   o   cliente   e   dos   trabalhos   de   revisão,   e   os   requisitos   éticos 
pertinentes,    incluindo    independência,    caso    ocorram    alterações    nas    condições    e 
circunstâncias. A execução de procedimentos iniciais sobre a aceitação e continuidade dos 
relacionamentos  com  o  cliente  e  dos  trabalhos  de  revisão,  e  a  avaliação  das  exigências 
éticas  pertinentes  (inclusive  independência)  no  início  do  trabalho  evidenciam decisões  do 
auditor  e  ações anteriores  para  o  desempenho  de  outras  atividades  importantes  para  o 
trabalho. 
 
Documentação 
 
Tempestividade da documentação da revisão (ver item 93) 
 
A151.  A  NBC  PA  01  requer  que  a  firma  estabeleça  um  objetivo  de  qualidade  para  que  a 
documentação  do  trabalho  seja  finalizada  e  arquivada  tempestivamente  após  a  data  do 
relatório do trabalho. 
 
2. Altera as letras (a) e (b) do item 3, item 4, letras (e) e (h) do item 12, item 21, letra (b) do 
item 22, item 23, item 32 e letra (a) do item 32, item 33 e letras (a), (b) e (c) do item 33, 34, 
35,  36, as  letras  (i)  e  (n)  do  item 69, o  título  do item A60 e  o item  A60, subtítulo  do  item 
A61 e os itens A61, A62, A63, A64, A65, A66, o título do item A69 e o item A69, o item A74, 
o  título  do  item A75 e  o  item  A75,  A86, altera  a  letra  (e)  do  item A121, o  título  do  item 
A124 e  o  item  A124,  A125,  A126,  A147, letra  (c)  do  item A156, o  título  do  item A172 e  o 
item  A172, o  título  do  item A205 e  o  item  A205,  A207, inclui  o  subitem  (aa)  do item  31, 
exclui  a  letra  (b)  do  item  36, na NBC  TO  3000 – Trabalho de  Asseguração  Diferente de 
Auditoria e Revisão, que passam a vigorar com as seguintes redações: 
 
Introdução 
 
3. Esta Norma tem como premissa que:  
 
(a) os membros da equipe de trabalho e o revisor da qualidade do trabalho (nos casos em que 
for  designado)  estão  sujeitos  ao  cumprimento  das  NBCs  PG  100 – Aplicação  Geral  aos 
Profissionais  da  Contabilidade  e  200 – Contadores  que  Prestam  Serviços  (Contadores 
Externos)  e  NBCs  PA  290 – Independência – Trabalhos  de  Auditoria  e  Revisão  e  291 – 

Independência – Outros Trabalhos  de Asseguração,  do  Conselho  Federal de  Contabilidade 
(CFC),  aplicáveis  aos  trabalhos  de  asseguração,  bem  como  outros  requisitos  profissionais, 
legais ou regulamentares, que possam ser tão exigentes quanto as normas profissionais do 
CFC (ver itens A30 a A34); e 
 
(b) o auditor independente que está executando o trabalho é membro de uma firma sujeita à 
NBC  PA  01 – Gestão de  Qualidade  para  Firmas  (Pessoas  Jurídicas  e  Físicas)  de  Auditores 
Independentes  ou  outros  requerimentos  profissionais,  previstos  em  lei  ou  regulamentos, 
acerca da responsabilidade da firma pelo seu sistema de gestão de qualidade, que possam 
ser tão exigentes quanto a NBC PA 01 (ver itens A61 a A66). 
 
4.  A gestão de qualidade em firmas que realizam trabalhos de asseguração e a conformidade 
com   os   princípios   éticos,   incluindo   exigências   de   independência,   são   amplamente 
reconhecidas como   sendo   de   interesse   público   e   parte   integrante   de   trabalhos   de 
asseguração   de   alta   qualidade.   Esta   norma   pode   também   ser   utilizada   por   outros 
profissionais  que  não  sejam  auditores  independentes,  todavia  esses  profissionais  devem 
reconhecer que esta norma inclui requerimentos que refletem as premissas constantes no 
item anterior. 
 
Definições 
 
(...) 
 
12. Para  os  propósitos  desta  e de outras  NBCs  TO,  a  não  ser  que  sejam  indicados  de  outra 
forma,  os  termos  e as expressões  a  seguir  possuem  os  seguintes  significados  abaixo 
atribuídos (ver item A27). 
 
(e) Sócio  encarregado  do  trabalho  é  o  sócio  ou  outro  indivíduo  nomeado  pela  firma  que 
seja responsável pelo trabalho, pela sua execução, e pelo relatório de asseguração que 
é emitido em nome da firma, e que, quando requerido, possui a permissão apropriada 
no organismo profissional, legal ou regulatório. “Sócio encarregado do trabalho” deve 
ser entendido como uma referência para a função equivalente no setor público. 
(...) 
 
(h) Equipe de trabalho são os sócios e demais profissionais que executam o trabalho, assim 
como   quaisquer   outros   indivíduos   que   executam   procedimentos   no   trabalho, 
excluindo o especialista externo do auditor. 
 
21.  O   sócio   encarregado   do   trabalho   deve   estar   satisfeito   de   que   as   políticas   ou   os 
procedimentos da firma para a aceitação e a continuidade do relacionamento com cliente 
e  dos  trabalhos  de  asseguração  foram  seguidos pela  firma.  Deve  também  determinar que 
as conclusões alcançadas são apropriadas. 
 
Aceitação e continuidade 
 
(...) 
 
22.  O  auditor  independente  deve  aceitar  ou  continuar  o  trabalho  de  asseguração  somente 
quando (ver itens A30 a A34): 

 
(...) 
 
(b) ele  estiver convencido  que  a  equipe  que  realizará  o  trabalho  possui  a  capacidade  e  as 
competências   apropriadas,   incluindo   tempo   suficiente   para   executar  o   trabalho   (ver 
também item 32); e (...) 
 
23.  Se o sócio responsável pelo trabalho obtiver informações que poderiam ter levado a firma 
a  recusar  o  trabalho,  caso  a  informação  fosse  de  conhecimento  pela  firma  antes  da 
aceitação ou da continuidade do relacionamento com o cliente ou do trabalho específico, o 
sócio  responsável  pelo  trabalho  deve  comunicar  imediatamente  essa  informação  para  a 
gerência  da  sua  firma  (principal  executivo  ou  presidente  da  firma  de  auditoria),  de  forma 
que a firma e o sócio responsável pelo trabalho possam tomar a ação necessária. 
 
Gestão de qualidade 
 
Características do sócio responsável pelo trabalho 
 
31. O sócio responsável pelo trabalho deve: 
 
(...) 
 
Recursos do trabalho 
 
(aa)  determinar  que  recursos  suficientes  e  apropriados  para  executar  o  trabalho  sejam 
designados  ou  disponibilizados  de  maneira  tempestiva  para  a equipe  de  trabalho, 
considerando   a   natureza   e   as   circunstâncias   do   trabalho,   as   políticas   ou   os 
procedimentos  da  firma  e  quaisquer  mudanças  que  possam  surgir  durante  o 
trabalho. 
 
Designação da equipe 
 
32. O sócio responsável pelo trabalho deve: 
 
(a)  estar   satisfeito de que   a   equipe   que   realizará   o   trabalho   possui   as   capacidades   e 
competências apropriadas, incluindo tempo suficiente para: (...) 
 
 
Responsabilidades do sócio responsável pelo trabalho 
 
33. O sócio responsável pelo trabalho deve assumir a responsabilidade geral pela gestão e pelo 
alcance da qualidade no trabalho e por estar suficientemente e apropriadamente envolvido 
durante todo o trabalho. Isso inclui a assunção de responsabilidade de que: 
 
(a) esteja satisfeito de que as políticas ou os procedimentos da firma para a aceitação e 
a continuidade do relacionamento com o cliente e trabalhos de asseguração foram 
seguidos;  

(b) o trabalho seja planejado e executado (incluindo a direção e supervisão apropriada 
dos  membros  da  equipe  de  trabalho)  de  acordo  com  as  normas  profissionais  e 
exigências legais e regulatórias aplicáveis; 
(c) revisões sejam realizadas de acordo com as políticas ou os procedimentos da firma, 
além  de  revisar  a  documentação  do  trabalho  até  a  emissão  do  relatório  de 
asseguração (ver item A74); (...) 
 
34.  Durante  todo  o  trabalho,  o  sócio  responsável  pelo  trabalho  deve  permanecer  alerta,  por 
meio   de   observação   e   indagações,   quando   necessárias,   para   as   situações   de   não 
conformidade com as exigências éticas pelos membros da equipe de trabalho. Se surgirem 
assuntos  que  chamem  a  atenção  do  sócio  responsável  por  meio  do  sistema  de  gestão  de 
qualidade  da  firma  ou  que, de  outra  forma, indiquem  que  os  membros  da  equipe  de 
trabalho não seguiram as exigências éticas, o sócio responsável pelo trabalho, consultando 
seus pares na firma, deve determinar a ação apropriada.   
 
35.  O sócio responsável pelo trabalho deve considerar as informações oriundas do processo de 
monitoramento e remediação da firma, conforme comunicadas pela firma (ou pela rede de 
firmas), e identificar se as informações podem afetar o trabalho de asseguração. 
 
Revisão da qualidade do trabalho 
 
36.  Para os trabalhos em que uma revisão de qualidade do trabalho seja exigida de acordo com 
a NBC PA 01 ou com as políticas ou procedimentos da firma: 
 
o  sócio  responsável  pelo  trabalho  deve  discutir  os  assuntos  significativos  e  julgamentos 
significativos  que  surgirem  durante  o  trabalho  com  o  revisor  da  qualidade  do  trabalho  e 
não deve emitir seu relatório de asseguração até a finalização dessa revisão. 
 
(b)o revisor do controle de qualidade do trabalho deve executar uma avaliação objetiva 
dos julgamentos significativos exercidos pela equipe de trabalho e sobre as conclusões 
alcançadas para formular o relatório de asseguração. Essa avaliação deve envolver (ver 
item A75): 
(i) discussão dos assuntos significativos com o sócio responsável pelo trabalho; 
(ii) revisão da informação do objeto e do relatório de asseguração proposto; 
(iii) revisão da documentação do trabalho relativa aos julgamentos significativos que 
foram exercidos pela equipe de trabalho e sobre as conclusões atingidas; e 
(iv) avaliação das conclusões alcançadas para formular o relatório de asseguração e a 
consideração se o relatório de asseguração proposto é apropriado ou não. 
 
Elaboração do relatório de asseguração 
 
Conteúdo do relatório de asseguração 
 
 69.  O relatório de asseguração deve incluir, no mínimo, os seguintes elementos básicos: 
 
(...) 
 

(i)  declaração de que a firma de que o auditor independente é membro aplica a NBC PA 01, ou 
aplica  outras  exigências  profissionais,  legais e regulatórias  que sejam,  pelo  menos,  tão 
exigentes   quanto a NBC   PA   01.   Se   o   profissional   da   contabilidade   não   for   auditor 
independente,   a   declaração   deve   identificar   as   exigências   profissionais,   legais   ou 
regulatórias  que  foram  aplicadas.  Essas  exigências  devem  ser,  pelo  menos,  tão  exigentes 
quanto a NBC PA 01 (ver item A172); 
 
(...) 
(n) Data do relatório de asseguração.  A data do relatório de asseguração não deve ser anterior 
àquela em que:  
(i)  o  auditor  independente  obteve  as  evidências  que  serviram  de  base  para 
fundamentar  sua  conclusão,  incluindo  evidências  nas  quais  aqueles  com  a 
reconhecida  autoridade  assumiram  a  responsabilidade  pela  informação  do 
objeto (ver item A 184); e 
         
(ii)  quando uma revisão da qualidade do trabalho é requerida de acordo com a 
NBC PA 01 ou com outras políticas ou procedimentos da firma, a revisão da 
qualidade do trabalho estiver finalizada (ver item A185). 
 
Gestão de qualidade 
 
Auditor independente (ver itens 20, 31(a) e (b)) 
 
A60.  Esta  Norma  foi  escrita  no  contexto  de  uma  série  de  medidas  tomadas  para  assegurar  a 
qualidade dos trabalhos de asseguração realizados por auditores independentes, tais como 
aquelas  realizadas  por  comitês  membros  da  IFAC, em  concordância  com  o  Programa  de 
Adequação  dos  Comitês  Membros  e  Declarações  das  Obrigações  dos  Associados  da  IFAC.  
Tais medidas incluem: 
 
• requisitos   de   competência,   tais   como   referências   de   formação   e   experiência 
profissional para conseguir se associar, e de desenvolvimento profissional contínuo, 
bem como de aprendizagem contínua;  
• um sistema de gestão de qualidade implementado em toda a firma. A NBC PA 01 se 
aplica  a  todas  as  firmas  para  os  trabalhos  de  asseguração  e  outros  serviços 
relacionados; e 
• código de ética abrangente, incluindo requerimentos detalhados de independência, 
estabelecidos   com   base   nos   princípios   éticos   de   integridade,   objetividade, 
competência e zelo profissional, confidencialidade e comportamento profissional. 
 
Gestão de qualidade em nível de firma (ver itens 3(b) e 31(a)) 
 
A61. A  NBC  PA  01  trata  das  responsabilidades  das  firmas  de  auditoria  independente  pelo 
planejamento, pela implementação e pela operação de um sistema de gestão de qualidade 
para trabalhos de asseguração (ver item 1 da NBC PA 01). Ela institui as responsabilidades 
da firma pelo estabelecimento de objetivos de qualidade que abordem o cumprimento das 
responsabilidades   de   acordo   com   os   requisitos   éticos   relevantes,   incluindo   aqueles 
relacionados com independência.  A NBC PA 01 trata também da responsabilidade da firma 
em  estabelecer  políticas  ou  procedimentos  para  endereçar  os  trabalhos  que  devem  ser 
submetidos  a  revisões  da  qualidade  do  trabalho.  A  NBC  PA  02  trata  da  nomeação  e 

elegibilidade  do  revisor  da  qualidade  do  trabalho,  e  da  execução  e  documentação  da 
revisão da qualidade do trabalho (ver itens 2 (a) e (b) da NBC PA 01). 
 
Um  sistema  de  gestão  de  qualidade  aborda  os  oito  componentes  a  seguir  (ver  item  6  da 
NBC PA 01):  
 
(a) processo de avaliação de riscos da firma;  
(b) governança e liderança;  
(c) requerimentos éticos relevantes; 
(d)  aceitação e continuidade dos relacionamentos de clientes e trabalhos específicos; 
(e) desempenho do trabalho;  
(f)  recursos;  
(g) informação e comunicação; e 
(h) processo de monitoramento e remedição. 
 
As  firmas  ou  os  requerimentos  nacionais  podem  utilizar  diferentes  terminologias  ou 
estruturas para descrever os componentes do sistema de gestão de qualidade. 
 
A62. Outros  requisitos  profissionais,  ou  previstos  em  lei  ou  regulamentos,  que  tratam  das 
responsabilidades da firma pelo planejamento, pela implementação e pela operação de um 
sistema de gestão de qualidade são, pelo menos, tão exigentes quanto a NBC PA 01 quando 
elas abordam os requerimentos da NBC PA 01 e impõem obrigações para a firma alcançar o 
objetivo da NBC PA 01.  
 
A63. As   ações  do   sócio   responsável   pelo  trabalho   e   as   mensagens  apropriadas   a   outros 
membros da equipe de trabalho, no contexto de o sócio responsável pelo trabalho assumir 
para si a responsabilidade geral pela gestão e pelo alcance da qualidade no trabalho e por 
estar  suficiente  e  apropriadamente  envolvido  durante  todo  o  trabalho,  devem  enfatizar  o 
fato  de  que  a  qualidade  é  essencial  no  desempenho  do  trabalho  de  asseguração  e  a 
importância da qualidade desse trabalho: 
 
(a) realizando  trabalhos  de  acordo  com  as normas  técnicas  e  exigências  legais  e 
regulatórias aplicáveis; 
(b) cumprindo políticas ou procedimentos da firma, conforme for aplicável;   
(c) emitindo relatórios apropriados às circunstâncias;  
(d) permitindo  que  a  equipe  de  trabalho  possa  levantar  assuntos  sem  receio  de 
represálias. 
 
A64. Um   sistema   de   gestão   de   qualidade   da   firma   inclui   estabelecer   um   processo   de 
monitoramento e remediação planejado para: 
 
(a) fornecer informações relevantes, confiáveis e tempestivas sobre o planejamento, a 
implementação e a operação do sistema de gestão de qualidade para a firma; 
(b) tomar  as  ações  apropriadas  para  responder a deficiências  identificadas, de  modo 
que elas sejam remediadas pela firma tempestivamente. 
 
A65. Normalmente, a equipe de trabalho pode depender do sistema de gestão de qualidade da 
firma, a menos que: 
 

• o  entendimento  ou  a  experiência  prática  da  equipe  de  trabalho  indique  que  as 
políticas   ou   os   procedimentos   da   firma   não   endereçarão   a   natureza   e   as 
circunstâncias do trabalho de maneira eficaz; ou 
• as  informações  fornecidas  pela  firma  ou  por  outras  partes  sobre  a  eficácia  de 
políticas ou desses procedimentos sugiram o contrário. 
 
Por  exemplo,  a  equipe  de  trabalho  pode  confiar  no  sistema  de  gestão  de  qualidade  da 
firma em relação à: 
 
(a) competência e capacidade do pessoal por meio do seu recrutamento e treinamento 
formal;  
(b) independência  por  meio  da  acumulação e  comunicação  de  informações  relevantes 
sobre independência; 
(c) manutenção    de    relacionamentos    com    clientes    por    meio    de políticas    ou 
procedimentos  da  firma  para  aceitação  e  continuidade  de  relacionamentos  com 
clientes e para trabalhos de asseguração;  
(d) aderência  aos  requisitos  legais  e  regulatórios  aplicáveis  por  meio  do  processo  de 
monitoramento e remediação da firma. 
 
Ao considerar as deficiências identificadas no sistema de gestão de qualidade da firma que 
possam afetar o trabalho de asseguração, o sócio encarregado do trabalho pode considerar 
as  ações  de  remediação  tomadas  pela  firma  para  endereçar  essas  deficiências (ver  item 
16(a) da NBC PA 01). 
 
A66. Uma  deficiência  no  sistema  de  gestão  de  qualidade  da  firma  não  indica  necessariamente 
que o trabalho de asseguração não foi executado de acordo com as normas profissionais e 
exigências legais e regulatórias aplicáveis, ou que o relatório do auditor não foi apropriado. 
 
Recursos de trabalho 
 
Competência e capacidades coletivas (ver item 32) 
 
A69. A  NBC  P  01  requer  que  a  firma  estabeleça  os  objetivos  de  qualidade  que  abordem  a 
aceitação  e  continuidade  do relacionamento  com  clientes  e  trabalhos  de  asseguração.  Os 
objetivos  de  qualidade  abordam  a  adequação  dos  julgamentos  da  firma  sobre  se  deve 
aceitar  ou  continuar  relacionamentos  e  trabalhos  baseados  na  capacidade  da  firma  em 
executar   o   trabalho   de   acordo   com   as   normas   profissionais   e   exigências   legais   e 
regulatórias aplicáveis (ver itens 30 (a)(ii) e A72 da NBC PA 01). 
 
Responsabilidades de revisão (ver item 33(c)) 
 
A74. De  acordo  com  a  NBC  PA  01,  a  firma  deve  estabelecer  um  objetivo  de  qualidade  que 
aborde a natureza, a época e a extensão do direcionamento e da supervisão das equipes de 
trabalho   e   da   revisão   do   seu   trabalho.   A   NBC   PA   01   também   requer   que   esse 
direcionamento, essa supervisão e essa revisão sejam planejados e executados levando em 
consideração  que  o  trabalho  executado  por  membros  menos  experientes  da  equipe  de 
trabalho  é  direcionado,  supervisionado  e  revisado  pelos  membros  mais  experientes  da 
equipe de trabalho (ver item 31 (b) da NBC PA 01). 
 

Revisão da qualidade do trabalho (ver item 36(b)) 
 
A75. Outras questões que podem ser consideradas na revisão da qualidade do trabalho incluem:  
 
(a) a  avaliação  pela  equipe  do  trabalho  acerca  da  independência  da  firma em  relação 
ao trabalho; 
(b) se  as  consultas  apropriadas  ocorreram  em  questões  que  envolvem  diferenças  de 
opinião  ou  outras  questões  difíceis  ou  contenciosas,  e  as  conclusões  que  surgiram 
dessas consultas; e 
(c)  se   a   documentação   do   trabalho   selecionada   para   revisão   reflete   o   trabalho 
realizado  em  relação  aos  julgamentos  significativos  e  se  suporta  as  conclusões 
alcançadas. 
 
Planejamento e execução do trabalho 
 
Planejamento (ver item 40) 
 
A86. O  planejamento  envolve  o  sócio  pelo  trabalho,  outros  membros-chave  da  equipe  de 
trabalho  e  quaisquer  especialistas  externos  do  auditor  para  desenvolver  uma  estratégia 
global  para  o  alcance,  a  ênfase,  a  época  e  a  condução  do  trabalho,  além  de  programa  de 
trabalho,   incluindo   uma   abordagem   detalhada   da   natureza,   época   e   extensão   dos 
procedimentos a serem realizados e as razões para escolhê-los. O planejamento adequado 
ajuda   a   dedicar   atenção   apropriada   a   áreas   importantes   do   trabalho,   a   identificar 
tempestivamente  problemas  potenciais,  a  organizar  e  a  administrar  adequadamente  o 
trabalho,  de  forma  que  ele  seja  realizado  de  maneira  eficaz.  O  planejamento  adequado 
também  auxilia  o  auditor  independente  a  designar  o  trabalho  de  forma  apropriada  aos 
membros  da  equipe,  assim  como  facilita  a  orientação  e  a  supervisão  dos  membros  da 
equipe de trabalho, e a revisão do seu trabalho.  (...) 
 
Considerações quando especialista é envolvido no trabalho 
 
Natureza, época e extensão dos procedimentos (ver item 52) 
 
A121. Os  seguintes  assuntos  geralmente  são  relevantes  ao  determinar  a  natureza,  a  época  e  a 
extensão dos procedimentos relativos ao trabalho do especialista de auditor independente 
quando  parte  do  trabalho  de  asseguração  for  realizado  por  um  ou  mais  especialistas  (ver 
item A70):  
(...) 
 
(e)  se  esse  especialista  está  sujeito  às  políticas  ou aos procedimentos  de  gestão  de 
qualidade da firma (ver itens A124 e A125). 
 
Políticas ou procedimentos de gestão de qualidade da firma do auditor independente 
 
A124. O  especialista  interno  do  auditor  independente  pode  ser  sócio  ou  equipe  da  firma  do 
auditor independente, incluindo equipe temporária e, portanto, está sujeito ao sistema de 
gestão   de   qualidade   da   firma,   incluindo   suas   políticas   ou seus procedimentos,   em 
concordância com a NBC PA 01 ou outras exigências profissionais, ou requerimentos de leis 
ou   regulamentos,   que sejam,   pelo   menos,   tão   exigentes   quanto   a   NBC   PA   01. 

Alternativamente, o especialista interno pode ser um sócio ou equipe da firma de auditoria 
de  rede,  incluindo  equipe  temporária,  que  pode  compartilhar  políticas  ou  procedimentos 
de  gestão  de  qualidade  em  comum  com  a  firma  do  auditor  independente.  O  especialista 
externo não é membro da equipe de trabalho. 
 
A125. Normalmente, a equipe de trabalho pode depender do sistema de gestão de qualidade da 
firma   (ver   item   A65). A   extensão   da   dependência   pode   variar   de   acordo   com   as 
circunstâncias, e pode afetar a natureza, a época e extensão dos procedimentos do auditor 
independente, com relação a tais assuntos:  
(...) 
• avaliação do auditor independente quanto à adequação do trabalho do especialista;   
Por  exemplo,  os  programas  de  treinamento  da  firma  podem  fornecer  aos  especialistas 
internos  o  entendimento  adequado  da  inter-relação  de  sua  especialidade  com  o  processo 
de obtenção   de   evidências.      A   dependência   desse   treinamento,   além   de   outros 
procedimentos  da  firma,  tais  como  protocolos  para  delimitar  o  escopo  do  trabalho  dos 
especialistas  internos,  pode  afetar  a  natureza,  época  e  extensão  dos  procedimentos  do 
auditor independente para avaliar a adequação do trabalho do especialista.  
• cumprimento aos  requerimentos  regulatórios  e  legais, por  meio  do  processo  de 
monitoramento e remediação da firma.  
(...) 
 
Essa  dependência  não  reduz  a  responsabilidade  do  auditor  independente de  atender  aos
 requerimentos desta Norma. 
 
 
Competência, capacidade e objetividade do especialista (ver item 52(a)) 
 
A126. Informações  sobre  a  competência,  capacidade  e  objetividade  do  especialista  podem  ser 
obtidas de várias fontes, tais como: 
(...) 
• políticas  ou  procedimentos  de  gestão  de  qualidade  da  firma  (ver  itens  A124  e 
A125). 
 
Formação da conclusão de asseguração 
 
Suficiência e adequação da evidência (ver itens 12(i) e 64) 
 
A147. Evidências  são  necessárias  para  fundamentar  a  conclusão  do  auditor independente  e  o 
relatório  de  asseguração. São  cumulativas  em  sua  natureza  e  são  principalmente  obtidas 
dos  procedimentos  realizados durante  o  curso de  trabalho. Elas  podem  incluir também  as 
informações obtidas de outras fontes, tais como trabalhos anteriores (desde que o auditor 
independente   tenha   determinado   quais   mudanças   ocorreram   desde   os   trabalhos 
anteriores  que  possam  impactar  sua  relevância  para  o  trabalho  atual), ou  políticas  ou 
procedimentos da firma para a aceitação e continuidade de relacionamentos com clientes 
e  para  os  trabalhos  de  asseguração.    As  evidências  podem  vir  de  fontes  internas  ou 
externas  às  partes  apropriadas.  Também,  as  informações  que  podem  ser  utilizadas  como 
evidências  podem  ter  sido  preparadas  por  especialista  empregado  ou  contratado  pela 
entidade.  A  evidência  abrange  informações  que  sustentam  e  corroboram  aspectos  da 
informação do objeto, e qualquer informação que contradiga os aspectos da informação do 

objeto.  Além disso, em alguns casos, a ausência de informação (por exemplo, recusa pelas 
partes  apropriadas  no  fornecimento  da  representação  solicitada)  é  utilizada  pelo  auditor 
independente  e,  portanto,  também  constitui evidências.  A  maior  parte  do  trabalho  do 
auditor  independente,  ao  formar  a  conclusão  da  asseguração,  consiste  na  obtenção  e 
avaliação das evidências. 
 
Limitação de alcance (ver itens 26 e 66) 
 
A156.  A limitação de alcance pode surgir de: 
 
(...)  
 
(c)  limitações  impostas  pela  parte  responsável,  pelo  mensurador  ou pelo avaliador,  ou  pela 
contratante  ao  auditor  independente  que,  por  exemplo,  possa  impedi-lo de  realizar um 
procedimento considerado necessário nas circunstâncias. Limitações desse tipo podem ter 
outras  implicações  ao  trabalho,  tais  como  a  consideração  do  auditor  sobre  o  risco  do 
trabalho e sobre a aceitação e continuidade do relacionamento com o cliente e do trabalho 
de asseguração.  
 
Elaboração do relatório de asseguração 
 
Requerimentos aplicáveis de gestão de qualidade (ver item 69(i)) 
 
A172. A  seguir  é  apresentado  exemplo  de  afirmação  no  relatório  de  asseguração  sobre  os 
requerimentos aplicáveis de gestão de qualidade: 
 
A  firma  aplica  a  Norma  Brasileira  de  Gestão  de  Qualidade  (NBC  PA  01),  que  requer  que  a 
firma planeje, implemente e opere um sistema de gestão de qualidade, incluindo políticas 
ou  procedimentos  relacionados  com  o  cumprimento  de  requerimentos  éticos,  normas 
profissionais e exigências legais e regulatórias aplicáveis. 
 
Montagem dos arquivos finais do trabalho 
 
A205. A  NBC  PA  01  (ou  outros  requerimentos  profissionais,  de  leis  ou  regulamentos  que  sejam, 
pelo  menos,  tão  exigentes  quanto  a  NBC  PA  01)  requer  que  as  firmas  estabeleçam  um 
objetivo  de  qualidade  que  aborde a  montagem  da  documentação  do  trabalho,  em  tempo 
hábil,  após  a  data  do  relatório  do  trabalho  (ver  item  31(f)  da  NBC  PA  01). Tempo-limite 
apropriado para a conclusão da montagem do arquivo final do trabalho é normalmente de, 
no máximo, 60 dias após a data do relatório de asseguração (ver item A83 da NBC PA 01). 
 
A207. A NBC PA 01 (ou outros requerimentos que sejam pelos menos tão exigentes quanto a NBC 
PA   01)   requer   que   as   firmas   estabeleçam   um   objetivo   de   qualidade  que   aborde   a 
manutenção  e  retenção  da  documentação  de  trabalho  para  satisfazer  as  necessidades  da 
firma   e   cumprir   com   lei,   regulamento,   requerimentos   éticos   relevantes   ou   normas 
profissionais   (item   31(f)   da   NBC   PA   01).   O   período   de   retenção   para   trabalhos   de 
asseguração, geralmente, não é menor do que 5 (cinco) anos a contar da data do relatório 
de asseguração (ver item A85 da NBC PA 01).  
 

3. Altera  o  item 8, a letra  (g)  do  item 35  e o Apêndice da NBC  TO  3420  (R1) – Trabalho  de 
Asseguração  sobre  a  Compilação  de  Informações  Financeiras Pro  Forma incluídas  em 
Prospecto, que passam a vigorar com as seguintes redações: 
 
8. O  cumprimento  da  NBC  TO  3000  requer,  entre  outros  procedimentos, o cumprimento  do 
Código  de  Ética  Profissional  do  Contador  do  Conselho  Federal  de  Contabilidade  (CFC) 
relacionado com trabalhos de asseguração, ou outros requisitos profissionais, ou requisitos 
previstos em lei ou regulamento que sejam, pelo menos, tão exigentes (ver itens 3(a), 20 e 
34 da NBC TO 3000). A NBC TO 3000 também requer que o sócio do trabalho seja membro 
de firma de auditoria que aplique a NBC PA 01 (ver itens 3(b) e 31(a) da NBC TO 3000) ou 
outros  requisitos  profissionais,  ou  requisitos  previstos  em  lei  ou  regulamento  que  sejam, 
pelo menos, tão exigentes quanto a NBC PA 01. 
 
 
Elaboração do relatório de asseguração 
 
35. O  relatório  do  auditor  independente  deve  incluir,  no  mínimo,  os seguintes  elementos 
básicos (ver item A57): 
 
(...) 
(g) declaração de que a firma da qual o auditor independente é membro aplica a NBC PA 01 
ou  outros  requisitos  profissionais,  ou  requisitos  previstos  em  lei  ou  regulamento  que 
sejam, no mínimo, tão exigentes quanto a NBC PA 01. (...) 
 
Apêndice 
 
Exemplo de relatório de auditor independente com opinião sem modificações 
 
(...) 
 
Nossa independência e gestão de qualidade 
 
Cumprimos  com  os  requisitos  de  independência  e  outros  requisitos  éticos  do  Código  de  Ética 
Profissional  do  Contador  do  Conselho  Federal  de  Contabilidade  (CFC),  baseados  nos  princípios 
fundamentais     de     integridade,     objetividade,     competência     profissional     e     devido     zelo, 
confidencialidade e comportamento profissional. 
 
A  firma  aplica  a  NBC  PA  01,  que requer  que  a  firma  planeje,  implemente  e  opere  um  sistema  de 
gestão  de  qualidade,  incluindo  políticas  ou  procedimentos  relacionados  com  o  cumprimento  de 
requisitos éticos, normas profissionais e requisitos legais e regulatórios aplicáveis. 
 
4. Altera os itens 3 e 13, as letras (c), (e) e (k) do item 13, 19, 21, 23, 26, A3, A4, A5, A6, A7, 
A8, o item A24 e as letras (a), (b) e (c) do item A24, A25, A26, A37, A47 e Apêndice; inclui o 
subtítulo   do   item   3 na NBC   TSC   4400 – Trabalhos   de   Procedimentos   Previamente 
Acordados, que passam a vigorar com as seguintes redações: 
Introdução 
 
Alcance 

 
Relação com a NBC PA 01 – Norma Internacional de Qualidade (NBC PA) 01, Gestão de Qualidade 
para  Firmas  (Pessoas  Jurídicas  e  Físicas)  de  Auditores  Independentes na Revisão  de  Qualidade  do 
Trabalho 
 
3. O   sistema   de   gestão   de   qualidade,   e   as   políticas   ou   os   procedimentos   são   de 
responsabilidade  da  firma  de  auditoria.  A  NBC  PA  01  se  aplica  a  firmas  com  relação  aos 
trabalhos de procedimentos previamente acordados da firma (ver item 5 da NBC PA 01). As 
disposições desta Norma em relação à gestão de qualidade no nível de trabalhos individuais 
de  procedimentos  previamente  acordados  baseiam-se  no  pressuposto  de  que  a  firma  está 
sujeita  à  NBC  PA  01  ou  aos  requisitos  que  sejam,  no  mínimo,  tão  exigentes  (ver  itens  A3  a 
A8). 
 
Definições 
 
13. Para fins desta Norma, os termos a seguir têm os significados atribuídos abaixo: 
 
(...) 
 
(c) Sócio do trabalho – O sócio ou outro indivíduo nomeado pela firma, responsável pelo 
trabalho,   pela   sua   realização,   e   pelo   relatório   de   procedimentos   previamente 
acordados emitido em nome da firma, e quem, quando requerido, tem a autoridade 
apropriada de órgão profissional, legal ou regulatório.  
(...) 
 
(e)  Equipe  de  trabalho – Todos  os  sócios  e a equipe  que  realizam  o  trabalho  de 
procedimentos  previamente  acordados,  assim  como  quaisquer  outros  indivíduos 
que   executam   procedimentos   no   trabalho,   excluindo   especialista   externo   do 
auditor independente.  
(...) 
 
(k)  Requisitos  éticos relevantes – Princípios  de  ética  profissional  e  requisitos  éticos 
aplicáveis  à  equipe  de  trabalho  na  condução  de  trabalhos  de  procedimentos 
previamente acordados. Os requisitos éticos relevantes normalmente 
compreendem as disposições do Código Internacional de Ética para Profissionais da 
Contabilidade do Comitê Internacional de Normas Éticas para Contadores (incluindo 
as   Normas   Internacionais   de   Independência, Código   de   Ética   Profissional   do 
Contador   do   CFC   e   as   Normas   Brasileiras   de   Contabilidade   Profissionais), 
juntamente com os requisitos nacionais mais restritivos. 
 
Gestão de qualidade do nível do trabalho 
 
19. O sócio do trabalho deve assumir a responsabilidade geral:  
 
(a) pela gestão e pelo alcance da qualidade no trabalho de procedimentos previamente 
acordados,  incluindo,  se  aplicável,  no  trabalho  realizado  por  um  especialista  do 
auditor independente, e por estar suficiente e apropriadamente envolvido durante 
todo o trabalho (ver item A24); e 

(b) pela execução do trabalho de acordo com políticas ou procedimentos de gestão de 
qualidade da firma mediante:  
 
(i) a observância das políticas ou dos procedimentos da firma relacionados com 
a  aceitação e  continuidade  de  relacionamentos  com  clientes  e trabalhos de 
procedimentos previamente acordados (ver item A25); 
 
(iA)  a  determinação  de  que  recursos  suficientes  e  apropriados  para  a  execução  do 
trabalho  foram  designados  ou  disponibilizados  de  maneira  tempestiva  para  a 
equipe  de  trabalho,  levando  em  consideração  a  natureza  e  as  circunstâncias  do 
trabalho,  as  políticas  ou  os  procedimentos  da  firma  e  quaisquer  mudanças  que 
possam surgir durante o trabalho; 
 
(ii) a  satisfação  de  que  a equipe de trabalho  e qualquer  especialista  do  auditor 
que  não  faça  parte  da  equipe  de  trabalho  têm  em  conjunto  a competência  e  a 
capacitação  adequadas,  incluindo  tempo  suficiente  para  realizar  o  trabalho  de 
procedimentos previamente acordados;  
(iii)  a  atenção  a  indicações  de  violações  por  parte  de  membros  da  equipe  do 
trabalho  dos  requisitos  éticos  relevantes,  e  a  determinação  das  ações  apropriadas 
se o sócio do trabalho tomar conhecimento de assuntos indicando que os membros 
da equipe de trabalho violaram os requisitos éticos relevantes (ver item A26); 
(iv) o  direcionamento  e  a  supervisão  dos  membros  da  equipe  de  trabalho, 
revisando  seu  trabalho,  e  a  execução  do  trabalho  de  acordo  com  as  normas 
profissionais e os requisitos legais e regulatórios aplicáveis; 
(v) a  assunção da  responsabilidade pela documentação  apropriada  do  trabalho 
a ser montada e apropriadamente mantida e retida; 
(vi) quando uma revisão da qualidade do trabalho é requerida de acordo com a 
NBC  PA  01  ou  com  as  políticas  ou  os procedimentos  da  firma,  não  datando  o 
relatório até a conclusão da revisão da qualidade do trabalho de acordo com a NBC 
PA 02 – Revisão de Qualidade do Trabalho – 5A. 
 
Aceitação e continuidade do trabalho 
 
21. Antes  de  aceitar  ou  continuar  o  trabalho  de  procedimentos  previamente  acordados,  o 
auditor deve obter um entendimento do objetivo do trabalho. O auditor não deve aceitar ou 
continuar  o  trabalho  de  procedimentos  previamente  acordados  se  tomar  conhecimento  de 
quaisquer  fatos  ou  circunstâncias  que  indiquem  que  os  procedimentos  solicitados  são 
inapropriados para fins do trabalho de procedimentos previamente acordados (ver itens A28 
a A31). 
 
23. Se  o  sócio  do  trabalho  obtém  informações  que  teriam  levado  a  firma  a  recusar  o  trabalho 
caso essas informações fossem conhecidas pela firma antes da aceitação ou da continuidade 
do   trabalho   específico,   o   sócio   do   trabalho   deve   comunicar   imediatamente   essas 
informações  à  firma,  de  modo  que  a  firma  e  ele  próprio  possam  tomar  as  medidas 
necessárias. 
 
Acordo sobre os termos do trabalho 
 
Trabalhos de procedimentos previamente acordados recorrentes 

 
26. Em trabalhos  de procedimentos previamente  acordados  recorrentes,  o  auditor  deve  avaliar 
se as circunstâncias, incluindo mudanças nos julgamentos da firma sobre se deve aceitar ou 
continuar  o  trabalho,  requerem  que  os  termos  do  trabalho  sejam  revisados,  e  se  há 
necessidade  de  que  a  parte  contratante  seja  lembrada  dos  termos  do  trabalho  existentes 
(ver item A44); 
 
Aplicação e outros materiais explicativos 
 
Relação com a NBC PA 01 (ver item 3) 
 
A3. A  NBC  PA  01  trata  das  responsabilidades  da  firma  pelo  planejamento,  implementação  e 
operação  de  um  sistema  de  gestão  de  qualidade  para  trabalhos  de  serviços  correlatos, 
incluindo trabalhos de procedimentos previamente acordados (ver item 2(a) da NBC PA 01). 
A  NBC  PA  01  trata  também  da  responsabilidade  da  firma  de  estabelecer  políticas  ou 
procedimentos para tratar dos trabalhos que devem ser submetidos a revisões da qualidade 
5C.  A NBC PA 02 trata da nomeação e elegibilidade do revisor da qualidade do trabalho, e da 
execução e documentação da revisão da qualidade do trabalho (ver item 2(b) da NBC PA 01). 
 
A4. De  acordo  com  a  NBC  PA  01,  o  objetivo  da  firma  é  planejar,  implementar  e  operar  um 
sistema de gestão de qualidade para trabalhos de serviços correlatos, incluindo trabalhos de 
procedimentos previamente acordados, que forneça à firma segurança razoável de que:   
 
(c) a  firma  e  seu  pessoal  cumprem  com  suas  responsabilidades  de  acordo  com  as 
normas profissionais  e  os  requisitos  legais  e  regulatórios  aplicáveis,  e  conduzem 
trabalhos de acordo com essas normas e requisitos; e 
(d) os  relatórios  de  trabalho  emitidos  pela  firma  ou  pelos  sócios  do  trabalho  são 
apropriados às circunstâncias (ver item 14 da NBC PA 01). 
 
A5. Uma jurisdição que não adotou a NBC PA 01 (no Brasil, não é aplicável, porque é adotada a 
NBC   PA   01)   em   relação   a   trabalhos   de   procedimentos   previamente   acordados   pode 
estabelecer  requisitos  de  gestão  de  qualidade  em  firmas  que  realizam  esses  trabalhos.    As 
disposições  desta  Norma  para  Serviços  Correlatos  sobre  gestão  de  qualidade  no  nível  de 
trabalhos baseiam-se no pressuposto de que os requisitos de gestão de qualidade adotados 
são,  no  mínimo,  tão  exigentes  quanto  os  da  NBC  PA  01.  Isso  é alcançado  quando  esses 
requisitos tratam dos requisitos da NBC PA 01 e impõem à firma a obrigação de alcançar os 
objetivos da NBC PA 01. O cumprimento da NBC PA 01 requer, entre outros procedimentos, 
que o sistema de gestão de qualidade da firma trate dos oito componentes a seguir (ver item 
6 da NBC PA 01): 
 
(a) processo de avaliação de riscos da firma;  
(b) governança e liderança; 
(c) requisitos éticos relevantes; 
(d) aceitação e continuidade de relacionamentos com clientes e trabalhos específicos; 
(e) execução do trabalho; 
(f) recursos;  
(g) informações e comunicação; e 
(h) processo de monitoramento e remediação. 
 

A6. Dentro do contexto do sistema de gestão de qualidade da firma, as equipes de trabalho têm 
a responsabilidade de implementar políticas ou procedimentos aplicáveis ao trabalho. 
 
A7. Normalmente,  a  equipe  de  trabalho  pode  depender  do  sistema  de  gestão  de  qualidade  da 
firma, a menos que: 
 
• o entendimento ou a experiência prática da equipe de trabalho indique que as políticas ou 
os procedimentos  da  firma  não  tratarão  da  natureza  e  das  circunstâncias  do  trabalho  de 
maneira eficaz; ou 
• as informações fornecidas pela firma ou por outras partes sobre a eficácia dessas políticas 
ou desses procedimentos sugiram o contrário. 
 
Por  exemplo, a  equipe  de  trabalho  pode  depender  do  sistema  de  gestão  de  qualidade  da 
firma em relação à: 
 
• competência  e  capacidade  do  pessoal  por  meio  do  seu  recrutamento  e  treinamento 
formal;  
• manutenção de relacionamentos com clientes por meio das políticas ou dos procedimentos 
da  firma  para  aceitação  e  continuidade  de  relacionamentos  com  clientes  e  trabalhos  de 
procedimentos previamente acordados;  
• adesão  aos  requisitos  legais  e  regulatórios  por  meio  de  processos  de  monitoramento  e 
remediação da firma. 
 
Ao  considerar  as  deficiências  (ver  item  16(a)  da  NBC  PA  01)  identificadas  no  sistema  de 
gestão  de  qualidade  da  firma  que  podem  afetar  o  trabalho  de  procedimentos  previamente 
acordados, o sócio do trabalho pode considerar as ações corretivas tomadas pela firma para 
tratar  dessas  deficiências  que  ele  considera  suficientes  no  contexto  desse  trabalho  de 
procedimentos previamente acordados. 
 
 
A8. Uma deficiência no sistema de gestão de qualidade da firma não indica necessariamente que 
o  trabalho  de  procedimentos  previamente  acordados  não  foi  realizado  de  acordo  com  as 
normas  profissionais  e  os  requisitos  legais e  regulatórios  aplicáveis,  ou  que  o  relatório  do 
trabalho de procedimentos previamente acordados não foi apropriado. 
 
Gestão de qualidade no nível do trabalho (ver itens 19 e 20) 
 
A24. As  ações  do  sócio  do  trabalho  e  as  mensagens  apropriadas  para  os  demais membros  da 
equipe  ao  assumir  a  responsabilidade  geral  pela  gestão  e  pelo  alcance  da  qualidade  no 
trabalho enfatizam a importância de se alcançar a qualidade do trabalho de: 
 
(a) realizar   trabalhos   que   cumpram   com   as   normas   profissionais   e   os requisitos 
regulatórios e legais;  
(b) cumprir com as políticas ou os procedimentos da firma, conforme aplicáveis; e 
(c) emitir  o  relatório  do  auditor  independente  para  o  trabalho, de  acordo  com  esta 
Norma. 
 
A25. A  NBC  PA  01  requer  que  a  firma  estabeleça  os  objetivos  de  qualidade  que  tratam  da 
adequação  dos  julgamentos  da  firma  sobre  se  deve  aceitar  ou  continuar  o  relacionamento 

com  um  cliente  ou  um  trabalho,  baseados  em  informações  obtidas  sobre  a  natureza  e  as 
circunstâncias do trabalho de procedimentos previamente acordados e sobre a integridade e 
os   valores   éticos   do   cliente   (incluindo   da   administração   e,   quando   apropriado,   dos 
responsáveis pela governança) que sejam suficientes para suportar esses julgamentos.  Se o 
sócio  do  trabalho  tem  razões  para  duvidar  da  integridade  da  administração  em  grau  que 
pode,  provavelmente,  afetar  a  execução  adequada  do  trabalho,  a  aceitação  do  trabalho 
pode não ser apropriada. 
 
A26. A  NBC  PA  01 descreve  as  responsabilidades da  firma  de  estabelecer  objetivos  de qualidade 
que   tratam   do   cumprimento  das   responsabilidades   com  relação   aos   requisitos   éticos 
relevantes.  Esta Norma descreve as responsabilidades do sócio do trabalho com relação ao 
cumprimento dos  requisitos éticos  relevantes  por  parte  da  equipe de  trabalho  (ver  item 29 
da NBC PA 01). 
 
Aceitação e continuidade de trabalho (ver itens 21 a 23) 
 
Cumprimento dos requisitos de independência (ver itens 22(e), 24(e)) 
 
A37. O   item   22(e)   se   aplica   quando   o   auditor   tiver   que   cumprir   com   os   requisitos   de 
independência  por  razões como  as  descritas  no  item  A15.  O  item  22(e)  também  se  aplica 
quando  o  auditor  concorda  com  a  parte  contratante,  nos  termos  do  trabalho,  em  cumprir 
com   os   requisitos   de   independência.   Por   exemplo,   o   auditor   pode   ter   inicialmente 
determinado que, de acordo com requisitos éticos relevantes, lei ou regulamento ou outras 
razões, não tem que cumprir com os requisitos de independência. Entretanto, ao considerar 
a  aceitação  ou  continuidade  do  trabalho,  ou  o  acordo  com  os  termos  do  trabalho,  o 
conhecimento do auditor sobre os assuntos a seguir pode indicar que uma discussão com a 
parte  contratante  sobre  se  o  cumprimento  de  determinados  requisitos  de  independência 
identificados é adequado para fins do trabalho de procedimentos previamente acordados: 
(...) 
 
A47. O especialista   do   auditor   pode   ser   especialista   externo   contratado   pelo   auditor   ou 
especialista interno que faz parte da firma e, portanto, está sujeito ao sistema de gestão de 
qualidade  da  firma.  Normalmente,  o  auditor  pode  depender  do  sistema  de  gestão  de 
qualidade da firma, a menos que: 
 
• o  entendimento  ou  a  experiência  prática  do  auditor  indique  que  as  políticas  ou  os 
procedimentos  da  firma  não  tratarão  da  natureza  e  das  circunstâncias  do  trabalho  de 
maneira eficaz; ou 
• as informações fornecidas pela firma ou por outras partes sobre a eficácia dessas políticas 
ou desses procedimentos sugiram o contrário. 
 
A  extensão  dessa  dependência  irá  variar  com  as  circunstâncias,  e  pode  afetar  a  natureza, 
época e extensão dos procedimentos do auditor com relação a assuntos como:  
 
• competência e habilidades por meio de programas de recrutamento e treinamento; 
•avaliação do auditor quanto à objetividade do seu especialista;  
• concordância com o especialista do auditor. 
 

Essa dependência não reduz a responsabilidade do auditor independente de cumprir com os 
requisitos desta Norma. 
 
Apêndice 
 
Exemplo 1 
 
Ética profissional e gestão de qualidade 
 
(...) 
 
Nossa firma aplica a NBC PA 01, que requer que a firma planeje, implemente e opere um sistema 
de gestão de qualidade, incluindo políticas ou procedimentos relacionados com o cumprimento de 
requisitos éticos, normas profissionais e requisitos legais e regulatórios aplicáveis. 
 
Exemplo 2 
 
Ética profissional e gestão de qualidade 
(...) 
 
Nossa firma aplica a NBC PA 01, que requer que a firma planeje, implemente e opere um sistema 
de gestão de qualidade, incluindo políticas ou procedimentos relacionados com o cumprimento de 
requisitos éticos, normas profissionais e requisitos legais e regulatórios aplicáveis. 
 
5. Altera o  item 4, as  letras  (c),  (d)  e  (g)  do  item 17,  23,  26,  40 e  a  letra  (k)  do  item  40, o 
subtítulo  do  item A6 e  o  item  A6,  A7,  A8,  A10,  A11,  A30,  A31,  A32 na NBC  TSC  4410 – 
Trabalho  de  Compilação  de  Informações  Contábeis,  que  passa  a vigorar  com  a  seguinte 
redação: 
 
Introdução  
 
Alcance 
 
Relacionamento com a NBC PA 011 
 
4. O   sistema   de   gestão   de   qualidade   e   as   políticas   ou os procedimentos   são   de 
responsabilidade da firma ou auditor que executar tal serviço. A NBC PA 01 se aplica a firmas 
com  relação  aos  trabalhos  de  compilação  (ver  item  5  da  NBC  PA  01).  As  disposições  desta 
Norma  relacionadas  com  a  gestão  de  qualidade  no  nível  dos  trabalhos  individuais  de 
compilação pressupõem que a firma está sujeita à NBC PA 01 ou a requisitos, no mínimo, tão 
exigentes (ver itens A6 a A11). 
 
Definições 
 
17. Os termos a seguir têm os significados atribuídos para fins desta Norma: 
 
(...) 
 

(c) Sócio responsável é  o  sócio  ou  outra  pessoa  na  firma  que  seja  responsável  pelo 
trabalho e pela sua realização, assim como pelo relatório de compilação emitido em 
nome  da  firma  e  que,  quando  for  requerido,  tem  a  autorização  apropriada  de  um 
órgão profissional, legal ou regulador.  
 
(d) Equipe de trabalho – Todos os sócios e o pessoal de campo que realizam o trabalho, 
ou   quaisquer   outros   indivíduos   que   executam   procedimentos   no   trabalho, 
excluindo  especialista  externo  do  auditor  independente  contratado  pela  firma  ou 
por firma da rede. 
(...) 
(g)  Requisitos  éticos  relevantes – Princípios  de  ética  profissional  e  requisitos  éticos 
aplicáveis  à  equipe  de  trabalho  na  condução  de  trabalhos  de  compilação.  Os 
requisitos  éticos  relevantes  normalmente  compreendem  as  disposições  do  Código 
Internacional  de  Ética  para  Profissionais  da  Contabilidade  do  Comitê  Internacional 
de   Normas   Éticas   para   Contadores   (incluindo   as   Normas   Internacionais   de 
Independência, Código  de  Ética  Profissional  do  Contador  do  CFC  e  as  Normas 
Brasileiras  de  Contabilidade  Profissionais),  juntamente  com  os  requisitos  nacionais 
mais restritivos (ver item A21). 
 
Gestão e alcance da qualidade em trabalhos de compilação 
 
23. O sócio do trabalho deve assumir a responsabilidade geral:  
 
(a) pela  gestão  e  pelo  alcance  da  qualidade  nos  trabalhos  de  compilação  sob  sua 
responsabilidade, e por estar suficiente e apropriadamente envolvido durante todo 
o trabalho; e  
 
(b) pela  execução  do  trabalho  de  acordo  com  as  políticas  ou os procedimentos  de 
gestão de qualidade da firma mediante (ver item A30): 
(i)  a  observância  das  políticas  ou  dos  procedimentos  da  firma  com  relação  à 
aceitação   e   continuidade   dos relacionamentos   com   clientes   e   trabalhos   de 
compilação (ver item A31); 
(iA)  a  determinação  de  que  recursos  suficientes  e  apropriados  para  a  execução  do 
trabalho  foram  designados  ou  disponibilizados  de  maneira  tempestiva  para  a 
equipe  de  trabalho,  levando  em  consideração  a  natureza  e  as  circunstâncias  do 
trabalho,  as  políticas  ou  os  procedimentos  da  firma  e  quaisquer  mudanças  que 
possam surgir durante o trabalho;  
(ii)  a  satisfação  de  que  a  equipe  de  trabalho  possui  coletivamente  competência  e 
capacidade  apropriadas,  incluindo  tempo  suficiente,  para  executar  o  trabalho  de 
compilação;  
(iii)  a  atenção  a  indicações  de  violações  por  parte  de  membros  da  equipe  de 
trabalho  dos  requisitos  éticos  relevantes,  e  a  determinação  das  ações  apropriadas 
se o sócio do trabalho tomar conhecimento de assuntos indicando que os membros 
da equipe de trabalho violaram os requisitos éticos relevantes (ver item A 32); 
(iv) dirigir, supervisionar os membros da equipe de trabalho, e revisar seu trabalho, 
e  a  execução  do  trabalho  de  acordo  com  as  normas  profissionais  e os requisitos 
legais e regulatórios aplicáveis;   
(v)  assumir  a  responsabilidade  pela  documentação  apropriada  do  trabalho  a  ser 
preparada, apropriadamente mantida e retida; e  

(vi) quando uma revisão da qualidade do trabalho é requerida de acordo com a NBC 
PA 01 ou com as políticas ou os procedimentos da firma, não datar o relatório até a 
conclusão da revisão da qualidade do trabalho. 
Trabalhos recorrentes 
 
26. Nos  trabalhos  de  compilação  recorrentes,  o  auditor  deve  avaliar  se  as  circunstâncias, 
inclusive  mudanças  nos  julgamentos  da  firma  sobre  o  relacionamento  com  o  cliente  ou  o 
trabalho,  requerem  que  os  termos  de  trabalho  sejam  revistos  e  se  há  necessidade  de 
lembrar à firma os termos do trabalho acordados anteriormente (ver item A45). 
 
Relatório de compilação do auditor 
 
40. O  relatório  do  auditor  emitido  para  o  trabalho  de  compilação  deve  ser  por  escrito  e  deve 
incluir os seguintes elementos (ver itens A62 a A63, A70): 
 
(...) 
 
(k) data do relatório do auditor. 
 
(...) 
 
Relacionamento com a NBC PA 01 (ver item 4) 
 
A6. A NBC PA 01 trata das responsabilidades da firma pelo planejamento, pela implementação e 
pela operação de um sistema de gestão de qualidade para trabalhos de serviços correlatos, 
inclusive trabalhos de compilação (ver item 1 da NBC PA 01). A NBC PA 01 trata também da 
responsabilidade   da   firma   de   estabelecer   políticas   ou   procedimentos   para   tratar   dos 
trabalhos  que  devem  ser  submetidos  a  revisões da qualidade  (ver  item  2(a)  da  NBC PA  01).  
A  NBC  PA  02  trata  da  nomeação  e  elegibilidade  do  revisor  da  qualidade  do  trabalho,  e  da 
execução e documentação da revisão da qualidade do trabalho (ver item 2(b) da NBC PA 01). 
 
A7. De  acordo  com  a  NBC  PA  01,  o  objetivo  da  firma  é  planejar,  implementar  e  operar  um 
sistema de gestão de qualidade para trabalhos de serviços correlatos, inclusive trabalhos de 
compilação, que forneça à firma segurança razoável de que:  
 
(a)  a  firma  e  seu  pessoal  cumpram  com  suas  responsabilidades  de  acordo  com  as  normas 
profissionais e os requisitos legais e regulatórios aplicáveis, e conduzam trabalhos de acordo 
com essas normas e requisitos; e 
(b)  os  relatórios  de  trabalho  emitidos  pela  firma  ou  pelos  sócios  responsáveis  do  trabalho 
são apropriados às circunstâncias (ver item 14, da NBC PA 01). 
 
A8. Uma  jurisdição  que  não  adotou  a  NBC  PA  01  em  relação  a  trabalhos  de  compilação  pode 
estabelecer  requisitos  de  gestão  de  qualidade  em  firmas  que  realizam  esses  trabalhos.  As 
disposições desta Norma referentes à gestão de qualidade no nível de trabalhos baseiam-se 
no  pressuposto  de  que  os  requisitos  de  gestão  de  qualidade  adotados  são,  no  mínimo,  tão 
exigentes  quanto  os  da  NBC  PA  01.  Isso  é  alcançado  quando  esses  requisitos  tratam  dos 
requisitos da ISQM 1 e impõem à firma a obrigação de alcançar os objetivos da NBC PA 01.  
O  cumprimento  da  NBC  PA  01  requer,  entre  outras  coisas,  que  o  sistema  de  gestão  de 
qualidade da firma trate dos oito componentes a seguir (ver item 6 da NBC PA 01): 

 
(a) avaliação de riscos da firma;  
(b) governança e liderança; 
(c) requisitos éticos relevantes; 
(d) aceitação e continuidade de relacionamentos com clientes e trabalhos específicos; 
(e) execução do trabalho; 
(f) recursos; 
(g) informações e comunicação; e 
(h) processo de monitoramento e remediação. 
 
A10. Normalmente,  a equipe  de  trabalho  pode  depender  do  sistema  de  gestão  de  qualidade  da 
firma, a menos que: 
 
• o entendimento ou a experiência prática da equipe de trabalho indique que as políticas ou 
os  procedimentos  da  firma  não  tratarão  da  natureza  e  das  circunstâncias  do  trabalho  de 
maneira eficaz; ou 
• as informações fornecidas pela firma ou por outras partes sobre a eficácia dessas políticas 
ou desses procedimentos sugiram o contrário. 
 
Por  exemplo,  a  equipe  de  trabalho  pode  se  basear  no  sistema  de  gestão  de  qualidade da 
firma em relação à: 
 
• competência e capacidade de em decorrência de seu recrutamento e treinamento formal;  
• manutenção  das  relações  com  clientes  por  meio  das  políticas  ou  dos  procedimentos  da 
firma  para  aceitação  e  continuidade  de  relacionamentos  com clientes  e  trabalhos  de 
compilação;  
• aderência  aos  requisitos  legais  e  regulatórios  por  meio  de  processos  de  monitoramento  e 
remediação da firma. 
 
Ao  considerar  as  deficiências  identificadas  no  sistema  de  gestão  de  qualidade  da  firma  que 
possam  afetar  o trabalho  de  compilação,  o  sócio  encarregado  do  trabalho  pode  considerar 
as remediações tomadas pela firma para tratar dessas deficiências (ver item 16(a) da NBC PA 
01). 
 
A11. Uma deficiência no sistema de gestão de qualidade da firma não indica necessariamente que 
o  trabalho  de  compilação  não  foi  realizado  de  acordo  com  as  normas  profissionais  e  os 
requisitos legais e regulatórios aplicáveis, ou que o relatório do auditor não foi apropriado. 
 
Gestão de qualidade no nível do trabalho (ver itens 23(b)) 
 
A30. As  ações  do  sócio  encarregado  do  trabalho  e  mensagens  apropriadas  para  os  outros 
membros  da  equipe,  ao  assumir  a  responsabilidade  geral  pela  gestão  e  por  alcançar  a 
qualidade no trabalho, enfatizam a importância de se alcançar a qualidade do trabalho ao: 
 
(a)  executar  trabalho  que  atenda  às  normas  profissionais  e aos  requisitos  regulatórios  e 
legais; 
(b) cumprir com as políticas ou os procedimentos da firma, conforme forem aplicáveis; e 
(c) emitir relatório do auditor para o trabalho de acordo com esta Norma. 
 

Aceitação e continuidade da relação com os clientes e trabalhos de compilação (ver item 23(b)(i)) 
 
A31. A  NBC  PA  01  requer  que  a  firma  estabeleça  os  objetivos  de  qualidade  que  tratam  da 
adequação  dos  julgamentos  da  firma sobre  se  deve  aceitar  ou  continuar  o  relacionamento 
com  um  cliente  ou  um  trabalho,  baseados  em  informações  obtidas  sobre  a  natureza  e  as 
circunstâncias do trabalho de compilação e sobre a integridade e os valores éticos do cliente 
(incluindo  da  administração  e,  quando  apropriado,  dos  responsáveis  pela  governança)  que 
sejam suficientes para suportar esses julgamentos. 
 
Cumprimento dos requisitos éticos relevantes na condução do trabalho (ver item 23(b)(iii)) 
 
A32. A  NBC  PA  01  estabelece  as  responsabilidades da  firma  pelo  estabelecimento  dos  objetivos 
de qualidade que tratam do cumprimento das responsabilidades com relação aos requisitos 
éticos  relevantes.  Esta  Norma  estabelece  as  responsabilidades  do  sócio  encarregado  do 
trabalho  com  respeito  ao  cumprimento  pela  equipe  do  trabalho  dos  requisitos  éticos 
pertinentes (ver item 29 da NBC PA 01). 
 
6. Altera  o item  5  e  as  letras  (a)  e  (b)  do  item  5, o item  9 e  as  letras  (a)  ao  (h)  do  item  9 na 
NBC  TA  Estrutura  Conceitual – Estrutura  Conceitual  para  Trabalhos  de  Asseguração,  que 
passa a vigorar com a seguinte redação: 
 
Princípios Éticos e Normas de Gestão de Qualidade 
 
5. A gestão de qualidade em firmas que realizam trabalhos de asseguração e a conformidade 
com   os   princípios   éticos,   incluindo   requisitos   de   independência,   são   amplamente 
reconhecidas   como   sendo   de   interesse   público   e   parte   integrante   de   trabalhos   de 
asseguração de  alta  qualidade. Esses  trabalhos  são  executados  de  acordo  com Normas  de 
Asseguração, que se baseiam no pressuposto que: 
 
(a) os membros da equipe de trabalho e o revisor da qualidade do trabalho (nos casos 
em que for designado) estão sujeitos às disposições do Código de Ética Profissional 
do   Contador   do   CFC e das   Normas   Brasileiras   de   Contabilidade   Profissionais 
relacionadas    com    trabalhos    de    asseguração,    bem    como    outros    requisitos 
profissionais, ou requisitos previstos em lei ou regulamento que sejam, no mínimo, 
tão exigentes; e 
(b) o auditor independente que executa o trabalho é membro de uma firma a qual está 
sujeita  à  NBC  PA  01, ou  outros  requisitos  profissionais,  ou  requisitos  previstos  em 
lei ou regulamento, acerca da responsabilidade da firma pelo seu sistema de gestão 
de qualidade, que sejam, no mínimo, tão exigentes quanto a NBC PA 01. 
 
9. A NBC PA 01 trata das responsabilidades da firma pelo planejamento, pela implementação 
e pela operação de um sistema de gestão de qualidade para trabalhos de asseguração (ver 
item  1  da  NBC  PA  01).  Um  sistema  de  gestão de  qualidade  trata  dos  oito  componentes  a 
seguir (ver item 6 da NBC PA 01): 
 
(a) processo de avaliação de riscos da firma;  
(b) governança e liderança; 
(c) requisitos éticos relevantes; 

(d) aceitação e continuidade de relacionamentos com clientes e trabalhos de compilação;  
(e) execução do trabalho;  
(f) recursos; 
(g) informações e comunicação; e 
(h) processo de monitoramento e remediação. 
 
7. Altera as  letras  (a),  (b)  e  (c)  do item A88, A95 na NBC  TR  2400 – Trabalhos  de  Revisão  de 
Demonstrações Contábeis, que passa a vigorar com a seguinte redação:  
 
A88. O  auditor pode  ter  responsabilidades  adicionais nos  termos de  leis,  de  regulamentos  ou  de 
requisitos éticos relevantes com relação à não conformidade por parte da entidade com leis 
e regulamentos, incluindo fraude, que podem diferir desta Norma ou ir além dela, como, por 
exemplo:  
 
(a) resposta à não conformidade identificada ou suspeita de não conformidade com leis e 
regulamentos,  incluindo  requisitos  relacionados  com  comunicações  específicas  com  a 
administração  e  os  responsáveis  pela  governança,  e  considerando  se  as  medidas 
adicionais são necessárias; 
(b) comunicação de não conformidade identificada ou suspeita de não conformidade com 
leis  e  regulamentos  ao  auditor,  por  exemplo,  sócio  do  trabalho  de  grupo  (ver,  por 
exemplo, itens R360.31 a 360.35 A1 do Código de Ética da Ifac); e 
(c) requisitos  de  documentação  relacionada  com  a  não  conformidade  identificada  ou 
suspeita de não conformidade com leis e regulamentos. 
 
O  cumprimento  de  quaisquer  responsabilidades  adicionais  pode  fornecer  mais  informações 
relevantes  para  o  trabalho  do  auditor  de  acordo  com  esta  Norma  (por  exemplo,  informações 
relacionadas  com  a  integridade  da  administração  ou,  quando apropriado,  dos  responsáveis  pela 
governança). No  Brasil,  a  Resolução  CFC  nº  1.530/2017  dispõe  sobre  os  procedimentos  a  serem 
observados  pelos  profissionais  e pelas organizações  contábeis,  quando  do  exercício  de  suas 
funções,   para   cumprimento   das   obrigações   previstas   na   Lei   nº   9.613/1998   e   alterações 
posteriores, que dispõem sobre os crimes de "lavagem" ou ocultação de bens, direitos e valores; a 
prevenção da utilização do sistema financeiro para ilícitos previstos nessa lei; e cria o Conselho de 
Controle de Atividades Financeiras (Coaf). 
 
A95. Em alguns casos, os requisitos éticos relevantes podem requerer que o auditor comunique 
ou considere se a comunicação de fraude ou não conformidade identificada ou suspeita de 
fraude  ou  não  conformidade  com  leis  e  regulamentos  à  autoridade  competente externa à 
entidade  é  uma  ação  apropriada  nas  circunstâncias.  Por  exemplo,  as  normas  profissionais 
(NBCs  PG  100,  200  e  300  e  NBC  PA  400  e  NBC  PO  900)  requerem que  o  auditor  tome 
medidas para responder à não conformidade identificada ou suspeita de não conformidade 
com  leis  e  regulamentos  e  determine  se  medidas  adicionais  são  necessárias,  o  que  pode 
incluir  a  comunicação  à  autoridade  competente  externa  à  entidade  (ver,  por  exemplo,  os 
itens  R360.36  a  360.36A3  do  Código  IESBA). As  normas  profissionais  explicam que  essa 
comunicação  não  seria  considerada  uma  violação  do  dever  de  confidencialidade  nos  seus 
termos  (ver,  por  exemplo,  o  item  114.1A1  da  NBC  PG  100  e  o  item  R360.37  da  NBC  PG 
300). 
 

8. Altera  o  item  7  na  NBC  TSC  4400 – Trabalhos  de  Procedimentos  Previamente  Acordados, 
que passa a vigorar com a seguinte redação: 
 
7. O auditor independente deve cumprir com o Código de Ética Profissional do Contador. Os 
princípios éticos que regem as responsabilidades profissionais do auditor para esse tipo de 
trabalho são: 
 
(a) integridade; 
(b) objetividade; 
(c) competência profissional e devido zelo; 
(d) confidencialidade; e 
(e) comportamento profissional. 
 
Independência  não  é  um  requisito  para  trabalhos  de  procedimentos  previamente  acordados.  No 
entanto,  os  termos  ou  os  objetivos  de  trabalho  específico  ou  normas  nacionais  podem  requerer 
que o auditor cumpra com as Normas de independência. Caso não exista independência por parte 
do auditor, deve ser incluída uma declaração nesse sentido no relatório de constatações factuais. 
 
9. Altera a letra (g) do item 17, o item 23, a letra (b) e o subitem (iii) do item 23, A19, A20 e 
letras (a), (b) e (c) do item A20, A21, letras (a) e (b) do item A22, A25, A26 e Apêndice 1, na 
NBC  TSC  4410 – Trabalho  de  Compilação  de  Informações  Contábeis,  que  passa  a  vigorar 
com a seguinte redação:  
 
17. Os termos a seguir têm os significados atribuídos para fins desta Norma: 
 
(g) Requisitos  éticos  relevantes – os  requisitos  éticos  aos  quais a  equipe  de  trabalho  está 
sujeita  ao  realizar  trabalhos  de  compilação,  que  normalmente  compreendem  o Código  de 
Ética   Profissional   do   Contador (NPG   01)   e   as   Normas   Brasileiras   de   Contabilidade 
Profissionais  do  CFC  (excluindo  a  NBC  PA  400  E  NBC  PO  900), em conjunto  com  outros 
requisitos de órgãos reguladores nacionais, quando forem mais restritivos. (ver item A21). 
 
23. O sócio do trabalho deve assumir a responsabilidade pela: 
 
(...) 
 
(b) observância de políticas  e  procedimentos  de gestão de  qualidade  da  firma  de 
auditoria, ao (ver item A25): 
(...) 
(iii)   permanecer   alerta   quanto   aos   indícios   de   violações   de   requisitos   éticos 
relevantes  por  parte  dos  membros  da  equipe  de  trabalho  e  determinar  a  medida 
apropriada,  se  assuntos dessa  natureza  chegarem  ao  seu  conhecimento,  indicando 
que membros da equipe de trabalho violaram requisitos éticos relevantes (ver item 
A27); 
 
Requisitos éticos (ver item 21) 
 
A19. As  Normas  Brasileiras  de  Contabilidade  Profissionais  estabelecem  os  princípios  éticos 
fundamentais, que são: 

 
(a) integridade; 
(b) objetividade; 
(c) competência profissional e devido zelo; 
(d) confidencialidade; e 
(e) comportamento profissional. 
 
Os  princípios  fundamentais  de  ética  estabelecem  o  padrão  de comportamento  esperado  de  um 
profissional da contabilidade. 
 
O Código  de  Ética  da  Ifac fornece  uma  estrutura  conceitual  que  estabelece  a  abordagem  que  o 
profissional   da   contabilidade   deve   aplicar   ao   identificar,   avaliar   e   tratar   as   ameaças   ao 
cumprimento dos  princípios  fundamentais.  No  caso  de  trabalhos  de  auditoria,  de  revisão  e  de 
outros trabalhos de asseguração, o Código de Ética da Ifac determina as Normas Internacionais de 
Independência  como  sendo  as  estabelecidas para  aplicação da estrutura conceitual  às  ameaças  à 
independência com relação a esses trabalhos. 
 
A20. Pelas  Normas  Brasileiras  de  Contabilidade  Profissionais,  na  aplicação  do  princípio  de 
integridade, o profissional da contabilidade não deve, de forma consciente, estar associado 
a relatórios, declarações, comunicações ou outras informações quando ele acreditar que as 
informações: 
 
(a) contêm declaração significativamente falsa ou enganosa; 
(b) contêm declarações ou informações fornecidas de maneira leviana; ou 
(c) omitem  ou  ocultam informações  necessárias em  que essa  omissão  ou  ocultação 
seria enganosa. 
  
Quando  o  profissional  da  contabilidade  tomar  conhecimento  de  que  o  contador  esteve 
associado a essas informações, o Código de Ética da Ifac requer que ele tome medidas para 
se desassociar dessas informações. 
 
A21. Embora  as  Normas  Internacionais  de  Independência  do Código  de  Ética  da  Ifac não  se 
apliquem  a  trabalhos  de  compilação,  os  códigos  nacionais  de  ética,  leis  ou  regulamentos  podem 
especificar requisitos ou regras de divulgação relacionadas com independência. 
 
A22. Leis, regulamentos ou requisitos éticos relevantes podem: 
(a)  requerer  que  o  profissional  comunique  a  não  conformidade  identificada  ou 
suspeita  de  não  conformidade  com  leis  e  regulamentos  à  autoridade  competente 
externa à entidade; 
(b) estabelecer    responsabilidades,    segundo    as    quais    a    comunicação    à 
autoridade  competente externa  à entidade  pode  ser  apropriada nas  circunstâncias 
(ver, por exemplo, itens R360.36 e R360.37 da NBC PG 300). 
 
A25. Em  algumas circunstâncias,  a  comunicação  da  não  conformidade  identificada  ou  suspeita 
de  não   conformidade  com   leis   e   regulamentos   à   autoridade   competente   externa   à 
entidade pode ser impedida pelo dever do profissional de confidencialidade nos termos de 
leis,  de  regulamentos  ou  de  requisitos  éticos  relevantes.  Em  outros  casos,  a  comunicação 
de   não   conformidade   identificada   ou   suspeita   de   não   conformidade   à   autoridade 
competente   externa   à   entidade   não   seria   considerada   uma   violação   do   dever   de 

confidencialidade  nos  termos  dos  requisitos  éticos  relevantes  (ver,  por  exemplo,  itens 
R114.1, 114.1 A1 e R360.37 da NBC PG 300). 
 
A26. O  profissional  pode  considerar  uma  consulta  interna  (por  exemplo,  dentro  da  firma  ou de 
firma   da   rede),   para   obtenção   de   assessoria   legal   para   entender   as   implicações 
profissionais  ou  legais  de  se  tomar  qualquer  curso  de  ação  em  particular  ou  consultar,  de 
forma confidencial, o regulador ou órgão profissional – a menos que isso seja proibido por 
lei  ou  regulamento  ou  que  viole  o  dever  de  confidencialidade  (ver,  por  exemplo,  item 
360.39 A1 da NBC PG 300). 
 
Apêndice 1 
 
Realizaremos o trabalho de compilação de acordo com a NBC TSC 4410 – Trabalho de Compilação 
de Informações Contábeis. Essa Norma requer que, na execução deste trabalho, cumpramos com 
os requisitos  éticos  relevantes,  inclusive  os  princípios  de  integridade,  objetividade,  competência 
profissional e devido zelo. Para tanto, devemos cumprir com o Código de Ética da Ifac. 
 
10. Altera o item 2, o item 5 e a letra (a) do item 5, os itens 6, 7, 8, e inclui parágrafo no item 6, 
na NBC TA Estrutura Conceitual – Estrutura Conceitual para Trabalhos de Asseguração, que 
passa a vigorar com a seguinte redação: 
 
2. Essa  Estrutura  não  é  uma  Norma  e,  consequentemente,  não  estabelece  requisito  (ou 
princípios básicos ou procedimentos essenciais) para a execução de trabalhos de auditoria, 
revisão  ou  outros  trabalhos  de  asseguração.  Portanto,  não  se  pode  declarar  que  um 
trabalho de asseguração foi conduzido de acordo com essa Estrutura, mas se deve referir a 
Normas de   Asseguração   relevantes.   As   Normas   de   Asseguração   contêm   objetivos, 
requisitos,  aplicação  e  outros  materiais  explicativos,  material  introdutório  e  definições 
compatíveis  com  essa  Estrutura  e  devem  ser  aplicados  em  trabalhos  de  auditoria,  revisão 
ou  outros  trabalhos  de  asseguração.  O  Apêndice  1  ilustra  o  âmbito  dos  pronunciamentos 
emitidos pelo Comitê das Normas de Auditoria e Segurança (IAASB) e a relação entre eles e 
o Código de Ética da Ifac. 
 
Princípios Éticos e Normas de Gestão de Qualidade 
 
5. A  gestão de  qualidade  em  firmas  que  prestam  serviços  de  asseguração  e  o  cumprimento 
dos princípios éticos, incluindo requisitos de independência, são amplamente reconhecidos 
como  sendo  de  interesse  público  e  parte  integrante  de  trabalhos  de  asseguração  de  alta 
qualidade. Esses trabalhos são executados de acordo com Normas de Asseguração, que se 
baseiam no pressuposto que: 
a) os membros da equipe de trabalho e o revisor de qualidade do trabalho (nos 
casos em que for designado) estão sujeitos às disposições relacionadas com 
trabalhos  de  asseguração,  bem  como  outros  requisitos  profissionais,  legais 
ou  regulamentares,  que  sejam,  no  mínimo,  tão  exigentes  quanto  o Código 
de Ética da Ifac; e 
b) (...) 
 
Código de ética e normas profissionais do CFC 
 

6. A Código de Ética da Ifac estabelece os princípios fundamentais de ética, que são: 
(a) integridade; 
(b) objetividade; 
(c) competência profissional e devido zelo; 
(d) confidencialidade; e 
(e) comportamento profissional. 
 
Os princípios fundamentais de ética estabelecem o padrão de comportamento esperado de 
um profissional da contabilidade. 
 
7. O Código  de  Ética  da  Ifac fornece  uma  estrutura  conceitual  que  os  profissionais  da 
contabilidade  devem  aplicar  para  identificar,  avaliar  e  tratar  as  ameaças  ao  cumprimento 
dos princípios fundamentais. 
 
8. O Código  de  Ética  da  Ifac apresenta  os  requisitos  e  o  material  de  aplicação sobre  vários 
temas. O Código de Ética da Ifac define independência como sendo tanto a independência 
psicológica quanto  independência  na  aparência.  A  independência  possibilita  a  capacidade 
de  formar  uma  conclusão  de  asseguração  sem  ser  afetada  pelas  influências  que  podem 
comprometer   essa   conclusão.   A   independência   aprimora   a   habilidade   de   agir   com 
integridade, ser objetivo e manter uma atitude de ceticismo profissional. 
 
11. Altera  os itens A16,  A17, A19, e inclui  parágrafo  no  item  A17 na NBC  TA  200  (R1) – 
Objetivos  Gerais  do  Auditor  Independente  e  a  Condução  da  Auditoria  em  Conformidade 
com Normas De Auditoria, que passa a vigorar com a seguinte redação: 
 
A16. O  auditor  está  sujeito  a  requisitos  éticos  relevantes,  inclusive  os  relativos  à  independência, 
no que  diz  respeito  a  trabalhos  de  auditoria  de  demonstrações  contábeis.  Os  requisitos 
éticos  relevantes  abrangem  o Código  de  Ética  Profissional  do  Contador e as  disposições  do 
Código  de  Ética  da  Ifac relacionadas  à  auditoria  de  demonstrações  contábeis,  em  conjunto 
com outros requisitos de órgãos reguladores, quando forem mais restritivos. 
 
A17. O Código  de  Ética  Profissional  do  Contador estabelece  os  princípios  fundamentais  de  ética, 
que são: 
 
(a) integridade; 
(b) objetividade; 
(c) competência profissional e devido zelo; 
(d) confidencialidade; e 
(e) comportamento profissional. 
 
Os  princípios  fundamentais  de  ética  estabelecem  o  padrão  de  comportamento  esperado  de  um 
profissional da contabilidade. 
 
O Código  de  Ética  Profissional  do  Contador fornece  uma  estrutura  conceitual  que  estabelece  a 
abordagem  que  o  profissional  da  contabilidade  deve  aplicar  ao  identificar,  avaliar  e  tratar  as 
ameaças  ao  cumprimento  dos  princípios  fundamentais.  No  caso  de  trabalhos  de  auditoria,  de 
revisão  e  outros  trabalhos de  asseguração,  o Código  de  Ética  Profissional  do  Contador apresenta 

as  Normas  Internacionais  de  Independência  estabelecidas  pela  aplicação  da  estrutura  conceitual 
às ameaças à independência com relação a esses trabalhos. 
 
A19. A  NBC  PA  01  ou os requisitos nacionais  que  sejam,  pelo  menos,  tão  exigentes  tratam  das 
responsabilidades da  firma  ao  estabelecer  e  manter  sistema  de gestão de  qualidade  para  a 
execução  de  trabalhos  de  auditoria. A  referida  NBC  PA,  itens  20  a  245,  apresenta  as 
responsabilidades  da  firma  para  o  estabelecimento  de  políticas  e  procedimentos  para  lhe 
fornecer segurança razoável de que a firma e seu pessoal cumprem com os requisitos éticos 
relevantes,  inclusive  os  relacionados  com  independência.  A  NBC  TA  220 – Gestão de 
Qualidade   da   Auditoria   de   Demonstrações   Contábeis,   itens   9   a   11,   apresenta   as 
responsabilidades do sócio do trabalho no que diz respeito aos requisitos éticos relevantes. 
Essas  responsabilidades  incluem  permanecer  alerta,  por  meio  de  observação  e  indagações, 
quando  necessário, para   evidenciar   as   violações   de   requisitos  éticos   relevantes  pelos 
membros   da   equipe   de   trabalho,   determinando   a medida   apropriada   se   vierem   ao 
conhecimento  do  sócio  do  trabalho  assuntos  que  indiquem  que  membros  da  equipe  de 
trabalho    violaram    requisitos    éticos    relevantes,    e    formar    uma    conclusão    sobre    a 
conformidade com os requisitos de independência que se aplicam ao trabalho de auditoria. 
A  NBC  TA  220  reconhece  que  a  equipe  de  trabalho  tem  direito  de  se  valer  dos  sistemas  de 
gestão de  qualidade  da  firma  para  cumprir  suas  responsabilidades  no  que  se  refere  a 
procedimentos  de gestão de  qualidade  aplicáveis  ao  trabalho  de  auditoria  individual,  a 
menos que a informação fornecida pela firma ou pelas outras partes sugira outra ação. 
 
12. Altera  o item 12 e a  letra  (k)  do  item  12, na  NBC  TA  220  (R3) – Gestão  de  Qualidade  da 
Auditoria de Demonstrações Contábeis, que passa a vigorar com a seguinte redação: 
 
Definições 
 
12. Para fins das normas de auditoria, os termos a seguir têm os significados a eles atribuídos: 
 
(...) 
(k)  Requisitos  éticos  relevantes  são  requisitos  éticos  aos  quais  estão  sujeitos  a  equipe  de 
trabalho  e  o  revisor  de  qualidade  do  trabalho  ao  realizar  auditorias,  que  normalmente 
compreendem  as  disposições  do Código  de Ética  Profissional  do  Contador e  as  normas 
profissionais  relacionadas  à  auditoria  de  demonstrações  contábeis,  em  conjunto  com 
outros requisitos de órgãos reguladores, quando forem mais restritivos. 
 
13. Altera o item A6 na NBC TA 240 (R1) – Responsabilidade do Auditor em Relação a Fraude, 
no Contexto da Auditoria de Demonstrações Contábeis, que passa a vigorar com a seguinte 
redação:  
A6. Leis,  regulamentos  ou  requisitos  éticos  relevantes  podem  requerer  que  o  auditor  realize 
procedimentos  adicionais  e  tome  medidas  adicionais.  Por  exemplo,  o Código  de  Ética 
Profissional  do  Contador requer  que  o  auditor  tome  medidas  para  responder  à  não 
conformidade  identificada  ou  suspeita  de  não  conformidade  com  leis  e  regulamentos  e 
determine   se   medidas   adicionais   são   necessárias.   Essas   medidas   podem   incluir   a 
comunicação de não conformidade identificada ou suspeita de não conformidade com leis 
e  regulamentos  a  outros  auditores  de  grupo,  incluindo  o  sócio  do  trabalho  de  grupo, 
auditores  de  componentes  ou  outros  auditores  que  estão  conduzindo  o  trabalho  em 

componentes de grupo para outros fins que não a auditoria das demonstrações contábeis 
de grupo (ver, por exemplo, itens R360.16 a 360.18A1 da NBC PG 300). 
 
14. Altera o item 17, a letra (a) e o subitem da letra (a) do item 17, A30, A31, A49, e exclui as 
letras (a) e (b) do item A30, na NBC TA 260 (R2) – Comunicação com os Responsáveis pela 
Governança, que passa a vigorar com a seguinte redação: 
 
17. No caso de entidades listadas, o auditor deve comunicar aos responsáveis pela governança: 
 
(a) uma declaração de que a equipe de trabalho e outras pessoas na firma de auditoria, 
bem como a própria firma e, quando aplicável, as firmas da rede, cumpriram os requisitos 
éticos relevantes relativos à independência; e 
(i) todos os relacionamentos e outros assuntos entre a firma, firmas da rede e a 
entidade que, segundo o julgamento profissional do auditor, podem razoavelmente 
ser   considerados   com   relação   à   independência.   Isso   deve   incluir   o   total   de 
honorários  cobrados  durante  o  período  coberto  pelas  demonstrações  contábeis, 
pelos  serviços  de  auditoria  e  não  auditoria  prestados  pela  firma  e  pelas  firmas  da 
rede  à  entidade  e  a  componentes  controlados  pela  entidade.    Esses  honorários 
devem   ser   alocados   a   categorias   que   sejam apropriadas   para   auxiliar   os 
responsáveis   pela   governança   a   avaliarem   o   efeito   dos   serviços   sobre   a 
independência do auditor; e 
(ii) com relação a ameaças à independência que não estão em um nível aceitável, as 
medidas   tomadas   para   tratá-las,   incluindo   medidas   que   foram   tomadas   para 
eliminar as circunstâncias que criam as ameaças, ou aplicação de salvaguardas para 
reduzi-las a um nível aceitável (ver itens A29 a A32). 
 
A30. A   comunicação   sobre   relacionamentos   e   outros   assuntos   e   como   as   ameaças   à 
independência  que  não  estão  em  um  nível  aceitável  foram  tratadas  variam com  as 
circunstâncias do trabalho de auditoria e geralmente tratam das ameaças à independência, 
das salvaguardas para reduzi-las e das medidas para eliminar as circunstâncias que criaram 
as ameaças. 
 
(a)  ameaças  à  independência,  que  podem  ser  classificadas  como:  ameaças  de  interesse 
próprio, ameaças de autorrevisão, ameaças de defesa de interesses da entidade, ameaças 
de familiaridade e ameaças de intimidação; e 
(b) salvaguardas criadas pela profissão, legislação ou regulamentação, salvaguardas na 
entidade e salvaguardas nos próprios sistemas e procedimentos da firma. 
 
A31. Requisitos    éticos    relevantes,    leis    ou    regulamentos    também    podem    determinar 
comunicações  específicas  aos responsáveis  pela  governança  em  circunstâncias  em  que 
foram  identificadas  violações  dos  requisitos  de  independência.  Por  exemplo,  os  itens 
R400.80  a  R400.82  e  o  item  R400.84  da  NBC  PA  400  requerem  que  o  auditor  comunique 
aos  responsáveis  pela  governança  por  escrito  qualquer  desvio  e  a  medida  que  a  firma 
tomou ou se propõe tomar. 
 
A49. A comunicação tempestiva durante a auditoria contribui para um diálogo recíproco robusto 
entre  os  responsáveis  pela  governança  e  o  auditor.  Contudo,  a  época  apropriada  das 
comunicações   irá   variar   de   acordo   com   as   circunstâncias   do   trabalho   de   auditoria. 

Circunstâncias  relevantes  incluem  a  importância e  a  natureza  do assunto,  e  a  medida  que 
se espera que seja tomada pelos responsáveis pela governança. Por exemplo: 
(...) 
• comunicações  sobre  independência  podem  ser  apropriadas  sempre  que  são  feitos 
julgamentos  significativos  sobre  ameaças  à  independência  e  como  as  ameaças  à 
independência  que  não  estão  em  um  nível  aceitável  serão  tratadas,  como,  por 
exemplo, ao aceitar um trabalho de prestação de serviços que não são de auditoria, e 
na discussão final. 
(...) 
 
15. Altera  os itens 6, 11,  A5,  A44,  A53, Apêndice  2, na  NBC  TO  3402 – Relatórios  de 
Asseguração de Controles em Organização Prestadora de Serviços, que passa a vigorar com 
a seguinte redação: 
 
6. O cumprimento da NBC TO 3000, itens 3(a), 20 e 24, requer, entre outros procedimentos, o 
cumprimento  das  disposições  do Código  de  Ética  da  Ifac relacionadas  com  trabalhos  de 
asseguração,   ou   outros   requisitos   profissionais,   ou   requisitos   impostos   por   lei   ou 
regulamento que sejam, pelo menos, tão exigentes. A NBC TO 3000 também requer que o 
sócio  do  trabalho  seja  membro  de  firma  de  auditoria  que  aplique  os  procedimentos  de 
gestão de qualidade estabelecidos pela NBC PA 01 (ver NBC TO 3000, itens 3(b) e 31(a)) 6, 
ou  outros  requisitos  profissionais,  ou  requisitos  impostos  por  lei  ou  regulamento,  que 
sejam, pelo menos, tão exigentes quanto a NBC PA 1. 
 
11.  O auditor da organização prestadora de serviços deve cumprir as disposições do Código de 
Ética  relacionadas  com  trabalhos  de  asseguração,  ou  outros  requisitos  profissionais,  ou 
requisitos impostos por lei ou regulamento que sejam, pelo menos, tão exigentes (ver item 
A5). 
 
53. Declaração  de  que  o  auditor  independente  cumpre  com  os  requisitos  de  independência 
outros requisitos profissionais ou requisitos impostos por leis ou regulamentos, que sejam 
tão exigentes quanto as disposições do CFC, relacionadas com trabalhos de asseguração. Se 
o  trabalho  de  asseguração  for  conduzido  por  outro  profissional  que  não  seja  auditor 
independente,  a  declaração  deve  identificar  os  requisitos  profissionais  aplicáveis  ou  os 
requisitos impostos por lei ou regulamento, que sejam, pelo menos, tão exigentes quanto 
as disposições do CFC aplicáveis aos relacionadas com trabalhos de asseguração. 
 
A5. O auditor da organização prestadora de serviços está sujeito a requisitos de independência 
relevantes   que   estão   estabelecidos   nas   normas   profissionais   e   no   Código   de   Ética 
Profissional do Contador. Na execução de trabalho de acordo com esta Norma, a regra do 
CFC não requer que o auditor da organização prestadora de serviços seja independente de 
cada entidade usuária. 
 
A44. As  normas  profissionais  e  o  Código  de Ética  Profissional  do  Contador  requerem  que  o 
auditor  da  organização  prestadora  de  serviços  não  esteja  associado  com  as  informações 
quando ele acreditar que as informações: 
(a) contêm declaração significativamente falsa ou enganosa; 

(b) contêm declarações ou informações fornecidas de maneira leviana; ou 
(c) omitem  ou  ocultam  informações  necessárias  onde  essa  omissão  ou  ocultação  seria 
enganosa. 
 
Se  outras  informações  incluídas  em  um  documento  contendo  a  descrição  do  sistema  da 
organização prestadora de serviços e o relatório de asseguração do auditor da organização 
prestadora  de  serviços  contêm  informações orientadas  para  o  futuro,  como  planos  de 
recuperação ou contingência, ou planos para modificações do sistema que tratarão desvios 
identificados no relatório de asseguração do auditor da organização prestadora de serviços, 
ou reinvindicações de   natureza   promocional   que   não   podem    ser   razoavelmente 
comprovadas,  o  auditor  da  organização  prestadora  de  serviços  pode  solicitar  que  as 
informações sejam retiradas ou atualizadas. 
 
A53. As medidas apropriadas para responder às circunstâncias identificadas no item 56, salvo se 
proibido por leis ou regulamentos, podem incluir: 
• obtenção de assessoria jurídica sobre as consequências de diferentes cursos de ação; 
• comunicação  com  os  responsáveis  pela  governança  da  organização  prestadora  de 
serviços; 
• determinação  quanto  a  comunicar  a  terceiros – por  exemplo,  leis,  regulamentos  ou 
requisitos éticos relevantes podem requerer que o auditor da organização prestadora 
de  serviços  comunique  à  autoridade  competente  externa  à  entidade  ou  ao  auditor 
externo  da  organização  prestadora  de serviços (ver,  por  exemplo,  os  itens  R360.31, 
R360.32,    R360.33,    360.34A1    e    360.35A1    da    NBC    PG    300)    ou    estabeleça 
responsabilidades   sobre   as   quais   essa   comunicação   pode   ser   apropriada   nas 
circunstâncias; 
• modificação  da  opinião  do  auditor  da  organização  prestadora  de  serviços  ou  adição 
de parágrafo sobre outros assuntos; 
• retirada do trabalho. 
 
Apêndice 2   
 
Cumprimos  com  os  requisitos  de  independência  e  outros  requisitos  éticos  do  CFC baseados  nos 
princípios    fundamentais    de    integridade, objetividade,    competência    e    zelo    profissional, 
confidencialidade e comportamento profissional. 
 
16. Altera  a  letra  (j)  do  item  69  na  NBC  TO  3000 – Trabalho  de  Asseguração  Diferente  de 
Auditoria e Revisão, que passa a vigorar com a seguinte redação: 
 
69  O  relatório  de  asseguração  deve  incluir,  no  mínimo,  os  seguintes  elementos  básicos  (ver 
item A134): 
(...) 
 

(j) Uma  declaração  de  que  o  auditor  independente  cumpre  com  os  requisitos  de 
independência ou outros requisitos éticos do CFC, outros requisitos profissionais ou 
requisitos  impostos  por  lei  ou  regulamento,  que  sejam,  pelo  menos,  tão  exigentes 
quanto  as  disposições  do  CFC relacionadas  com  trabalhos  de  asseguração.  Se  o 
trabalho  de  asseguração  for  conduzido  por  outro  profissional  que  não  seja  auditor 
independente,   a   declaração   deve   identificar   os   requisitos   profissionais   ou   os 
requisitos impostos por lei ou regulamento, aplicáveis, que sejam, pelo menos, tão 
exigentes quanto as disposições do CFC relacionadas com trabalhos de asseguração. 
 
17. Altera o item 8, a letra (h) do item 35, A10, A41, as letras (a), (b) e (c) do item A41 na NBC 
TO  3420  (R1) – Trabalho  de  Asseguração  sobre  a  Compilação  de  Informações  Financeiras 
Pro Forma Incluídas em Prospecto, que passa a vigorar com a seguinte redação: 
 
8. O cumprimento da NBC TO 3000 requer, entre outros procedimentos, o cumprimento das 
disposições das normas NBCs PG 100 e 200 e NBCs PA 400 e NBC PO 900 relacionadas com 
trabalhos de asseguração, ou outros requisitos profissionais, ou requisitos impostos por lei 
ou  regulamento  (ver  NBC  TO  3000,  itens  3(a),  20  e  34)  que  sejam,  pelo  menos,  tão 
exigentes.  A NBC  TO  3000  também  requer que o  sócio  do  trabalho  seja membro  de firma 
de auditoria que aplique os procedimentos de gestão de qualidade estabelecidos pela NBC 
PA  01  (ver  NBC  TO  3000,  itens  3(b)  e  31(a)),  pela Norma  Internacional  de Gestão de 
Qualidade (NBC PA) 01, pela Gestão de Qualidade para Firmas (Pessoas Jurídicas e Físicas) 
de Auditores independentes), ou por outros requisitos profissionais, ou requisitos impostos 
por lei ou regulamento. 
 
35. O  relatório  do  auditor  independente  deve  incluir,  no  mínimo,  os  seguintes  elementos 
básicos (ver item A51): 
 
(h)  Declaração   de    que    o    auditor    independente    cumpre    com    o    requisito    de 
independência e outros requisitos éticos das NBCs PG 100, 200 e 300 e NBC PA 400 
e NBC PO 900, ou outros requisitos profissionais ou outros requisitos impostos por 
lei ou regulamento, que sejam pelo menos tão exigentes quanto as NBCs PG 100 e 
200  e  a NBC  PA  291,  relacionadas  com trabalhos  de  asseguração.  Se o  trabalho  de 
asseguração    for    conduzido    por    outro    profissional    que    não    seja    auditor 
independente, a declaração deve identificar os requisitos profissionais aplicáveis ou 
os  requisitos  impostos  por  lei  ou  regulamentos,  que  sejam,  pelo  menos,  tão 
exigentes quanto as regras de independência do CFC relacionadas com trabalhos de 
asseguração. 
 
A10. O  Código  de  Ética  Profissional  do  Contador  requer  que  o  auditor  independente cumpra 
com   o   princípio   da   competência   profissional   e   devido   zelo   mediante   obtenção   e 
manutenção  de  conhecimento  e habilidades  profissionais para prestar  serviço  profissional 
competente, com base em padrões técnicos e profissionais atuais e legislação relevante, e 
aja de forma diligente e de acordo com tais padrões profissionais e legislação. No contexto 
deste  requisito  CFC,  a  competência  profissional  para  executar  o  trabalho  pode  incluir 
questões como: 
 
• conhecimento e experiência no setor em que a entidade atua; 

• entendimento   das   leis   e   regulamentos   de   valores   mobiliários   aplicáveis   e 
acontecimentos relacionados; 
• entendimento  dos  requisitos  relevantes  de  registro  nas  bolsas  de  valores  e  de 
operações  do  mercado  de  capitais,  como  fusões,  aquisições  e  ofertas  de  títulos  e  valores 
mobiliários; 
• familiaridade  com  o  processo  de  elaboração  de  prospecto  e  registro  de  valores 
mobiliários na bolsa de valores; e 
• conhecimento de estruturas de relatório financeiro usadas na elaboração das fontes 
das  quais  as informações  financeiras  históricas  e,  se  aplicável,  as  informações  financeiras 
da adquirida foram extraídas. 
 
A41. O  Código  de  Ética  Profissional  do  Contador  que  o  auditor  independente  não  esteja 
intencionalmente associado a relatórios, declarações, comunicações ou outras informações 
que o auditor independente acredite: 
 
(a) conter declaração materialmente falsa ou enganosa; 
(b) conter declarações ou informações fornecidas de forma imprudente; ou 
(c) omitir  ou  ocultar  informações  necessárias  que  devem  ser  incluídas  onde  essa 
omissão ou ocultação seria enganosa. 
 
Apêndice 
 
Cumprimos com os requisitos de independência e outros requisitos éticos das NBCs PG 100 e 200 
e  NBC  PA  291, das  NBCs  PG  100  e  200  e  NBC  PO  900,  baseados  nos  princípios  fundamentais  de 
integridade,   objetividade,   e   competência   profissional   e   devido   zelo,   confidencialidade   e 
comportamento profissional. 
 
18. Altera o  Apêndice1, na NBC  TA  600  (R1) – Considerações  Especiais – Auditorias de 
Demonstrações    Contábeis    de    Grupos,    incluindo    o    Trabalho    dos    Auditores    dos 
Componentes, que passa a vigorar com a seguinte redação: 
 
APÊNDICE 1 
 
Para  fins  deste  exemplo  de  relatório  do  auditor  independente,  são  consideradas  as  seguintes 
circunstâncias:  
 
(...) 
 
• Os  requisitos  éticos  pertinentes  que  se  aplicam  à  auditoria  compõem  o  Código  de  Ética 
Profissional   do   Contador   e   as   normas   profissionais   emitidas   pelo   Conselho   Federal   de 
Contabilidade. 
 
(...) 
 
• Nossa  auditoria  foi  conduzida  de  acordo  com  as  normas  brasileiras  e  internacionais  de 
auditoria.  Nossas responsabilidades, em conformidade com tais normas, estão descritas na seção 
a  seguir,  intitulada “Responsabilidades do auditor pela auditoria das demonstrações contábeis”. 
Somos  independentes  em  relação  à  Companhia  e  suas  controladas,  de  acordo  com  o  Código 

Internacional  de  Ética  para  Profissionais  da  Contabilidade  do  Comitê  Internacional  de  Normas 
Éticas para Contadores (incluindo as Normas Internacionais de Independência) e com o Código de 
Ética da Ifac, e cumprimos com as demais responsabilidades éticas de acordo com o Código IESBA. 
Acreditamos  que  a  evidência  de  auditoria  obtida  é  apropriada  e  suficiente  para  fundamentar 
nossa opinião com ressalva. 
 
19. Altera os itens A14, A18, A19, na NBC TA 610 – Utilização do Trabalho de Auditoria Interna, 
incluindo o Trabalho dos Auditores dos Componentes, que passa a vigorar com a seguinte 
redação: 
 
A14. Além disso, a subseção 605 da NBC PA 400 afirma que a prestação de serviços de auditoria 
interna  para  cliente  de  auditoria  pode  criar  ameaça  de  autorrevisão. Os  itens  605.1  a 
R605.5 da NBC PA 400 discutem as proibições que se aplicam em certas circunstâncias, e as 
salvaguardas  que  podem  ser  aplicadas  para  reduzir  as  ameaças  a  um  nível  aceitável  em 
outras circunstâncias. 
 
A18. Uma  ampla  gama  de  circunstâncias  pode  ameaçar  a  objetividade, como,  por  exemplo, 
ameaças  de  interesse  próprio,  ameaças  de  defesa  de  interesse  do  cliente,  ameaças  de 
familiaridade,  ameaças  de  autorrevisão  e  ameaças  de  intimidação.  Essas  ameaças  podem 
ser  tratadas  mediante  a  eliminação  das  circunstâncias  que  criam  as  ameaças,  ou  a 
aplicação  de  salvaguardas  para  reduzi-las  a  um  nível  aceitável.  Pode  haver,  também, 
salvaguardas específicas para o trabalho de auditoria. 
 
A19. A  avaliação  de  se  as  ameaças  à  objetividade  estão  em  um  nível  aceitável  pode  depender 
das atribuições do especialista do auditor e da importância do seu trabalho no contexto da 
auditoria.  Em  alguns  casos,  pode  não  ser  possível  eliminar  as  circunstâncias  que  criam 
ameaças  ou  aplicar  salvaguardas  para  reduzi-las  a  um  nível  aceitável,  por  exemplo,  se  o 
especialista do auditor proposto for uma pessoa que teve papel significativo na elaboração 
das informações que estão sendo auditadas, ou seja, se o especialista é um especialista da 
administração. 
 
20. Altera a letra (c) do item 28, a letra (b) do item 40, A34, Apêndice diversos, na NBC TA 700 
– Formação   da  Opinião   e   Emissão  do Relatório   do   Auditor   Independente   sobre   as 
Demonstrações Contábeis, que passa a vigorar com a seguinte redação: 
 
28. O relatório do auditor deve incluir uma seção, logo após a seção “Opinião”, com o título 
“Base para opinião”, que (ver item A32): 
 
(...) 
(c) inclua  a  declaração  de  que  o  auditor  é  independente  da  entidade  de  acordo  com  os 
requisitos  éticos  pertinentes  relacionados  com  a  auditoria  e  que  ele  atendeu  às  outras 
responsabilidades  éticas  do  auditor  de  acordo  com  esses  requisitos.  A  declaração  deve 
identificar  a  jurisdição  de  origem dos  requisitos éticos  pertinentes  ou  referir-se  ao  Código 
de Ética Internacional para Profissionais da Contabilidade (IESBA) (ver itens A34 a A39); e 
 
 
40. A seção “Responsabilidades do auditor pela auditoria das demonstrações contábeis” do 
relatório do auditor deve também (ver item A50): 

 
(...) 
 
(b) declarar, para a auditoria das demonstrações contábeis de entidades de listadas, que o 
auditor  independente  fornece  para  os  responsáveis  pela  governança  uma declaração  de 
que ele  cumpriu  com os  requisitos  éticos pertinentes  relacionados  à  independência  e que 
comunicou  a  eles  todos  os  relacionamentos  e  outras  questões  que  podem,  de  forma 
razoável,  criar  ameaça  à  independência  do  auditor  e,  quando  aplicável,  as ações  tomadas 
para eliminar as ameaças ou as salvaguardas aplicadas; e 
 
 
A34. A  identificação  da  jurisdição  de  origem  dos  requisitos  éticos  pertinentes  aumenta  a 
transparência  esses  requisitos  com  relação  a  trabalho  de  auditoria  específico.  A  NBC  TA 
200, item A16, explica que os requisitos éticos pertinentes compreendem as disposições do 
Código de Ética Profissional do Contador e as normas profissionais emitidas pelo Conselho 
Federal  de  Contabilidade  em  conjunto  com  outros  requisitos  de  órgãos  reguladores, 
quando   forem   mais   restritivos.   Quando   os   requisitos   éticos   pertinentes   incluem   os 
requisitos  do  Código de Ética  Internacional  para Profissionais  da  Contabilidade  (Código  de 
Ética da  Ifac),  a declaração também pode  fazer  referência ao Código  de Ética da  Ifac. Se o 
Código  de  Ética  da  Ifac constitui  todos  os  requisitos  éticos  pertinentes  para  a  auditoria,  a 
declaração  não  precisa  identificar  a  jurisdição  de  origem.  No  Brasil,  a  declaração  acima 
somente fará referência ao Código de Ética da Ifac e às normas profissionais emitidas pelo 
Conselho Federal de Contabilidade. 
 
Apêndices (Diversos) 
 
Os   requisitos   éticos   pertinentes   que   se   aplicam   à   auditoria   compõem   o   Código   de   Ética 
Profissional   do   Contador   e   as   normas   profissionais   emitidas   pelo   Conselho Federal   de 
Contabilidade juntamente com os requisitos éticos relacionados com a auditoria na jurisdição, e o 
auditor refere-se a ambos. 
 
 
*** Diversos exemplos de relatório em outras normas requerem a mesma atualização 
 
Nossa  auditoria  foi  conduzida  de  acordo  com  as  normas  brasileiras  e  internacionais  de  auditoria. 
Nossas  responsabilidades,  em  conformidade  com  tais  normas,  estão  descritas  na  seção  a  seguir, 
intitulada “Responsabilidades do auditor pela auditoria das demonstrações contábeis”. Somos 
independentes  em  relação  à  Companhia,  de  acordo  com  o  Código  de  Ética  Profissional  do 
Contador e as normas profissionais emitidas pelo Conselho Federal de Contabilidade, juntamente 
com  os  requisitos  éticos  pertinentes  para  nossa  auditoria  das  demonstrações  contábeis  em 
[jurisdição], e cumprimos com as demais responsabilidades éticas de acordo com esses requisitos. 
 
Acreditamos  que  a  evidência  de  auditoria  obtida  é  suficiente  e  apropriada  para  fundamentar 
nossa opinião. 
 
Fornecemos  também  aos  responsáveis  pela  governança  declaração  de  que  cumprimos  com  os 
requisitos    éticos    pertinentes,    de    independência,    e    comunicamos    todos    os    eventuais 
relacionamentos  ou  assuntos  que  poderiam  afetar,  consideravelmente,  nossa  independência, 

incluindo,  quando  aplicável,  as  ações  tomadas para  eliminar  as  ameaças  ou  as  salvaguardas 
aplicadas. 
 
21. Altera o item 4, A38, na NBC TA 720 – Responsabilidades do Auditor em Relação a Outras 
Informações, que passa a vigorar com a seguinte redação: 
 
4. Esta   norma   também   pode   auxiliar   o   auditor   no cumprimento   dos   requisitos   éticos 
pertinentes,  que  requerem  que  o  auditor  evite  estar,  conscientemente,  associado  com 
informações que, segundo ele, contêm declaração significativamente falsa ou enganosa ou 
declarações   ou   informações   fornecidas   de   maneira   leviana,   ou   omitem   ou   ocultam 
informações necessárias nos casos em que essa omissão ou ocultação seja enganosa.  
 
A38. Permanecer atento a outros indícios de que as outras informações não relacionadas com as 
demonstrações contábeis ou com o conhecimento do auditor obtido na auditoria parecem 
apresentar   distorção   relevante   ajuda   o   auditor   a   cumprir   com   os   requisitos   éticos 
relevantes,  que  requerem  que  o  auditor  evite  estar,  conscientemente,  associado  com  as 
outras informações que, segundo acredita o auditor, contêm declaração significativamente 
falsa  ou  enganosa  ou  declaração  fornecida  de  maneira  leviana,  ou  omitem  ou  ocultam 
informações necessárias de forma que as outras informações sejam enganosas (ver NBC PG 
100(R1), item R111.2). 
 
Permanecer  atento  a  outros  indícios  de  que  as  outras  informações  parecem  apresentar 
distorção  relevante  pode,  potencialmente,  resultar  na  identificação,  por  parte  do  auditor, 
de questões como: 
 
• diferenças   entre   as   outras   informações   e   o   conhecimento   geral,   além   do 
conhecimento  obtido  na  auditoria,  do  membro  da  equipe  de  trabalho  que  lê  as 
outras  informações  que  levam  o  auditor  a  acreditar  que  as  outras  informações 
parecem apresentar distorção relevante; ou 
• inconsistência interna nas outras informações, que leva o auditor a acreditar que as 
outras informações parecem apresentar distorção relevante. 
 
22. Altera   o   exemplo   3   na   NBC   TA   800 – Considerações   Especiais – Auditorias   de 
Demonstrações   Contábeis   Elaboradas   de   Acordo   com   as   Estruturas   Conceituais   de 
Contabilidade para Propósitos Especiais, que passa a vigorar com a seguinte redação:  
 
Exemplo 3 
 
Fornecemos  também  aos  responsáveis  pela  governança  declaração  de  que  cumprimos  com  os 
requisitos    éticos    pertinentes,    de    independência,    e    comunicamos    todos    os    eventuais 
relacionamentos  ou  assuntos  que  poderiam  afetar,  de  forma  razoável,  a  nossa  independência, 
incluindo,  quando  aplicável,  as  ações  tomadas  para  eliminar  as  ameaças  ou  as  salvaguardas 
aplicadas. 
 
23. Altera  o  exemplo  3  na  NBC  TA  805 – Considerações  Especiais – Auditoria  de  Quadros 
Isolados  das  Demonstrações  Contábeis  e  de  Elementos,  Contas  ou  Itens  Específicos  das 
Demonstrações Contábeis, que passa a vigorar com a seguinte redação:  

 
Exemplo 3 
 
Fornecemos  também  aos  responsáveis  pela  governança  declaração  de  que  cumprimos  com  os 
requisitos    éticos    pertinentes,    de    independência,    e    comunicamos    todos    os    eventuais 
relacionamentos  ou  assuntos  que  poderiam  afetar,  de  forma  razoável,  nossa  independência, 
incluindo,  quando  aplicável,  as  ações  tomadas  para  eliminar  as  ameaças  ou  as  salvaguardas 
aplicadas. 
 
24. Altera   o   item   A13  na   NBC   TA  810 - Trabalhos  para   a   Emissão   de   Relatório   sobre 
Demonstrações Contábeis Condensadas, que passa a vigorar com a seguinte redação:  
 
A13. Ao ler as informações incluídas em documento que contenha as demonstrações contábeis 
condensadas  e  o  respectivo  relatório  do  auditor,  o  auditor  pode  tomar  conhecimento  de 
que  essas  informações  são  enganosas  e  pode  precisar  tomar  medidas  apropriadas. Os 
requisitos   éticos   pertinentes   requerem   que   o   auditor   evite   estar   conscientemente 
associado  com  informações que  ele acredita  conter  declaração  significativamente falsa  ou 
enganosa ou declarações ou informações fornecidas de maneira leviana, ou que omitem ou 
ocultam  informações  necessárias  nos  casos  em  que  essa  omissão  ou  ocultação  seria 
enganosa (ver NBC PG 100(R1) item R111.2). 
 
25. Altera  a  letra  (a)  do  item  3,  20,  34, a letra  (j)  do  item  69,  A30,  A31,  A32,  A33,  A34,  A68, 
A102, A128, A173, as letras (a) e (b) do item A195, A198, A199, na NBC TO 3000 – Trabalho 
de  Asseguração  Diferente  de  Auditoria  e  Revisão,  que  passa  a  vigorar  com  a  seguinte 
redação:  
3. Esta norma tem como premissa que: 
 
(a) os membros da equipe de trabalho e o revisor de qualidade do trabalho (nos casos em 
que  for  designado)  estão  sujeitos  às  disposições  do Código  de  Ética  Profissional  do 
Contador e às Normas Profissionais relacionadas com trabalhos de asseguração, bem como 
a outros  requisitos  profissionais,  ou  requisitos  de  leis  ou  regulamentos,  que  sejam,  no 
mínimo,  tão  exigentes  quanto  o Código  de  Ética  Profissional  do  Contador e  as  Normas 
Profissionais (ver itens A30 a A34); e 
 
20. O  auditor  independente  deve  cumprir  com  disposições  do Código  de  Ética  Profissional  do 
Contador e  as  Normas  Profissionais  relacionadas  com  trabalhos  de  asseguração  ou outros 
requisitos  profissionais  impostos  por  leis  ou  regulamentos  que  sejam,  no  mínimo,  tão 
exigentes quanto o Código de Ética Profissional do Contador e as Normas Profissionais (ver 
itens A30 a A34, A60). 
 
34. Durante  todo  o  trabalho,  o  sócio  responsável  pelo  trabalho  deve  permanecer  alerta, 
observando  e  fazendo  indagações,  conforme  necessário,  para  evidenciar  violações  de 
requisitos  éticos  relevantes  pelos  membros  da  equipe  de  trabalho.  No  caso  de  algum 
assunto chegar  ao  conhecimento  do  sócio  responsável  pelo  trabalho  por  meio  do  sistema 
de gestão de qualidade da  firma  ou de outra forma,  que  indique  que  membros da  equipe 
de trabalho violaram requisitos éticos relevantes, o sócio do trabalho, mediante consulta a 
outros profissionais da firma, deve determinar as medidas apropriadas. 
 

Durante  todo  o  trabalho,  o  sócio  responsável  pelo  trabalho  deve  permanecer  alerta,  por 
meio  de  observação  e  indagações,  quando  necessárias,  a  evidências  de  violações  dos 
requisitos éticos pelos membros da equipe de trabalho.  Se surgirem assuntos que chamem 
a  atenção  do  sócio  responsável  por  meio  do  sistema  de gestão de  qualidade  da  firma  ou 
que, de  outra  forma, indiquem  que  os  membros  da  equipe  de  trabalho  violaram  os 
requisitos éticos, o sócio responsável pelo trabalho, consultando seus pares na firma, deve 
determinar a ação apropriada. 
 
69. O relatório de asseguração deve incluir, no mínimo, os seguintes elementos básicos: 
(...) 
 
(j) declaração de que o auditor independente cumpre com os requisitos de independência 
e  outros  requisitos  éticos  do Código  de  Ética  Profissional  do  Contador e  as  Normas 
Profissionais,   ou   outros   requisitos   profissionais   ou   requisitos   impostos   por   leis   ou 
regulamentos,   que   sejam   tão   exigentes   quanto   as   disposições   do Código   de   Ética 
Profissional   do   Contador e   as   Normas   Profissionais   relacionadas   com   trabalhos   de 
asseguração.  Se  o  trabalho  de  asseguração  for  conduzido  por  outro  profissional  que  não 
seja   auditor   independente,   a   declaração   deve   identificar   os   requisitos   profissionais 
aplicáveis  ou  os  requisitos  impostos  por  lei  ou  regulamento,  que  sejam,  pelo  menos,  tão 
exigentes  quanto  as  disposições  do Código  de  Ética  Profissional  do  Contador e  as  Normas 
Profissionais aplicáveis aos relacionadas com trabalhos de asseguração (ver NBC PO 900); 
(...) 
 
A30. O Código  de  Ética  Profissional  do  Contador e  as  Normas  Profissionais  estabelecem  os 
princípios fundamentais de ética, que são: 
 
(a) integridade; 
(b) objetividade; 
(c) competência profissional e devido zelo; 
(d) confidencialidade; e 
(e) comportamento profissional. 
 
Os princípios fundamentais de ética estabelecem o padrão de comportamento esperado de 
um profissional da contabilidade. 
 
 
A31. O Código  de  Ética  Profissional  do  Contador e  as  Normas  Profissionais  fornecem  uma 
estrutura conceitual que o profissional da contabilidade deve aplicar ao identificar, avaliar 
e tratar as ameaças ao cumprimento dos princípios fundamentais, incluindo: 
 
(a) identificar   ameaças   ao   cumprimento   dos   princípios   éticos.   As   ameaças   se 
enquadram em uma ou mais das seguintes categorias: 
(i) interesse próprio; 
(ii) autorrevisão; 
(iii) defesa de interesse do cliente; 
(iv) familiaridade; e 
(v) intimidação. 
 
(b) avaliar se as ameaças identificadas estão em um nível aceitável; e  

 
(c) se as ameaças ao cumprimento dos princípios fundamentais identificadas não estão em 
um  nível  aceitável,  tratá-las  mediante  a  eliminação  das  circunstâncias  que  criam  as 
ameaças, aplicando  salvaguardas  para  reduzi-las  a  um  nível  aceitável,  ou  retirando-se 
do trabalho, quando a retirada é permitida por lei ou regulamento aplicável. 
 
A32. O Código  de  Ética  Profissional  do  Contador e  as  Normas  Profissionais  apresenta  os 
requisitos e o material de aplicação sobre vários temas, incluindo: 
  
• conflitos de interesses; 
  • nomeação de profissionais; 
• segunda opinião; 
• honorários e outros tipos de remuneração; 
• incentivos, incluindo presentes e afins; 
• custódia de ativos de clientes; e 
• resposta à não conformidade com leis e regulamentos. 
 
A33. O Código   de   Ética   Profissional   do   Contador e   as   Normas   Profissionais   definem 
independência    como    sendo    tanto    a    independência    de    pensamento    quanto    a 
independência  na  aparência.    A  independência  possibilita  a  capacidade  de  formar  uma 
conclusão de asseguração sem ser afetada pelas influências que podem comprometer essa 
conclusão.  A  independência  aprimora  a  habilidade  de  agir  com  integridade,  ser  objetivo  e 
manter   uma   atitude   de   ceticismo   profissional.   Assuntos   abordados nas Normas   de 
Independência  do Código  de  Ética  Profissional  do  Contador e  as  Normas  Profissionais 
incluem, por exemplo: 
 
  • honorários; 
 • presentes e afins; 
 • litígio real ou ameaças de litígio; 
 • interesses financeiros; 
 • empréstimos e garantias; 
 • relacionamentos comerciais; 
 • relações familiares e pessoais; 
 • serviço recente em um cliente de asseguração; 
 • função de conselheiro ou diretor em um cliente de asseguração; 
 • emprego em um cliente de asseguração; 
 • longa associação do pessoal sênior com um cliente de asseguração; 
 • prestação de serviços que não são de asseguração para um cliente de asseguração; 
e  
  • relatórios que incluem uma restrição ao uso e à distribuição. 
 
A34.  Requisitos  profissionais  ou  requisitos  estabelecidos  por  leis  ou  regulamentos  são  pelo 
menos  tão  exigentes  quanto  as  disposições  do Código  de  Ética  Profissional  do  Contador e 
as Normas Profissionais relacionadas com trabalhos de asseguração ao abordarem todos os 
assuntos  mencionados  nos  itens  A30  a  A33  e  obrigações  estabelecidas  que  alcancem  os 
objetivos  dos  requisitos  estabelecidos  no Código  de  Ética  Profissional  do  Contador e nas 
Normas Profissionais para esses trabalhos de asseguração. 
 

A68. O Código   de   Ética   Profissional   do   Contador e   as   Normas   Profissionais   estabelecem 
requisitos  e  orientações  sobre  ameaça  de  interesse  próprio  ao  cumprimento  do  princípio 
de competência profissional e devido zelo que é criada se a equipe de trabalho não tem, ou 
não  pode  adquirir,  as  competências  para  executar  os  serviços  profissionais.  O  auditor 
independente  é  o  único  responsável  pela  conclusão  da  asseguração  emitida,  e  essa 
responsabilidade não é reduzida pelo uso que ele faça de seu especialista. No entanto, se o 
auditor   independente,   ao   usar   o   trabalho   do   especialista tendo   seguido   as   normas 
aplicáveis,  concluir  que  o  seu  trabalho  é  adequado  para  os  propósitos  do  auditor,  este 
pode aceitar as constatações ou conclusões dos especialistas como evidências apropriadas. 
 
A102. O auditor pode ter responsabilidades adicionais nos termos de leis, de regulamentos ou de 
requisitos  éticos  relevantes  com  relação  à  não  conformidade  por  parte  da  entidade  com 
leis e regulamentos, que podem diferir desta Norma ou ir além dela, como, por exemplo: 
 
(a) resposta  à  não  conformidade  identificada  ou  suspeita  de  não  conformidade  com 
leis    e    regulamentos,    incluindo    requisitos    relacionados    com    comunicações 
específicas    com    a    administração    e    aos    responsáveis    pela    governança,    e 
considerando se medidas adicionais são necessárias; 
 
(b) comunicação  de  não  conformidade  identificada  ou  suspeita  de  não  conformidade 
com leis e regulamentos ao auditor (ver, por exemplo, itens R360.31 e 360.35 A1 da 
NBC PG 300); e  
 
(c) requisitos  de  documentação relacionada  com  a  não  conformidade  identificada  ou 
suspeita de não conformidade com leis e regulamentos. 
 
O  cumprimento  de  quaisquer  responsabilidades  adicionais  pode  fornecer  informações 
adicionais  relevantes  para  o  trabalho  do  auditor  de  acordo  com  esta e  qualquer  outra 
norma (por exemplo, informações relacionadas com a integridade da parte responsável ou 
dos responsáveis pela governança). Os itens A194 a A198 tratam de forma mais detalhada 
das  responsabilidades  do  auditor  nos  termos  de  leis,  de  regulamentos  ou  de  requisitos 
éticos  relevantes  relacionados  com  a  comunicação  de  não  conformidade  identificada  ou 
suspeita de não conformidade com leis e regulamentos. 
 
A128. A avaliação de se as ameaças à objetividade estão em um nível aceitável pode depender do 
papel  do  especialista  e  da  relevância  de  seu  trabalho  no  contexto  da  asseguração. Em 
alguns casos, pode não ser possível eliminar as circunstâncias que criam ameaças ou aplicar 
salvaguardas  para  reduzi-las  a  um  nível  aceitável,  por  exemplo,  se  o  especialista  for  uma 
pessoa que teve papel significativo na preparação das informações do objeto. 
 
A172. A  seguir, é  apresentado  exemplo  de  afirmação  no  relatório  de  asseguração  sobre  o 
cumprimento dos requisitos éticos: 
 
Cumprimos  com  os  requisitos  de  independência e  outros  requisitos  éticos  do Código  de 
Ética   Profissional   do   Contador e das Normas   Profissionais   (incluindo   as   Normas   de 
Independência)   baseados   nos   princípios   fundamentais   de   integridade,   objetividade, 
competência profissional e devido zelo, confidencialidade e comportamento profissional. 
 
A195. Leis, regulamentos ou requisitos éticos relevantes podem: 

 
(a) requerer que o auditor comunique a não conformidade identificada ou suspeita de 
não  conformidade  com  leis  e  regulamentos  à  autoridade competente  externa  à 
entidade; 
(b) estabelecer   responsabilidades,   segundo   as   quais   a   comunicação   à   autoridade 
competente  externa  à  entidade  pode  ser  apropriada  nas  circunstâncias  (ver,  por 
exemplo, os itens 360.36A2 e 360.36A3 da NBC PG 300 itens R360.36 e R360.37 da 
NBC PG 300). 
 
A198. Em outras circunstâncias, a comunicação da não conformidade identificada ou suspeita de 
não  conformidade  com  leis  e  regulamentos  à  autoridade  competente  externa  à  entidade 
pode  ser  impedida  pelo  dever  do  auditor  de  confidencialidade  nos  termos  de  leis,  de 
regulamentos  ou  de  requisitos  éticos  relevantes.  Em  outros  casos,  a  comunicação  de  não 
conformidade  identificada  ou  suspeita  de  não  conformidade  à  autoridade  competente 
externa à entidade não seria considerada uma violação do dever de confidencialidade nos 
termos dos requisitos éticos relevantes (ver, por exemplo, itens R114.1, 114.1 A1 e R360.37 
da NBC PG 300). 
 
A199. O auditor pode considerar uma consulta interna (por exemplo, dentro da firma ou de firma 
da  rede),  para  obtenção  de  assessoria  legal  para  entender  as  implicações  profissionais  ou 
legais   de   se   tomar   qualquer   curso   de   ação   em   particular   ou   consultar,   de   forma 
confidencial,  o  regulador  ou  órgão  profissional, a  menos  que  isso  seja  proibido  por  lei  ou 
regulamento ou que viole o dever de confidencialidade (ver, por exemplo, o item 360.39A1 
da NBC PG 300). 
 
 
 
 
 
Brasília, 9 de novembro de 2022. 
 
 
CONTADOR AÉCIO PRADO DANTAS JÚNIOR 
Presidente 
 
Ata CFC n.º 1.092.
