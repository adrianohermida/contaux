# NBC TA Estrutura Conceitual para Trabalhos de Asseguração

- Código externo: 2015/nbctaestruturaconceitual
- Fonte: CFC 2015/NBCTAESTRUTURACONCEITUAL — DOU 25/11/2015
- URL fonte: https://www2.cfc.org.br/sisweb/sre/detalhes_sre.aspx?Codigo=2015/NBCTAESTRUTURACONCEITUAL
- Arquivo original: https://www1.cfc.org.br/sisweb/SRE/docs/NBCTAESTRUTURACONCEITUAL.pdf
- Nome do arquivo: NBCTAESTRUTURACONCEITUAL.pdf
- Tags: Contábil, NBC, NBC TA
- Atualizado em: 2026-10-10 14:28:38.244248+00

## Resumo

NBC TA Estrutura Conceitual para Trabalhos de Asseguração

## Texto integral extraído

NORMA  BRASILEIRA  DE  CONTABILIDADE – NBC TA ESTRUTURA  CONCEITUAL, 
DE 20 DE NOVEMBRO DE 2015.  
 
 
Dá  nova  redação  à  NBC TA ESTRUTURA 
CONCEITUAL que  dispõe  sobre a  estrutura 
conceitual para trabalhos de asseguração.  
 
 
O CONSELHO   FEDERAL   DE   CONTABILIDADE, considerando   o   processo   de 
convergência  das  Normas  Brasileiras  de  Contabilidade  aos  padrões  internacionais  e  que,  mediante 
acordo  firmado  com  a Ifac, que  autorizou,  no  Brasil,  o  CFC  e  o  Instituto  dos  Auditores 
Independentes  do  Brasil (Ibracon) como  tradutores de  suas  normas  e  publicações,  outorgando  os 
direitos  de  realizar  tradução,  publicação  e  distribuição  das  normas  internacionais  em  formato 
eletrônico, no exercício  de suas  atribuições legais e regimentais e com  fundamento no disposto na 
alínea “f” do Art. 6º do Decreto-Lei n.º 9.295/1946, alterado pela Lei n.º 12.249/2010, faz saber que 
foi  aprovada  em  seu  Plenário  a  seguinte  Norma  Brasileira  de  Contabilidade  (NBC), elaborada  de 
acordo com a sua equivalente internacional “International Framework for Assurance Engagements” 
da Ifac: 
 
 
NBC TA ESTURUTURA CONCEITUAL – ESTRUTURA CONCEITUAL PARA 
TRABALHOS DE ASSEGURAÇÃO 
 
 
Sumário Item 
Introdução 1 – 4 
Princípios éticos e normas de controle de qualidade 5 – 9 
Descrição dos trabalhos de asseguração 10 – 11 
Trabalho de atestação e trabalho direto 12 – 13 
Trabalho de asseguração razoável e trabalho de asseguração limitada 14 – 16 
Abrangência da estrutura conceitual 17 – 19 
Relatório de trabalho que não é de asseguração 20 – 21 
Precondições para trabalho de asseguração 22 – 25 
Elementos do trabalho de asseguração 26 
Relacionamento entre três partes 27 – 38 
Objeto 39 – 41 
Critérios 42 – 49 
Evidências 50 – 82 
Relatório de asseguração 83 – 92 

 
 
 
2 
 
Outras partes 93 – 95 
Uso inapropriado do nome do auditor independente 96 
Vigência 97 
Apêndice 1: Não editado  
Apêndice 2: Trabalho de atestação e trabalho direto  
Apêndice 3: Partes do trabalho de asseguração  
Apêndice 4: Categorização dos objetos em trabalhos de asseguração  
 
 
 
Introdução 
 
1. Esta Estrutura Conceitual é  emitida  apenas  com  o  intuito  de  facilitar  o  entendimento  dos 
elementos  e  objetivos  dos  trabalhos  de  asseguração  e  dos  trabalhos  aos  quais  as  NBCs  TA, 
NBCs TR e NBCs TO (doravante referidas como Normas de Asseguração) se aplicam. 
 
2.  Esta estrutura não  é  uma norma  e,  por  conseguinte,  não  estabelece  nenhum  requisito  (nem 
princípios  básicos  ou  procedimentos  essenciais)  para  a  realização  de  auditorias,  revisões  ou 
outros trabalhos de asseguração. Um relatório de asseguração não pode, portanto, afirmar que 
o  trabalho  foi  conduzido  de  acordo  com  esta estrutura,  devendo  se  referir  às normas  de 
asseguração   aplicáveis.   As normas   de   asseguração possuem   objetivos,   requerimentos, 
aplicações e outros materiais explicativos, introduções e definições que são consistentes com 
esta estrutura e devem ser aplicados em auditorias, revisões e outros trabalhos de asseguração.  
 
3.  Esta estrutura fornece quadro de referência para: 
(a) auditores independentes; 
(b) outras pessoas envolvidas com trabalhos de asseguração, incluindo os usuários previstos 
de  relatório  de  asseguração  e  aqueles  que  contratam  o  auditor  independente  (parte 
contratante); e 
(c) CFC ao emitir normas de asseguração e outras normas técnicas. 
  
4.  O que se segue é uma visão geral desta estrutura:  
 Introdução:  Esta  estrutura  trata dos  trabalhos  de  asseguração  executados  por  auditores 
independentes. 
 Descrição dos trabalhos de asseguração: Esta parte descreve os trabalhos de asseguração e 
distingue o trabalho direto em relação ao trabalho de atestação, assim como o trabalho de 
asseguração razoável e o trabalho de asseguração limitada. 
 Abrangência  da estrutura conceitual:  Esta  parte distingue  trabalhos  de  asseguração  de 
outros trabalhos, como, por exemplo, trabalhos de consultoria. 
 Precondições para trabalho de asseguração: Esta parte estabelece precondições para que o 

 
 
 
3 
 
auditor independente aceite trabalho de asseguração. 
 Elementos  de  trabalho  de  asseguração: Esta  parte identifica  e  discute  os  cinco  elementos 
presentes  em  trabalhos  de  asseguração:  o  relacionamento  entre  três  partes,  o  objeto,  os 
critérios,  as  evidências  e  o  relatório  de  asseguração.  Ela  explica, adicionalmente, as 
distinções importantes entre trabalhos de asseguração razoável e trabalhos de asseguração 
limitada.  Esta  seção  também  discute,  por  exemplo,  a  variação  significativa  no  objeto  dos 
trabalhos de asseguração, as características requeridas dos critérios adequados, a função do 
risco e da relevância nos trabalhos de asseguração e como as conclusões são expressas em 
trabalhos de asseguração razoável e trabalhos de asseguração limitada. 
 Outros assuntos: Esta parte discute as responsabilidades de outras comunicações do auditor 
independente   que   não   estejam   relacionadas   com   o   seu   relatório   de   asseguração,   a 
documentação  e  as  implicações  da  associação  do  auditor  com  o  objeto  ou  com  a 
informação do objeto. 
 
Princípios éticos e normas de controle de qualidade 
 
5.  O controle de qualidade em firmas que executam trabalhos de asseguração e a conformidade 
com   os   princípios   éticos,   incluindo   requerimentos   de   independência,   é   amplamente 
reconhecido como sendo de interesse público e parte integrante dos trabalhos de asseguração 
de alta qualidade. Tais trabalhos são realizados de acordo com as normas de asseguração, que 
possuem como premissa a base de que: 
(a) os  membros  da  equipe  e  o  revisor  de controle  de  qualidade  (para  aqueles  trabalhos  em 
que  tal  revisão  foi  estabelecida)  estão  sujeitos  às  normas  NBCs  PG 100 – Aplicação 
Geral  aos  Profissionais  da  Contabilidade e  200 – Contadores  que  Prestam  Serviços 
(Contadores  Externos) e  NBCs  PA  290 – Independência – Trabalhos  de  Auditoria  e 
Revisão  e  291 – Independência – Outros  Trabalhos  de  Asseguração,  relacionadas  aos 
trabalhos  de  asseguração,  ou  requerimentos  de  lei  ou  regulamento,  que  sejam, pelo 
menos, tão exigentes quanto às referidas NBCs; e 
(b) o auditor  independente  é  membro  da  firma  que  está  sujeita  à  NBC  PA  01  ou  outros 
requerimentos de lei ou  regulamento sobre a  responsabilidade da  firma pelo seu sistema 
de  controle  de  qualidade,  que  seja, pelo  menos, tão  exigente  quanto à referida  NBC  PA 
01. 
 
Código de ética e normas profissionais do CFC  
 
6.  A  NBC  PG 100  estabelece  os  seguintes  princípios éticos que  o  auditor  independente  é 
requerido a cumprir: 
(a) integridade;  
(b) objetividade;  
(c) competência e zelo profissionais; 
(d) sigilo profissional; e 
(e) comportamento profissional.  
 
7.  A NBC PG 100 também fornece uma estrutura conceitual para ser aplicada pelos profissionais 
da contabilidade  para  identificar  ameaças  ao  cumprimento  dos  princípios éticos,  avaliar  a 

 
 
 
4 
 
significância  das  ameaças  identificadas  e,  quando  necessário,  aplicar  salvaguardas  para 
eliminar as ameaças ou reduzi-las a um nível aceitável. 
 
8.  A NBC PG 200 descreve como os conceitos da NBC PG 100 se aplicam em certas situações 
para  profissionais  da contabilidade  que  atuem  como  auditor  independente,  incluindo  a 
independência. Essas normas profissionais definem a independência como abrangendo tanto a 
independência de pensamento quanto a independência na aparência. A independência garante 
a  habilidade  de  formar  uma  conclusão  de  asseguração  sem  ser  afetado  por  influências  que 
possam  comprometer  essa  conclusão.  A  independência  aprimora  a  habilidade  de  agir  com 
integridade, ser objetivo e de manter atitude de ceticismo profissional. 
 
NBC PA 01 
 
9.  A NBC PA 01 – Controle de Qualidade para Firmas (Pessoas Jurídicas e Físicas) de Auditores 
Independentes trata  das  responsabilidades  da  firma  em  estabelecer  e  manter  seu  sistema  de 
controle de qualidade para trabalhos de  asseguração. O cumprimento da NBC PA 01 requer, 
entre  outras  coisas,  que  a  firma  estabeleça  e  mantenha um sistema de  controle  de  qualidade. 
Esse  sistema  deve incluir políticas  e  procedimentos que abordem cada  um  dos  elementos  a 
seguir mencionados e que documentem suas políticas e procedimentos e que os comuniquem 
ao pessoal da firma, a saber: 
(a) responsabilidades da liderança pela qualidade dentro da firma; 
(b) exigências éticas relevantes; 
(c) aceitação e continuidade de relacionamento com clientes e para trabalhos específicos; 
(d) recursos humanos; 
(e) execução do trabalho; e 
(f) monitoramento. 
 
Descrição dos trabalhos de asseguração 
 
10.  Trabalho  de  asseguração  é o trabalho  no  qual  o  auditor  independente  visa  obter  evidências 
apropriadas  e  suficientes  para  expressar  sua  conclusão, de  forma  a  aumentar  o  grau  de 
confiança dos usuários previstos sobre o resultado da mensuração ou avaliação do objeto, de 
acordo com os critérios que sejam aplicáveis.  
 
11.  O resultado da mensuração ou avaliação do objeto é a informação que resulta da aplicação do 
critério ao objeto. Por exemplo: 
 Demonstrações  contábeis  (resultado) resultam  da  mensuração  da  posição  patrimonial  e 
financeira da entidade, do desempenho e dos fluxos de caixa (objeto) ao aplicar a estrutura 
de relatórios financeiros aplicáveis (critério). 
 Conclusão sobre a eficácia do controle interno (resultado) decorre da avaliação da eficácia 
do processo de controle interno da entidade (objeto) ao aplicar os critérios aplicáveis. 
 Mensurações  de  desempenho  específicas  à  entidade  (resultado)  decorrem  da  mensuração 
de  vários  aspectos  de  desempenho  (objeto)  ao  aplicar  as  metodologias de  mensuração 
aplicáveis (critério). 

 
 
 
5 
 
 Declaração  de  gases  de  efeito  estufa  (resultado)  decorre  da  mensuração  das  emissões  de 
gases  de  efeito  estufa  da entidade  (objeto)  ao  aplicar  o  reconhecimento,  mensuração  e 
apresentação de protocolos (critério). 
 Declaração  sobre  o  cumprimento  (resultado)  decorre  da  avaliação  do  cumprimento  da 
entidade (objeto) com, por exemplo, lei ou regulamento (critério). 
A  expressão “informação do objeto” é usada para  significar  o  resultado  da  mensuração  ou 
avaliação do objeto de acordo com os critérios. É sobre a informação do objeto que o auditor 
independente obtém evidências apropriadas e suficientes para a base de sua conclusão. 
 
Trabalho de atestação e trabalho direto 
 
12.  No trabalho de atestação, o profissional, que não seja o auditor independente, deve mensurar 
ou avaliar o objeto de acordo com os critérios aplicáveis. O referido profissional também deve 
apresentar,  frequentemente, a informação resultante do objeto no relatório  ou afirmação. Em 
alguns casos, contudo, a informação do objeto pode ser apresentada pelo auditor independente 
no  relatório  de  asseguração.  A  conclusão  do  auditor deve mencionar se  a  informação  do 
objeto está livre de distorções relevantes (ver item 85). 
 
13.  No trabalho  direto,  o  auditor deve mensurar ou  avaliar o  objeto  de  acordo  com os  critérios 
aplicáveis.  Adicionalmente,  o  auditor deve aplicar as  habilidades  e  técnicas  de  asseguração 
para obter evidências apropriadas e suficientes sobre o resultado da mensuração ou avaliação 
do  objeto, de  acordo  com  os  critérios  aplicáveis.  O  auditor  independente  pode  obter  essa 
evidência  simultaneamente  com  a  mensuração  ou  avaliação  do  objeto,  mas  também  pode 
obtê-la antes ou após tal mensuração ou avaliação. No trabalho direto, a conclusão do auditor 
independente deve mencionar se o resultado reportado da mensuração ou avaliação do objeto, 
de  acordo  com  os  critérios, é  redigido  nos  termos  do  objeto  e  dos  critérios.  Em  alguns 
trabalhos diretos, a conclusão do auditor independente é a informação do objeto ou é parte da 
informação do objeto (ver Apêndice 2). 
 
Trabalho de asseguração razoável e trabalho de asseguração limitada 
 
14.  No trabalho  de  asseguração  razoável,  o  auditor  independente  reduz  o  risco  do  trabalho  para 
um nível aceitavelmente baixo nas circunstâncias do trabalho como base para a sua conclusão. 
A conclusão do auditor independente é expressa de forma que transmita a sua opinião sobre o 
resultado  da  mensuração  ou  avaliação  de  determinado  objeto  de  acordo  com  os  critérios 
aplicáveis. 
 
15.  No trabalho  de  asseguração  limitada,  o  auditor  independente  reduz  o  risco  do  trabalho  para 
um  nível  que  é  aceitável  nas  circunstâncias  do  trabalho,  mas  que  ainda  é  maior  do  que  para 
um  trabalho  de  asseguração  razoável.  Dessa  forma,  sua  conclusão  deve  transmitir  se,  com 
base  nos  procedimentos  realizados  e  evidências  obtidas,  algum  assunto  chegou  ao  seu 
conhecimento de forma a levá-lo a acreditar que a informação do objeto está relevantemente 
distorcida.  A  natureza,  a  época  e  a  extensão  dos  procedimentos  executados no trabalho  de 
asseguração  limitada  são  restritos  (menos  extensos),  quando  comparados  com  os  que  são 
necessários no trabalho  de  asseguração  razoável,  mas  são  planejados  para  obter  um  nível  de 
segurança  que  seja,  no  julgamento  profissional  do  auditor  independente,  significativo.  Para 
que seja significativo, o nível de segurança obtido pelo auditor deve ser capaz de aumentar a 
confiança dos usuários previstos sobre a informação do objeto em nível que seja mais do que 

 
 
 
6 
 
irrelevante. 
 
16.  Em  toda  a  gama  de  trabalhos  de  asseguração  limitada,  o  sentido  de  segurança  significativa 
pode  variar  de  um  nível  que  é  logo  acima  de  asseguração  que  seja  capaz  de  aumentar  a 
confiança dos usuários previstos sobre a informação do objeto, em nível que seja claramente 
maior  do  que  irrelevante,  até  um  nível  que  é  logo  abaixo  da  segurança  razoável.  O  que  é 
significativo  em  trabalho  específico é o  julgamento  dentro  desse  intervalo  que  depende  das 
circunstâncias  do  trabalho,  incluindo  as  necessidades  de  informação  pelos  usuários  previstos 
como  grupo,  critérios  utilizados  e  o  objeto  do  trabalho.  Em  alguns  casos,  as  consequências 
para  os  usuários  previstos  ao  receberem  um  tipo  de  asseguração  inapropriada  podem  ser  tão 
graves que o trabalho de asseguração razoável seja necessário para que o auditor independente 
obtenha a segurança que é significativa nas circunstâncias. 
 
Abrangência da estrutura conceitual 
 
17.  Nem todos os trabalhos realizados por auditores independentes são trabalhos de asseguração. 
Outros  trabalhos  frequentemente  realizados  que  não  são  de  asseguração,  como  definido  no 
item 10, não são abrangidos por esta estrutura. Esses outros trabalhos incluem: 
 trabalhos   abrangidos   pelas   Normas   de   Serviços   Correlatos   (NBCs   TSC,   tais   como 
procedimentos previamente acordados e trabalhos de compilação); 
 elaboração de declarações de imposto de renda em que nenhuma conclusão de asseguração 
é expressa; 
 trabalhos de consultoria (ou assessoria), tais como gerenciamento e consultorias tributárias. 
(*)  
(*) Nos  trabalhos  de  consultoria,  o  profissional  aplica  suas  habilidades,  seu  conhecimento  obtido  em 
treinamentos, observações, experiências e conhecimentos técnicos sobre o processo de consultoria. Trabalhos 
de  consultoria  envolvem  um  processo  analítico  que  tipicamente  inclui  alguma  combinação  das  atividades 
relacionadas  com  a  definição  de  objetivos,  a  descoberta  de  fatos,  as  definições  dos  problemas  ou  das 
oportunidades,  a  avaliação  de  alternativas,  o  desenvolvimento  ou as recomendações,  incluindo  ações, 
comunicação  de  resultados  e,  em  alguns  casos,  a  implementação  do  que  foi  recomendado  e  o  seu 
acompanhamento.  Os  relatórios  (caso  emitidos)  geralmente  são  escritos  em  estilo  narrativo  (ou  “formato 
longo”). Geralmente o trabalho realizado é apenas para uso e benefício do cliente. A natureza e o alcance do 
trabalho  são  determinados  mediante  acordo  entre  o  profissional  e  o  cliente.  Qualquer  serviço  que  atenda  às 
definições de trabalho de asseguração não é trabalho de consultoria, mas, sim, trabalho de asseguração. 
 
18.  O trabalho  de  asseguração  pode  ser  parte  de  um  trabalho  maior,  por  exemplo,  quando o 
trabalho   de consultoria   para a aquisição   de   negócios   inclui   requerimento   para   obter 
asseguração acerca da informação financeira histórica ou prospectiva. Em tais circunstâncias, 
esta estrutura é aplicável apenas na parte do trabalho relacionada à asseguração. 
 
19.  Os trabalhos mencionados a seguir, que podem ser consistentes com  a descrição no item 10, 
não são considerados trabalhos de asseguração nos termos desta estrutura: 
(a) trabalhos  para  prestar  declarações  em  processos  judiciais  sobre  contabilidade,  auditoria, 
tributação ou outros assuntos; e 
(b) trabalhos que incluem opiniões, pontos de vista ou declarações profissionais dos quais o 
usuário pode extrair alguma segurança, se todos os seguintes itens forem aplicáveis: 
(i) essas  opiniões,  pontos  de  vistas  ou  declarações  são  meramente  fortuitos  para  o 

 
 
 
7 
 
trabalho como um todo;  
(ii) qualquer  relatório  por  escrito  deve  ser  emitido  com  uso  expressamente  restrito  aos 
usuários previstos especificados no relatório; 
(iii) mediante acordo formal com os usuários previstos especificados, não se pretendendo 
que seja trabalho de asseguração; e 
(iv) o  trabalho  não  seja  relatado  como  trabalho  de  asseguração  no  relatório  do  auditor 
independente. 
 
Relatório de trabalho que não é de asseguração 
 
20.  O auditor independente ao reportar sobre trabalho, que não é de asseguração no âmbito desta 
estrutura,  deve  claramente  distinguir  esse  relatório  de  relatório  de  asseguração.  Para  não 
confundir os usuários, o relatório que não é de asseguração evita, por exemplo: 
 mencionar adequação com esta estrutura ou norma de asseguração;  
 usar inapropriadamente as palavras “asseguração,” “auditoria” ou “revisão”;  
 incluir  declaração  que  possa ser  confundida  com  conclusão  com  base  em  evidências 
apropriadas  e  suficientes  que tenham sido desenvolvidas para  aumentar  o  nível  de 
confiança  dos  usuários  previstos  sobre  o  resultado  da  mensuração  ou  avaliação  do objeto 
de acordo com os critérios aplicáveis. 
 
21.  O  auditor  independente  e  a  parte  responsável  podem  concordar  sobre  a  aplicação  dos 
princípios desta estrutura para o trabalho quando não existirem outros usuários previstos além 
da  parte   responsável, desde  que todos  os  outros  requisitos  aplicáveis  das normas  de 
asseguração  sejam  atendidos. Em  tais  casos,  o  relatório  do  auditor  independente  inclui 
declaração restringindo o uso do relatório à parte responsável. 
 
Precondições para trabalho de asseguração 
 
22.  As  seguintes  precondições  para  trabalho  de  asseguração  são  relevantes  para  aceitação  e 
continuidade: 
(a) as  funções  e as responsabilidades das  partes  apropriadas  (ou  seja,  parte  responsável, 
mensurador   ou   avaliador   e   contratante,   conforme   apropriado)   são   adequadas   às 
circunstâncias; e 
(b) o trabalho apresenta todas as seguintes características: 
(i) o objeto é apropriado; 
(ii) os critérios que o auditor independente espera que sejam aplicados na elaboração da 
informação  do  objeto  são  apropriados  às  circunstâncias  do  trabalho.  Os  critérios 
devem apresentar as características descritas no item 44; 
(iii) os critérios que o auditor independente espera que sejam aplicados na elaboração da 
informação do objeto estarão disponíveis aos usuários previstos; 
(iv) o auditor  independente  espera  ser  capaz  de  obter  a  evidência  necessária  para 
fundamentar a sua conclusão; 
(v) a conclusão  do  auditor  independente,  na  forma  apropriada  tanto  para  o  trabalho  de 

 
 
 
8 
 
asseguração  razoável  quanto  para  o  trabalho  de  asseguração  limitada,  será  incluída 
no relatório; e 
(vi) um propósito racional incluindo, no caso de trabalho de asseguração limitada, que o 
auditor independente espera ser capaz de obter nível apropriado de segurança.  
 
23.  Os  objetos  de  diferentes  tipos  de trabalhos  de  asseguração  podem  variar  muito.  Alguns 
objetos  podem  requerer  conhecimentos  e  habilidades  especializados, além  daqueles  que o 
auditor  independente  normalmente  possui.  É  importante,  contudo,  que  o  auditor  esteja 
convencido  que  a  equipe  que  irá realizar  o  trabalho  possua  capacidade  e  competências 
apropriadas (ver também o item 31). 
 
24.  Quando um trabalho em potencial não pode ser aceito como trabalho de asseguração, a parte 
contratante pode ser capaz de identificar um trabalho diferente que irá atender às necessidades 
dos usuários previstos. Por exemplo:  
(a) se os critérios que o auditor independente espera aplicar não são adequados, o trabalho de 
asseguração que atenda às outras precondições do item 22 ainda pode ser realizado se: 
(i) o auditor independente puder identificar um ou  mais aspectos do objeto  para o qual 
esses  critérios  são  adequados.  Nesses  casos,  o  auditor  pode  realizar o trabalho  de 
asseguração  em  relação  a  esse  aspecto  específico  do  objeto, e o  relatório  de 
asseguração deve esclarecer que o relatório não diz respeito ao objeto original em sua 
totalidade; ou 
(ii) critérios  alternativos  que  são  apropriados  para  o  objeto  podem  ser  selecionados  ou 
desenvolvidos; 
(b) a parte  contratante  pode  requisitar  um  trabalho  que  não  é  de  asseguração,  tal  como 
trabalho de consultoria ou procedimentos previamente acordados. 
 
25. Tendo sido aceito, não é apropriado alterar o trabalho de asseguração para um que não seja de 
asseguração,  ou  o  trabalho  de  asseguração  razoável  para  um  de  asseguração  limitada,  sem  a 
justificativa razoável.  Uma  alteração  nas  circunstâncias  que  afetam  os  requerimentos  dos 
usuários  previstos,  ou  um  mal-entendido  sobre  a  natureza  do  trabalho,  pode  justificar  a 
solicitação de alteração no trabalho. Se tal alteração for feita, as evidências que foram obtidas 
previamente não devem ser descartadas. A impossibilidade de obter evidências apropriadas e 
suficientes para formar uma conclusão de asseguração razoável não é razão aceitável para se 
alterar o trabalho de asseguração razoável para um trabalho de asseguração limitada. 
 
Elementos do trabalho de asseguração 
 
26.  Os seguintes elementos do trabalho de asseguração são discutidos nesta parte: 
(a) relação  de  três  partes  envolvendo  o  auditor  independente,  a  parte  responsável  e  os 
usuários previstos; 
(b) objeto apropriado; 
(c) critérios aplicáveis; 
(d) evidências apropriadas e suficientes; e 
(e) relatório  de  asseguração  escrito  no  formato  apropriado  ao  trabalho  de  asseguração 

 
 
 
9 
 
razoável ou de asseguração limitada. 
 
Relacionamento entre três partes 
 
27.  Todos os trabalhos de asseguração possuem pelo menos três partes: o auditor independente, a 
parte  responsável  e  os  usuários  previstos.  Dependendo  das  circunstâncias  do  trabalho,  pode 
haver  também  a  função  separada  de  mensurador  ou  avaliador,  ou  a  parte  contratante  (ver 
também o Apêndice 3). 
 
28.  A  parte  responsável  e  os  usuários  previstos  podem  ser  de  entidades  diferentes  ou  da  mesma 
entidade.  Como  exemplo  do  último  caso,  na  estrutura  de administração de  dois  níveis,  o 
conselho  de  administração  pode  buscar  a  asseguração  sobre  uma  informação  fornecida  pela 
diretoria  executiva  da  entidade.  O  relacionamento  entre  a  parte  responsável  e  os  usuários 
previstos  deve  ser  visto  dentro  do  contexto  de  trabalho  específico  e  pode  variar  das  linhas 
tradicionalmente  mais  bem  definidas  de  responsabilidade.  Por  exemplo,  a  alta  administração 
(usuário   previsto)   pode   contratar   o   auditor   independente   para   realizar   o   trabalho   de 
asseguração  em  aspecto  específico  das  atividades  da  entidade  que  são  de  responsabilidade 
imediata  de  nível  mais  baixo  da  administração  (parte  responsável),  mas  pela  qual  a  alta 
administração é, no fim, responsável. 
 
Auditor independente 
 
29.  O  “auditor  independente”  (pessoa  física  ou  jurídica)  é  aquele  que  conduz  o  trabalho 
(geralmente  o  sócio  responsável  pelo  trabalho  ou  outros  membros  da  equipe,  ou,  conforme 
adequado,  a  firma),  aplicando  habilidades  e  técnicas  de  asseguração  para  obter  segurança 
razoável  ou  limitada,  conforme  adequado,  sobre  se  a  informação  do  objeto  está  livre  de 
distorções  relevantes.  (*)  No  trabalho  direto,  o  auditor  tanto  mensura  quanto  avalia  o  objeto 
de  acordo  com  os  critérios  e  aplica  as  habilidades  e  técnicas  de  asseguração  para  obter 
segurança  razoável  ou  limitada,  conforme  adequado,  sobre  se  o  resultado  dessa  mensuração 
ou avaliação está livre de distorções relevantes. 
(*) “Sócio encarregado do trabalho” e “firma” devem ser lidos, referindo-se aos seus equivalentes  no setor público, 
quando relevante. 
 
30.  Esta  estrutura  pode  também  ser  utilizada  por  outros  profissionais  que  não  sejam  auditores 
independentes,  todavia  esses  profissionais  devem  reconhecer  que  essas  normas  incluem 
requerimentos que refletem as premissas nas normas profissionais e na NBC PA 01, ou outros 
requerimentos profissionais, ou requerimentos em lei ou regulamento, que sejam, pelo menos, 
tão exigentes. 
 
31.  O  trabalho  não  deve  ser  aceito  se  o  conhecimento  preliminar  sobre  as  circunstâncias  do 
trabalho  indicar  que  os  requisitos  éticos  referentes  à  competência  não  serão  cumpridos.  Em 
alguns  casos,  esses  requisitos  podem  ser  cumpridos  pelo  auditor  independente  ao  utilizar  o 
trabalho de especialista. 
 
32.  Adicionalmente,  o  auditor  independente  precisa  se  envolver  de  forma  suficiente  no  trabalho 
do  especialista  e  de  outros  auditores  para  aceitar  a  responsabilidade  pela  conclusão  da 
asseguração sobre a informação do objeto e para obter a evidência necessária para concluir se 
o trabalho desse especialista ou do outro auditor é apropriado para seus propósitos. 
 

 
 
 
10 
 
33.  O  auditor  independente  é  o  único  responsável  pela  conclusão  de  asseguração  emitida,  e  essa 
responsabilidade  não  é  reduzida  pelo  uso  que  ele  faça  de  seu  especialista  ou  de  outros 
auditores.  No  entanto,  se  o  auditor  independente,  ao  usar  o  trabalho  de  especialista,  tendo 
seguido  as  normas  aplicáveis,  concluir  que  o  seu  trabalho  é  adequado  para  os  propósitos  do 
auditor,  este  pode  aceitar  as  constatações  ou  conclusões  do  especialista  como  evidências 
adequadas. 
 
Parte responsável 
 
34.  Parte  responsável  é a  parte  responsável  pelo  objeto.  No  trabalho  de  atestação,  a  parte 
responsável  geralmente  também  é  o  mensurador  ou  avaliador. A  parte  responsável  pode  ser, 
ou  não,  a  parte  que  contrata  o  auditor  independente  para  realizar  o  trabalho  de  asseguração 
(parte contratante). 
 
Usuários previstos 
 
35.  Os  usuários  previstos  são  os  indivíduos,  organizações  ou  grupos  que  o  auditor  independente 
espera  que  utilizem  o  relatório  de  asseguração.  A  parte  responsável  pode  ser  um  dos  usuários 
previstos, mas não o único. 
 
36.  Em  alguns  casos,  pode  haver  usuários  previstos  além  daqueles  para  quem  o  relatório  de 
asseguração  é  destinado.  O  auditor  independente pode  não  ser  capaz  de  identificar  todos 
aqueles que lerão o relatório de asseguração, especialmente se grande número de pessoas tiver 
acesso  a  ele.  Em  tais  casos,  especialmente  em  que  os  possíveis  usuários  são  propensos  a 
possuir  vasta  gama  de  interesses no  objeto,  os  usuários  previstos  podem  ser  limitados  aos 
principais interessados com interesses  relevantes  e comuns. Os usuários previstos podem ser 
identificados   de   diferentes   formas,   por   exemplo,   mediante   acordo   entre   o   auditor 
independente e a parte responsável ou a parte contratante, ou por lei ou regulamento. 
 
37.  Usuários previstos ou seus representantes podem estar diretamente envolvidos com o auditor 
independente  e a parte  responsável (e a parte  contratante, caso seja diferente) em determinar 
os  requisitos  do  trabalho.  Independente  do  envolvimento  de  outros,  e  diferentemente  de 
trabalhos  de  procedimentos  previamente  acordados  (que  envolve  relatar  fatos  identificados 
com base nos procedimentos acordados com a parte contratante e outra parte apropriada, em 
vez de uma conclusão): 
(a) o  auditor  independente  é  responsável  pela  determinação  da  natureza,  época  e  extensão 
dos procedimentos; e 
(b) o  auditor  independente  pode  precisar  realizar  procedimentos  adicionais  se  chegarem  ao 
seu  conhecimento  informações  que  diferem,  significativamente,  daquelas  que  foram 
utilizadas na determinação dos procedimentos planejados. 
 
38.  Em alguns casos, os usuários previstos (bancos e reguladores, por exemplo) impõem requisito 
ou  pedido  às  partes  apropriadas  para  que  o  trabalho  de  asseguração  seja  realizado  para 
propósito  específico.  Quando  trabalhos  usam  critérios  que  foram  desenvolvidos  para  um 
propósito específico, o relatório de asseguração inclui declaração alertando aos leitores sobre 
esse  fato.  Adicionalmente,  o  auditor  independente pode  considerar  adequado  indicar  que  o 
relatório  de  asseguração  é  destinado  apenas  para  usuários  específicos.  Dependendo  das 
circunstâncias  do  trabalho,  isso  pode  ser  alcançado  ao  restringir  a  distribuição  ou  uso  do 

 
 
 
11 
 
relatório  de  asseguração.  Enquanto  o  relatório  de  asseguração  possa  ser  restrito  quando  for 
destinado  apenas  a  usuários  ou  propósitos  específicos,  a  ausência  dessa  restrição  não  indica 
por  si  só  que  a  responsabilidade  legal  é  devida  pelo  auditor  independente  em  relação  àquele 
usuário  ou  propósito.  Se  essa  responsabilidade  legal  é  devida  dependerá  da  circunstância  de 
cada caso. 
 
Objeto  
 
39.  O objeto do trabalho de asseguração pode ter várias formas, tais como: 
 histórico  de  desempenho  ou  condição  financeira  (por  exemplo,  histórico  de  posição 
financeira,  desempenho  financeiro  e  fluxos  de  caixa)  para  o  qual  a  informação  do  objeto 
pode ser o reconhecimento, a mensuração, a apresentação e a divulgação representada nas 
demonstrações contábeis;  
 condição ou desempenho financeiro futuro (por  exemplo, posição financeira, desempenho 
financeiro  e  fluxos  de  caixa  prospectivos)  para  o  qual  a  informação  do  objeto  pode  ser  o 
reconhecimento, a mensuração, a apresentação e a divulgação representada na projeção ou 
previsão financeira; 
 condições ou desempenhos não financeiros (por exemplo, desempenho da entidade) para o 
qual as informações do objeto podem ser os indicadores principais de eficácia e eficiência; 
 características  físicas  (por  exemplo,  capacidade  máxima  de  ocupação  do  prédio)  para  o 
qual a informação do objeto pode ser documento de especificações; 
 sistemas e processos (por exemplo, o controle interno ou o sistema de TI da entidade) para 
o qual a informação do objeto deve ser declaração sobre sua efetividade; 
 comportamento (por exemplo, governança corporativa, conformidade com 
regulamentações, políticas de recursos humanos) para o qual a informação do objeto pode 
ser uma declaração de conformidade ou declaração de efetividade. 
O  Apêndice  4  apresenta  uma  categorização  da  gama  de  possíveis  objetos  com  alguns 
exemplos. 
 
40.  Os  objetos  possuem  diferentes  características,  incluindo  o  grau  ao  qual  a  informação  sobre 
eles é qualitativa versus quantitativa, objetiva versus subjetiva, histórica versus prospectiva e 
se  relacionam  a  uma  determinada  data-base  ou  abrangem  um  período.  Tais  características 
afetam: 
(a) a  precisão  na  qual  o  objeto  pode  ser  mensurado  ou  avaliado  com  base  em  critérios 
identificáveis; e  
(b) a persuasão da evidência disponível.  
O relatório de asseguração pode apresentar características que são de relevância específica aos 
usuários previstos. 
 
41.  A  adequação  do  objeto  independe  do  nível  de  asseguração,  ou  seja,  se  o  objeto  não  for 
apropriado para trabalho de asseguração razoável, ele também não é apropriado para trabalho 
de  asseguração  limitada  e  vice-versa.  Um  objeto  apropriado  é  identificável  e  capaz  de 
mensuração  ou  avaliação  consistente  com  base  em  critérios  identificados  de  forma  que  a 
informação  do  objeto  resultante  possa  ser  sujeita  a  procedimentos  para  obter  evidências 

 
 
 
12 
 
apropriadas  e  suficientes  para  apoiar uma  conclusão  de  asseguração  razoável  ou  limitada, 
conforme apropriado. 
 
Critérios 
 
42.  Critérios  são  referências  usadas  para  mensurar  ou  avaliar  o  objeto.  Os  critérios  podem  ser 
formais, por exemplo, na elaboração das demonstrações contábeis; e os critérios podem ser as 
normas  internacionais  de  relatórios  financeiros  ou  as  normas  internacionais  de  contabilidade 
do setor público. Ao emitir relatório sobre a efetividade operacional dos controles internos, os 
critérios  podem  ser  baseados  na  estrutura  estabelecida  de  controle  interno  ou  objetivos  de 
controles  individuais,  especialmente  desenvolvidos  para  o  propósito;  e  ao  emitir  o  relatório 
sobre  a  conformidade,  os  critérios  podem  ser  estabelecidos  por  leis  e  regulamentos  ou 
contratos.  Um  exemplo  de  critério  menos formal  seria  o  código  de  conduta  desenvolvido 
internamente ou o nível de desempenho acordado (tal como o número de vezes que se espera 
que um comitê específico se reúna no ano). 
 
43.  Critérios adequados são requeridos para mensuração ou avaliação razoável consistente com o 
objeto dentro do contexto do julgamento profissional. Sem a estrutura de referência fornecida 
pelos critérios adequados, qualquer conclusão está sujeita a interpretação  individual e a mal-
entendidos.  Critérios  adequados  são  sensíveis  ao  contexto,  ou  seja,  relevantes  para  as 
circunstâncias  do  trabalho.  Para  o  mesmo  objeto,  podem  existir  critérios  diferentes,  que 
conduzirão  à  mensuração  ou  à  avaliação  diferente.  Por  exemplo,  um  dos  critérios  que  um 
mensurador  ou  avaliador  pode  escolher  para  mensuração  da  satisfação  do  consumidor  é  o 
número de reclamações dos consumidores resolvidas de forma satisfatória para o consumidor, 
enquanto outro mensurador ou avaliador pode escolher o número de compras recorrentes nos 
três meses seguintes à compra inicial. Adicionalmente, os critérios podem ser adequados para 
um  conjunto  específico  de  circunstâncias  do  trabalho.  Por  exemplo,  reportar  a  governos  ou 
reguladores  pode  requerer  o  uso  de  um  conjunto  específico  de  critérios,  mas  esses  critérios 
podem não ser adequados para um grupo mais amplo de usuários. 
 
44.  Critérios adequados apresentam as seguintes características: 
(a) Relevância:  Critérios  relevantes  resultam  na  informação  do  objeto  que  auxilia  a  tomada 
de decisões dos usuários previstos. 
(b) Integralidade:  Critérios são  plenos  quando  a  informação  do  objeto  preparada  de  acordo 
com  eles  não  omite  fatores  relevantes  que  poderiam  se  esperar,  razoavelmente,  que 
afetem decisões dos usuários previstos feitas com base nessa informação. Critérios plenos 
incluem, quando relevantes, referências para apresentação e divulgação. 
(c) Confiabilidade:  Critérios  confiáveis  permitem  a  mensuração  ou  avaliação  consistente  de 
determinado  objeto,  incluindo,  se  relevante,  apresentação  e  divulgação,  quando  usadas 
em circunstâncias similares por auditores independentes diferentes. 
(d) Neutralidade:  Critérios  neutros  resultam  em  informação  do  objeto  que  está  livre  de 
tendências como apropriado nas circunstâncias do trabalho. 
(e) Compreensibilidade:  Critérios  compreensíveis  resultam  em  informação  do  objeto  que 
pode ser compreendida pelos usuários previstos. 
 
45.  Descrições   vagas   de   expectativas   ou   julgamentos   das   experiências   de   indivíduo   não 
constituem critérios aceitáveis. 

 
 
 
13 
 
 
46.  A  importância  relativa  de  cada  uma  das  características  acima  ao  avaliar  a  adequação  dos 
critérios  para  um  trabalho  específico  é  questão  de  julgamento  profissional.  A  adequação  dos 
critérios não é influenciada pelo nível de asseguração, ou seja, se os critérios são inadequados 
para  um  trabalho  de  asseguração  razoável,  eles  também  serão  inadequados  para  um  trabalho 
de   asseguração   limitada,   e   vice-versa.   Os   critérios   podem   ser   prescritos   por   leis   e 
regulamentos  ou  emitidos  por  órgãos  autorizados  ou  reconhecidos  que  seguem  o  devido 
processo   transparente   (critério   estabelecido).   Outros   critérios podem   ser   desenvolvidos 
especificamente  para  o  propósito  de  preparar  a  informação  do  objeto  nas  circunstâncias 
específicas do trabalho. Se os critérios são estabelecidos ou desenvolvidos especificamente, o 
procedimento  necessário  para  avaliar  a  sua  adequação  para  um  trabalho  específico  pode  ser 
afetado, por exemplo, na ausência de indicações contrárias, presume-se que os critérios serão 
adequados se forem relevantes para as necessidades de informação dos usuários previstos. 
 
47.  Os   critérios   precisam   estar   disponíveis   para   os   usuários   previstos   para   permitir   que 
compreendam   como   o   objeto   foi   mensurado   ou   avaliado.   Os   critérios   podem   ser 
disponibilizados aos usuários previstos em uma ou mais das seguintes formas: 
(a) publicamente; 
(b) por meio da inclusão, de forma clara, na apresentação da informação do objeto; 
(c) por meio da inclusão, de forma clara, no relatório de asseguração; 
(d) por entendimento geral, por exemplo, o critério de mensurar o tempo em horas e minutos. 
 
48.  Os  critérios  podem  também  ser  disponibilizados  apenas  aos  usuários  previstos  específicos, 
por exemplo, os termos do contrato ou os critérios emitidos por associação setorial que esteja 
disponível  apenas  aos  seus  membros  por  serem  relevantes  para  propósitos  específicos  (ver  o 
item 38). 
 
49.  Como parte do trabalho, o auditor independente estabelece se os critérios são adequados. 
 
Evidências 
 
50.  Os   trabalhos   de   asseguração   são   planejados   e   realizados   com   postura   de   ceticismo 
profissional  para  obter  evidências  apropriadas  e  suficientes  no  contexto  do  trabalho  sobre  o 
resultado  obtido  da mensuração  ou  avaliação  do  objeto  de  acordo  com  os  critérios.  O 
julgamento profissional  deve ser exercido  ao considerar  a materialidade,  o risco do trabalho, 
bem  como  a  quantidade  e  a  qualidade  das  evidências  disponíveis  ao  planejar  e  realizar  o 
trabalho, especialmente, ao determinar a natureza, a época e a extensão dos procedimentos. 
 
Ceticismo profissional 
 
51.  O ceticismo profissional é a postura que inclui estar alerta a, por exemplo: 
(a) evidência inconsistente com outras evidências obtidas; 
(b) informações  que  geram  dúvidas  quanto  à  confiabilidade  de  documentos  e  respostas  a 
indagações que serão usadas como evidências; 
(c) circunstâncias   que   sugerem   a   necessidade   de   procedimentos   adicionais   àqueles 
requeridos pelas normas de asseguração; e 

 
 
 
14 
 
(d) condições que podem indicar distorções. 
 
52.  Manter o ceticismo profissional durante o trabalho é necessário, por exemplo, para reduzir o 
risco de: 
 negligenciar circunstâncias incomuns; 
 generalização excessiva ao tirar conclusões a partir das observações; e 
 usar   premissas   inapropriadas   ao   determinar   a   natureza,   a   época   e   a   extensão   dos 
procedimentos e avaliar os seus resultados. 
 
53.  O  ceticismo  profissional  é  necessário  para  a  avaliação  crítica  das  evidências.  Isso  inclui 
questionar  as  evidências  inconsistentes  e  a  confiabilidade  de  documentos  e  repostas  a 
indagações.  Também  inclui  a  consideração  da  suficiência  e  a  adequação  das  evidências 
obtidas à luz das circunstâncias. 
 
54.  A  menos  que  o  trabalho  envolva  asseguração  sobre  a  veracidade  de  documentos,  registros  e 
documentos,  podem  ser  aceitos  como  genuínos,  a  não  ser  que  o  auditor  independente  tenha 
razões   para   acreditar   o   contrário.   Mesmo   assim,   o   auditor   independente   considera   a 
confiabilidade da informação a ser usada como evidência. 
 
55.  Não  se  pode  esperar  que  o  auditor  independente  desconsidere  experiências  passadas  sobre  a 
honestidade e a integridade daqueles que fornecem evidências. Ainda assim, a crença de que 
aqueles  que  fornecem  evidências  são  honestos  e  íntegros  não  diminui  a  necessidade  de  o 
auditor manter o ceticismo profissional. 
 
Julgamento profissional 
 
56.  O julgamento profissional é essencial para a condução apropriada do trabalho de asseguração. 
Isso  porque  a  interpretação  de  requerimentos  éticos  e normas  de  asseguração relevantes  e  as 
decisões   necessárias   durante   o   trabalho   não   podem   ser   tomadas   sem   a   aplicação   de 
treinamento, conhecimento e experiência necessária aos fatos e circunstâncias. O julgamento 
profissional é necessário, particularmente, para decisões sobre: 
 a materialidade e o risco do trabalho; 
 a natureza, a época e a extensão dos procedimentos usados para atender aos requerimentos 
das normas de asseguração relevantes e obter evidências; 
 avaliar  se  foram  obtidas  evidências  apropriadas  e  suficientes  e  se  algo  mais  precisa  ser 
feito para alcançar os objetivos das normas de asseguração aplicáveis. Especificamente, no 
caso de trabalho de asseguração limitada, o julgamento profissional é requerido ao avaliar 
se um nível significativo de asseguração foi obtido; 
 no caso do trabalho direto, aplicação dos critérios ao objeto, e caso o auditor selecione ou 
desenvolva  o  critério,  a  sua  seleção  ou  seu  desenvolvimento.  No  caso  de  trabalho  de 
atestação, avaliar tais julgamentos executados por terceiros; 
 as conclusões apropriadas com base nas evidências obtidas. 
 
57.  A principal característica do julgamento profissional esperada do auditor independente é que 
ele  seja  exercido  por  auditor  cujo  treinamento,  conhecimento  e  experiência  auxiliaram  no 

 
 
 
15 
 
desenvolvimento das competências necessárias para alcançar julgamentos razoáveis. 
 
58.  O  exercício  do  julgamento  profissional,  em  qualquer  caso  particular,  é  com  base  nos  fatos  e 
circunstâncias que são conhecidos pelo auditor independente. A consulta em questões difíceis 
ou  controversas  durante  o  curso  do  trabalho,  quer  dentro  da  equipe  de  trabalho,  quer  entre  a 
equipe de trabalho e outros com nível apropriado, dentro ou fora da firma, auxiliam o auditor 
independente a exercer julgamentos razoáveis. 
 
59.  O  julgamento  profissional  pode  ser  avaliado  com  base  se  o  julgamento  alcançado  reflete  a 
aplicação  competente  da  asseguração  e  princípios  de  mensuração  ou  avaliação  e  se  é 
adequado  à  luz  dos,  e  consistente  com,  fatos  e  circunstâncias  que  eram  conhecidos  pelo 
auditor independente até a data do relatório do auditor. 
 
60.  O   julgamento   profissional   deve   ser   exercido   durante   todo   o   trabalho.   O   julgamento 
profissional não deve ser usado como justificativa para decisões que não são, de outra forma, 
suportadas   pelos   fatos   e   circunstâncias   do   trabalho   ou   por   evidências   apropriadas   e 
suficientes. 
 
Evidência suficiente e apropriada 
 
61.  A  evidência  suficiente  e  apropriada  está correlacionada.  A  suficiência  é  a  mensuração  da 
quantidade de evidências. A quantidade de evidência necessária é influenciada pelos riscos de 
a informação do objeto ser distorcida de forma relevante (quanto maior forem os riscos, mais 
evidência  será  necessária)  e  também  pela  qualidade  dessas  evidências  (quanto  melhor  a 
qualidade, menos será necessária). Obter mais evidências, contudo, pode não compensar a sua 
baixa qualidade (ver itens 81 e 82). 
 
62.  Adequação é a mensuração da qualidade da evidência, ou seja, sua relevância e confiabilidade 
em fornecer fundamentação para a conclusão do auditor independente. 
 
63.  A  confiabilidade  da  evidência  é  influenciada  por  sua  fonte  e  sua  natureza  e  depende  das 
circunstâncias particulares sob as quais são obtidas. Generalizações sobre a confiabilidade de 
vários  tipos  de  evidências  podem  ser  feitas;  contudo,  tais  generalizações  estão  sujeitas  a 
exceções importantes. Mesmo quando a  evidência é obtida de fontes externas, podem  existir 
circunstâncias que poderiam afetar sua confiabilidade. Por exemplo, evidência obtida de fonte 
externa  pode  não  ser  confiável  se  a  fonte  não  for  conhecida  ou  objetiva.  Enquanto  se 
reconhece que possam existir exceções, as seguintes generalizações sobre a confiabilidade da 
evidência podem ser úteis: 
 a evidência é mais confiável quando é obtida de fontes externas às partes apropriadas; 
 a  evidência  que  é  gerada  internamente  é  mais  confiável  quando  os  controles  relacionados 
são efetivos;  
 a evidência obtida diretamente pelo auditor independente (por exemplo, na observação da 
efetividade  de  controle)  é  mais  confiável  do  que  a  evidência  obtida  indiretamente  ou  por 
dedução (por exemplo, indagação sobre a efetividade do controle); 
 a evidência formal é mais confiável, seja em papel, de forma eletrônica ou outra mídia (por 
exemplo,  a  ata  de  reunião  geralmente  é  mais  confiável  do  que  a  representação  verbal  do 
que foi discutido).  

 
 
 
16 
 
 
64.  Segurança  maior  é  geralmente  obtida  de  evidências  consistentes de  fontes  ou  de  natureza 
diferentes do que evidências consideradas individualmente. Adicionalmente, obter evidências 
de fontes ou de natureza diferente pode tanto corroborar outras evidências quanto indicar que 
um  item  particular  da  evidência  não  é  confiável.  Quando  a  evidência  obtida  de  uma  fonte  é 
inconsistente  com  aquela  obtida  de  outra,  será  necessário  determinar  quais  procedimentos 
adicionais devem ser executados para eliminar a inconsistência. 
 
65.  A  obtenção  da  evidência  apropriada  e  suficiente  é  geralmente  mais  difícil na  asseguração 
sobre a informação do objeto, cobrindo um período de tempo, do que do objeto na data base. 
Adicionalmente,  as  conclusões  fornecidas  sobre  processos  geralmente  são  limitadas  ao 
período  coberto  pelo  trabalho;  o  auditor  independente  não  fornece  conclusão  sobre  se  o 
processo irá continuar a funcionar no futuro de modo especificado. 
 
66.  É  uma  questão  de  julgamento  profissional  se  evidências  apropriadas  e  suficientes  foram 
obtidas para suportar a conclusão do auditor independente, o que envolve considerar a relação 
entre o custo e o benefício da obtenção das evidências. O auditor utiliza o julgamento e exerce 
o ceticismo profissional ao avaliar a quantidade e a qualidade das evidências e, portanto, sua 
suficiência e adequação para suportar o relatório de asseguração. 
 
Materialidade 
 
67.  A materialidade é relevante ao planejar e realizar o trabalho de asseguração para determinar a 
natureza, a época e a extensão dos procedimentos, bem como para avaliar se a informação do 
objeto  está  livre de  distorções.  Os  julgamentos  profissionais  sobre  materialidade  são  feitos  à 
luz das circunstâncias, mas não são influenciadas pelo nível de asseguração, ou seja, para os 
mesmos usuários e propósitos previstos, a materialidade do trabalho de asseguração razoável 
é a mesma utilizada em trabalho de asseguração limitada, considerando que ela é determinada 
com base nas necessidades de informação dos usuários previstos. 
 
68.  Distorções,  incluindo  omissões,  são  consideradas  relevantes  se  elas,  individualmente  ou  em 
conjunto,  puderem,  razoavelmente,  influenciar  as  decisões  relevantes  dos  usuários  previstos 
tomadas com base na informação do objeto. A consideração do auditor independente sobre a 
materialidade é um assunto de julgamento profissional, e é influenciada pela percepção que o 
auditor possui sobre as necessidades comuns de informação dos usuários previstos como um 
grupo. A  menos  que  o  trabalho  tenha  sido  desenvolvido  para  atender  às  necessidades  de 
informações  de  usuários  específicos,  os  possíveis  efeitos  das  distorções  para  os  usuários 
específicos,  cuja  necessidade  de  informação  possa  variar  amplamente,  não  são  geralmente 
considerados.  
 
69.  A  materialidade  é  considerada  no  contexto  dos  fatores  qualitativos  e,  quando  aplicável,  a 
fatores  quantitativos.  Ao  considerar  a  materialidade  em  trabalho  específico,  a  importância 
relativa de fatores quantitativos e qualitativos é assunto de julgamento profissional. 
 
70.  A  materialidade  se  refere  à  informação  coberta  pelo  relatório  de  asseguração  do  auditor 
independente.  Portanto,  quando  o  trabalho  cobrir  alguns,  mas  não  todos,  os  aspectos  da 
informação  do  objeto,  a  materialidade  é  considerada  em  relação  apenas  àquela  parte  da 
informação que é coberta pelo trabalho. 
 

 
 
 
17 
 
Risco do trabalho 
 
71.  A  informação  do  objeto  pode  não  se  relacionar  adequadamente  no  contexto  do  objeto  e  dos 
critérios,  e  pode,  portanto,  ser  potencialmente  distorcida  de  forma  relevante.  Isso  ocorre 
quando a informação não reflete apropriadamente a aplicação dos critérios para mensurar ou 
avaliar o objeto. 
 
72.  Risco  do  trabalho  é  o  risco  de  o  auditor  independente  expressar  uma  conclusão  inadequada 
quando a informação do objeto estiver distorcida de forma relevante. O risco do trabalho não 
se  refere  nem  inclui  os  riscos  de  negócio  do  auditor  independente,  tais  como  perdas em 
litígios,  publicidade  adversa,  ou  outros  eventos  que  surjam  em  conexão  com  a  informação 
específica do objeto. 
 
73.  Eliminar totalmente o risco do trabalho é raramente alcançável ou possui um custo altíssimo 
em  relação  ao  benefício.  Portanto,  a  “asseguração razoável”  é  menor  do  que  asseguração 
absoluta, como resultado de fatores, tais como: 
 uso de testes seletivos; 
 limitações inerentes ao controle interno; 
 fato de que muitas das evidências disponíveis ao auditor independente são persuasivas, ao 
invés de conclusivas; 
 uso de julgamento profissional ao obter e avaliar as evidências e formar as conclusões com 
base nessas evidências; 
 em alguns  casos,  as  características  do  objeto  quando  avaliadas  ou  mensuradas  pelos 
critérios. 
 
74.  No  geral,  os  riscos  do  trabalho  podem  estar  representados  pelos  seguintes  componentes, 
apesar  de  que  nem  todos  esses  componentes  estarão  necessariamente  presentes  ou  serão 
significativos para todos os trabalhos de asseguração: 
(a) riscos, que não dependem diretamente do auditor independente, consistem em: 
(i) risco inerente – a suscetibilidade da informação do objeto conter distorção relevante 
antes da consideração de quaisquer controles aplicados pelas partes apropriadas; e 
(ii) risco  de  controle – o  risco  de  ocorrer  distorção  relevante  na  informação  do objeto 
não  seja  evitado  por  controle  preventivo  ou,  detectado  e  corrigido,  em  tempo  hábil, 
pelo controle interno implementado pelas partes apropriadas; e 
(b) riscos, que o auditor independente influencia diretamente, consistem em: 
(i) risco  de  detecção – o  risco  dos  procedimentos  realizados  pelo  auditor  independente 
não detectarem distorção relevante; e 
(ii) risco de mensuração ou avaliação – no caso de trabalho direto, o risco associado com 
a mensuração ou avaliação que o auditor independente fizer do objeto pelos critérios. 
 
75.  O  nível  pelo  qual  cada  um  desses  componentes  é  relevante  para  o  trabalho  é  influenciado 
pelas  circunstâncias  do  trabalho,  em  particular. A  consideração  de  riscos  é  assunto  de 
julgamento  profissional,  em  vez  de  ser  passível  de  mensuração  precisa.  As  circunstâncias 
podem estar relacionadas com: 

 
 
 
18 
 
 A  natureza  do  objeto  e  a  sua  informação.  Por  exemplo,  o  conceito  de  controle  de  risco 
pode ser mais útil quando a informação do objeto for relativa à preparação da informação 
sobre  o  desempenho  da  entidade  quando  ele  for  relativo  à  informação  sobre  a  eficácia  de 
controle ou a existência de condição física.  
 O  tipo  de  trabalho  de  asseguração  (razoável  ou  limitada)  que  está  sendo  executado.  Por 
exemplo,   em   trabalhos   de    asseguração   limitada,   o    auditor   independente pode, 
frequentemente, decidir obter evidência por outros meios que não sejam testes de controle. 
Neste  caso,  a  consideração  do  risco  de  controle  pode  ser  menos  relevante  do  que  em 
trabalhos de asseguração razoável sobre a mesma informação do objeto. 
 Se for trabalho direto ou trabalho de atestação. Enquanto o conceito de risco de controle é 
relevante  ao  trabalho  de  atestação,  o  conceito  mais  amplo  de  risco  de  mensuração  ou 
avaliação é mais relevante para trabalho direto.  
 
Natureza, época e extensão dos procedimentos 
 
76.  A combinação  de  procedimentos  é  tipicamente  utilizada  para  obter  tanto  a  asseguração 
razoável como a asseguração limitada. Os procedimentos podem incluir: 
 inspeção;  
 observação; 
 confirmação;  
 recálculo; 
 reexecução; 
 procedimentos analíticos; e 
 indagação.  
A exata natureza, a época e a extensão dos procedimentos variam de um trabalho para outro. 
Em  teoria,  para  muitos  trabalhos  de  asseguração,  são  possíveis  variações  infinitas  dos 
procedimentos.  Na  prática,  contudo,  elas  são  difíceis  de  comunicar de  forma   clara  e 
inequívoca.  
 
77.  Para  a  compreensão  do  objeto  e  de  outras  circunstâncias,  tanto  os  trabalhos  de  asseguração 
razoável  como  de  asseguração  limitada  requerem  a  aplicação  de  habilidades  e  técnicas,  bem 
como a obtenção de evidências apropriadas e suficientes como parte do processo de trabalho 
iterativo e sistemático.  
 
78.  O trabalho de asseguração razoável deve considerar: 
(a) identificar e avaliar o risco de distorção relevante na informação do objeto, com base na 
compreensão da informação do objeto e de outras circunstâncias do trabalho;  
(b) desenvolver   e   realizar   procedimentos   para   responder   aos   ricos   avaliados   e   obter 
asseguração razoável para suportar a conclusão do auditor independente; e 
(c) avaliar  a  suficiência  e  a  adequação  das  evidências  obtidas  no contexto  do  trabalho  e,  se 
necessário nas circunstâncias, tentar obter evidências adicionais. 
 
79.  A  natureza,  a  época  e  a  extensão  dos  procedimentos,  para  obterem  evidências  apropriadas  e 

 
 
 
19 
 
suficientes em trabalho de asseguração limitada, são, por definição, limitadas se comparados 
com  os  necessários  para  o  trabalho  de  asseguração  razoável.  Uma norma  de  asseguração 
específica  para  um  objeto  pode  estabelecer  que,  por  exemplo,  as  evidências  apropriadas  e 
suficientes   para   um   tipo   específico   de   trabalho   de   asseguração   limitada   são   obtidas 
primariamente por meio de procedimentos analíticos e indagações. Na ausência de normas de 
asseguração   para   objetos   específicos   para   outros   tipos   de   asseguração   limitada,   os 
procedimentos  analíticos  e  indagações  podem  variar  com  as circunstâncias  do  trabalho,  em 
particular,  com  o  objeto  e  a  necessidade  de  informações  dos  usuários  previstos  e  da 
contratante, incluindo restrições relevantes de tempo e custo. A determinação da natureza, da 
época  e  da  extensão  dos  procedimentos  depende  de  julgamento  profissional  e  varia  de  um 
trabalho para outro. 
 
80.  O trabalho de asseguração limitada deve considerar: 
(a) identificar  as  áreas  em  que  uma  distorção  relevante  da  informação  do  objeto  é  capaz  de 
surgir, com base na compreensão do objeto e outras circunstâncias do trabalho;  
(b) desenvolver  e  realizar  procedimentos  para  abordar  essas  áreas  e  obter  a  asseguração 
limitada para suportar a conclusão do auditor independente; e 
(c) desenvolver e  executar  procedimentos  adicionais  para  obter  evidências,  se  o  auditor 
independente tomar conhecimento de assuntos que o levem a acreditar que a informação 
do objeto possa estar distorcida de forma relevante. 
 
Quantidade e qualidade das evidências disponíveis 
 
81.  Normalmente,  a  evidência  disponível  é  persuasiva  em  vez  de  conclusiva.  A  quantidade  ou  a 
qualidade das evidências disponíveis são influenciadas por: 
(a) características  do  objeto  ou  da  informação.  Por  exemplo,  evidências  menos  objetivas 
podem  ser  esperadas  quando  a  informação  for  prospectiva  ao  invés  de  histórica  (ver  o 
item 40); e 
(b) outras circunstâncias,  como  quando  as  evidências  que  possam  ser  razoavelmente  esperadas 
não estiverem disponíveis devido, por exemplo, à data de nomeação do auditor independente, 
à política de retenção de documentos da entidade, a sistemas de informação inadequados, ou 
à restrição imposta pela parte responsável. 
 
82. Uma conclusão não modificada não é apropriada tanto para o trabalho de asseguração razoável 
como para o trabalho de asseguração limitada quando:  
(a) as circunstâncias impedem que o auditor independente obtenha as evidências necessárias 
para reduzir os riscos de trabalho ao nível apropriado; ou 
(b) uma  das  partes  envolvidas  com  o  trabalho  impõe  uma  restrição  que  impede  o  auditor 
independente de obter as evidências necessárias para reduzir o risco de trabalho ao nível 
apropriado. 
 
Relatório de asseguração 
 
83.  O  auditor  independente  forma  sua  conclusão  com  base  nas  evidências  obtidas  e  emite  o 
relatório escrito contendo uma expressão clara dessa conclusão de asseguração. As normas de 
asseguração estabelecem elementos básicos para os relatórios de asseguração.  

 
 
 
20 
 
 
84.  No  trabalho  de  asseguração  razoável,  a  conclusão  do  auditor  independente  é  expressa  na 
forma positiva para transmitir a sua opinião sobre o resultado da mensuração ou avaliação do 
objeto. 
 
85.  Exemplos de conclusões emitidas de forma apropriada em trabalhos de asseguração razoável 
incluem:  
 quando  expressas  nos  termos  de  determinado  assunto  e  das  normas,  leis  ou  regulamentos 
aplicáveis, “Em nossa opinião, a entidade cumpriu, em todos os aspectos relevantes,  a  lei 
XYZ”;  
 quando expressas nos termos da informação do objeto e dos critérios aplicáveis “Em nossa 
opinião,  as  demonstrações  contábeis  apresentam  adequadamente,  em  todos  os  aspectos 
relevantes, a posição patrimonial e financeira da entidade em [data], o desempenho de suas 
operações  e  seus  fluxos  de  caixa  para  o  exercício  findo  naquela  data  de  acordo  com  a 
estrutura XYZ”; ou 
 quando  expressa  nos  termos  de  uma  declaração  feita  pela  parte  responsável,  “Em  nossa 
opinião,  a  declaração  da  [parte  responsável]  de  que  a  entidade  cumpriu  com  a  lei  XYZ 
está, em todos os aspectos relevantes, adequadamente apresentada” ou “Em nossa opinião, 
a declaração da [parte responsável] de que os principais indicadores de desempenho estão 
apresentados  de  acordo  com  os  critérios  XYZ  está,  em todos  os aspectos  relevantes, 
adequadamente  apresentada.”  Por  outro  lado,  no  trabalho  direto,  a  conclusão  do  auditor 
independente é escrita nos termos de determinado objeto e critérios. 
 
86.  No  trabalho  de  asseguração  limitada,  a  conclusão do  auditor  independente  é  expressa  de 
forma   a   transmitir   se,   com   base   no   trabalho   realizado,   algum   fato   chegou   ao   seu 
conhecimento que o levasse a acreditar que a informação do objeto esteja distorcida de forma 
relevante,  como  por  exemplo,  “Com  base  nos  procedimentos  realizados  e  nas  evidências 
obtidas, não temos conhecimento de nenhum fato que nos leve a acreditar que a entidade não 
tenha cumprido, em todos os aspectos relevantes, com a lei XYZ.”. 
 
87.  O  auditor  independente  pode  escolher  o  modelo  de  relatório de “forma curta” ou de “forma 
longa” para facilitar a efetividade da comunicação com os usuários previstos. Relatórios de 
“forma  curta”  geralmente  incluem  apenas  os  elementos  básicos.  Os  relatórios  de  “forma 
longa”  incluem  outras  informações  e  explicações  que  não  afetam  a  conclusão  do  auditor 
independente.  Os  relatórios  em  forma  longa  podem  descrever  com  detalhe  os  termos  do 
trabalho, os critérios usados, as constatações relativas aos aspectos específicos do trabalho, os 
detalhes sobre as qualificações e a experiência do auditor independente e de outros envolvidos 
com   o   trabalho,   a   divulgação   dos   níveis   de   materialidade   e,   em   alguns   casos,   as 
recomendações. A inclusão de qualquer dessas informações depende da sua relevância para os 
usuários previstos. 
 
88.  A conclusão  do  auditor  independente  é  claramente  separada  das  outras  informações  ou 
explicações  que  não  pretendem  afetar  a  sua  conclusão,  incluindo  quaisquer  Ênfases,  Outros 
Assuntos,  constatações  relativas  a  aspectos  específicos  do  trabalho,  recomendações ou 
informações  adicionais  incluídas  no  relatório  de  asseguração.  A  redação  utilizada  deixa  bem 
claro  que  uma  Ênfase,  Outros  Assuntos,   constatações,   recomendações  ou  informações 
adicionais não pretendem afetar a conclusão do auditor. 

 
 
 
21 
 
 
89.  O auditor deve expressar uma conclusão modificada nas seguintes circunstâncias: 
(a) quando,  no  julgamento  profissional  do  auditor  independente,  existe  uma  limitação  de 
escopo, cujo efeito do assunto pode ser relevante. Em tais casos, o auditor independente 
expressa uma conclusão com ressalva, ou se abstém de uma conclusão. Em alguns casos, 
o auditor pode considerar se retirar do trabalho;  
(b) quando, no julgamento profissional do auditor independente, a informação do objeto está 
relevantemente distorcida. Em tais casos, o auditor expressa uma conclusão com ressalva 
ou adversa.  No caso de trabalho direto  em que a  informação do objeto é a conclusão do 
auditor independente, se  ele concluir que parte, ou todos os objetos, não está de  acordo, 
em  todos  os  aspectos  relevantes,  com  os  critérios,  tal  conclusão  também  deve  ser 
expressa com ressalvas (ou adversa, conforme o caso). 
 
90.  A conclusão com ressalvas é expressa quando os efeitos, ou possíveis efeitos, de um assunto 
das  distorções,  individualmente  ou  em  conjunto,  são  relevantes,  mas  não  generalizados  a 
ponto de requerer uma conclusão adversa ou a abstenção de conclusão. 
 
91.  Se,  após  o  trabalho  ter  sido  aceito,  for  descoberto  que  uma  ou  mais  precondições  para  o 
trabalho de asseguração não estão presentes, o auditor independente discute a questão com as 
partes apropriadas e estabelece:  
(a) se o assunto pode ser resolvido de modo a satisfazer o auditor independente; 
(b) se é apropriado dar continuidade ao trabalho; e 
(c) em caso afirmativo, como comunicar o assunto no relatório de asseguração. 
 
92.  Se,  após  a  aceitação  do  trabalho,  for  descoberto  que  parte  ou  todos  os  critérios  são 
inadequados  ou  que  parte  ou  todos  os  objetos  não  são  apropriados  para  o  trabalho  de 
asseguração, o auditor independente pode considerar retirar-se do trabalho, caso seja possível 
de acordo com lei ou regulamento. Se o auditor der continuidade ao trabalho, ele expressa:  
(a) conclusão  com  ressalvas  ou  adversa  dependendo  de  quanto  o  assunto  for  relevante  e 
generalizado,  quando,  no  julgamento  profissional  do  auditor,  o  critério  inadequado  ou 
objeto inapropriado estiver propenso a induzir os usuários previstos ao erro; ou 
(b) conclusão   com   ressalvas   ou   abstenção   da   conclusão,   dependendo   do   julgamento 
profissional do auditor independente de quanto o assunto for relevante e generalizado, em 
outros casos.  
 
Outras partes 
 
Outras responsabilidades de comunicação 
 
93.  O auditor considera, nos termos do trabalho e de outras circunstâncias do trabalho, se algum 
assunto  que  chegou  ao  seu  conhecimento  deve  ser  comunicado  à  parte  responsável,  ao 
mensurador ou avaliador, à parte contratante, aos responsáveis pela governança ou a outros.  
 
Documentação 
 
94.  A  documentação  do  trabalho  fornece  o  registro  da  base  para  o  relatório  de  asseguração 

 
 
 
22 
 
quando preparada em tempo hábil e for apropriada e suficiente para permitir que um auditor 
independente experiente, sem conexão prévia com o trabalho, compreenda:  
(a) a  natureza,  a  época  e  a  extensão  dos  procedimentos  realizados  para  cumprir  com  as 
normas de asseguração relevantes e requerimentos de leis e regulamentos;  
(b) o resultado dos procedimentos realizados e as evidências obtidas; e 
(c) os  assuntos  relevantes  que  surgirem  durante  o  trabalho,  as  conclusões  alcançadas  e  os 
julgamentos profissionais significativos exercidos para se chegar a tais conclusões. 
  
95.  A documentação do trabalho inclui como o auditor endereçou qualquer inconsistência entre as 
informações  por  ele  identificadas  e  a  sua  conclusão  final  relacionada  com  um  assunto 
relevante.  
 
Uso inapropriado do nome do auditor independente 
 
96.  O  auditor  independente  está  associado  com o  objeto  ou  com  a  informação  do  objeto 
relacionada,  quando  o  auditor  reporta  informações  sobre  o  objeto  ou  consente  com  o  uso  de 
seu  nome  em  conexão  profissional  com  esse  objeto  ou  com  a  informação  do  objeto 
relacionada. Se o auditor não estiver associado dessa maneira, terceiros não podem assumir a 
responsabilidade do auditor. Se o auditor independente descobrir que uma parte está usando o 
seu  nome  indevidamente  em  associação  com  o  objeto  ou  com  a  informação  do  objeto 
relacionada, ele deve exigir que essa parte cesse essa ação. O auditor também deve considerar 
quais  outras  ações  podem  ser  necessárias,  como  informar  quaisquer  terceiros  conhecidos  do 
uso inapropriado do seu nome ou procurar assistência legal. 
 
Vigência 
 
97.  Esta  norma  entra  em  vigor  na  data de  sua  publicação, produzindo  efeitos  a  partir  de 1º  de 
janeiro de  2016, quando  será revogada  a  Resolução CFC  n.º 1.202/2009,  publicada  no 
D.O.U., Seção 1, de 3/12/2009. 
 
  
Brasília, 20 de novembro de 2015. 
 
 
 
Contador José Martonio Alves Coelho 
Presidente 
 
 
 
Apêndice 1 – não editado. 
 
Apêndice 2 – Trabalho de atestação e trabalho direto 
 
Este Apêndice destaca as diferenças entre um trabalho de atestação e um trabalho direto. 
 
1.  No  trabalho  de atestação,  o  mensurador  ou  o  avaliador,  que  não  é  o  auditor  independente, 
mensura  ou  avalia  o  objeto  de  acordo  com  critérios,  resultando  na  informação  do  objeto. A 

 
 
 
23 
 
informação do objeto pode falhar em ser adequadamente expressa no contexto de determinado 
objeto  e  dos  critérios,  e  pode,  portanto,  ser  distorcida,  potencialmente,  a  uma  extensão 
relevante.  A  função  do  auditor  independente  no  trabalho  de  atestação  é  obter  evidências 
apropriadas  e  suficientes  de  forma  a  expressar  uma  conclusão  sobre  se  a  informação  do 
objeto, como preparada pelo mensurador ou avaliador, está livre de distorções relevantes.  
 
2.  No trabalho direto, o auditor mensura ou avalia o objeto de acordo com critérios e apresenta a 
informação do objeto resultante como parte, ou acompanhando o relatório de asseguração. A 
conclusão  do  auditor  no  trabalho  direto  aborda  o  resultado  relatado  da  mensuração  ou 
avaliação  de  determinado  objeto  de  acordo  com  critérios.  Em  alguns  trabalhos  diretos,  a 
conclusão do auditor é, ou é parte da, a informação do objeto. Dependendo do objeto:  
(a) o  resultado  da  mensuração  ou  avaliação  no  trabalho  direto  pode  ser  semelhante  ao 
relatório ou declaração preparada pelo mensurador ou avaliador em trabalho de atestação. 
Em outras circunstâncias, contudo, o resultado, ou seja, a informação do objeto, pode ser 
refletido na descrição das constatações e base para a conclusão do auditor em relatório de 
asseguração de formato longo; e 
(b) o  auditor  independente  pode  usar  dados  coletados  ou  compilados  por  outros.  Por 
exemplo, os dados podem vir do sistema de informação mantido pela parte responsável.  
 
3.  Em adição à mensuração ou à avaliação de determinado objeto, em trabalho direto, o auditor 
independente  também  aplica  habilidades  e  técnicas  de  asseguração  para  obter  evidências 
apropriadas e suficientes de forma a expressar sua conclusão sobre se a informação do objeto 
está  relevantemente  distorcida.  O  auditor  pode  obter  evidências  simultaneamente  com  a 
mensuração  ou  avaliação  do  objeto,  mas  também  pode  obtê-la  antes  ou  após  tal  mensuração 
ou avaliação. 
 
4.  O valor do trabalho direto se dá na combinação:  
(a) da independência do auditor em relação ao objeto, ao contratante, aos usuários previstos e 
à  parte  responsável,  não  obstante  ele  não  seja  independente  da  informação  do  objeto, 
porque o próprio auditor a preparou; e 
(b) das  habilidades  e  técnicas  aplicadas  ao mensurar  ou  avaliar  o  objeto,  que  resultam  na 
acumulação  de  evidências  que  são  de  quantidade  e  qualidade  semelhantes  para  um 
trabalho  de  atestação.  É  essa  obtenção  de  evidências  apropriadas  e  suficientes  que 
distingue  um  trabalho  direto  de  uma  mera  compilação.  Para  ilustrar  este  ponto,  se  o 
auditor independente estivesse compilando informação sobre uma declaração de emissão 
de gases de efeito estufa da entidade, o auditor não iria, por exemplo, testar a calibração 
dos  dispositivos  de  monitoramento.  No  trabalho  direto,  contudo,  o  auditor  independente 
iria,  onde  relevante,  calibrar  os  dispositivos  como  parte  do  processo  de  mensuração  ou 
testar  a  calibração  dos  dispositivos  de  monitoramento  realizada  por  outros  da  mesma 
forma que iria proceder se o trabalho fosse um trabalho de atestação. 
 
 
Apêndice 3 – Partes do trabalho de asseguração 
 

 
 
 
24 
 
 
 
 
1.  Todos  os  trabalhos  de  asseguração  possuem,  pelo  menos,  três  partes:  a  parte  responsável,  o 
auditor  independente  e  os  usuários  previstos.  Dependendo  das  circunstâncias  do  trabalho,  pode 
haver também uma função separada de mensurador ou avaliador, ou de parte contratante. 
 
2.  O diagrama acima ilustra como as seguintes funções se relacionam ao trabalho de asseguração: 
(a) a parte responsável é responsável pelo objeto;  
(b) o mensurador ou o avaliador usa os critérios para mensurar ou avaliar o objeto, resultando 
na informação do objeto;  
(c) a parte contratante contrata os termos do trabalho com o auditor independente;  
(d) o  auditor  independente  obtém  evidências  apropriadas  e  suficientes  de  forma  a  poder 
expressar  uma  conclusão  desenvolvida  para  aumentar  o  grau  de  confiança  dos  usuários 
previstos, que não se referem à parte responsável, sobre a informação do objeto; 
(e) os  usuários  previstos  tomam  decisões  com  base  na  informação  do  objeto.  Os  usuários 
previstos  são  indivíduos,  organizações  ou  grupo  de  indivíduos  e  organizações  que  o 
auditor espera que utilizem o relatório de asseguração. 
 
3.  As seguintes observações podem ser feitas sobre essas funções:  
 todo  trabalho  de  asseguração  possui  pelo  menos  uma  parte  responsável  e  usuários 

 
 
 
25 
 
previstos, em adição ao auditor independente; 
 o  auditor  independente  não  pode  ser  a  parte  responsável,  a  contratante  ou  um  usuário 
previsto; 
 no trabalho direto, o auditor independente também é o mensurador ou o avaliador; 
 no trabalho  de  atestação,  a  parte  responsável  ou  outra  pessoa,  que  não  seja  o  auditor 
independente, pode ser o mensurador ou o avaliador; 
 quando o próprio auditor independente mensurou ou avaliou o objeto sem relação com os 
critérios,  o  trabalho  é  direto.  A  característica  desse  trabalho  não  pode  ser  mudada  para 
trabalho  de  atestação  com  outra  parte  assumindo  a  responsabilidade  da  mensuração  ou 
avaliação,  como,  por  exemplo,  mediante  uma  declaração  sobre  informação  do  objeto 
anexada pela parte responsável, aceitando a responsabilidade sobre ele; 
 a parte responsável pode ser, também, a contratante; 
 em  muitos  trabalhos  de  atestação,  a  parte  responsável  pode  ser  também  o  mensurador  ou 
avaliador  e a parte  contratante. Por  exemplo, a  entidade  contrata o auditor independente para 
executar trabalho de asseguração sobre o relatório que foi preparado para suas próprias práticas 
sustentáveis.  Por  outro  lado,  existem  situações  em  que  a  parte  responsável  é  diferente  do 
mensurador  ou  avaliador.  Nesse  caso,  por  exemplo,  o  auditor  é  contratado  para  executar 
trabalho  de  asseguração  sobre  o  relatório  preparado  por  organização  governamental  sobre  as 
práticas de sustentabilidade da companhia; 
 no  trabalho  de  atestação,  o  mensurador  ou  o  avaliador  geralmente  fornece  ao  auditor 
independente uma representação escrita sobre a informação do objeto. Em alguns casos, o 
auditor  pode  não  ser  capaz  de  obter  tal  representação,  por  exemplo,  quando  a  contratante 
não é o mensurador ou o avaliador; 
 a parte responsável pode ser um dos usuários previstos, mas não o único; 
 a  parte  responsável,  o  mensurador  ou  o  avaliador  e  os  usuários  previstos  podem  ser  de 
entidades diferentes ou da mesma entidade. Como exemplo do último caso, em entidade com 
estrutura  de  administração  de  dois  níveis,  o  conselho  de  administração  pode  querer  obter 
asseguração sobre uma informação fornecida pela diretoria executiva dessa entidade. A relação 
entre  a  parte  responsável,  o  mensurador  ou  o  avaliador  e  os  usuários  previstos  precisam  ser 
observados  dentro  do  contexto  de  cada  trabalho  específico  e  podem  diferir  das  linhas 
tradicionalmente definidas de responsabilidade. Por exemplo, a alta administração da entidade 
(usuário previsto) pode contratar o auditor independente para executar trabalho de asseguração 
sobre  um  aspecto  específico  das  atividades  da  entidade  que  é  de  responsabilidade  do  nível 
imediatamente  inferior  de  administração  (parte  responsável)  em  relação  à  alta  administração, 
todavia,  em  última  instância,  a  alta  administração,  que  é  a  usuária  prevista,  é,  também,  a 
responsável final pela informação; 
 uma  parte  contratante  que  não  seja  também  uma  parte  responsável  pode  ser  o  usuário 
previsto. 
 
4.  A conclusão do auditor independente pode ser escrita nos termos: 
 do objeto e dos critérios aplicáveis; 
 da informação do objeto e dos critérios aplicáveis; ou 

 
 
 
26 
 
 de declaração feita pela parte apropriada. 
 
5.  O auditor e a parte responsável podem concordar em aplicar os princípios das NBCs TO para 
trabalho nos quais não existam outros usuários previstos além da parte responsável, desde que 
todos  os  outros  requisitos  das  NBCs  TO  sejam  cumpridos.  Em  tais  casos,  o  relatório  do 
auditor   independente   inclui   declaração   restringido   o   uso   do   relatório   apenas   à   parte 
responsável. 
 
 
 
Apêndice 4 – Categorização dos objetos em trabalhos de asseguração  
 
A tabela  abaixo  mostra  uma  série  de  possíveis  objetos  em  trabalhos  de  asseguração  com  alguns 
exemplos de trabalhos. Algumas categorias não possuem exemplos, porque é improvável que trabalhos 
de asseguração relacionados com essa informação sejam realizados nessas categorias. A categorização 
não  é  necessariamente  completa  e  as  categorias  não  são  necessariamente  mutuamente  exclusivas. 
Alguns  objetos  ou  informação  do  objeto  podem  possuir  componentes  em  mais  de  uma  categoria,  por 
exemplo, relatório integrado e relatório de responsabilidade social corporativa são propensos a ter tanto 
informações   históricas   quanto   voltadas   para   o   futuro,   assim   como   informações   financeiras   e 
informações não financeiras. Também, em alguns casos, os exemplos são de informação do objeto; em 
outros  casos,  eles  são  o  próprio  objeto  ou  meramente  uma  indicação  do  tipo  de  questão  que  a 
informação poderia auxiliar com o que for mais significativo nas circunstâncias. 
 
 
Informação sobre: Informação histórica Informação 
prospectiva 
    
Financeira Desempenho 
Demonstrações contábeis elaboradas 
de acordo com uma estrutura 
aceitável de relatórios financeiros 
 Fluxo de caixa 
previsto/projetado 
Posição 
 Posição financeira 
prevista/projetada 
Não 
financeira 
Desempenho/uso 
de recursos/ 
relação custo x 
benefício (value 
for money) 
 Declaração de emissão de gases 
de efeito estufa 
 Relatório de sustentabilidade 
 Indicadores chave de desempenho 
 Declaração sobre o efetivo uso de 
recursos 
 Declaração sobre a relação custo 
x benefício 
 Relatório de responsabilidade 
social da corporação 
 Reduções de 
emissão atribuídas à 
nova tecnologia, ou 
gases de efeito 
estufa a serem 
capturados por 
plantio de árvores 
 Declaração de que 
uma ação proposta 
fornecerá benefício 
maior do que seu 
custo 
Condição 
Descrição do sistema/processo como 
implementado em determinado 
momento 
 

 
 
 
27 
 
Características físicas, por exemplo, 
o tamanho da propriedade arrendada 
 
Sistema/ 
processo 
Descrição 
Descrição do sistema de controle 
interno. 
 
Projeto 
Projeto de controles para uma 
organização de serviços 
Desenvolvimento dos 
controles propostos 
para um processo 
futuro de produção 
Operação/ 
desempenho 
 
Eficácia operacional dos processos 
de contratação e treinamento de 
empregados 
 
Aspectos 
comporta-
mentais 
Cumprimento ou 
conformidade 
com regra 
 
Cumprimento pela entidade de 
convênios de empréstimo, requisitos 
legais ou regulamentários específicos 
 
Comportamento 
humano 
Avaliação da eficácia do comitê de 
auditoria 
 
Outros 
Adequação do aplicativo (ou do 
pacote de software) à sua finalidade
