# Aprova a Rev.NBC 04, que altera normas

- Código externo: 2019/revisaonbc04
- Fonte: CFC 2019/REVISAONBC04 — DOU 13/12/2019
- URL fonte: https://www2.cfc.org.br/sisweb/sre/detalhes_sre.aspx?Codigo=2019/REVISAONBC04&arquivo=REVISAONBC04.doc
- Arquivo original: https://www1.cfc.org.br/sisweb/SRE/docs/REVISAONBC04.pdf
- Nome do arquivo: REVISAONBC04.pdf
- Tags: Contábil, NBC
- Atualizado em: 2026-10-10 14:27:54.632613+00

## Resumo

Aprova a Rev.NBC 04, que altera normas

## Texto integral extraído

NORMA  BRASILEIRA  DE  CONTABILIDADE,  REVISÃO  NBC 04,  DE 21 DE NOVEMBRO DE 
2019 
 
Aprova   a   Revisão   NBC   04,   que   altera   as 
seguintes normas: NBC TG 03 (R3), NBC TG 04 
(R4), NBC TG 06 (R3), NBC TG 09, NBC TG 10 
(R3),  NBC  TG  11  (R2),  NBC  TG  15  (R4), NBC 
TG 20 (R2), NBC TG 21 (R4), NBC TG 23 (R2), 
NBC TG 25 (R2), NBC TG 26 (R5), NBC TG 27 
(R4), NBC TG  28  (R4),  NBC  TG  29  (R2), NBC 
TG 32 (R4), NBC TG 37 (R5), NBC TG 46 (R2), 
NBC  TG  47, NBC TG  48, NBC TG  1000  (R1), 
ITG  01  (R1),  ITG  16  (R2),  ITG  17,  ITG  18,  ITG 
21 e CTG 05. 
 
 
O CONSELHO FEDERAL DE CONTABILIDADE, no exercício de suas atribuições legais 
e  regimentais  e  com  fundamento  no  disposto  na  alínea  “f”  do  Art.  6º  do  Decreto-Lei  n.º 
9.295/1946,  alterado  pela  Lei  n.º  12.249/2010,  faz  saber  que  foi  aprovada  em  seu  Plenário  a 
Revisão NBC 04, que altera as seguintes normas: 
 
1. Inclui  nota  de  rodapé  na  definição  de  “Ativo” do  item  8  e  altera  o  item  5  da 
Interpretação  Técnica  anexa à NBC  TG 04 (R4) – Ativo  Intangível,  que  passam  a 
vigorar com as seguintes redações: 
 
Ativo
1
 é um recurso: 
(a) controlado pela entidade como resultado de eventos passados; e 
(b) do qual se espera que resultem benefícios econômicos futuros para a entidade. 
 
1 
A definição de ativo nesta Norma não foi revisada após a revisão da definição de ativo na 
NBC TG ESTRUTURA CONCEITUAL – Estrutura Conceitual para Relatório Financeiro. 
 
5.  Esta Interpretação não se aplica aos gastos com a aquisição, desenvolvimento e operação 
de hardware (por exemplo, servidores de sítio na internet, servidores de teste, servidores de 
produção  e  conexões  à  internet)  de  sítio  na  internet.  Gastos  dessa  natureza  devem  ser 
contabilizados,  de  acordo  com a NBC  TG 27 – Ativo  Imobilizado.  Além  disso,  quando  a 
entidade  incorre  em  gastos  com  o  fornecedor  de  serviços  da  internet,  o  qual  realiza  a 
hospedagem do sítio da entidade, o gasto deve ser reconhecido como despesa, de acordo 
com a NBC  TG 26 – Apresentação  das  Demonstrações  Contábeis,  item  88,  e  com a NBC 
TG ESTRUTURA  CONCEITUAL – Estrutura  Conceitual  para Relatório  Financeiro,  quando 
os serviços são recebidos. 
 
 
2. Altera  a  definição  “Instrumento  patrimonial”  do  Apêndice  A  da NBC  TG 10  (R3) – 
Pagamento Baseado em Ações, que passa a vigorar com a seguinte redação: 
 
Instrumento  patrimonial é  um  contrato  que  evidencia  um  interesse  residual  nos  ativos da 
entidade após a dedução de todos os seus passivos.
4
  
 
4
 A NBC TG ESTRUTURA CONCEITUAL – Estrutura Conceitual para Relatório Financeiro define passivo como 
obrigação presente da entidade de transferir recurso econômico como resultado de eventos passados.  
 
 
3. Altera os itens 3, 11, B7, B8, e inclui seu título, B9, B12, e inclui seu título, a definição 
de “Negócio” do Apêndice A, inclui os itens B7A e seu título, B7B, B7C, B8A, de B12A 
a  B12D  e  exclui  o  item  B10  da NBC  TG 15  (R4) – Combinação  de  Negócios,  que 
passam a vigorar com as seguintes redações: 

 
 
 
3. A  entidade  deve  determinar  se  uma  operação, ou  outro  evento, é  uma  combinação  de 
negócios  pela  aplicação  da  definição  utilizada  nesta Norma,  a  qual  exige  que  os  ativos 
adquiridos  e  os  passivos  assumidos  constituam  um  negócio.  Se  os  ativos  adquiridos  não 
constituem  um  negócio,  a  entidade  deve  contabilizar  a  operação  ou  o  evento  como 
aquisição  de  ativos.  Os  itens  B5  a B12D  fornecem  orientações  sobre  a  identificação  da 
combinação de negócios e a definição de negócio. 
 
11.  Para   se  qualificarem  para  reconhecimento,  como   parte  da   aplicação   do   método  de 
aquisição,  os  ativos  identificáveis  adquiridos  e  os  passivos  assumidos  devem  atender,  na 
data da aquisição, às definições de ativo e de passivo dispostas na NBC TG ESTRUTURA 
CONCEITUAL – Estrutura Conceitual para Relatório Financeiro. Por exemplo, os custos que 
o  adquirente  espera,  porém  não  está  obrigado  a  incorrer  no  futuro,  para  efetivar  um  plano 
para   encerrar   uma   atividade   da   adquirida,   ou   os   custos   para   realocar   ou   desligar 
empregados  da  adquirida  não  constituem  passivo  na  data  da  aquisição.  Portanto,  o 
adquirente  não  deve  reconhecer  tais  custos  como  parte  da  aplicação  do  método  de 
aquisição. Em vez disso, o adquirente deve reconhecer tais custos em suas demonstrações 
contábeis  pós-combinação, de  acordo  com  o  disposto  em  outras normas,  interpretações  e 
comunicados. 
 
Negócio é  um  conjunto  integrado  de  atividades  e  ativos  capaz  de  ser  conduzido  e 
gerenciado  com  o  objetivo  de  fornecer  bens  ou  serviços  a  clientes,  gerando  receita  de 
investimento (como dividendos ou juros) ou gerando outras receitas de atividades ordinárias.  
 
B7. Um  negócio  consiste  de inputs – entrada  de  recursos – e  processos  (os  processos  são 
aplicados aos inputs), os quais têm a capacidade de contribuir para gerar outputs – saída de 
recursos.  Os  três  elementos  de  um  negócio  são  definidos  a  seguir  (consulte  os  itens  B8  a 
B12D para obter orientação sobre os elementos de negócio): 
(a) input: qualquer recurso econômico que gera outputs ou tem a capacidade de contribuir 
para  gerar outputs quando  um  ou  mais  processos  são  aplicados  sobre ele. Exemplos 
incluem ativos não circulantes (incluindo ativos intangíveis ou direitos ao uso de ativos 
não circulantes),  propriedade  intelectual,  a habilidade de  obter  acesso aos  materiais 
necessários ou direitos e empregados; 
(b) processos: qualquer  sistema,  padrão,  protocolo,  convenção  ou  regra  que,  quando 
aplicado a  um input ou inputs, gera outputs ou tem a  capacidade  de  contribuir  para 
gerar outputs.   Exemplos   incluem   processos de   gestão   estratégica,   processos 
operacionais  e  processos  de  gestão  de  recursos.  Esses  processos  normalmente  são 
documentados,  porém  a  capacidade  intelectual  da  força  de  trabalho  organizada,  que 
detém  a  experiência  e as  habilidades  necessárias para  seguir regras  e  convenções, 
pode  gerar  os  processos  necessários  e  ser  capaz  de  aplicá-los  aos inputs para  gerar 
outputs (faturamento,    contabilidade,    folha    de    pagamento    e    outros    sistemas 
administrativos normalmente não são processos usados para criar outputs); 
(c) output: o resultado  de inputs e de processos  aplicados  aos inputs, que fornecem  bens 
ou  serviços  a  clientes,  gera  receita  de  investimento  (como  dividendos  ou  juros)  ou 
geram outras receitas de atividades ordinárias. 
 
Teste opcional para identificar concentração de valor justo 
 
B7A. O  item  B7B  estabelece  um  teste  opcional  (teste  de  concentração)  para  permitir  avaliação 
simplificada sobre se  o  conjunto  de  atividades  e  ativos  adquiridos  não  é  um  negócio.  A 
entidade  pode  optar  por  aplicar  ou  não  aplicar  o  teste. A  entidade  pode  fazer  tal  escolha 
separadamente  para  cada  transação  ou  outro  evento.  O  teste  de  concentração  tem  as 
seguintes consequências: 
(a)  se   o   teste   de   concentração   for   atendido,   o   conjunto   de   atividades   e   ativos   é 
determinado como não sendo um negócio e nenhuma avaliação adicional é necessária; 
(b)  se  o  teste  de  concentração  não  for  atendido,  ou  se  a  entidade  optar  por  não  aplicar  o 
teste, a entidade deve então realizar a avaliação prevista nos itens de B8 a B12D. 

 
 
 
B7B.  O  teste  de  concentração  é atendido  se, substancialmente, todo  o  valor  justo  dos  ativos 
brutos  adquiridos  estiver  concentrado  em  um  único  ativo  identificável  ou  grupo  de  ativos 
identificáveis similares. Para o teste de concentração: 
(a)  os  ativos  brutos  adquiridos  devem  excluir  caixa  e  equivalentes  de  caixa, ativos  fiscais 
diferidos e ágio resultante dos efeitos de passivos fiscais diferidos; 
(b)  o  valor   justo   dos   ativos  brutos  adquiridos   deve  incluir   qualquer   contraprestação 
transferida (acrescido do valor justo de qualquer participação de não controladores e do 
valor  justo  de  qualquer  participação  anteriormente  detida)  em  excesso  do  valor  justo 
dos  ativos  líquidos  identificáveis adquiridos.  O  valor  justo  dos  ativos  brutos  adquiridos 
pode  normalmente  ser  determinado  como  o  total  obtido  pela  soma  do  valor  justo da 
contraprestação  transferida  (acrescido  do  valor  justo  de  qualquer  participação  de  não 
controladores  e  do  valor  justo  de  qualquer  participação  anteriormente  detida)  ao  valor 
justo de passivos assumidos (exceto passivos de impostos diferidos), excluindo os itens 
identificados na alínea (a). No entanto, se o valor justo dos ativos brutos adquiridos for 
maior que o total, cálculo mais preciso pode, às vezes, ser necessário; 
(c)  um  único  ativo  identificável  deve  incluir  qualquer  ativo  ou  grupo  de  ativos  que seriam 
reconhecidos  e  mensurados  como  um  único  ativo  identificável  na  combinação  de 
negócios; 
(d)  se  o  ativo  tangível  for  anexado  e  não  puder  ser  fisicamente  removido  e  usado 
separadamente de outro ativo tangível (ou de ativo subjacente sujeito a arrendamento, 
conforme   definido   na NBC   TG 06 – Arrendamentos),   sem   incorrer   em   custos 
significativos  ou  significativa  diminuição  na  utilidade  ou  valor  justo dos  referidos ativos 
(por exemplo, terrenos e edifícios), esses ativos devem ser considerados um único ativo 
identificável; 
(e)  ao avaliar se os ativos são semelhantes, a entidade deve considerar a natureza de cada 
ativo  individual  identificável  e  os  riscos  associados  à  gestão  e  à  criação  de outputs 
pelos ativos (isto é, às características de risco); 
(f)  os seguintes itens não devem ser considerados ativos similares: 
(i)  ativo tangível e ativo intangível; 
(ii)  ativos  tangíveis  em  diferentes  classes  (por  exemplo,  estoque,  equipamentos  de 
fabricação  e  automóveis),  a  menos  que  sejam  considerados  um  único  ativo 
identificável de acordo com o critério da alínea (d); 
(iii)  ativos  intangíveis  identificáveis em  diferentes  classes  (por  exemplo,  nomes  de 
marcas, licenças e ativos intangíveis em desenvolvimento); 
(iv)  ativo financeiro e ativo não financeiro; 
(v)   ativos   financeiros   em   diferentes   classes   (por   exemplo,   contas   a   receber   e 
investimentos em instrumentos patrimoniais); e 
(vi)  ativos  identificáveis que  estão  dentro  da  mesma  classe  de  ativo,  mas  possuem 
características de risco significativamente diferentes. 
 
B7C.  Os requisitos do item B7B não modificam a orientação sobre ativos similares na NBC TG 04 
– Ativo  Intangível, nem  modificam  o  significado  do  termo  "classe"  na NBC  TG 27 – Ativo 
Imobilizado, na NBC TG 04 e na NBC TG 40 – Instrumentos Financeiros: Evidenciação. 
 
Elementos de negócio 
 
B8. Embora um  negócio geralmente  tenha outputs, outputs não  são  necessários  para  que  o 
conjunto integrado de atividades e ativos se qualifique como negócio. Para ser capaz de ser 
conduzido  e  gerenciado  para  o  objetivo  identificado  na  definição  de  negócio,  o  conjunto 
integrado  de  atividades  e  ativos  precisa  ter  dois  elementos  essenciais – os inputs e  os 
processos a serem aplicados sobre os inputs. O negócio não precisa incluir todos os inputs 
e os processos que o vendedor utilizava na operacionalização daquele negócio. Entretanto, 
para  ser  considerado  um  negócio,  o  conjunto  integrado  de  atividades  e  ativos  deve  incluir, 
no mínimo, o input e o processo substantivo que juntos contribuam, significativamente, para 
a  capacidade  de gerar output.  Os  itens  de  B12  a  B12D  especificam  como  avaliar  se  o 
processo é substantivo. 

 
 
 
B8A.  Se o conjunto de atividades e ativos adquiridos tiver outputs, a continuação da receita não 
indica, por si só, que tanto o input quanto o processo substantivo foram adquiridos. 
 
B9. A  natureza  dos  elementos  do  negócio  varia  conforme  o  tipo  de  indústria,  segmento  e 
estrutura das operações da entidade (atividades), incluindo o estágio de desenvolvimento da 
entidade. Negócios estabelecidos frequentemente têm diferentes tipos de inputs, processos 
e outputs, enquanto que novos negócios, com frequência, têm poucos inputs e processos e, 
às  vezes,  somente  um  único output (produto).  Quase  todos  os  negócios  também  têm 
passivos, mas não é necessário que um negócio contenha passivos. Além disso, o conjunto 
de atividades e ativos adquiridos que não seja um negócio pode ter passivos. 
 
B10.  Eliminado. 
 
Avaliar se o processo adquirido é substantivo 
 
B12. Os itens de B12A a B12D explicam como avaliar se o processo adquirido é substantivo; se o 
conjunto  de  atividades  e  ativos  adquiridos  não  possui outputs (item  B12B); e  se  possui 
outputs (item B12C). 
 
B12A. Um exemplo de conjunto de atividades e ativos adquiridos que não possui outputs na data 
de  aquisição  é  uma  entidade  em  estágio  inicial  que  não  começou  a  gerar  receita.  Além 
disso,  se  o  conjunto  de  atividades  e  ativos  adquiridos  estava  gerando  receita  na  data  de 
aquisição,  considera-se  que  possui outputs nessa  data,  mesmo  que  subsequentemente 
deixe  de  gerar  receita  de  clientes  externos,  por  exemplo,  porque  será  integrado  pela 
entidade adquirente. 
 
B12B. Se  o  conjunto  de  atividades  e  ativos  não  tiver outputs na  data  de  aquisição,  o  processo 
adquirido (ou grupo de processos) só deve ser considerado substantivo se: 
(a)  for essencial  para  a  capacidade  de  desenvolver  ou  converter  o input ou inputs 
adquiridos em outputs; e 
(b)  os inputs adquiridos  incluírem  tanto  a  força  de  trabalho  organizada  que  possui  a 
habilidade  necessária,  conhecimento  ou  experiência  para  executar  esse  processo  (ou 
grupo  de  processos)  e  outros inputs que  a  força  de  trabalho  organizada  poderia 
desenvolver ou converter em outputs. Esses outros inputs podem incluir: 
(i)  propriedade intelectual que poderia ser usada para desenvolver o bem ou serviço; 
(ii)  outros recursos econômicos que poderiam ser desenvolvidos para gerar outputs; ou 
(iii)  direitos  para  obter  acesso  a  materiais  ou  direitos  necessários  que  permitam  a 
geração de outputs futuros. 
Exemplos  de inputs mencionados  nos  incisos  de  (i)  a  (iii)  da  alínea  (b)  incluem  tecnologia, 
projetos de pesquisa e desenvolvimento em andamento, bens imóveis e interesses minerais. 
 
B12C. Se  o  conjunto  de  atividades  e  ativos  tiver outputs na  data  de  aquisição,  o  processo 
adquirido (ou grupo de processos) deve ser considerado substantivo, se, quando aplicado a 
input ou inputs adquiridos, ele: 
(a)  for fundamental  para  a  capacidade  de  continuar  a  produzir outputs,  e  os inputs 
adquiridos  incluírem  a  força  de  trabalho  organizada  com  as  habilidades  necessárias, 
conhecimento ou experiência para executar esse processo (ou grupo de processos); ou 
(b)  contribui significativamente para a capacidade de continuar produzindo outputs e: 
(i)  é considerado único ou escasso; ou 
(ii)  não  pode  ser  substituído  sem  custo,  esforço  ou  atraso significativo  na  capacidade 
de continuar produzindo outputs. 
 
B12D.  A seguinte discussão dá suporte a ambos os itens B12B e B12C: 
(a)  contrato  adquirido  é  um input e  não  um  processo  substantivo.  No  entanto,  o  contrato 
adquirido,  por  exemplo,  contrato  de  gerenciamento  de  propriedade  terceirizada  ou 
gerenciamento de ativos terceirizados, pode dar acesso à força de trabalho organizada. 

 
 
A  entidade  deve  avaliar  se  a  força  de  trabalho  organizada  acessada  por  meio  de  tal 
contrato  realiza  processo  substantivo  que  a  entidade  controla  e,  portanto,  adquiriu.  Os 
fatores a serem considerados ao fazer essa avaliação incluem a duração do contrato e 
seus termos de renovação; 
(b)  dificuldades em substituir a força de trabalho organizada adquirida podem indicar que a 
força de trabalho organizada adquirida realiza processo que é crítico para a capacidade 
de criar outputs; 
(c)  processo  (ou  grupo  de  processos)  não  é  crítico  se,  por  exemplo,  for  secundário  ou 
menor no contexto de todos os processos necessários para criar outputs. 
 
 
4. Altera os itens 31 e 33 da NBC TG 21 (R4) – Demonstração Intermediária, que passam 
a vigorar com as seguintes redações: 
 
31.   Pela NBC TG ESTRUTURA CONCEITUAL – Estrutura Conceitual para Relatório Financeiro, 
reconhecimento  é  o  processo  de  captura,  para  inclusão  no  balanço  patrimonial  ou  na 
demonstração  do  resultado,  de  item  que  atende  à  definição  de  um  dos  elementos  das 
demonstrações  contábeis.  As  definições  de  ativos,  passivos,  receitas  e  despesas  são 
fundamentais para o reconhecimento ao término de ambos os períodos de reporte anuais e 
intermediários. 
 
33. Uma  característica  essencial  das  receitas  e  despesas  é  que  as  entradas  e  as  saídas  de 
ativos e passivos correspondentes já ocorreram. Se tais entradas e saídas já ocorreram, as 
correspondentes  receitas e  despesas  devem  ser  reconhecidas,  caso  contrário  elas  não 
devem   ser   reconhecidas. A NBC   TG ESTRUTURA   CONCEITUAL não autoriza   o 
reconhecimento de itens no balanço patrimonial que não satisfaçam à definição de ativos ou 
passivos. 
 
 
5. Altera  os  itens  5  e  11  e exclui  o  item  6 na NBC  TG 23 (R2) – Políticas  Contábeis, 
Mudança de Estimativa e Retificação de Erro, que passam a vigorar com as seguintes 
redações: 
 
5. (...) 
Material  é  definido  no  item  7  da NBC  TG 26  e  é  utilizado  nesta  Norma com  o  mesmo 
significado. 
(...) 
 
6.  Eliminado. 
 
11.  Ao  exercer  os  julgamentos  descritos  no  item  10,  a  administração  deve  consultar  e 
considerar a aplicabilidade das seguintes fontes por ordem decrescente:  
(a) os  requisitos  e  a  orientação  de normas,  interpretações  e comunicados que  tratem  de 
assuntos semelhantes e relacionados; e  
(b) as  definições,  os  critérios  de  reconhecimento  e  os  conceitos  de  mensuração  para 
ativos, passivos, receitas e despesas contidos na NBC TG ESTRUTURA CONCEITUAL 
– Estrutura Conceitual para Relatório Financeiro.  
 
6. Inclui  nota  de  rodapé  na  definição  de  “Passivo” do  item  10  da NBC  TG 25 (R2) – 
Provisões, Passivos Contingentes e  Ativos Contingentes, que passa a  vigorar com a 
seguinte redação: 
 
Passivo
1
 é  uma  obrigação  presente  da  entidade,  derivada  de  eventos  já  ocorridos,  cuja 
liquidação  se  espera  que  resulte  em  saída  de  recursos  da  entidade  capazes  de  gerar 
benefícios econômicos. 
1 
A  definição  de  passivo  nesta Norma não  foi  revisada  após  a  revisão  da  definição  de  passivo  na NBC  TG 
ESTRUTURA CONCEITUAL – Estrutura Conceitual para Relatório Financeiro. 

 
 
 
 
7. Altera  os  itens 7, 15,  19,  20,  23,  24,  28  e  89  da NBC  TG 26  (R5) – Apresentação  das 
Demonstrações Contábeis, que passam a vigorar com as seguintes redações:  
 
7.  (...) 
Material – A  informação  é  material  se  sua  omissão, distorção  ou  obscuridade pode 
influenciar, de  modo  razoável,  decisões  que  os  usuários primários das  demonstrações 
contábeis  de  propósito  geral tomam como base  nessas  demonstrações  contábeis,  que 
fornecem informações financeiras sobre relatório específico da entidade. 
A  materialidade  depende  da  natureza  ou  magnitude  da  informação,  ou  de  ambas.  A 
entidade avalia se a informação, individualmente ou em combinação com outra informação, 
é material no contexto das suas demonstrações contábeis tomadas como um todo. 
A  informação  é  obscura  se  for  comunicada  de  forma  que  teria  efeito  semelhante, para  os 
usuários  primários  das  demonstrações  contábeis, à  omissão  ou  ao  erro dessa  informação. 
Seguem-se  exemplos  de  circunstâncias  que  podem  resultar  na  ocultação  de  informações 
relevantes: 
(a)  as  informações  relativas  ao  item,  transação  ou  outro evento  relevante são  divulgadas 
nas demonstrações contábeis, mas a linguagem utilizada é vaga ou pouco clara; 
(b)  as  informações  relativas  ao  item,  transação  ou  outro  evento  relevante  estão  dispersas 
nas demonstrações contábeis; 
(c)  itens distintos, transações ou outros eventos são agregados de forma inadequada; 
(d)  itens similares, transações ou outros eventos são desagregados inadequadamente; e 
(e)  a  compreensibilidade  das  demonstrações  contábeis  é  reduzida  como  resultado  de 
informações materiais ocultas por informações imateriais, na medida em que o usuário 
principal não consegue determinar quais informações são relevantes. 
Avaliar  se poderia  ser  razoavelmente  esperado  que a  informação  influencie as  decisões 
tomadas pelos usuários primários das demonstrações contábeis para fins gerais de entidade 
específica requer que a entidade considere as características desses usuários e, ao mesmo 
tempo, considere as próprias circunstâncias da entidade. 
Muitos  investidores,  mutuantes  e  outros  credores  existentes  e  potenciais  não  podem  exigir 
que  a  entidade  que  reporta  forneça  informações  diretamente  a  eles  e  devem  confiar  nas 
demonstrações contábeis para fins gerais para grande parte das informações financeiras de 
que  precisam.  Consequentemente,  eles  são  os  usuários primários para  os  quais  as 
demonstrações  contábeis  para  fins  gerais  são  direcionadas.  As  demonstrações  contábeis 
são   elaboradas   para   usuários   que   tenham   conhecimento   razoável   das   atividades 
econômicas  e  de  negócios  e  que  revisem  e  analisem  as  informações  com  diligência.  Às 
vezes,  até  mesmo  usuários  bem  informados  e  diligentes  podem  precisar  buscar  ajuda  de 
consultor para entender às informações sobre fenômenos econômicos complexos. 
(...) 
 
15. As  demonstrações  contábeis  devem  representar  apropriadamente  a  posição  financeira  e 
patrimonial, o desempenho e os fluxos de caixa da entidade. Para apresentação adequada, 
é  necessária  a  representação  fidedigna  dos  efeitos  das  transações,  outros eventos  e 
condições de acordo com as definições e critérios de reconhecimento para ativos, passivos, 
receitas  e  despesas  como  estabelecidos  na NBC  TG ESTRUTURA  CONCEITUAL – 
Estrutura  Conceitual  para Relatório  Financeiro.  Presume-se  que  a  aplicação  das normas, 
interpretações  e comunicados,  com  divulgação  adicional  quando  necessária,  resulta  em 
demonstrações contábeis que se enquadram como representação apropriada.  
 
19. Em  circunstâncias  extremamente  raras,  nas  quais  a  administração  vier  a  concluir  que  a 
conformidade  com  um  requisito  de norma,  interpretação  ou comunicado conduziria  a  uma 
apresentação  tão  enganosa  que  entraria  em  conflito  com o objetivo  das  demonstrações 
contábeis  estabelecido  na NBC  TG ESTRUTURA  CONCEITUAL,  a  entidade  não  deve 
aplicar esse requisito e deve seguir o disposto no item 20, a não ser que esse procedimento 
seja terminantemente vedado do ponto de vista legal e regulatório. 
 

 
 
20.  Quando a entidade não aplicar um requisito de norma, interpretação ou comunicado ou de 
acordo com o item 19, deve divulgar:  
(a) que  a  administração  concluiu  que  as  demonstrações  contábeis  apresentam  de  forma 
apropriada  a  posição  financeira  e  patrimonial,  o  desempenho  e  os  fluxos  de  caixa  da 
entidade; 
(b) que  aplicou as normas,  interpretações  e comunicados aplicáveis, exceto  pela  não 
aplicação de requisito específico com o propósito de obter representação apropriada; 
(c) o título da norma, interpretação ou comunicado que a entidade não aplicou, a natureza 
dessa  exceção,  incluindo  o  tratamento  que a norma, interpretação  ou comunicado 
exigiria; a razão pela qual esse tratamento seria tão enganoso que entraria em conflito 
com  o  objetivo  das  demonstrações  contábeis,  estabelecido na NBC  TG ESTRUTURA 
CONCEITUAL; e o tratamento efetivamente adotado; e 
(d) para  cada  período  apresentado,  o  impacto  financeiro  da  não  aplicação  da norma, 
interpretação  ou comunicado vigente  em  cada  item  nas  demonstrações  contábeis  que 
teria sido informado, caso tivesse sido cumprido o requisito não aplicado. 
 
23. Em  circunstâncias  extremamente  raras,  nas  quais  a  administração  vier  a  concluir  que  a 
conformidade  com  requisito  de norma,  interpretação  ou comunicado conduziria  a  uma 
apresentação  tão  enganosa  que  entraria  em  conflito  com  o  objetivo  das  demonstrações 
contábeis estabelecido   na NBC   TG ESTRUTURA   CONCEITUAL, mas   a   estrutura 
regulatória vigente proibir a não aplicação do requisito, a entidade deve, na maior extensão 
possível,  reduzir  os  aspectos  inadequados  identificados  no  cumprimento  estrito  da norma, 
interpretação ou comunicado divulgando: 
(a) o  título  da norma,  interpretação  ou comunicado em  questão,  a  natureza  do  requisito  e 
as  razões  que  levaram  a  administração  a  concluir  que  o  cumprimento  desse  requisito 
tornaria  as  demonstrações  contábeis  tão  enganosas que  entraria  em  conflito  com  o 
objetivo   das   demonstrações   contábeis   estabelecido na NBC   TG ESTRUTURA 
CONCEITUAL; e 
(b) para cada período apresentado, os ajustes de cada item nas demonstrações contábeis 
que   a   administração   concluiu   serem   necessários   para   se   obter   representação 
apropriada. 
 
24. Para  a  finalidade  dos  itens  de  19  a  23,  um  item  de  informação  entra  em  conflito  com  o 
objetivo   das   demonstrações   contábeis   quando   não   representa   fidedignamente   as 
transações,  outros  eventos  e  condições a que  se  propõe  representar,  ou  que  se  poderia 
esperar   razoavelmente   que   representasse   e,   consequentemente,   seria   provável   que 
influenciasse   as   decisões   econômicas   tomadas   pelos   usuários   das   demonstrações 
contábeis. Ao avaliar se o cumprimento de requisito específico de norma, interpretação ou 
comunicado resultaria  em  divulgação  tão  distorcida  a  ponto  de entrar  em  conflito  com  o 
objetivo    das    demonstrações    contábeis,    estabelecido na NBC    TG ESTRUTURA 
CONCEITUAL, a administração deve considerar: 
(a) a  razão  pela  qual  o  objetivo  das  demonstrações  contábeis  não  é  alcançado  nessa 
circunstância particular; e 
(b) como as circunstâncias da entidade diferem das circunstâncias de outras entidades que 
cumprem  o  requisito.  Se  outras  entidades  em  circunstâncias  similares  cumprem  o 
requisito, há um pressuposto refutável de que o cumprimento do requisito por parte da 
entidade  não  resultaria  em  divulgação  tão  enganosa  e,  portanto,  não  entraria  em 
conflito  com   o  objetivo  das   demonstrações  contábeis,   estabelecido na NBC   TG 
ESTRUTURA CONCEITUAL. 
 
28. Quando o regime de competência é utilizado, os itens devem ser reconhecidos como ativos, 
passivos, patrimônio líquido, receitas e despesas (elementos das demonstrações contábeis) 
quando  satisfazem  às  definições  e  aos  critérios  de  reconhecimento  para  esses  elementos 
contidos na NBC TG ESTRUTURA CONCEITUAL. 
 
89. Algumas normas,   interpretações   e comunicados especificam   circunstâncias   em   que 
determinados itens podem ser excluídos dos resultados líquidos do período. A NBC TG 23 

 
 
trata de duas dessas circunstâncias, a saber: a correção de erros e o efeito de alterações 
nas   políticas   contábeis.   Outras normas,   interpretações   e comunicados requerem   ou 
permitem que outros resultados abrangentes que se enquadram na definição de receitas e 
despesas  da NBC  TG ESTRUTURA  CONCEITUAL sejam  excluídos  do  resultado  líquido 
(ver item 7). 
 
 
8. Altera  o  item  D1  da NBC  TG 37 (R5) – Adoção  Inicial  das  Normas  Internacionais  de 
Contabilidade, que passa a vigorar com a seguinte redação: 
 
D1.  A entidade pode optar por uma ou mais das seguintes isenções: 
(a) (...); 
(b) (eliminada); 
(c) (...) 
(d) (...) 
(e) (eliminada); 
(o)  (eliminada); 
(...) 
 
 
9. Altera  a  denominação  da NBC  TG ESTRUTURA  CONCEITUAL – Estrutura  Conceitual 
para Elaboração e Divulgação de Relatório Contábil-Financeiro citada na ITG 01 (R1) – 
Contratos de Concessão, que passa a vigorar com a seguinte redação: 
 
Referências 
 NBC TG ESTRUTURA CONCEITUAL – Estrutura Conceitual para Relatório Financeiro 
 (...) 
 
 
10. Altera  a  denominação  da NBC  TG ESTRUTURA  CONCEITUAL – Estrutura  Conceitual 
para Elaboração e Divulgação de Relatório Contábil-Financeiro citada na ITG 16 (R2) – 
Extinção  de  Passivos  Financeiros  com  Instrumentos  Patrimoniais,  que  passa  a 
vigorar com a seguinte redação: 
 
Referências 
 NBC TG ESTRUTURA CONCEITUAL – Estrutura Conceitual para Relatório Financeiro 
 (...) 
 
 
11. Altera  a  denominação  da NBC  TG ESTRUTURA  CONCEITUAL – Estrutura  Conceitual 
para  Elaboração  e  Divulgação  de  Relatório  Contábil-Financeiro citada na  ITG 18 – 
Custos de Remoção de Estéril de Mina de Superfície na Fase de Produção, que passa 
a vigorar com a seguinte redação: 
 
Referências: 
 NBC TG ESTRUTURA CONCEITUAL – Estrutura Conceitual para Relatório Financeiro 
 (...) 
 
 
12. Altera  a  denominação  da NBC  TG ESTRUTURA  CONCEITUAL – Estrutura  Conceitual 
para  Elaboração  e  Divulgação  de  Relatório  Contábil-Financeiro citada na  ITG 21 – 
Transação em Moeda Estrangeira e Adiantamento, que passa a vigorar com a seguinte 
redação: 
 
Referências 
 NBC TG ESTRUTURA CONCEITUAL – Estrutura Conceitual para Relatório Financeiro  

 
 
 (...) 
 
 
13. Altera, na NBC TG 06 (R3), a sua denominação: 
 
De:  Operações de Arrendamento Mercantil;   
Para:  Arrendamentos 
 
14. Inclui no item 1 da NBC TG 06 (R3) a seguinte nota de rodapé: 
  
O termo "arrendamentos" adotado nesta Norma corresponde à tradução do termo 'leases' na 
língua  inglesa  e  pode  abranger  contratos  (mas  não  se  limita  a)  de  arrendamento,  aluguel, 
locação e outros contratos que conferem à entidade que reporta o direito de uso de um ativo 
em troca de uma contraprestação. 
 
15. Altera a denominação da NBC TG 06 (R3) para Arrendamentos e substitui a expressão 
“arrendamento(s)  mercantil(is)”  por  “arrendamento(s)”,  se  aplicável,  nas  seguintes 
normas, interpretações e comunicado: NBC TG 03 (R3), NBC TG 04 (R4), NBC TG 09, 
NBC TG 11 (R2), NBC TG 15 (R4), NBC TG 20 (R2), NBC TG 25 (R2), NBC TG 27 (R4), 
NBC TG 28 (R4), NBC TG 29 (R2), NBC TG 32 (R4), NBC TG 37 (R5), NBC TG 46 (R2), 
NBC TG 47, NBC TG 48, NBC TG 1000 (R1), ITG 01 (R1), ITG 17 e CTG 05. 
 
Essas alterações, inclusões e revogações entram em vigor na data de sua publicação. 
  
 
Brasília, 21 de novembro de 2019. 
 
 
Contador Zulmir Ivânio Breda 
Presidente 
 
Ata CFC n.º 1057.
