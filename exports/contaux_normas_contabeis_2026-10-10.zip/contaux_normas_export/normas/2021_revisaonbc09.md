# Aprova a Revisão NBC 09

- Código externo: 2021/revisaonbc09
- Fonte: CFC 2021/REVISAONBC09 — DOU 19/02/2021
- URL fonte: https://www2.cfc.org.br/sisweb/sre/detalhes_sre.aspx?Codigo=2021/REVISAONBC09&arquivo=REVISAONBC_09.doc
- Arquivo original: https://www1.cfc.org.br/sisweb/SRE/docs/REVISAONBC_09.pdf
- Nome do arquivo: REVISAONBC_09.pdf
- Tags: Contábil, NBC, Revisão NBC
- Atualizado em: 2026-10-10 14:27:54.953714+00

## Resumo

Aprova a Revisão NBC 09

## Texto integral extraído

NORMA  BRASILEIRA  DE  CONTABILIDADE,  REVISÃO  NBC 09,  DE 11  DE  FEVEREIRO  DE 
2021 
 
Aprova  a  Revisão  NBC 09, que  altera  as 
seguintes  normas: NBC  TG  06(R3),  NBC 
TG   11(R2), NBC   TG   38(R3),   NBC   TG 
40(R3) e NBC TG 48. 
 
 
O CONSELHO FEDERAL DE CONTABILIDADE, no exercício de suas atribuições legais 
e  regimentais  e  com  fundamento  no  disposto  na  alínea  “f”  do  Art.  6º  do  Decreto-Lei  n.º 
9.295/1946,  alterado  pela  Lei  n.º  12.249/2010,  faz  saber  que  foi  aprovada  em  seu  Plenário  a 
Revisão NBC 09, que altera Norma Brasileira de Contabilidade (NBC): 
 
 
1. Inclui os itens de 5.4.5 a 5.4.9, itens 6.8.13, de 6.9.1 a 6.9.13, 7.1.9 e de 7.2.43 a 7.2.46, 
inclui  título  antes  do  item  6.9.1  e  inclui  subtítulos  antes  dos  itens  5.4.5,  6.9.7,  6.9.9, 
6.9.11 e 7.2.43 na NBC TG 48 – Instrumentos Financeiros, que passam a vigorar com 
as seguintes redações: 
 
Mudanças na base para determinar os fluxos de caixa contratuais como resultado da 
Reforma da Taxa de Juros de Referência 
5.4.5.  A  entidade  deve  aplicar  os  itens  5.4.6  a  5.4.9  a  um  ativo  financeiro ou  passivo 
financeiro se, e somente se, a base para determinar os fluxos de caixa contratuais do ativo 
financeiro  ou  passivo  financeiro  muda  como  resultado  da  reforma  da  taxa  de  juros  de 
referência. Para este efeito, o termo “Reforma da Taxa de Juros de Referência" refere-se à 
reforma em todo o mercado de uma taxa de juros de referência como descrito no item 6.8.2. 
5.4.6.  A  base  para  determinar  os  fluxos  de  caixa  contratuais  de  um  ativo  financeiro  ou 
passivo financeiro pode mudar: 
(a) alterando os termos contratuais especificados no reconhecimento inicial do instrumento 
financeiro (por exemplo, os termos contratuais são alterados para substituir a referência de 
taxa de juros por uma taxa de referência alternativa); 
(b) de uma forma que não foi considerada por (ou contemplada em) termos contratuais no 
reconhecimento  inicial  do  instrumento  financeiro,  sem  alterar  os  termos  contratuais  (por 
exemplo,  o  método  para  cálculo  da  taxa  de  juros  de  referência  é  alterado  sem  alterar  os 
termos contratuais); ou 
(c)  por  causa  do  acionamento  de  um  termo  contratual  existente  (por  exemplo,  uma 
cláusula de salvaguarda (fallback) existente é acionada). 
5.4.7. Como um expediente prático, a entidade deve aplicar o item B5.4.5 para contabilizar 
uma  mudança  na  base  para  determinar  os  fluxos  de  caixa  contratuais  de  um  ativo  ou 
passivo  financeiro  que  é  exigido  pela  Reforma  da  Taxa  de  Juros  de  Referência.  Este 
expediente  prático  se  aplica  apenas  a  tais  mudanças  e  apenas  na  medida  em  que  a 
mudança  é  exigida  pela  Reforma  da  Taxa  de  Juros de  Referência  (ver  também  item 
5.4.9). Para tanto, uma mudança na base de determinação dos fluxos de caixa contratuais é 

 
 
exigida  pela  Reforma  da  Taxa  de  Juros  de  Referência  se,  e  somente  se,  ambas  as 
condições forem atendidas:  
(a)  a  mudança  é  necessária  como  consequência  direta  da  reforma  da  taxa  de  juros  de 
referência; e 
(b)  a  nova  base  para  determinar  os  fluxos  de  caixa  contratuais  é  economicamente 
equivalente à base anterior (ou seja, a base imediatamente antes da mudança). 
5.4.8. Exemplos de mudanças que dão origem a uma nova base para determinar fluxos de 
caixa  contratuais  que  são  economicamente  equivalentes  à  base  anterior  (ou  seja,  a  base 
imediatamente anterior à mudança) são: 
(a)  a  substituição  de  um  referencial  de  taxa  de  juros  existente  usado  para determinar  os 
fluxos de caixa contratuais de um ativo financeiro ou passivo financeiro com uma taxa de 
referência alternativa - ou a implementação de tal reforma da taxa de juros de referência, 
alterando  o  método  usado  para  calcular  o  referencial  da  taxa de  juros - com  a  adição  de 
um spread fixo necessário para compensar a diferença de base entre a referência de taxa 
de juros existente e a referência alternativa taxa; 
(b)  mudanças  no  período  de  redefinição  (reset),  datas  de  redefinição  (reset)ou  o  número 
de dias entre datas de pagamento de cupom, a fim de implementar a reforma da taxa de 
juros de referência; e 
(c) a adição de uma cláusula de contingência aos termos contratuais de um ativo financeiro 
ou passivo financeiro para permitir qualquer mudança descrita em (a) e (b) acima a serem 
implementadas. 
5.4.9.Se  forem  feitas  alterações  em  um  ativo  financeiro  ou  passivo  financeiro,  além  de 
mudanças na base para determinar os fluxos de caixa contratuais exigidos pela reforma da 
taxa  de  juros  de  referência,  a  entidade  deve  primeiro  aplicar  o  expediente  prático  do  item 
5.4.7  para  as  mudanças  exigidas  pela  reforma  da  taxa  de  juros  de  referência.  A  entidade 
deve   então   aplicar   os   requisitos   aplicáveis   nesta   Norma para   quaisquer   alterações 
adicionais às quais o expediente prático não se aplica. Se a mudança adicional não resultar 
no  desreconhecimento  do  ativo  financeiro  ou  passivo  financeiro,  a  entidade  deve  aplicar  o 
item 5.4.3 ou item B5.4.6, conforme aplicável, para contabilizar essa alteração adicional. Se 
a mudança adicional resulta no desreconhecimento do ativo financeiro ou passivo financeiro, 
a entidade deve aplicar os requisitos de desreconhecimento. 
6.8.13 A entidade deve cessar prospectivamente a aplicação dos itens 6.8.7 e 6.8.8, no que 
ocorrer primeiro entre:  
(a)  quando  as  mudanças  exigidas  pela  Reforma  da  Taxa  de  Juros  de  Referência 
foremfeitas  para  o  componente  de  risco  não  especificado  contratualmente  aplicando  item 
6.9.1; ou 
(b)  quando  a  relação  de  proteção  (hedging)  em  que  o  componente  de  risco  não 
contratualmente especificado é designado for descontinuado. 
6.9  Exceções  temporárias  adicionais  decorrentes  da  Reforma  da  Taxa  de  Juros  de 
Referência 

 
 
6.9.1  Como  e  quando  os  requisitos  dos  itens  6.8.4  a  6.8.8  cessarem  de  se  aplicar  a  uma 
relação  de  proteção (ver  itens  6.8.9  a  6.8.13),  a entidade  deve  alterar a designação  formal 
dessa relação de proteção, conforme documentado anteriormente para refletir as mudanças 
exigidas pela reforma da taxa de juros de referência, ou seja, as mudanças são consistentes 
com  os requisitos  dos  itens  5.4.6  a  5.4.8. Nesse  contexto,  a  designação  de  proteção  deve 
ser alterada apenas para fazer um ou mais dessas mudanças: 
(a)  designando  uma  taxa  de  referência  alternativa  (contratualmente  especificada  ou  não) 
como um risco coberto;  
(b) alterar  a  descrição  do  item  protegido,  incluindo  a  descrição  da  parcela  designada  dos 
fluxos de caixa ou valor justo sendo coberto; ou 
(c) alterar a descrição do instrumento de cobertura. 
6.9.2  A  entidade  também  deve  aplicar  o  requisito  do  item  6.9.1(c)  se  estas  três  condições 
forem atendidas: 
(a)  a  entidade  faz  uma  alteração  exigida  pela  reforma  da  taxa  de  juros  de  referência 
usando uma abordagem diferente da mudança de base para determinar os fluxos de caixa 
contratuais do instrumento de hedge (conforme descrito no item 5.4.6); 
(b) o instrumento de proteção original não é desreconhecido; e 
(c) a abordagem escolhida é economicamente equivalente a mudar a base para determinar 
os  fluxos  de  caixa  contratuais  da  proteção  do  instrumento  original  (conforme  descrito  nos 
itens 5.4.7 e 5.4.8). 
6.9.3  Os  requisitos  dos  itens  6.8.4  a  6.8.8  podem  cessar  a  aplicação  em  diferentes 
situações. Portanto,  ao  aplicar  o  item  6.9.1,  a  entidade  pode  ser  requerida  a  alterar  a 
designação  formal  de  suas  relações  de  proteção  em  momentos  diferentes,  ou  pode  ser 
necessário   alterar   a   designação   formal   de   uma   relação   de   proteção   mais   de   uma 
vez. Quando,  e  somente  quando,  tal  mudança  for  feita  na  designação  de  proteção,  a 
entidade  deve  aplicar  os  itens  6.9.7  a  6.9.12  conforme  aplicável. A entidade  também  deve 
aplicar o item 6.5.8 (para um hedge de valor justo) ou item 6.5.11 (para um hedge de fluxo 
de  caixa)  para  contabilizar  quaisquer  mudanças  no  valor  justo  do  item  protegido  ou  do 
instrumento de hedge. 
6.9.4  A  entidade  deve  alterar  uma  relação  de  proteção  conforme  exigido  no  item  6.9.1  no 
final  do  período  da  demonstração  contábil  durante  o  qual  uma  mudança  exigida  pela 
reforma  da  taxa  de  juros  de  referência  é  feita  para  o  risco  protegido,  item  coberto  ou 
instrumento  de hedge. Para  evitar  dúvidas,  tal  alteração  na  designação  formal  de  uma 
relação  de  proteção  não  constitui  nem  a  descontinuação  da  relação  de  proteção  nem  a 
designação de uma nova relação de proteção. 
6.9.5 Se alterações forem feitas além das alterações exigidas pela reforma da taxa de juros 
de  referência  para  o  ativo  financeiro  ou  passivo  financeiro  designado  em  uma  relação  de 
proteção  (conforme  descrito  nos  itens  5.4.6  a  5.4.8)  ou  para  a  designação  da  relação  de 
proteção  (conforme  exigido  pelo  item  6.9.1),  a  entidade  deve  primeiro  aplicar  os  requisitos 
previstos nesta   Norma para   determinar   se   essas   mudanças   adicionais   resultam   na 

 
 
descontinuação  da  contabilidade  do hedge. Se  as  mudanças  adicionais  não  resultarem  na 
descontinuação da contabilidade de hedge, a entidade deve alterar a designação formal da 
relação de proteção conforme especificado no item 6.9.1.  
6.9.6 Os itens 6.9.7 a 6.9.13 estabelecem exceções aos requisitos especificados para esses 
itens apenas. A entidade deve aplicar todos os outros requisitos da contabilidade de hedge 
desta  Norma,  incluindo  os  critérios  de  qualificação  do  item  6.4.1,  para  relações  de hedge 
que foram diretamente afetadas pela reforma da taxa de juros de referência. 
Contabilização de relacionamentos de proteção qualificados 
Hedges de fluxo de caixa 
6.9.7  Para  efeitos  de  aplicação  do  item  6.5.11,  no  momento  em  que  a  entidade  altera  a 
descrição  de  um  item  coberto  conforme  exigido  no  item  6.9.1  (b),  o  valor  acumulado  na 
reserva  do hedge de  fluxo  de  caixa  será  considerado  com  base  na  taxa  de  referência 
alternativa na qual os fluxos de caixa futuro coberto são determinados. 
6.9.8  Para  uma  relação  de  proteção  descontinuada,  quando  é  alterada  a  taxa  de  juros  de 
referência em que os fluxos de caixa futuros cobertos foram baseados conforme exigido por 
reforma da taxa de juros de referência, para fins de aplicação do item 6.5.12 para determinar 
se  os  fluxos  de  caixa  futuros  cobertos  são  esperados  para  ocorrer,  o  valor  acumulado  na 
reserva de hedge de fluxo de caixa para aquela relação de proteção deve ser atribuída com 
base  na  taxa  de  referência  alternativa  na  qual  os  fluxos  de  caixa  futuros  cobertos  serão 
baseados. 
Grupos de itens 
6.9.9  Quando  a  entidade  aplica  o  item  6.9.1  a  grupos  de  itens  designados  como  itens 
protegidos num hedge de valor justo ou hedge de fluxo de caixa, a entidade deve alocar os 
itens cobertos para subgrupos com base na taxa de referência que está sendo protegida e 
designe a taxa de referência como o risco protegido para cada subgrupo. Por exemplo, em 
uma  relação  de  proteção  em  que  um  grupo  de  itens  é  protegido  para  mudanças  em  uma 
referência  de  taxa  de  juros  sujeita  a  reforma  da  taxa  de  juros  de  referência,  os  fluxos  de 
caixa protegidos ou o valor justo de alguns itens do grupo poderiam ser alterados para fazer 
referência  a  uma  taxa  de referência  alternativa  antes  de  outros  itens  no  grupo  serem 
alterados.  Neste  exemplo,  ao  aplicar  o  item  6.9.1,  a  entidade  designa  a  taxa  de  referência 
alternativa  como  o  risco  protegido  para  esse  subgrupo  relevante  de  itens  cobertos.  A 
entidade continua a designar a taxa de juros de referência existente como o risco protegido 
para  o  outro  subgrupo  de  itens  cobertos  até  os  fluxos  de  caixa  protegidos  ou  valor  justo 
desses  itens  serem  alterados  para  referenciar  a  taxa  de  referência  alternativa  ou  os  itens 
expiram  e  são  substituídos  por  itens  cobertos  que  fazem  referência  à  taxa  de  referência 
alternativa. 
6.9.10  A  entidade  deve avaliar  separadamente  se  cada  subgrupo  atende  aos  requisitos  do 
item  6.6.1  para  ser  um  item  protegido  elegível. Caso  existam  subgrupo  deixar  de  atender 
aos  requisitos  do  item  6.6.1,  a  entidade  deve  descontinuar  a  contabilidade  de  hedge 
prospectivamente  para  a  relação  de  proteção  em  seu  por  inteiro. A  entidade  também  deve 

 
 
aplicar  os  requisitos  dos  itens  6.5.8  e  6.5.11  para  contabilizar  a  ineficácia  relacionada  à 
relação de proteção em sua totalidade 
Designação de componentes de risco 
6.9.11  Uma  taxa  de  referência  alternativa  designada  como  um  componente  de  risco  não 
especificado  contratualmente  que  não  é  identificável  separadamente  (ver  itens  6.3.7(a)  e 
B6.3.8) na data em que for designada será considerada como tendo cumprido este requisito 
nessa  data,  se,  e  somente  se,  a  entidade  razoavelmente  espera  que  a  taxa  de  referência 
alternativa será identificada separadamente dentro de 24 meses. O período de 24 meses se 
aplica  separadamente  a  cada  taxa  de  referência  alternativa  e  começa  a  partir  da  data  em 
que a entidade designa a taxa de referência alternativa como um componente de risco não 
especificado contratualmente pela primeira vez (isto é, o período de 24 meses aplica-se taxa 
por taxa). 
6.9.12  Se  subsequentemente  a  entidade  razoavelmente  espera  que  a  taxa  de  referência 
alternativa  não  será  identificável  separadamente  dentro  de  24  meses  a  partir  da  data  em 
que  entidade  o  designou  como  um  componente  de  risco  contratualmente  não  especificado 
pela  primeira  vez,  a  entidade  deve  cessar  a  aplicação  do  requisito  do  item  6.9.11  a  essa 
taxa  de  referência  alternativa  e  descontinuar  a  contabilidade  de hedge prospectivamente  a 
partir  da  data  dessa  reavaliação  para  todas  as  relações  de  proteção  em  que  a  taxa  de 
referência   alternativa   foi   designada   como   componente   de   risco   não   especificado 
contratualmente. 
6.9.13  Além  dessas  relações  de  proteção  especificadas  no  item  6.9.1,  a  entidade  deve 
aplicar os requisitos dos itens 6.9.11 e 6.9.12 para novas relações de proteção em que uma 
taxa   de   referência   alternativa   é   designada   como   um   componente   de   risco   não 
contratualmente especificado (ver itens 6.3.7 (a) e B6.3.8) quando, devido à reforma da taxa 
de juros de referência, esse componente de risco não é identificável separadamente na data 
em que é designada.  
7.1.9 A  Revisão  NBC  09 aprovada  pelo  CFC em 11 de fevereiro de  2021,  alterou as NBC 
TG 48, NBC TG 38, NBC TG 40, NBC TG 11 e NBC TG 06, adicionou os itens 5.4.5 a 5.4.9, 
6.8.13, Seção 6.9 e itens 7.2.43 a 7.2.46.  
A  vigência  desta  Revisão  será  estabelecida  pelos  órgãos  reguladores  que  a  aprovarem, 
sendo que para o pleno atendimento às normas internacionais de contabilidade, a entidade 
deve aplicar esta revisão para períodos anuais com início em ou após 1º de janeiro de 2021. 
Transição para a Reforma da Taxa de Juros de Referência - Fase 2 
7.2.43 A entidade deve aplicar as alterações introduzidas pela Reforma da Taxa de Juros de 
Referência - Fase  2 retrospectivamente  de  acordo  com a NBC  TG  23,  exceto  conforme 
especificado nos itens 7.2.44 a 7.2.46. 
7.2.44 A entidade deve designar uma nova relação de proteção (por exemplo, como descrito 
no item 6.9.13) apenas prospectivamente (ou seja, a entidade é proibida designar uma nova 
relação  de  contabilidade  de  hedge  em  períodos  anteriores).  No  entanto,  a  entidade  deve 

 
 
restabelecer  uma  relação  de  cobertura  descontinuada  se,  e  somente  se,  essas  condições 
forem atendidas: 
(a)  a  entidade  havia  descontinuado  essa  relação  de  proteção  exclusivamente  devido  a 
mudanças exigidas pela reforma da taxa de juros de referência e não teria sido necessário 
interromper essa relação de proteção se essas alterações tivessem sido aplicadas naquele 
momento; e 
(b)  no  início  do  período  das  demonstrações  contábeis  em  que  a  entidade  aplica  pela 
primeira  vez  essas  alterações  (data  de  aplicação  inicial  dessas  alterações),  essa  relação 
de  proteção  descontinuada  atende  aos  critérios  de  qualificação  para  contabilidade  de 
hedge (depois de levar em consideração essas alterações). 
7.2.45  Se,  ao  aplicar  o  item  7.2.44,  a  entidade  restabelece  uma  relação  de  proteção 
descontinuada,  a  entidade  deve  consideraras  referências  nos  itens  6.9.11  e  6.9.12  até  a 
data  em  que  a  taxa  de  referência  alternativa  é  designada  como  componente  de  risco  não 
especificado  contratualmente  pela  primeira  vez,  referindo-se  à  data  de  aplicação  inicial 
dessas  alterações  (ou  seja,  o  período  de  24  meses  para  aquela  taxa  de  referência 
alternativa  designada  como  um  componente  de  risco  não  identificada  especificação  não 
estabelecida   contratualmente   começa   a   partir   da   data   de   aplicação   inicial   destes 
alterações). 
7.2.46 A entidade não é obrigada a reapresentar períodos anteriores para refletir a aplicação 
dessas alterações. A entidade pode reapresentar períodos anteriores se, e somente se, for 
possível  sem  o  uso  de  retrospectiva(hindsight).  Se  a  entidade  não  reapresentar  períodos 
anteriores, a entidade deve reconhecer qualquer diferença entre o valor contábil anterior e o 
valor contábil no início do período que inclui a data de aplicação inicial destas alterações no 
saldo  de  abertura  dos  lucros  acumulados  (ou  outro  componente  do  patrimônio  líquido, 
conforme  apropriado)  do  período  de  relatório  anual  que  inclui  a  data  de  início  aplicação 
destas alterações. 
 
2. Altera  o  item  102M,  inclui  os  itens  de  102O  a  102Z3  e  de  108H  a  108K,  inclui  título 
antes  do  item  102P  e  inclui  subtítulos  antes  dos  itens  102P,  102V,  102Y  e  102Z1 na 
NBC  TG  38 (R3) – Instrumentos  Financeiros:  Reconhecimento  e  Mensuração,  que 
passam a vigorar com as seguintes redações: 
 
102M.  A  entidade  deve  cessar,  prospectivamente,  de  aplicar  o  item  102G  à  relação  de 
proteção no que ocorrer primeiro entre: 
(a)  quando  a  incerteza  decorrente  da  reforma  da  taxa  de  juros  de  referência  não  estiver 
mais presente com relação ao risco protegido e ao momento e ao valor dos fluxos de caixa 
baseados na taxa de juros de referência do item protegido e do instrumento de hedge; e 
(b) quando a relação de proteção à qual a exceção é aplicada for descontinuada. 
102O.  A  entidade  deve  deixar  de  aplicar  prospectivamente  os  itens  102H  e  102I  no  que 
ocorrer primeiro entre: 

 
 
(a) quando as mudanças exigidas pela reforma da taxa de juros de referência forem feitas 
para a porção de risco não especificada contratualmente aplicando o item 102P; ou 
(b)  quando  a  relação  de  proteção  em  que  a  porção  designada  de  risco  não  especificada 
contratualmente for descontinuada. 
Exceções   temporárias   adicionais   decorrentes   de   reforma   de   taxa   de   juros   de 
referência 
Contabilidade de hedge 
102P.Como  e  quando  os  requisitos  dos  itens  102D  a  102I  cessarem  de  se  aplicar  a  uma 
relação  de  proteção  (ver  itens  102J  a  102O),  a  entidade  deve  alterar  a  designação  formal 
dessa relação de proteção, conforme documentado anteriormente para refletir as mudanças 
exigidas pela reforma da taxa de juros de referência, ou seja, as mudanças são consistentes 
com  os requisitos  dos  itens  5.4.6  a  5.4.8  da  NBC  TG 48.  Neste  contexto,  a  designação  de 
hedge deve ser alterada apenas para tornar uma ou mais dessas mudanças: 
(a)    designando    uma    taxa    de    referência    alternativa    (contratualmente    ou    não 
contratualmente especificado) como um risco coberto; 
(b)  alterar  a  descrição  do  item  coberto,  incluindo  a  descrição  da  parcela  designada  dos 
fluxos de caixa ou valor justo sendo coberto; 
(c) alterar a descrição do instrumento de cobertura; ou  
(d) alterar a descrição de como a entidade avaliará a efetividade do hedge. 
102Q. A entidade também deve aplicar o requisito do item 102P (c) se estas três condições 
forem atendidas: 
(a)  a  entidade  faz  uma alteração  exigida  pela  reforma  da  taxa  de  juros  de  referência 
usando  uma  abordagem  diferente  de  mudar  a  base  para  determinar  os  fluxos  de  caixa 
contratuais do instrumento de hedge (conforme descrito no item 5.4.6 da NBC TG 48); 
(b) o instrumento de cobertura original não é desreconhecido; e  
(c)   a   abordagem   escolhida   é   economicamente   equivalente   a   mudar   a   base   para 
determinação   dos   fluxos   de   caixa   contratuais   do   instrumento   de   cobertura   original 
(conforme descrito nos itens 5.4.7 e 5.4.8 da NBC TG 48). 
102R.Os  requisitos  dos  itens  102D  a  102I  podem  cessar  de  serem  aplicados  diferentes 
vezes. Portanto, aplicando o item 102P, a entidade pode ser obrigada a alterar a designação 
formal de seus relacionamentos de hedge em momentos diferentes, ou pode ser necessário 
alterar  a  designação  formal  de  uma  relação  de  proteção  mais  de  uma  vez.  Quando,  e 
somente quando, tal mudança for feita na designação de proteção (hedge), a entidade deve 
aplicar  os  itens  102V  a 102Z2,  conforme  aplicável.  A  entidade também deve  aplicar o  item 
89  (para  um hedge de  valor  justo)  ou  o  item  96  (para  um hedge de  fluxo  de  caixa)  para 
reconhecer  quaisquer  mudanças  no  valor  justo  do  item  protegido  ou  o  instrumento  de 
proteção. 

 
 
102S.A  entidade  deve  alterar  uma  relação  de  proteção  conforme  exigido no  item  102P  no 
final  do  período  de  relatório  durante  o  qual  uma  mudança  exigida  pela  reforma  da  taxa  de 
juros  de  referência  é  feita  para  o  risco  coberto,  item  coberto  ou  instrumento  de  cobertura. 
Para  evitar  dúvidas,  tal  alteração  na  designação  formal  de uma  relação  de  proteção  não 
constitui  nem  a  descontinuação  da  relação  de  proteção  nem  a  designação  de  uma  nova 
relação de proteção. 
102T.Se alterações forem feitas além das alterações exigidas pela reforma da taxa de juros 
de  referência  para  o  ativo  financeiro  ou  passivo  financeiro  designado  em  uma  relação  de 
proteção (conforme descrito nos itens 5.4.6 a 5.4.8 da NBC TG 48) ou para a designação da 
relação de proteção (conforme exigido pelo item 102P), a entidade deve primeiro aplicar os 
requisitos  aplicáveis  nesta  Norma para  determinar  se  essas  mudanças  adicionais  resultam 
na  descontinuação  da  contabilidade  de hedge.  Se  as  mudanças  adicionais  não  resultarem 
na descontinuação da contabilidade de hedge, a entidade deve alterar a designação formal 
da relação de proteção conforme especificado no item 102P. 
 102U.Os  itens  102V  a  102Z3  fornecem  exceções  aos  requisitos  especificados  apenas 
nesses itens. A entidade deve aplicar todos os outros requisitos de contabilidade de hedge 
nesta  Norma,  incluindo  os  critérios  de  qualificação  do  item  88,  para  relações  de  cobertura 
que foram diretamente afetadas pela reforma da taxa de juros de referência. 
Contabilização de relacionamentos de cobertura qualificados 
Avaliação retrospectiva de efetividade 
102V.Com a finalidade de avaliar a efetividade retrospectiva de uma relação de proteção em 
uma  base  cumulativa  aplicando  o  item  88  (e),  e  apenas  para  essa  finalidade,  a  entidade 
pode optar por redefinir para zero as alterações cumulativas de valor justo do item coberto e 
do  instrumento  de  cobertura  quando  cessar  a  aplicação  do  item  102G,  conforme  exigido 
pelo  item  102M.  Essa  escolha  é  feita  separadamente  para  cada  relação  de  proteção  (ou 
seja, em uma base de relacionamento de proteção individual). 
Hedges de fluxo de caixa 
102W.Para efeitos de aplicação do item 97, no ponto em que a entidade altera a descrição 
de  um  item  coberto  conforme  exigido  no  item  102P  (b),  o  ganho  ou  perda  acumulado  em 
outros  resultados  abrangente  será  considerado  com  base  na  taxa  de  referência  alternativa 
na qual os fluxos de caixa futuro coberto são determinados. 
102X.Para  uma  relação  de  proteção  descontinuada,  quando  a  taxa  de  juros  de  referência 
em que os fluxos de caixa futuros cobertos foram baseados é alterado conforme exigido por 
reforma  da  taxa  de  juros de  referência,  para  fins  de  aplicação  do  item  101  (c)  a  fim  de 
determinar  se  os  fluxos  de  caixa  futuros  protegidos  são  esperados  para  ocorrer,  o  valor 
acumulado  em  outros  resultados  abrangentes  para  aquela  relação  de  proteção  será 
considerada  baseada  na  taxa  de  referência  alternativa  na  qual  os  fluxos  de  caixa  futuros 
cobertos serão baseados. 
Grupos de itens 

 
 
102Y.Quando  a  entidade  aplica  o  item  102P  a  grupos  de  itens  designados  como  itens 
protegidos em um hedge de valor justo ou hedge de fluxo de caixa, a entidade deve alocar 
os  itens  protegidos  para  subgrupos  com  base  na  taxa  de  referência  que  está  sendo 
protegida e designar a taxa de referência como o risco protegido para cada subgrupo. Para 
por  exemplo,  em  uma  relação  de  proteção  em  que  um  grupo  de  itens é  coberto  para 
mudanças  em  uma  taxa  de  juros  de  referência  sujeitas  a  reforma  da  taxa  de  juros  de 
referência, os fluxos de caixa protegidos ou o valor justo de alguns itens do grupo podem ser 
alterados para fazer referência a uma taxa de referência alternativa antes de outros itens do 
grupo  serem  alterados. Nesse  exemplo,  ao  aplicar  o  item  102P,  a  entidade  designa  a  taxa 
de  referência  alternativa  como  o  risco  coberto  para  esse  subgrupo  relevante  de  itens 
cobertos.  A  entidade  continua  a  designar  a  taxa  de  juros  de  referência  existente  como  o 
risco  coberto  para  o  outro  subgrupo  de  itens  cobertos  até  os  fluxos  de  caixa  cobertos  ou 
valor justo desses itens serem alterados para referenciar a taxa de referência alternativa ou 
os  itens  expiram  e  são  substituídos  por  itens  cobertos  que  fazem  referência  à  taxa  de 
referência alternativa.  
102Z.A  entidade  deve  avaliar  separadamente  se  cada  subgrupo  atende  aos  requisitos  nos 
itens 78 e 83 para ser um item protegido elegível. Caso qualquer subgrupo deixar de cumprir 
os  requisitos  dos  itens  78  e  83,  a  entidade  deve  descontinuar  a  contabilidade  de  hedge 
prospectivamente  para  a  relação  de  proteção  na  sua  totalidade.  A  entidade  também  deve 
aplicar  os  requisitos  dos  itens  89  ou  96  para  reconhecer  a  inefetividade  relacionada  à 
relação de proteção por inteiro. 
Designando itens financeiros como itens cobertos 
102Z1.Uma   taxa   de   referência   alternativa   designada   como   parcela   do   risco   não 
contratualmente especificado que não é identificável separadamente (ver itens 81 e AG99F) 
na  data em  que  for  designada  será  considerada  como  tendo  cumprido  esse  requisito 
naquela data, se, e somente se, a entidade razoavelmente espera que a taxa de referência 
alternativa  será  identificável  separadamente  dentro  de  24  meses.  O  período  de  24  meses 
aplica-se  a  cada  taxa  de  referência  alternativa  separadamente  e  começa  na  data  que  a 
entidade  designa  a  taxa  de  referência  alternativa  como  uma  parcela  de  risco  da  taxa  não 
contratualmente  especificada  pela  primeira  vez  (ou  seja,  o  período  de  24  meses  se  aplica 
numa base taxa por taxa). 
102Z2.  Se  subsequentemente  a  entidade  tem  uma  razoável  expectativa  que  a  taxa  de 
referência  alternativa  não  será  identificável  separadamente  dentro  de  24  meses  a  partir  da 
data   em   que   entidade   designou-o   como   uma   parcela   de   risco   não   contratualmente 
especificada inicialmente, a entidade deve deixar de aplicar o requisito do item 102Z1 para 
aquela   taxa   de   referência   alternativa   e   descontinuar   a   contabilidade   de   hedge 
prospectivamente a partir da data dessa reavaliação para todas as relações de cobertura em 
que  a  taxa  de  referência  alternativa  foi  designada  como  uma  parcela  de  risco  não 
especificada contratualmente. 
102Z3.  Além  dessas  relações  de  proteção  especificadas  no  item  102P,  a  entidade  deve 
aplicar  os  requisitos  dos  itens  102Z1 e  102Z2  a  novas  relações  de  proteção  em  que  uma 
taxa de referência alternativa é designada como uma parcela do risco contratualmente não 

 
 
especificado  (ver  itens  81  e  AG99F)  quando,  por  causa  da  reforma  da  taxa  de  juros  de 
referência,  essa  parcela  de  risco não  é  identificável  separadamente  na  data  em  que  é 
designada. 
108H. A  Revisão  NBC  09,  aprovada  pelo  CFC em 11  de  fevereiro  de  2021,  alterou a  NBC 
TG 48, NBC  TG  38, NBC  TG  40, NBC  TG  11 e NBC  TG  06,  adicionou  os  itens  102O  a 
102Z3  e  108I  a  108K,  e  alterou o  item  102M.  A  vigência  desta  Revisão  será  estabelecida 
pelos órgãos reguladores que a aprovarem, sendo que para o pleno atendimento às normas 
internacionais  de  contabilidade,  a  entidade  deve  aplicar  esta  revisão  para  períodos  anuais 
com  início  em  ou  após 1º  de  janeiro  de  2021.  A  entidade  deve  aplicar  essas  alterações 
retrospectivamente  de  acordo  com a NBC  TG  23,  exceto  conforme  especificado  nos  itens 
108I a 108K. 
108I. A entidade deve designar uma nova relação de proteção (por exemplo, como descrito 
no item 102Z3) apenas prospectivamente (ou seja, a entidade é proibida designar uma nova 
relação como contabilidade de hedge em períodos anteriores). No entanto, a entidade deve 
restabelecer  uma  relação  de  proteção  descontinuada  se,  e  somente  se  essas  condições 
forem atendidas:  
(a)  a  entidade  havia  descontinuado  essa  relação  de  proteção  exclusivamente  devido  a 
mudanças exigidas pela reforma da taxa de juros de referência e a entidade não teria sido 
requerida  a  interromper  essa  relação  de  proteção  se  essas  alterações  tivessem  sido 
aplicadas naquele momento; e 
(b)  no  início  do  período  de  relatório  em  que  a  entidade  aplica  pela  primeira  vez  essas 
alterações   (data   de   aplicação   inicial   dessas   alterações),   essa  relação   de   proteção 
descontinuada atende aos critérios de qualificação para contabilidade de hedge (depois de 
levar em consideração essas alterações). 
108J.Se,   ao   aplicar   o   item   108I,   a   entidade   restabelece   uma   relação   de   proteção 
descontinuada,  a  entidade  deve  ler  as referências  nos  itens  102Z1  e  102Z2  até  a  data  em 
que a taxa de referência alternativa é designada como parcela de risco contratualmente não 
especificada pela primeira vez como referente à data de aplicação inicial dessas alterações 
(ou  seja,  o  período  de  24  meses  para  essa  taxa  de  referência  alternativa  designada  como 
uma parcela do risco não contratualmente especificada a partir na data de aplicação inicial 
das alterações).  
108K.  A  entidade  não  é  requerida  a  reapresentar  períodos  anteriores  para  refletir  a 
aplicação  dessas  alterações. A  entidade  pode  reapresentar  períodos  anteriores  se,  e 
somente  se,  for  possível  sem  o  uso  de  retrospectiva  (hindsight). Se  a  entidade  não 
reapresentar  períodos  anteriores,  a  entidade  deve  reconhecer  qualquer  diferença  entre  o 
valor  contábil  e  o  valor  contábil  no  início do  período  que  inclui  a  data  de  aplicação  inicial 
destas  alterações  nos  lucros  acumulados  de  abertura  (ou  outro  componente  do  patrimônio 
líquido,  conforme  apropriado)  do  período  de  relatório  anual  que  inclui  a  data  de  início 
aplicação destas alterações. 
 

 
 
3. Inclui os itens de 24I a 24J, 44GG e 44HH e inclui subtítulo antes do item 24I na NBC 
TG  40  (R3) – Instrumentos  Financeiros:  Evidenciação,  que  passam  a  vigorar  com  as 
seguintes redações: 
Divulgações adicionais relacionadas à reforma da taxa de juros de referência 
24I.  Para  permitir  que  os  usuários  das  demonstrações  contábeis  compreendam  o  efeito  da 
reforma  da  taxa  de  juros  de  referência  nos  instrumentos  financeiros  e  risco  estratégia  de 
gestão da entidade, a entidade deve divulgar informações sobre: 
(a)  a  natureza  e  extensão  dos  riscos  aos  quais  a  entidade  está  exposta  decorrentes  de 
instrumentos  financeiros  sujeitos  à  reforma  da  taxa  de  juros  de  referência,  e  como  a 
entidade gerencia esses riscos; e 
(b) o progresso da entidade na conclusão da transição para a taxa de referência alternativa 
e como a entidade está gerenciando a transição. 
24J. Para cumprir os objetivos do item 24I, a entidade deve divulgar: 
(a) como a entidade está gerenciando a transição para a taxa de referência alternativa, o 
seu  progresso na  data  de  relatório  e  os  riscos  aos  quais  é  exposto  decorrente  de 
instrumentos financeiros por causa da transição; 
(b) informação não agregada por taxa de referência de juros significativa sujeita à reforma 
da  taxa  de  juros  de  referência,  informações  quantitativas  sobre  instrumentos  financeiros 
que  ainda  precisam  fazer  a  transição  para  uma  taxa  de  referência  alternativa  no  final  do 
período das demonstrações contábeis, demonstrando separadamente: 
(i) ativos financeiros não derivativos; 
(ii) passivos financeiros não derivativos; e 
(iii) derivativos; e 
(c)  se  os  riscos  identificados  no  item  24J  (a)  resultaram  em  mudanças  a  estratégia  de 
gestão de risco de a entidade (ver item 22A), a descrição dessas mudanças. 
44GG.A Revisão NBC 09, aprovada pelo CFC em 11 de fevereiro de 2021, alterou as NBC 
TG 48, NBC TG 38, NBC TG 40, NBC TG 11 e NBC TG 06, adicionou os itens 24I a 24J e 
44HH.  A  entidade  deve  aplicar  essas  alterações  quando  aplicar  as  alterações  da  NBC  TG 
48, NBC TG 38, NBC TG 11 e NBC TG 06. 
44HH. No período das demonstrações em que a entidade aplica pela primeira vez a Revisãa 
NBC TG 17, a entidade não é obrigada a divulgar as informações que seriam de outra forma 
exigido pelo item 28 (f) da NBC TG 23. 
 
4. Inclui os itens de 20R, 20S, 50 e 51 e inclui subtítulo antes do item 20R na NBC TG 11  
(R2) – Contratos de Seguro, que passam a vigorar com as seguintes redações: 
Mudanças na base para determinar os fluxos de caixa contratuais como resultado da 
reforma da taxa de juros de referência 

 
 
20R.  Uma  seguradora  que  aplique  a  isenção  temporária  da  NBC  TG 48  deve  aplicar  os 
requisitos  nos  itens  5.4.6  a  5.4.9  da  NBC  TG 48  para  um  ativo  ou  passivo  financeiro  se,  e 
somente  se,  a  base  para  determinar  o  fluxo  de  caixa  contratual  desse  ativo  financeiro  ou 
passivo  financeiro  muda  como  resultado  da  reforma  da  taxa  de  juros  de  referência. Para 
este efeito, o termo “reforma da taxa de juros de referência” refere-se à reforma em todo o 
mercado de uma taxa de juros de referência como descrito no item 102B da NBC TG 38. 
20S.  Para  efeitos  de  aplicação  dos  itens  5.4.6  a  5.4.9  das  alterações  aos NBC  TG 48,  as 
referências ao item B5.4.5 da NBC TG 48 devem ser lidas como referências ao item AG7 da 
NBC TG 38. Referências aos itens 5.4.3 e B5.4.6 da NBC TG 48 devem ser lidas como se 
referindo ao item AG8 da NBC TG 38. 
50.A Revisão NBC 09, aprovada pelo CFC em 11 de fevereiro de 2021, alterou as NBC TG 
48, NBC TG 38, NBC TG 40, NBC TG 11 e NBC TG 06, adicionou os itens 20R e 20S e item 
51. A vigência desta Revisão será estabelecida pelos órgãos reguladores que a aprovarem, 
sendo que para o pleno atendimento às normas internacionais de contabilidade, a entidade 
deve aplicar esta revisão para períodos anuais com início em ou após 1º de janeiro de 2021.  
A entidade deve aplicar essas alterações retrospectivamente de acordo com a NBC TG 23, 
exceto conforme especificado no item 51. 
51.  A  entidade  não  é  obrigada  a  reapresentar  períodos  anteriores  para  refletir  a  aplicação 
dessas alterações. A entidade pode reapresentar períodos anteriores se, e somente se, for 
possível  sem  o  uso  de  retrospectiva(hindsight).  Se  a  entidade  não  reapresentar  períodos 
anteriores,  a  entidade  deve  reconhecer  qualquer  diferença  entre  o  valor  contábil  e  o  valor 
contábil  no  início  do  período  de  relatório  que  inclui  a  data  de  aplicação  inicial  dessas 
alterações nos lucros acumulados de abertura (ou outro componente do patrimônio líquido, 
conforme  apropriado)  do  período  de  relatório  anual  que  inclui  a  data  de  início  aplicação 
destas alterações. 
 
5. Inclui os itens de 104 a 106, C1B, C20C e C20D, inclui título antes do item 104 e inclui 
subtítulo  antes  do  item  C20C na NBC  TG  06 (R3) – Arrendamentos,  que  passam  a 
vigorar com as seguintes redações: 
Exceção temporária decorrente da Reforma da Taxa de Juros de Referência 
104. Um locatário deve aplicar os itens 105 e 106 a todas as modificações do arrendamento 
que  mudam  a  base  para  determinar  os  pagamentos  futuros  do  arrendamento  como 
resultado  da  reforma  da  taxa  de juros  de  referência  (ver  os  itens 5.4.6 e  5.4.8  da  NBC  TG 
48). Estes itens aplicam-se apenas a tais modificações de arrendamento. Para este efeito, o 
termo “reforma da taxa de juros de referência” refere-se  à  reforma  em  todo  o  mercado  da 
taxa de juros de referência, conforme descrito no item 6.8.2 da NBC TG 48. 
105.  Como  um  expediente  prático,  o  locatário  deve  aplicar  o  item  42  para  reconhecer  uma 
modificação  do  arrendamento  exigida  pela  reforma  da  taxa  de  juros  de  referência. Esse 
expediente prático aplica-se apenas a tais modificações. Para este efeito, uma modificação 
no  arrendamento  é  exigida  pela  reforma  da  taxa  de  juros  de  referência  se,  e  somente  se, 
ambas as seguintes condições forem atendidas: 

 
 
(a) a modificação é necessária como consequência direta da reforma da taxa de juros de 
referência; e 
(b)  a  nova  base  para  determinar os  pagamentos  do  arrendamento  é  economicamente 
equivalente à base anterior (ou seja, a base imediatamente anterior à modificação). 
106.  No  entanto,  se  modificações  de  locação  forem  feitas  além  dessas  modificações 
exigidas pela reforma da taxa de juros de referência, um locatário deve aplicar os requisitos 
aplicáveis nesta  Norma para  contabilizar  todas  as  modificações  de  arrendamento  feitas  ao 
mesmo tempo, incluindo aquelas exigidas por interesse taxa de reforma de referência. 
C1B. A  Revisão  NBC  09,  aprovada  pelo  CFC em 11  de  fevereiro  de  2021,  alterou as NBC 
TG 48, NBC TG 38, NBC TG 40, NBC TG 11 e NBC TG 06, adicionou os itens 104 a 106 e 
C20C e C20D. A vigência desta Revisão será estabelecida pelos órgãos reguladores que a 
aprovarem, sendo que para o pleno atendimento às normas internacionais de contabilidade, 
a  entidade  deve  aplicar  esta  revisão  para  períodos  anuais  com  início  em  ou  após  1º  de 
janeiro de 2021. 
Reforma da Taxa de Juros de Referência - Fase 2 
C20C. A entidade deve aplicar essas alterações retrospectivamente de acordo com NBC TG 
23, exceto conforme especificado no item C20D. 
C20D.A entidade não é obrigada a reapresentar períodos anteriores para refletir a aplicação 
dessas alterações. A entidade pode reapresentar períodos anteriores se, e somente se, for 
possível  sem  o  uso  de  retrospectiva  (hindsight).  Se  a  entidade  não  reapresentar  períodos 
anteriores,  a  entidade  deve  reconhecer  qualquer  diferença  entre  o  valor  contábil  e  o  valor 
contábil  no  início  do  período  que  inclui  a  data  de  aplicação  inicial  destas  alterações  nos 
lucros  acumulados  de  abertura  (ou  outro  componente  do  patrimônio  líquido,  conforme 
apropriado)  do  período  de  relatório  anual  que  inclui  a  data  de  início  aplicação  destas 
alterações. 
Essas alterações e inclusões serão incorporadas às NBC TG 06 (R3), NBC TG 11 (R2), NBC TG 
38 (R3), NBC TG 40 (R3) e NBC TG 48 e entram em vigor na data de sua publicação, produzindo 
seus efeitos a partir de 1º de janeiro de 2021. 
  
Brasília, 11 de fevereiro de 2021. 
 
 
Contador Zulmir Ivânio Breda 
Presidente 
 
Ata CFC n.º 1.072.
