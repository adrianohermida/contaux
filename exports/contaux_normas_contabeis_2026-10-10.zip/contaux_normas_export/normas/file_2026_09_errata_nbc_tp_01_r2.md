# errata NBC TP 01 R2

- Código externo: file:2026/09/errata_nbc_tp_01_r2.pdf
- Fonte: file:2026/09/errata_NBC_TP_01_R2.pdf
- URL fonte: https://cfc.org.br/wp-content/uploads/2026/09/errata_NBC_TP_01_R2.pdf
- Arquivo original: https://cfc.org.br/wp-content/uploads/2026/09/errata_NBC_TP_01_R2.pdf
- Nome do arquivo: errata_NBC_TP_01_R2.pdf
- Tags: Contábil, NBC, NBC TP, Errata
- Atualizado em: 2026-10-10 14:28:00.548118+00

## Resumo



## Texto integral extraído

CONSELHOFEDERALDECONTABILIDADE
AVISODERETIFICAÇÃO
RETIFICAÇÃODANBCTP01(R2)-PERÍCIACONTÁBIL
OConselhoFederaldeContabilidade(CFC)tornapúblicoapresenteretificaçãonaNBCTP
01(R2)-PeríciaContábil,publicadanoDiárioOficialdaUniãoem14demarçode2025,cabendo
aseguintealteração:
1.Alteraoitem58(e)naNBCTP01(R2)-PeríciaContábil,quepassaavigorarcoma
seguinteredação:
ONDESELÊ:
Estrutura
58.Olaudopericialcontábildeveconter,nomínimo,osseguintesitens:
[...]
(e)relatodasdiligências,reuniõestécnicasrealizadaseinformaçãoderecebimentopelo
peritonomeadodememoriais,planilhas,cálculos,informaçõesedemonstraçõesrecebidosdos
assistentestécnicosduranteaexecuçãodaperícia,conformeocaso,observadooitem22(e);
[...]
LEIA-SE:
Estrutura
58.Olaudopericialcontábildeveconter,nomínimo,osseguintesitens:
[...]
(e)relatodasdiligências,reuniõestécnicasrealizadaseinformaçãoderecebimentopelo
peritonomeadodememoriais,planilhas,cálculos,informaçõesedemonstraçõesrecebidosdos
assistentestécnicosduranteaexecuçãodaperícia,conformeocaso,observadooitem25(e);
[...]
ContadorJoaquimdeAlencarBezerraFilho
Presidente
Brasília,14desetembrode2026
