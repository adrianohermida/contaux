# Trabalhos de Compilação de Demonstrações Contábeis

- Código externo: 2019/revisaonbc03
- Fonte: CFC 2019/REVISAONBC03 — DOU 29/11/2019
- URL fonte: https://www2.cfc.org.br/sisweb/sre/detalhes_sre.aspx?Codigo=2019/REVISAONBC03&arquivo=REVISAONBC03.doc
- Arquivo original: https://www1.cfc.org.br/sisweb/SRE/docs/REVISAONBC03.pdf
- Nome do arquivo: REVISAONBC03.pdf
- Tags: Contábil, NBC
- Atualizado em: 2026-10-10 14:27:53.797016+00

## Resumo

Trabalhos de Compilação de Demonstrações Contábeis

## Texto integral extraído

NORMA  BRASILEIRA  DE  CONTABILIDADE,  REVISÃO  NBC 03,  DE 21 DE NOVEMBRO DE 
2019 
 
Aprova   a   Revisão   NBC 03,   que   altera   as 
seguintes  normas: NBC TA 200 (R1), NBC TA 
210  (R1),  NBC  TA  220  (R2), NBC TA  230  (R1), 
NBC TA  240  (R1), NBC  TA  250, NBC  TA  260 
(R2), NBC TA 450 (R1), NBC TA 500 (R1), NBC 
TA  580  (R1), NBC TA  700, NBC TA  701, NBC 
PA  01, NBC  PA  11, NBC  TR  2400, NBC T0 
3000, NBC T0 3402 e NBC TSC 4410. 
 
 
O CONSELHO FEDERAL DE CONTABILIDADE, no exercício de suas atribuições legais 
e  regimentais  e  com  fundamento  no  disposto  na  alínea  “f”  do  Art.  6º  do  Decreto-Lei  n.º 
9.295/1946,  alterado  pela  Lei  n.º  12.249/2010,  faz  saber  que  foi  aprovada  em  seu  Plenário  a 
Revisão NBC 03, que altera as seguintes normas: 
 
1.  Altera o item A42 da NBC TA 200 (R1) – Objetivos Gerais do Auditor Independente e a 
Condução  da  Auditoria  em  Conformidade  com  Normas  de  Auditoria, que  passa  a 
vigorar com a seguinte redação:  
 
A42. A  avaliação  dos  riscos  de  distorção  relevante  pode  ser  expressa  em  termos  quantitativos, 
como porcentagens, ou em termos não quantitativos. De qualquer forma, a necessidade de 
que  o  auditor  faça  avaliações  de  risco  apropriadas  é  mais  importante  do  que  as  diferentes 
abordagens  pelas  quais  elas  são  feitas.  As NBCs  TA geralmente  não  se  referem  ao  risco 
inerente e ao risco de controle separadamente, mas a uma avaliação combinada dos “riscos 
de distorção relevante”. Contudo, a NBC TA 540,  item  16, requer  a  avaliação  separada  do 
risco  inerente  e  do  risco  de  controle  para  fornecer  a  base  para  o  planejamento  e  a 
realização de procedimentos adicionais de auditoria para responder aos riscos avaliados de 
distorção relevante, incluindo riscos significativos, para as estimativas contábeis no nível de 
afirmações, de acordo com a NBC TA 330, item A7(b). Ao identificar e avaliar os riscos de 
distorção   relevante   para   classes   de   transações,   saldos   contábeis   ou   divulgações 
significativas  que  não  de  saldos  contábeis,  o  auditor  pode  fazer  avaliações  separadas  ou 
combinadas do risco inerente e do risco de controle, dependendo das técnicas de auditoria 
ou metodologias e considerações práticas. 
 
 
2.  Altera o item A26 na NBC TA 210 (R1) – Concordância com os Termos do Trabalho de 
Auditoria, que passa a vigorar com a seguinte redação: 
 
A26. Quando   relevante,   os   assuntos   a  seguir   também   podem   ser   incluídos   na   carta   de 
contratação de auditoria: 
• acordos relacionados com o envolvimento de outros auditores e especialistas em alguns 
aspectos da auditoria;  
• acordos  relacionados  com  o  envolvimento  de  auditores  internos  e  outros  membros  da 
entidade;  
• acordos  a  serem  feitos  com  o  auditor  independente  antecessor,  se  houver,  no  caso  de 
auditoria inicial;  
• referência  às  responsabilidades  do  auditor  nos  termos  de  leis,  de  regulamentos  ou  de 
requisitos  éticos  relevantes  e  sua  descrição,  que  tratam  da  comunicação  de  não 
conformidade  identificada  ou  suspeita  de  não  conformidade  com  leis  e  regulamentos  à 
autoridade competente externa à entidade;  
• qualquer  restrição  de  imputar  responsabilidade  ao  auditor  quando  essa  possibilidade 
existe;  
• referência a quaisquer acordos adicionais entre o auditor e a entidade;  
• quaisquer obrigações de fornecer papéis de trabalho da auditoria a outras partes. 

O Apêndice 1 apresenta exemplo de carta de contratação de auditoria.  
 
 
 
3.  Na NBC  TA  220  (R2) – Controle  de  Qualidade  da  Auditoria  de  Demonstrações 
Contábeis: 
(a) inclui o item A9; 
(b) em  razão  da  inclusão  do  item A9,  renumera  os  itens  de A9  a A35 existentes  para 
A10 a A36; 
(c) altera as referências relativas a esta Norma, nesta e em outras normas, quando for 
o caso, em razão da inclusão e da renumeração de itens. 
 
A9.  Leis, regulamentos ou requisitos éticos relevantes (ver, por exemplo, o item R320.8 da NBC 
PG 300) podem requerer, antes da aceitação do trabalho, que o auditor antecessor forneça 
informações  conhecidas  referentes  a  quaisquer  fatos  ou  circunstâncias  dos  quais,  no 
julgamento do auditor antecessor, o auditor precisa tomar conhecimento antes de decidir se 
aceita, ou  não, o  trabalho.  Nessas  circunstâncias,  o  auditor  antecessor  pode  ter  que, 
mediante  solicitação  do  auditor  sucessor  proposto,  fornecer  informações  referentes  à  não 
conformidade identificada ou suspeita de não conformidade com leis e regulamentos para o 
auditor  sucessor  proposto.  Por  exemplo,  quando  o  auditor  antecessor  tiver  se  retirado  do 
trabalho como resultado de não conformidade identificada ou suspeita de não conformidade 
com  leis  e  regulamentos,  o  auditor  antecessor,  mediante  solicitação  do  auditor  sucessor 
proposto,  deve  fornecer  todos  os  fatos  e  outras  informações  referentes  a  essa  não 
conformidade  das  quais,  na  opinião  do  auditor  antecessor,  o  auditor  sucessor  proposto 
precisa  ter  conhecimento  antes  de  decidir  se  aceita  a  indicação  de  auditoria  (ver,  por 
exemplo, os itens R360.22, 360.22A1, R360.23 e 36.23A1 da NBC PG 300).  
 
 
4.  Altera  os itens  A7  e A10  e  o  Apêndice da  NBC  TA  230  (R1) – Documentação  de 
Auditoria, que passam a vigorar com as seguintes redações: 
 
A7.  A  documentação  de  auditoria  fornece  evidências  de  que  a  auditoria  está  em  conformidade 
com  as  normas  de  auditoria.  Contudo,  não  é  necessário  nem  praticável  para  o  auditor 
documentar   todos   os   assuntos   considerados   ou   todos   os   julgamentos   profissionais 
exercidos  na  auditoria.  Além  disso,  é  desnecessário  o  auditor  documentar  separadamente 
(como  em  lista  de  verificação,  por  exemplo)  a  conformidade  em  assuntos  já  demonstrada 
por documentos incluídos no arquivo de auditoria. Por exemplo: 
• a existência de plano de auditoria adequadamente documentado demonstra que o auditor 
planejou a auditoria; 
• a  existência  de  carta  de  contratação  assinada  no  arquivo  de  auditoria  demonstra  que  o 
auditor  e  a  administração  concordaram  com  os  termos  do  trabalho  de  auditoria,  ou, 
quando apropriado, com os responsáveis pela governança; 
• o relatório do auditor que contém opinião com ressalva demonstra que o auditor cumpriu 
o  requisito  de  expressar  opinião  com  ressalva  sob  as  circunstâncias  especificadas  nas 
normas; 
• em relação às exigências que se aplicam geralmente ao longo de toda a auditoria, pode 
haver  várias  maneiras  pelas  quais  a  conformidade  a  elas  pode  ser  demonstrada  no 
arquivo de auditoria: 
o por   exemplo,   o   ceticismo   profissional   do   auditor   pode   não   ser   passível   de 
documentação,  todavia,  a  documentação  de  auditoria,  não  obstante,  pode  fornecer 
evidências do exercício do ceticismo profissional do auditor em conformidade com as 
normas  de  auditoria. Por  exemplo,  em  relação  às  estimativas  contábeis,  quando  a 
evidência  de  auditoria  obtida  inclui  evidência  que  tanto  corrobora  como  contradiz  as 
afirmações  da  administração,  a  documentação  do  modo  como  o  auditor  avaliou  essa 
evidência, incluindo os julgamentos profissionais exercidos na formação da conclusão 
quanto à suficiência e à adequação da evidência de auditoria obtida; 

o de  forma  similar,  o  fato  de  que  o  sócio  do  trabalho  assumiu  a  responsabilidade  pela 
direção,  supervisão  e  execução  da  auditoria  em  conformidade  com  as  normas  de 
auditoria pode ser evidenciado de várias maneiras na documentação de auditoria. Isso 
pode  incluir  a  documentação  do  envolvimento  tempestivo  do  sócio  do  trabalho  em 
aspectos da auditoria, tais como a participação nas discussões da equipe exigida pela 
NBC TA 315, item 10. 
 
A10.  Alguns  exemplos  de  circunstâncias  em  que,  em  conformidade  com  o  item  8,  é  apropriado 
preparar documentação de auditoria relativa à aplicação do julgamento profissional incluem, 
quando assuntos e julgamentos forem significativos: 
• a justificativa para a conclusão do auditor quando uma exigência determina que o auditor 
“deve considerar” certas informações ou fatores, e que a consideração é significativa no 
contexto do trabalho específico;  
• a base  para  a  conclusão  do  auditor  quanto  à  razoabilidade  das  áreas  de  julgamento 
subjetivo exercido pela administração; 
• a  base  para  a  avaliação  do  auditor  sobre  se  a  estimativa  contábil  e  as  divulgações 
relacionadas  são  razoáveis  no  contexto  da  estrutura  de  relatório  financeiro  aplicável  ou 
se apresentam distorção; 
• a base para as conclusões do auditor a respeito da autenticidade de documento quando 
investigações   adicionais   (tais   como   utilizar   de  forma  apropriada  um   perito  ou   de 
procedimentos  de  confirmação)  são  conduzidas  em  resposta  a  condições  identificadas 
durante  a  auditoria  que  levaram  o  auditor  a  acreditar  que  o  documento  pode  não  ser 
autêntico; 
• quando a NBC TA 701 – Comunicação dos Principais Assuntos de Auditoria no Relatório 
do  Auditor  Independente  se  aplica,  a  determinação  pelo  auditor  dos  principais  assuntos 
de auditoria ou de que não há nenhum principal assunto de auditoria a ser comunicado. 
 
 
Apêndice (ver item 1) 
 
Requerimentos específicos de documentação de auditoria em outras normas 
 
Este  apêndice  identifica  itens  em  outras  normas  de  auditoria  que  contenham  requerimentos 
específicos de documentação. A lista não substitui a consideração das exigências e da aplicação 
relacionada e de outros materiais explicativos nas normas. 
• NBC TA 210, itens 10 a 12; 
• NBC TA 220, itens 24 e 25; 
• NBC TA 240, itens 44 a 47; 
• NBC TA 250, item 29; 
• NBC TA 260, item 23; 
• NBC TA 300, item 12; 
• NBC TA 315, item 32; 
• NBC TA 320, item 14; 
• NBC TA 330, itens 28 a 30; 
• NBC TA 450, item 15; 
• NBC TA 540, item 39; 
• NBC TA 550, item 28; 
• NBC TA 600, item 50;  
• NBC TA 610, itens 36 e 37; 
• NBC TA 720, item 25. 
 
 
5.  Na NBC TA 240 (R1) – Responsabilidade do Auditor em Relação a Fraude, no Contexto 
da Auditoria de Demonstrações Contábeis: 
(a) inclui os itens 9, A6, e seus títulos, e A61; 

(b) em razão da inclusão do item 9, renumera os itens de 9 a 47 existentes para 10 a 
48; 
(c) em  razão  da  inclusão  dos itens A6  e  A61,  renumera  os  itens  de  A6  a  A59 
existentes para A7 a A60 e de A60 a A67 existentes para A62 a A69; 
(d) altera  os  itens  41,  42,  43,  44,  e  seu  título,  A48,  A67,  e  seu  título,  e  A68  após  a 
renumeração; 
(e) altera as referências relativas a esta Norma, nesta e em outras normas, quando for 
o caso, em razão da inclusão e da renumeração de itens. 
  
9.  O auditor pode ter responsabilidades adicionais nos termos de leis, de regulamentos ou de 
requisitos éticos relevantes com relação à não conformidade por parte da entidade com leis 
e  regulamentos,  incluindo  fraude,  que  podem  diferir  desta  Norma  ou  ir  além  desta  ou  de 
outras normas de auditoria, como, por exemplo (ver item A6):  
(a) resposta  à  não  conformidade  identificada  ou  suspeita  de  não  conformidade  com  leis  e 
regulamentos,  incluindo exigências  relacionadas com  comunicações  específicas  com  a 
administração  e  os  responsáveis  pela  governança,  avaliando  a  adequação  de  sua 
resposta à não conformidade e determinando se medidas adicionais são necessárias;  
(b) comunicação  da  não  conformidade  identificada  ou  suspeita  de  não  conformidade  com 
leis  e  regulamentos  a  outros  auditores  (por  exemplo,  na  auditoria  de  demonstrações 
contábeis de grupo); e  
(c) exigências  de  documentação  relacionada  com  a  não  conformidade  identificada  ou 
suspeita de não conformidade com leis e regulamentos.  
 
O cumprimento de quaisquer responsabilidades adicionais pode fornecer mais informações 
que  são  relevantes  para  o  trabalho  do  auditor  de  acordo  com  esta  e  outras  normas  de 
auditoria  (por  exemplo,  informações  relacionadas  com  a  integridade  da  administração  ou, 
quando apropriado, dos responsáveis pela governança).  
 
No  Brasil,  a  Resolução  CFC  n.º  1.530/2017  dispõe  sobre  os  procedimentos  a  serem 
observados  pelos  profissionais  e  organizações  contábeis,  quando  do  exercício  de  suas 
funções,  para  cumprimento  das  obrigações  previstas  na  Lei  n.º  9.613/1998  e  alterações 
posteriores,  que  dispõe  sobre  os  crimes  de  "lavagem"  ou  ocultação  de  bens,  direitos  e 
valores;  a  prevenção  da  utilização  do  sistema  financeiro  para  ilícitos  previstos  nessa  lei;  e 
cria o Conselho de Controle de Atividades Financeiras (Coaf). 
 
41.  Caso  o  auditor  tenha  identificado  uma  fraude  ou  obtido  informações  que  indiquem  a 
possibilidade  de  fraude,  o  auditor  deve  comunicar  esses  assuntos  tempestivamente,  salvo 
se proibido por lei ou regulamento, à pessoa de nível apropriado da administração que têm a 
responsabilidade primordial de prevenir e detectar fraude em assuntos relevantes no âmbito 
de suas responsabilidades (ver itens A61 e A62).  
 
42.  A menos que todos os responsáveis pela governança estejam envolvidos na administração 
da entidade, se o auditor tiver identificado ou suspeitar de fraude envolvendo: 
(a) a administração;  
(b) empregados com funções significativas no controle interno; ou  
(c) outros, cujas fraudes gerem distorção relevante nas demonstrações contábeis, 
auditor    deve    comunicar   tempestivamente    esses    assuntos    aos    responsáveis    pela 
governança. Caso o auditor suspeite de fraude envolvendo a administração, o auditor deve 
comunicar  essas  suspeitas  aos  responsáveis  pela  governança  e  discutir  com  eles  a 
natureza,  época  e  extensão  dos  procedimentos  de  auditoria  necessários  para  concluir  a 
auditoria. Essas comunicações aos responsáveis pela governança são necessárias a menos 
que a comunicação seja proibida por lei ou regulamento (ver itens A61 e de A63 a A65).  
 
43.  O auditor deve comunicar, salvo se proibido por lei ou regulamento, aos responsáveis pela 
governança quaisquer outros assuntos relacionados a fraudes que, no seu julgamento, são 
relevantes para suas responsabilidades (ver itens A61 e A66). 
 

Comunicação de fraude à autoridade competente externa à entidade 
 
44.  Caso  o  auditor  tenha  identificado  ou  suspeite  de  fraude,  ele  deve  determinar  se  leis, 
regulamentos ou requisitos éticos relevantes (ver itens de A67 a A69):  
(a) exigem que o auditor comunique à autoridade competente externa à entidade; 
(b) estabelecem   responsabilidades   segundo   as   quais   a   comunicação   à   autoridade 
competente externa à entidade pode ser apropriada nas circunstâncias.  
 
No Brasil, as regras de comunicação de não conformidade ou suspeita de não conformidade 
a  autoridades  externas  à  entidade  se  aplicam  somente  nos  casos  em  que  a  legislação 
expressamente estabelece dita obrigação, como ocorre, por exemplo, quanto à obrigação do 
auditor   de   comunicar   suspeita   ou   a   ocorrência   de   não   conformidade   com   leis   e 
regulamentos, conforme determinado por órgãos reguladores para determinados segmentos 
regulados,  tais  como  o  Banco  Central  do  Brasil  e  a  Comissão  de  Valores  Mobiliários,  ou 
ainda  em  decorrência  do  disposto  na  Resolução  CFC  n.º  1.530/2017,  que  dispõe  sobre  os 
procedimentos  a  serem  observados  pelos  profissionais  e  organizações  contábeis,  com 
relação  às  obrigações  previstas  na  Lei  n.º  9.613/1998  (sobre  "lavagem"  de  dinheiro).  Em 
todos    os    outros    casos,    o    auditor    continua    obrigado    ao    dever    profissional    de 
confidencialidade das informações do cliente (ver item A6 da NBC TA 250). 
 
Responsabilidade pela prevenção e detecção de fraude 
 
Responsabilidade do auditor (ver item 9) 
 
A6. Leis,  regulamentos  ou  requisitos  éticos  relevantes  podem  exigir  que  o  auditor  realize 
procedimentos adicionais e tome medidas adicionais. Por exemplo, as normas profissionais 
(NBCs  PG  100,  200  e  300  e NBC  PA  400  e  NBC  PO  900)  requerem  que  o  auditor  tome 
medidas para responder à não conformidade identificada ou suspeita de não conformidade 
com  leis  e  regulamentos  e  determine  se  medidas  adicionais  são  necessárias.  Essas 
medidas podem incluir a comunicação de não conformidade identificada ou suspeita de não 
conformidade  com  leis  e  regulamentos  a  outros  auditores  de  grupo,  incluindo  o  sócio  do 
trabalho  de  grupo,  auditores  de  componentes  ou  outros  auditores  que  estão  conduzindo  o 
trabalho em componentes de grupo para outros fins que não a auditoria das demonstrações 
contábeis  de  grupo  (ver  itens  R360.16,  360.16A1,  R360.17,  R360.18  e  360.18A1  da  NBC 
PG 300).  
 
No Brasil, o auditor deve também atentar para os requisitos específicos contidos na NBC PG 
01 – Código  de  Ética  Profissional  do  Contador  e  nas  normas  profissionais  (NBCs  PG  100, 
200 e 300 e NBC PA 400 e NBC PO 900). 
 
A48  A  revisão  retrospectiva  é  também  requerida  pela  NBC  TA  540,  item  9.  Essa  revisão  é 
conduzida  como  procedimento  de  avaliação  de  risco  para  obter  informação  em  relação  à 
efetividade das estimativas contábeis, evidência de auditoria sobre o desfecho, ou, quando 
aplicável,  a  sua  reestimativa subsequente  para  auxiliar  na  identificação  e  avaliação  dos 
riscos de distorção relevante no período corrente, e evidência de auditoria de assuntos, tais 
como   incerteza   da   estimativa,   que   pode   ser   requerida   para   ser   divulgada   nas 
demonstrações  contábeis. Por  questões  práticas,  a  revisão  pelo  auditor  dos  julgamentos  e 
premissas  por  tendenciosidade  que  poderiam  representar  riscos  de  distorção  relevante 
decorrente  de  fraude  de  acordo  com  esta  Norma  pode  ser  realizada  em  conjunto  com  a 
revisão requerida pela NBC TA 540. 
 
A61. Em algumas jurisdições, leis ou regulamentos podem restringir a comunicação do auditor de 
certos assuntos à administração e aos responsáveis pela governança. Leis ou regulamentos 
podem,  especificamente,  proibir  a  comunicação,  ou  outra  ação,  que  poderia  prejudicar  a 
investigação  por  parte  da  autoridade  competente  de  ato  ilícito,  real  ou  suspeito,  inclusive 
alertando   a   entidade,   por   exemplo,   quando   o   auditor   tiver   que   comunicar   a   não 
conformidade  identificada  ou  suspeita  de  não  conformidade  à  autoridade  competente, de 

acordo com a lei de prevenção de crime de lavagem de dinheiro. Nessas circunstâncias, as 
questões  consideradas  pelo  auditor  podem  ser  complexas  e  o  auditor  pode  considerar 
apropriada a obtenção de assessoria legal. O item 44 descreve o contexto no Brasil. 
 
Comunicação de fraude à autoridade competente externa à entidade (ver item 44) 
 
A67.  A  NBC  TA  250 – Consideração  de  Leis  e  Regulamentos  na  Auditoria  de  Demonstrações 
Contábeis, itens de A28 a A34, fornece orientação adicional com relação à determinação do 
auditor  quanto  a  se  a  comunicação  de  não  conformidade  identificada  ou  suspeita  de  não 
conformidade  com  leis  e  regulamentos  à  autoridade  competente  externa  à  entidade  é 
necessária   ou   apropriada   nas   circunstâncias,   incluindo   a   consideração   do   dever   de 
confidencialidade do auditor.  
 
A68.  A   determinação   requerida   pelo   item   44 pode   envolver   considerações   complexas   e 
julgamentos profissionais. Dessa forma, o auditor pode considerar uma consulta interna (por 
exemplo,  dentro  da  firma  ou  de  firma  da  rede)  ou,  de  forma  confidencial,  consultar  o 
regulador  ou  órgão  profissional  (a  menos  que  isso  seja  proibido  por  lei  ou  regulamento  ou 
que  viole  o  dever  de  confidencialidade).  O  auditor  pode  considerar  também  a  obtenção  de 
assessoria  legal  para  entender  as  suas  opções e  as  implicações  profissionais  ou  legais  de 
se tomar qualquer medida em particular.  
 
 
6. Altera os itens A8, A30 e A36, na NBC TA 250 – Consideração de Leis e Regulamentos 
na  Auditoria  de  Demonstrações  Contábeis,  que  passam  a  vigorar  com  as  seguintes 
redações: 
 
A8. As normas profissionais (NBCs PG 100, 200 e 300 e NBCs PA 400 e 900) requerem que o 
auditor  tome  medidas  para  responder  à  não  conformidade  identificada  ou  suspeita  de  não 
conformidade com leis e regulamentos e determine se medidas adicionais são necessárias. 
Essas medidas podem incluir a comunicação de não conformidade identificada ou suspeita 
de não conformidade com leis e regulamentos a outros auditores de grupo, incluindo o sócio 
do trabalho de grupo, auditores de componentes ou outros auditores que estão conduzindo 
o   trabalho   em   componentes   de   grupo   para   outros   fins   que   não   a   auditoria   das 
demonstrações  contábeis  de  grupo  (ver  itens  R360.16,  360.16A1,  R360.17,  R360.18  e 
360.18A1  da  NBC  PG  300). No  Brasil,  o  auditor  deve também atentar  para  os  requisitos 
específicos  contidos  na  NBC  PG  01 – Código  de  Ética  Profissional  do  Contador  e  nas 
normas profissionais (NBCs PG 100, 200 e 300 e NBC PA 400 e NBC PO 900). 
 
A30.  Em outros casos, os requisitos éticos relevantes podem requerer que o auditor determine se 
a comunicação de não conformidade identificada ou suspeita de não conformidade com leis 
e  regulamentos  à  autoridade  competente  externa  à  entidade  é  uma  ação  apropriada  nas 
circunstâncias. Por exemplo, as normas profissionais (NBCs PG 100, 200 e 300 e NBC PA 
400  e NBC  PO 900)  requerem  que  o  auditor  tome  medidas  para  responder  à  não 
conformidade  identificada  ou  suspeita  de  não  conformidade  com  leis  e  regulamentos  e 
determine  se  ações  adicionais  são  necessárias,  o  que  pode  incluir  a  comunicação  à 
autoridade competente externa à entidade (ver, por exemplo, os itens 360.21A1, 360.25A1, 
360.25A2,  360.25A3,  360.26  e  360.27  da  NBC  PG  200). As  normas  profissionais  explicam 
que  essa  comunicação  não  seria  considerada  uma  violação  do  dever  de  confidencialidade 
nos  seus  termos  (ver,  por  exemplo,  o  item  114.1A1  da  NBC  PG  100  e  o  item  R360.26  da 
NBC  PG  300). No  Brasil,  o  auditor  deve também atentar  para  os  requisitos  específicos 
contidos  na  NBC  PG  01 – Código  de  Ética  Profissional  do  Contador  e  nas  normas 
profissionais (NBCs PG 100, 200 e 300 e NBC PA 400 e NBC PO 900). O item A6 descreve 
o contexto no Brasil mais detalhadamente. 
 
A36.  Leis, regulamentos ou requisitos éticos relevantes podem estabelecer também exigências de 
documentação  adicional  com  relação  à  não  conformidade  identificada  ou  suspeita  de  não 
conformidade com leis e regulamentos (ver, por exemplo, o item R360.28 da NBC PG 300). 

No Brasil, o auditor deve também atentar para os requisitos específicos contidos na NBC PG 
01 – Código  de  Ética  Profissional  do  Contador  e  nas  normas  profissionais  (NBCs  PG  100, 
200 e 300 e NBC PA 400 e NBC PO 900). 
 
 
7.  Altera os itens 7, A19 e A20 e os Apêndices 1 e 2 da NBC TA 260 (R2) – Comunicação 
com  os  Responsáveis  pela  Governança,  que  passam  a  vigorar  com  as  seguintes 
redações: 
 
7.  Em algumas jurisdições, leis ou regulamentos podem restringir a comunicação do auditor de 
certos  assuntos  aos  responsáveis  pela  governança. Leis  ou  regulamentos  podem  proibir, 
especificamente,  a  comunicação  ou  outra  ação  que  possa  prejudicar  a  investigação  pela 
autoridade  competente  de  ato  ilegal,  real  ou  suspeito,  inclusive  alertando  a  entidade,  por 
exemplo, quando o auditor tiver que comunicar a não conformidade identificada ou suspeita 
de não conformidade com leis e regulamentos à autoridade competente de acordo com a lei 
de  prevenção  de  crime  de  lavagem  de  dinheiro. Nessas  circunstâncias,  as  questões 
consideradas  pelo  auditor  podem  ser  complexas  e  ele  pode  considerar  apropriada  a 
obtenção de assessoria legal. 
 
No  Brasil,  a  Resolução  CFC  n.º  1.530/2017  dispõe  sobre  os  procedimentos  a  serem 
observados  pelos  profissionais e  organizações  contábeis,  quando  do  exercício  de  suas 
funções,  para  cumprimento  das  obrigações  previstas  na  Lei  n.º  9.613/1998  e  alterações 
posteriores,  que  dispõe  sobre  os  crimes  de  "lavagem"  ou  ocultação  de  bens,  direitos  e 
valores;  a  prevenção  da  utilização  do  sistema  financeiro  para  ilícitos  previstos  nessa  lei;  e 
cria o Conselho de Controle de Atividades Financeiras (Coaf). 
 
A19.  As estruturas de relatório financeiro normalmente permitem que a entidade faça estimativas 
contábeis  e  julgamentos  sobre  políticas  contábeis  e divulgações  nas  demonstrações 
contábeis, como, por exemplo,  em relação  ao  uso  de premissas no  desenvolvimento  de 
estimativas  contábeis. Além  disso,  leis, regulamentos  ou  estruturas  de  relatório  financeiro 
podem   requerer   a divulgação  do   resumo   das   principais   políticas   contábeis   ou   fazer 
referência a “estimativas contábeis críticas” ou “políticas e  práticas contábeis críticas” para 
identificar  e  fornecer informações  adicionais  aos  usuários  sobre  os  julgamentos  mais 
difíceis, subjetivos    ou complexos    feitos    pela    administração    na    elaboração    das 
demonstrações contábeis. 
 
A20.  Como  resultado,  a  visão  do  auditor  sobre  os  aspectos  subjetivos  das  demonstrações 
contábeis  pode  ser,  particularmente,  relevante  para  os  responsáveis  pela  governança  no 
cumprimento  de  suas  responsabilidades  de  supervisão  sobre  o  processo  de  relatório 
financeiro.  Por  exemplo,  em  relação  aos  assuntos  descritos  no  item  A19,  os  responsáveis 
pela  governança  podem  ter  interesse nas  opiniões  do  auditor  sobre  o  grau  no  qual  a 
complexidade,  a  subjetividade  ou  outros  fatores  de  risco  inerente  afetam  a  seleção  ou  a 
aplicação  dos  métodos,  premissas  e  dados  utilizados  na  elaboração  de  estimativa  contábil 
significativa, bem como na avaliação do auditor, se a estimativa pontual da administração e 
as divulgações  relacionadas  nas  demonstrações  contábeis  são  razoáveis  no  contexto  da 
estrutura  de  relatório  financeiro  aplicável. A  comunicação  aberta  e  construtiva  sobre 
aspectos  qualitativos  significativos  das  práticas  contábeis  da  entidade  também  pode  incluir 
comentários  sobre  a  aceitabilidade  de  práticas  contábeis  significativas  e sobre a  qualidade 
das  divulgações. Quando  aplicável,  ela  pode  incluir  se  uma  prática  contábil  significativa  da 
entidade  relacionada  com  as  estimativas  contábeis  é  considerada  pelo  auditor  como  não 
sendo  a  mais  apropriada  para  as  circunstâncias  específicas  da  entidade, como,  por 
exemplo,  quando  um método  alternativo  aceitável  para  a  elaboração  da  estimativa  contábil 
seria,  no  julgamento  do  auditor,  mais  apropriado. O  Apêndice  2  identifica  assuntos  que 
podem ser incluídos nessa comunicação. 
 
Apêndice 1 (item 3) 

 
Requisitos  específicos  na  NBC  PA  01 – Controle  de  Qualidade  para  Firmas  (Pessoas 
Jurídicas  e  Físicas)  de  Auditores  Independentes  e  outras  normas  de  auditoria  que  se 
referem a comunicações com os responsáveis pela governança 
 
Este Apêndice  identifica  itens  na  NBC  PA  01  e em outras  normas  de  auditoria  que  exigem  a 
comunicação de assuntos específicos aos responsáveis pela governança.  A lista não substitui a 
consideração  dos  requisitos  e  a  correspondente  aplicação  e  outros  materiais  explicativos  nas 
normas de auditoria. 
 
• NBC PA 01 – Controle de Qualidade para Firmas (Pessoas Jurídicas e Físicas) de Auditores 
Independentes, item 30(a); 
• NBC TA 240 – Responsabilidade do Auditor em Relação a Fraude, no Contexto da Auditoria 
de Demonstrações Contábeis, itens 21, 38(c)(i) e 40 a 42; 
• NBC  TA  250 – Consideração  de  Leis  e  Regulamentos  na  Auditoria  de  Demonstrações 
Contábeis, itens 14, 19 e 22 a 24; 
• NBC TA 265 – Comunicação de Deficiências de Controle Interno, item 9; 
• NBC TA 450 – Avaliação das Distorções Identificadas durante a Auditoria, itens 12 e 13; 
• NBC TA 505 – Confirmações Externas, item 9; 
• NBC TA 510 – Trabalhos Iniciais – Saldos Iniciais, item 7; 
• NBC TA 540 – Auditoria de Estimativas Contábeis e Divulgações Relacionadas, item 38; 
• NBC TA 550 – Partes Relacionadas, item 27; 
• NBC TA 560 – Eventos Subsequentes, itens 7(b) e (c), 10(a), 13(b), 14(a) e 17; 
• NBC TA 570 – Continuidade Operacional, item 25; 
• NBC  TA  600 – Considerações  Especiais – Auditorias  de  Demonstrações  Contábeis  de 
Grupos, Incluindo o Trabalho dos Auditores dos Componentes, item 49; 
• NBC TA 610 – Utilização do Trabalho de Auditoria Interna, itens 20 e 31; 
• NBC TA 700 – Formação da Opinião e Emissão do Relatório do Auditor Independente sobre 
as Demonstrações Contábeis, item 46; 
• NBC  TA  701 – Comunicação  dos  Principais  Assuntos  de  Auditoria  no  Relatório  do  Auditor 
Independente, item 17; 
• NBC TA 705 – Modificações na Opinião do Auditor Independente, itens 12, 14, 23 e 30; 
• NBC  TA  706 – Parágrafos  de  Ênfase  e  Parágrafos  de  Outros  Assuntos  no  Relatório  do 
Auditor Independente, item 12; 
• NBC  TA  710 – Informações  Comparativas – Valores  Correspondentes  e  Demonstrações 
Contábeis Comparativas, item 18; 
• NBC  TA  720 – Responsabilidade  do  Auditor  em  Relação  a  Outras  Informações,  itens  17  a 
19. 
  
Apêndice 2 (itens 16(a), A19 e A20) 
 
Aspectos qualitativos de práticas contábeis 
 
A  comunicação  exigida  pelo  item  16(a)  e  discutida  nos  itens  A19  e  A20  pode  incluir  assuntos 
como: 
 
Políticas contábeis: 
 
• a    adequação    das    políticas    contábeis    às    circunstâncias    específicas    da    entidade, 
considerando  a  necessidade  de  equilibrar  o  custo  do  fornecimento  de  informações  com  o 
provável  benefício  a  usuários  das  demonstrações  contábeis  da  entidade.  No  caso  de  haver 
políticas  contábeis  alternativas  aceitáveis,  a  comunicação  pode  incluir  a  identificação  dos 
itens  das  demonstrações  contábeis  que  são  afetados  pela  escolha  de  políticas  contábeis 
significativas,   bem   como   informações   sobre   políticas   contábeis   usadas   por   entidades 
similares; 
• a  seleção  inicial  e  alterações  de  políticas  contábeis  significativas,  incluindo  a  aplicação  de 

novas  normas  contábeis.  A  comunicação  pode  incluir:  o  efeito  da  época  e  do  método  de 
adoção  da  alteração  de  política  contábil  sobre  os  lucros  atuais  e  futuros  da  entidade  e  a 
época da alteração de políticas contábeis em relação às novas normas contábeis esperadas; 
• o  efeito  de  políticas  contábeis  significativas  sobre  áreas  controversas  ou  emergentes  (ou 
específicas da indústria/setor, especialmente, quando há falta de orientação ou consenso); 
• o efeito da época das transações em relação ao período em que são registradas. 
 
Estimativas contábeis da auditoria e divulgações relacionadas 
 
O  Apêndice  2  da  NBC  TA  540  inclui  os  assuntos  que  o  auditor  pode  considerar  comunicar  com 
relação  aos  aspectos  qualitativos  significativos  das  práticas  contábeis  da  entidade  relacionadas 
com as estimativas contábeis e divulgações relacionadas. 
 
Divulgação nas demonstrações contábeis: 
 
• os   assuntos   envolvidos   e   os   correspondentes   julgamentos   feitos   na   elaboração   de 
divulgações  de  demonstrações  contábeis,  especialmente  críticas  (por exemplo,  divulgações 
relacionadas  a  reconhecimento  de  receita,  remuneração,  continuidade  do  negócio,  eventos 
subsequentes e contingências); 
• a  neutralidade  geral,  a  consistência  e  a  clareza  das  divulgações  nas  demonstrações 
contábeis. 
 
Assuntos relacionados: 
 
• o  possível  efeito  sobre  as  demonstrações  contábeis  de  riscos  significativos,  exposições  e 
incertezas, como litígio pendente, que são divulgados nas demonstrações contábeis; 
• a  extensão  em  que  as  demonstrações  contábeis  são  afetadas  por  transações  significativas 
que  estão  fora  do  curso  normal  dos  negócios  para  a  entidade  ou  que,  de  outra  forma, 
parecem ser não usuais. Essa comunicação pode destacar: 
o os valores não recorrentes reconhecidos durante o período; 
o a extensão em que essas transações são divulgadas separadamente nas demonstrações 
contábeis; 
o se  essas  transações  parecem  ter  sido  planejadas  com  a  finalidade  de  obter  tratamento 
contábil ou fiscal específico, ou com objetivo legal ou regulador específico; 
o se  a  forma  dessas  transações  parece  extremamente  complexa,  ou  quando  foi  feita  uma 
extensa consultoria sobre a estruturação da transação; 
o quando  a  administração  está  dando  mais  ênfase  à  necessidade  de  tratamento  contábil 
específico do que à razão econômica subjacente da transação; 
• os  fatores  que  afetam  os  valores  contábeis  de  ativos  e  passivos,  incluindo  as  bases  da 
entidade   para   determinar   a   vida   útil   econômica   de   bens   tangíveis   e   intangíveis.   A 
comunicação   pode   explicar   como   os   fatores   que   afetam   os   valores   contábeis   foram 
selecionados e como as seleções alternativas teriam afetado as demonstrações contábeis; 
• a correção seletiva de distorções, por exemplo, corrigir distorções cujo efeito é aumentar os 
lucros divulgados, mas, não, aqueles cujo efeito é diminuir os lucros divulgados. 
 
 
8.  Altera  os  itens  8  e A11  na  NBC TA  450  (R1) – Avaliação  das  Distorções  Identificadas 
durante a Auditoria, que passam a vigorar com as seguintes redações: 
 
8.  O  auditor  deve  comunicar, salvo  se  proibido  por  lei  ou  regulamento,  tempestivamente,  ao 
nível apropriado da administração, todas as distorções detectadas durante a auditoria (NBC 
TA  260 – Comunicação  com  os  Responsáveis  pela  Governança,  item  7). O  auditor  deve 
requerer que a administração corrija essas distorções (ver itens de A10 a A129).  
 
A11.  Em algumas jurisdições, leis ou regulamentos podem restringir a comunicação do auditor de 
certas  distorções  à  administração,  ou  outros,  dentro  da  entidade.  A  legislação  ou  a 
regulamentação  pode  proibir,  especificamente,  a  comunicação  ou  outra  ação  que  possa 

prejudicar a investigação por autoridade competente de ato ilegal, real ou suspeito, inclusive 
alertando   a   entidade,   por   exemplo,   quando   o   auditor   tiver   que   comunicar   a   não 
conformidade  identificada  ou  suspeita  de  não  conformidade  à  autoridade  competente  de 
acordo com a lei de prevenção de crime de lavagem de dinheiro. Nessas circunstâncias, as 
questões consideradas pelo auditor podem ser complexas e ele pode considerar apropriada 
a obtenção de assessoria legal.  
 
No  Brasil,  a  Resolução  CFC  n.º  1.530/2017  dispõe  sobre  os  procedimentos  a  serem 
observados  pelos  profissionais  e  organizações  contábeis,  quando  do  exercício  de  suas 
funções,  para  cumprimento  das  obrigações  previstas  na  Lei  n.º  9.613/1998  e  alterações 
posteriores,  que  dispõe  sobre  os  crimes  de  "lavagem"  ou  ocultação  de  bens,  direitos  e 
valores;  a  prevenção  da  utilização  do  sistema  financeiro  para  ilícitos  previstos  nessa  lei;  e 
cria o Conselho de Controle de Atividades Financeiras (Coaf). 
 
 
9.  Na NBC TA 500 (R1) – Evidência de Auditoria: 
(a) inclui os itens de A1 a A4 e de A38 a A44; 
(b) em  razão  da  inclusão  dos  itens  de  A1  a  A4,  renumera  os  itens  de A1  a A33 
existentes para A5 a A37; 
(c) em  razão  da  inclusão  dos  itens  de  A38  a  A44,  renumera  os  itens  de  A34 a  A57 
existentes para A45 a A68; 
(d) altera os itens 5, 7, A5, A10, A12, A13, A18, A30, A32, A34, A35, A46, A48, A55, A59 
após a renumeração; 
(e) altera as referências relativas a esta Norma, nesta e em outras normas, quando for 
o caso, em razão da inclusão e da renumeração de itens. 
   
5.  Para fins desta Norma, os termos a seguir têm os significados atribuídos abaixo: 
(a) Registros  contábeis compreendem  os  registros  de  lançamentos  contábeis  e  sua 
documentação-suporte  (cheques  e  registros  de  transferências  eletrônicas  de  fundos, 
faturas,  contratos);  os  livros  diário,  razões  geral  e  auxiliares; as  reclassificações  nas 
demonstrações  contábeis  não  refletidas  no  diário; e  as  planilhas  de  trabalho,  que 
suportem as alocações de custos, cálculos, conciliações e divulgações. 
(b) Adequação  da  evidência  de  auditoria é  a  medida  da  qualidade  da  evidência  de 
auditoria, isto é, a sua relevância e confiabilidade para suportar as conclusões em que 
se fundamenta a opinião do auditor. 
(c)  Evidência de auditoria compreende as informações utilizadas pelo auditor para chegar 
às conclusões em que se fundamentam a sua opinião. A evidência de auditoria inclui as 
informações   contidas   nos   registros   contábeis   que   suportam   as   demonstrações 
contábeis e informações obtidas de outras fontes. 
(d)  Fonte  de  informação  externa é  um  indivíduo  ou  organização  externa  que  fornece 
informação que foi utilizada pela entidade na elaboração das demonstrações contábeis, 
ou  que  foi  obtida  pelo  auditor  como  evidência  de  auditoria,  quando  tal  informação  é 
apropriada para utilização por diversos usuários. Quando a informação que foi fornecida 
por  indivíduo  ou  organização  agindo  como  especialista  da  administração,  prestador  de 
serviço (NBC  TA  402,  item  8),  ou  especialista  do  auditor (NBC  TA  620,  item  6),  o 
indivíduo ou a organização não é considerado fonte de informação externa em relação 
àquela informação (ver itens de A1 a A3). 
(e)  Especialista da administração é uma pessoa ou organização com especialização em 
uma   área,   que   não Contabilidade   ou Auditoria,   cujo   trabalho   naquela   área   de 
especialização    é    utilizado    pela    entidade    para    ajudá-la    na    elaboração    das 
demonstrações contábeis. 

(f) Suficiência  da  evidência  de  auditoria é  a  medida  da  quantidade  da  evidência  de 
auditoria.  A  quantidade  necessária  da  evidência  de  auditoria  é  afetada  pela  avaliação 
do  auditor  dos  riscos  de  distorção  relevante  e também  pela  qualidade  da  evidência  de 
auditoria. 
 
7.  Ao  estabelecer   e   executar   procedimentos  de   auditoria,   o   auditor   deve   considerar   a 
relevância  e a confiabilidade  das  informações  a  serem  utilizadas  como  evidência  de 
auditoria, incluindo informações obtidas de fonte de informações externa (ver itens de A30 a 
A44). 
 
Fonte de informações externa (ver item 5(d)) 
 
A1. As  fontes  de  informações  externas  podem  incluir  serviços  de  precificação,  organizações 
governamentais,   bancos   centrais   ou   bolsas   de   valores   reconhecidas.   Exemplos   de 
informações que podem ser obtidas de fontes de informações externas incluem: 
 preços e dados relacionados com precificação; 
 dados  macroeconômicos,  como  taxas  de  desemprego  históricas  e  projetadas  e  taxas 
de crescimento econômico, ou dados de censos; 
 dados históricos de crédito; 
 dados  específicos  de  um  setor, como,  por  exemplo,  índice  de  custos  de  recuperação 
para    determinadas    indústrias    extrativistas,    ou    informações    de    audiência    ou 
classificações   utilizadas   para   determinar   receita   de   publicidade   no   setor   de 
entretenimento; e 
 tábuas de mortalidade utilizadas para determinar os passivos nos setores de seguro de 
vida e de pensão. 
 
A2. É mais provável que um conjunto específico de informações seja adequado para o uso por 
grande número de usuários e menos provável que ele esteja sujeito à influência de qualquer 
usuário específico se o indivíduo externo ou a organização externa o fornece para o público 
de  graça,  ou  o  disponibiliza  para  vasta  gama  de  usuários  em  troca  do  pagamento  de  taxa. 
Um julgamento pode ser necessário para determinar se as informações são adequadas para 
o  uso  por  grande  número  de  usuários,  levando-se  em  consideração  a  capacidade  da 
entidade de influenciar a fonte de informações externa.  
 
A3. Um indivíduo externo ou organização externa não pode, com relação a qualquer conjunto de 
informações  específico,  ser  fonte  de  informações  externa  e  especialista  da  administração, 
ou organização de serviços ou especialista do auditor ao mesmo tempo. 
 
A4. Entretanto,  um  indivíduo  externo  ou  organização  externa  pode,  por  exemplo,  atuar  como 
especialista  da  administração  enquanto  fornece  um  conjunto  de  informações  específico, 
mas  pode  atuar  como  fonte  de  informações  externa  quando  fornece  um  conjunto  de 
informações  diferente.  Em  algumas  circunstâncias,  o  julgamento  profissional  pode  ser 
necessário  para  determinar  se  o  indivíduo  externo  ou a organização  externa  está  atuando 
como  fonte  de  informações  externa  ou  como  especialista  da  administração  com  relação  a 
um  conjunto  de  informações  específico.  Em  outras  circunstâncias,  a  distinção  pode  ser 
clara. Por exemplo: 
 um  indivíduo  externo  ou  organização  externa  pode  fornecer  informações  sobre  preços 
de  imóveis  que  são  adequadas  para  o  uso  por grande  número  de  usuários, como,  por 
exemplo, informações disponibilizadas de forma geral para uma região geográfica, e ser 
determinado como sendo fonte de informações externa com relação a esse conjunto de 
informações.  A  mesma  organização  externa  também  pode  atuar  como  especialista  da 
administração ou do auditor no fornecimento de avaliações comissionadas com relação 
à carteira de imóveis da entidade elaborada sob medida para os fatos e circunstâncias 
da entidade; 
 algumas  organizações  atuariais  publicam  tábuas  de  mortalidade  para  uso  geral, que, 
quando utilizadas pela entidade, seriam geralmente consideradas informações de fonte 
de  informações  externa.  A  mesma  organização  atuarial  também  pode  ser  especialista 

da administração com relação a informações diferentes elaboradas sob medida para as 
circunstâncias  específicas  da  entidade  para  auxiliar  a  administração  a  determinar  o 
passivo de pensão para diversos planos de pensão da entidade; 
 um  indivíduo  externo  ou  organização  externa  pode  ter  especialização  na  aplicação  de 
modelos para estimar o valor justo de títulos e valores mobiliários para os quais não há 
mercado  observável.  Se  o  indivíduo  externo  ou  a  organização  externa  aplica  essa 
especialização  na  elaboração  de  estimativa  especificamente  para  a  entidade  e  esse 
trabalho   é   utilizado   pela   administração   na   elaboração   de   suas   demonstrações 
contábeis,   é   provável   que   o   indivíduo   externo   ou   a   organização   externa   seja 
especialista  da  administração  com  relação  a  essas  informações.  Se,  por  outro  lado,  o 
indivíduo  externo  ou  a  organização  externa  simplesmente  fornece,  para  o  público, 
preços  ou  dados  relacionados  com  preços  referentes  a  transações  particulares,  e  a 
entidade  usa  essas  informações  em  seus  próprios  métodos  de  estimativa,  é  provável 
que  o  indivíduo  externo  ou  a  organização  externa  seja  fonte  de  informações  externa 
com relação a essas informações; 
 um  indivíduo  externo  ou  organização  externa  pode  publicar  informações  adequadas 
para  grande  número  de  usuários  sobre  os  riscos  ou  as  condições  de  um  setor.  Se 
utilizadas  pela  entidade  na  elaboração  das  divulgações  de  risco  (por  exemplo,  em 
conformidade  com  a  NBC  TG  40 – Instrumentos  Financeiros:  Evidenciação),  essas 
informações seriam geralmente consideradas informações de fonte externa. Entretanto, 
se  os  mesmos  tipos  de  informações  tiverem  sido  especificamente  comissionados  pela 
entidade  para  utilizar  a  sua  especialização  para  desenvolver  informações  sobre  esses 
riscos,  sob  medida  para  as  circunstâncias  da  entidade,  é  provável  que  o  indivíduo 
externo ou a organização externa esteja atuando como especialista da administração; 
 um  indivíduo  externo  ou  organização  externa  pode  aplicar  a  sua  especialização  no 
fornecimento de informações sobre as tendências atuais e futuras do mercado, o que as 
torna  disponíveis  para  grande  número  de  usuários  e  adequadas  para  serem  utilizadas 
por  eles.  Se  elas  forem  utilizadas  pela  entidade  para  auxiliar  a  tomada  de  decisões 
sobre premissas a serem utilizadas na elaboração das estimativas contábeis, é provável 
que  essas  informações  sejam  consideradas  informações  de  fonte  externa.  Se  os 
mesmos tipos de informações tiverem sido comissionados pela entidade para tratar de 
tendências   atuais   e   futuras   do   mercado   relevantes   para   fatos   e   circunstâncias 
específicas  da  entidade,  é  provável  que  o  indivíduo  externo  ou  a  organização  externa 
esteja atuando como especialista da administração. 
 
A5.  A  evidência  de  auditoria  é  necessária  para  fundamentar  a  opinião  e  o  relatório  do  auditor. 
Ela  tem  natureza  cumulativa  e  é  obtida  principalmente  a  partir  dos  procedimentos  de 
auditoria   realizados  durante   o  curso   do   trabalho.   Contudo,   ela   também   pode   incluir 
informações  obtidas  de  outras  fontes,  como  auditorias  anteriores  (contanto  que  o  auditor 
tenha  determinado  se  ocorreram  mudanças  desde  a  auditoria  anterior  que  possam  afetar 
sua  relevância  para  a  atual  auditoria – ver  NBC  TA  315,  item  9)  ou  procedimentos  de 
controle de qualidade da firma de auditoria para aceitação e continuidade de clientes. Além 
disso, os registros contábeis e outras fontes internas da entidade são importantes fontes de 
evidência  de  auditoria. Informações  que  podem  ser  utilizadas  como  evidência  de  auditoria 
podem ter sido elaboradas com a utilização do trabalho de especialista da administração ou 
obtidas de fonte de informações externa. A evidência de auditoria abrange informações que 
suportam   e   corroboram   as   afirmações   da   administração   e   qualquer   informação   que 
contradiga  tais  afirmações.  Além  disso,  em  alguns  casos,  a  ausência  de  informações  (por 
exemplo,  a  recusa  da  administração  em  fornecer  uma  representação  solicitada)  é  utilizada 
pelo auditor e, portanto, também constitui evidência de auditoria. 
 
A10.  A  NBC  TA  330,  item 26,  exige  que  o  auditor  conclua  se  foi  obtida  evidência  de  auditoria 
apropriada  e  suficiente.  É  questão  de  julgamento  profissional  determinar  se  foi  obtida 
evidência  de  auditoria  apropriada  e  suficiente  para  reduzir  o  risco  de  auditoria  a  um  nível 
aceitavelmente  baixo  e,  com  isso,  possibilitar  ao  auditor  atingir  conclusões  razoáveis  que 
fundamentem  sua  opinião.  A  NBC  TA  200  contém  a  discussão  de  assuntos,  como  a 
natureza  dos  procedimentos  de  auditoria,  a  tempestividade  dos  relatórios  financeiros  e  a 

relação  entre  benefício  e  custo,  que  são  fatores  relevantes  quando  o  auditor  exerce  o 
julgamento  profissional  e  determina  se  foi  obtida  evidência  de  auditoria  apropriada  e 
suficiente.  
 
A12.  Geralmente, obtém-se mais segurança com evidência de auditoria consistente obtida a partir 
de  fontes  diferentes  ou  de  natureza  diferente  do  que  a  partir  de  itens  de  evidência  de 
auditoria considerados individualmente. Por exemplo, informações corroborativas obtidas de 
fonte  independente  da  entidade  podem  aumentar  a  segurança  que  o  auditor  obtém  da 
evidência  de  auditoria  gerada  internamente,  tais  como  a  evidência  existente  em  registros 
contábeis, atas de reuniões ou representação da administração. 
 
A13.  Entre  as  informações  de  fontes  independentes  da  entidade  que  o  auditor  pode  usar  como 
evidência  de  auditoria  podem  estar  confirmações  de  terceiros e  informações  de  fonte 
externa  de  informações, incluindo relatórios  de  analistas  e  dados  comparáveis  sobre 
concorrentes (dados referenciais de benchmarking). 
 
A18.  A  inspeção  envolve  o  exame  de  registros  ou  documentos,  internos  ou  externos,  em  papel, 
em  forma  eletrônica  ou  em  outras  mídias,  ou  o  exame  físico  de  ativo.  A  inspeção  de 
registros   e   documentos   fornece   evidência   de   auditoria   com   graus   variáveis   de 
confiabilidade,  dependendo  de  sua  natureza  e  fonte  e,  no  caso  de  registros  internos  e 
documentos,  da efetividade dos  controles  sobre  a  sua  produção.  Um  exemplo  de  inspeção 
utilizada como teste é a inspeção de registros em busca de evidência de autorização. 
 
A30.  Como observado no item A5, embora a evidência de auditoria seja, principalmente, obtida a 
partir  de  procedimentos  de  auditoria  realizados  durante  o  curso  do  trabalho,  ela  também 
pode  incluir  informações  obtidas  de  outras  fontes,  por  exemplo,  auditorias  anteriores,  em 
certas  circunstâncias,  procedimentos  de  controle  de  qualidade  da  firma  de  auditoria  para 
aceitação   e   continuidade   de   clientes e   cumprimento   com   certas   responsabilidades 
adicionais  nos  termos  de  lei,  de  regulamento  ou  de  exigências  éticas  relevantes  (por 
exemplo, referentes à não conformidade da entidade com leis e regulamentos). A qualidade 
de  toda  evidência  de  auditoria  é  afetada  pela  relevância  e  confiabilidade  das  informações 
em que ela se baseia. 
 
A32.  Um  dado  conjunto  de  procedimentos  de  auditoria  pode  fornecer  evidência  relevante  para 
certas  afirmações,  mas, não, para  outras.  Por  exemplo,  a  inspeção  de  documentos 
relacionados  com  a  cobrança  de  contas  a  receber  após  o  fim  do  período  pode  fornecer 
evidência  de  auditoria  referente  à  existência  e  valorização,  mas  não  necessariamente  ao 
corte.  Similarmente,  a  obtenção  de  evidência  de  auditoria  referente  a  uma  afirmação 
específica, por exemplo, a existência de estoque, não substitui a obtenção de evidência de 
auditoria  referente  a  outra  afirmação,  por  exemplo,  a  valorização  desse estoque.  Por  outro 
lado,   evidência   de   auditoria   de   diferentes   fontes   ou   de   diferente   natureza   pode, 
frequentemente, ser relevante para a mesma afirmação. 
 
A34.  Os procedimentos substantivos são definidos para detectar distorções relevantes no nível da 
afirmação. Eles compreendem testes de detalhes e procedimentos analíticos substantivos. A 
definição de procedimentos substantivos inclui a identificação de condições relevantes para 
o propósito do teste que constituem distorção na afirmação relevante. 
 
A35.  A confiabilidade das informações a serem utilizadas como evidência de auditoria e, portanto, 
da própria auditoria, é influenciada pela sua fonte e sua natureza, e pelas circunstâncias nas 
quais  são  obtidas,  incluindo  os  controles  sobre  sua  elaboração  e  manutenção,  quando 
relevante.  Portanto,  generalizações  sobre  a  confiabilidade  de  vários  tipos  de  evidência  de 
auditoria  estão  sujeitas  a  importantes  exceções.  Mesmo  quando  as  informações  a  serem 
utilizadas  como  evidência  de  auditoria  são  obtidas  de  fontes  externas  à  entidade,  podem 
existir  circunstâncias  que  podem  afetar  a  sua  confiabilidade.  Por  exemplo,  informações 
obtidas de fonte independente podem não ser confiáveis se a fonte não tiver conhecimento 
ou  se  for  possível  que  especialista  da  administração  não  tenha  objetividade.  Embora 

reconhecendo   que   podem   existir   exceções,   as   seguintes   generalizações   sobre   a 
confiabilidade da evidência de auditoria podem ser úteis: 
• a  confiabilidade  da  evidência  de  auditoria  é  maior  quando  ela  é  obtida  de  fontes 
independentes fora da entidade;  
•  a  confiabilidade  da  evidência  de  auditoria  gerada  internamente  é  maior  quando  os 
controles  relacionados,  incluindo  os  controles  sobre  sua  elaboração  e  manutenção, 
impostos pela entidade, são efetivos;  
•  a evidência de auditoria obtida diretamente pelo auditor (por exemplo, a observação da 
aplicação   de   controle)   é   mais   confiável   do   que   a   evidência   de   auditoria   obtida 
indiretamente  ou  por  inferência  (por  exemplo,  indagação  a  respeito  da  aplicação  de 
controle); 
•  a  evidência  de  auditoria  em  forma  de  documentos,  em  papel,  mídia  eletrônica  ou  de 
outro tipo, é mais confiável do que a evidência obtida verbalmente (por exemplo, uma ata 
de  reunião  elaborada  tempestivamente  é  mais  confiável  do  que  uma  representação 
verbal subsequente dos assuntos discutidos); 
• a  evidência  de  auditoria  fornecida  por  documentos  originais  é  mais  confiável  do  que  a 
evidência  de  auditoria  fornecida  por  fotocópias  ou  fac-símiles  ou  por  documentos  que 
foram filmados, digitalizados ou transpostos de outra maneira para forma eletrônica, cuja 
confiabilidade pode depender dos controles sobre sua elaboração e manutenção.  
 
A38.  A  NBC  TA  250 – Consideração  de  Leis  e  Regulamentos  na  Auditoria  de  Demonstrações 
Contábeis,  item  9,  fornece  orientação  adicional  com  relação  ao  cumprimento  pelo  auditor 
com  quaisquer  responsabilidades  adicionais  nos  termos  de  leis,  de  regulamentos  ou  de 
requisitos  éticos  relevantes  referentes  à  não  conformidade  identificada  ou  suspeita  de  não 
conformidade   com   leis   e   regulamentos   por   parte   da   entidade   que   podem   fornecer 
informações  adicionais  que  sejam  relevantes  para  o  trabalho  do  auditor  de  acordo  com  as 
normas de auditoria e à avaliação das implicações dessa não conformidade com relação a 
outros aspectos da auditoria.  
 
Fontes de informações externas 
 
A39. Conforme   o   item   7,   o   auditor   deve   considerar   a  relevância   e   a   confiabilidade   das 
informações obtidas de fonte de informações externa que será utilizada como evidência de 
auditoria,  independentemente  se  as  informações  tiverem  sido  utilizadas  pela  entidade  na 
elaboração  das  demonstrações  contábeis  ou  obtidas  pelo  auditor.  Para  as  informações 
obtidas de fonte de informações externa, essa consideração pode, em determinados casos, 
incluir  evidência  de  auditoria  sobre  a  fonte  de  informações  externa  ou  sobre  a  elaboração 
das informações pela fonte de informações externa, obtidas por meio do planejamento e da 
realização  dos  procedimentos  adicionais  de  auditoria  de  acordo  com  a  NBC  TA  330  ou, 
quando aplicável, com a NBC TA 540. 
 
A40. A  obtenção  de  entendimento  do  motivo  pelo  qual  a  administração  ou,  quando  aplicável,  o 
especialista  da  administração  utiliza  fonte  de  informações  externa  e  o  modo  como  a 
relevância  e  a  confiabilidade  foram  consideradas  (incluindo  sua  exatidão  e  integridade) 
podem   ajudar   a   embasar   a   consideração   do   auditor   em   termos   da   relevância   e 
confiabilidade dessas informações. 
 
A41. Os   seguintes   fatores   podem   ser   importantes   na   consideração   da   relevância   e   da 
confiabilidade  das  informações  obtidas  de  fonte  de  informações  externa,  incluindo  sua 
exatidão e integridade, levando em consideração que alguns desses fatores somente podem 
ser   relevantes   quando   as   informações   tiverem   sido   usadas   pela   administração   na 
elaboração das demonstrações contábeis ou obtidas pelo auditor: 
 a natureza e a autoridade da fonte de informações externa. Por exemplo, é provável que 
o banco central ou a repartição de estatísticas do governo com mandato legislativo para 
fornecer  informações  setoriais  para  o  público  seja  a  autoridade  para  certos  tipos  de 
informações; 

 a capacidade de influenciar as informações obtidas por meio de relações entre a entidade 
e a fonte de informações; 
 a   competência   e   a   reputação   da   fonte   de   informações   externa   com   relação   às 
informações,  incluindo  se,  no  julgamento  profissional  do  auditor,  as  informações  são 
fornecidas  de  forma  rotineira  por  fonte  com  histórico  de  fornecimento  de  informações 
confiáveis; 
 a  experiência  anterior  do  auditor  com  a  confiabilidade  das  informações  fornecidas  pela 
fonte de informações externa; 
 evidências   de   aceitação   geral   do   mercado   pelos   usuários   da   relevância   e/ou 
confiabilidade   das   informações   de   fonte   de   informações   externa   para   finalidade 
semelhante  àquela  para  a  qual  as  informações  foram  utilizadas  pela  administração  ou 
pelo auditor; 
 se a entidade tem controles implantados para tratar da relevância e da confiabilidade das 
informações obtidas e utilizadas; 
 se  a  fonte  de  informações  externa  acumula  informações  gerais  do  mercado  ou  participa 
diretamente no “estabelecimento” das transações do mercado; 
 se as informações são adequadas para uso na forma na qual elas estão sendo usadas e, 
se  aplicável,  foram  desenvolvidas  levando  em  consideração  a  estrutura  de  relatório 
financeiro aplicável; 
 informações alternativas que podem contradizer as informações utilizadas; 
 a  natureza  e  a  extensão  das  isenções  de  responsabilidade  ou  de  outro  termo  restritivo 
relacionado com as informações obtidas; 
 informações  sobre  os  métodos  utilizados  na elaboração  das  informações,  o  modo  como 
os  métodos  estão  sendo  aplicados,  quando  aplicável,  o  modo  como  os  modelos  foram 
utilizados nessa aplicação, e os controles dos métodos; e 
 quando  disponível,  as  informações  relevantes  na  consideração  da  adequação  das 
premissas  e  de  outros  dados  aplicados  pelas  fontes  de  informações  externas  no 
desenvolvimento das informações obtidas. 
 
A42. A  natureza  e  a  extensão  das  considerações  do  auditor  levam  em  consideração  os  riscos 
avaliados  de  distorção  relevante  no  nível  de  afirmações  no  qual  o  uso  das  informações 
externas é relevante, o grau no qual o uso dessas informações é relevante para as razões 
para os riscos avaliados de distorção relevante e a possibilidade de que as informações da 
fonte  de  informações  externa  não  sejam  confiáveis  (por  exemplo,  se  elas  são  de  fonte 
crível).  Com  base  na  consideração  do  auditor  dos  assuntos  descritos  no  item  A33B,  o 
auditor  pode  determinar  que  um  entendimento  adicional  da  entidade  e  do  seu  ambiente, 
incluindo  seu  controle  interno,  é  necessário,  de  acordo  com  a  NBC  TA  315,  ou  que 
procedimentos  adicionais  de  auditoria,  de  acordo  com  a  NBC  TA  330,  item  6,  e  a  NBC  TA 
540,  item  30,  quando  aplicável,  são  apropriados  nas  circunstâncias,  para  responder  aos 
riscos avaliados de distorção relevante relacionados com o uso das informações de fonte de 
informações externa. Esses procedimentos podem incluir: 
 realização de comparação das informações obtidas da fonte de informações externa com 
as informações obtidas de fonte de informações externa alternativa; 
 quando  for  relevante  para  considerar  o  uso  por  parte  da  administração  de  fonte  de 
informações externa, a obtenção de entendimento dos controles que a administração tem 
implantados  para  considerar  a  confiabilidade  das  informações  de  fontes  de  informações 
externas, e testar, potencialmente, a efetividade operacional desses controles; 
 a  realização  de  procedimentos  para  obter  as  informações  da  fonte  de  informações 
externa  para  entender  seus  processos,  técnicas  e  premissas  para  fins  da  identificação, 
do  entendimento  e,  quando  relevante,  do  teste  da  efetividade  operacional  de  seus 
controles. 
 
A43. Em  algumas  situações,  pode  haver  apenas  um  fornecedor  de  determinadas  informações 
como, por exemplo, informações de banco central ou governo, como taxa de inflação, ou de 
um único órgão setorial reconhecido. Nesses casos, a determinação do auditor da natureza 
e   da   extensão   dos   procedimentos   de   auditoria   que   podem   ser   apropriados   nas 
circunstâncias  é  influenciada  pela  natureza  e  credibilidade  da  fonte  de  informações,  pelos 

riscos  avaliados  de  distorção  relevante  para  os  quais  essas  informações  externas  são 
relevantes e pelo grau no qual o uso dessas informações é relevante para as razões para os 
riscos  avaliados  de  distorção  relevante.  Por  exemplo,  quando  as  informações  são de  fonte 
oficial  crível,  a  extensão  dos  procedimentos  adicionais  de  auditoria  do  auditor  pode  ser 
menor,  como  a  corroboração  das  informações  no  site  da  fonte  ou  em  informações 
publicadas.  Em  outros  casos,  se  a  fonte  não  é  avaliada  como  crível,  o  auditor  pode 
determinar que procedimentos mais extensivos são apropriados e, na ausência de qualquer 
fonte alternativa de informações independentes para comparação, ele pode considerar se a 
realização  de  procedimentos  para  a  obtenção  de  informações  da  fonte  de  informações 
externa,   quando   praticável,   é   adequada   para   a   obtenção   de   evidência   de   auditoria 
apropriada e suficiente. 
 
A44. Quando  o  auditor  não  tem  base  suficiente  com  a  qual  considerar  a  relevância  e  a 
confiabilidade  das  informações  de  fonte  de  informações  externa,  o  auditor  pode  ter  uma 
limitação de escopo se a evidência de auditoria apropriada e suficiente não puder ser obtida 
por  meio  de  procedimentos  alternativos.  Qualquer  limitação  de  escopo  imposta  deve  ser 
avaliada de acordo com os requisitos da NBC TA 705, item 13.  
 
A46.  Quando  as  informações  a  serem  utilizadas  como  evidência  de  auditoria  foram  elaboradas 
com  o  uso  do  trabalho  de especialista  da  administração,  aplica-se o  requisito do  item  8 
desta  Norma.  Por  exemplo,  um  indivíduo  ou  organização  pode  possuir  conhecimento 
especializado na aplicação de modelos para estimar o valor justo de títulos mobiliários para 
os   quais   não   há   mercado   observável.   Se   o   indivíduo   ou   organização   aplica   esse 
conhecimento  especializado na  estimativa  que  a  entidade  utiliza  na  elaboração  das  suas 
demonstrações  contábeis,  o  indivíduo  ou  organização  é  especialista  da  administração  e 
aplica-se  o  item  8.  Se,  por  outro  lado,  esse  indivíduo  ou  organização  meramente  fornece 
dados  de  preço  referentes  a  transações  privadas  não  disponíveis  de  outra  maneira  para  a 
entidade  e  que esta  utiliza  nos  seus métodos  de  estimativa,  tais  informações,  se  utilizadas 
como evidência de auditoria, estão sujeitas ao item 7 desta Norma, sendo a informação de 
fonte externa e não se trata de utilização, pela entidade, de especialista da administração. 
 
A48.  A competência relaciona-se com a natureza e nível de conhecimento na área de atuação do 
especialista   da   administração.   As   habilidades   relacionam-se   com   a   capacidade   do 
especialista  da  administração  para  exercer  essa  competência  nas  circunstâncias.  Fatores 
que  influenciam  as  habilidades  podem  incluir,  por  exemplo, a localização geográfica e  a 
disponibilidade  de  tempo  e  recursos.  A  objetividade  relaciona-se  com  os  possíveis  efeitos 
que  tendenciosidades,  conflitos  de  interesse  ou  influência  que  outros  possam  ter  sobre  o 
julgamento  profissional  ou  de  negócios  do  especialista  da  administração.  A  competência, 
habilidades  e  objetividade  do especialista  da  administração  e  quaisquer  controles  da 
entidade   sobre   o   trabalho   desse   especialista   são   fatores   importantes   em   relação   à 
confiabilidade de qualquer informação apresentada por especialista da administração. 
 
A55.  O entendimento do trabalho do especialista da administração inclui o entendimento da área 
de especialização relevante. O entendimento da área de especialização relevante pode ser 
obtido  em  conjunto  com  a  determinação,  por  parte  do  auditor,  se  ele  tem conhecimento 
especializado  para  avaliar  o  trabalho  do  especialista  da  administração, ou  se  o  auditor 
precisa de especialista para essa finalidade (ver NBC TA 620, item 7). 
 
A59.  Considerações   durante   a   avaliação da   adequação do   trabalho   do   especialista   da 
administração como evidência de auditoria para a afirmação relevante podem incluir: 
• a  relevância  e  razoabilidade  das  constatações  ou  conclusões  desse  especialista,  sua 
consistência  com  outras  evidências  de  auditoria,  e  se  elas  foram  apropriadamente 
refletidas nas demonstrações contábeis; 
• se   o   trabalho   desse   especialista   envolve   a   utilização   de   premissas   e   métodos 
significativos, a relevância e a razoabilidade dessas premissas e métodos; 
• se o trabalho desse especialista envolve uso significativo de dados-fonte, a relevância, a 
integridade e a exatidão desses dados-fonte; e 

• se  o trabalho  desse  especialista  envolve  o  uso de  informações  de fonte  de  informações 
externa, a relevância e a confiabilidade dessas informações. 
 
 
10.  Altera os Apêndices 1 e 2 da NBC TA 580 (R1) – Representações Formais, que passam 
a vigorar com as seguintes redações: 
 
Apêndice 1 (ver item 2) 
 
Lista de normas de auditoria que contêm requisitos para representações formais  
Este  apêndice  identifica  os  itens  de  outras  normas  de  auditoria  que  exigem  representações 
formais específicas por assunto. A lista não substitui a consideração dos requisitos e da aplicação 
relacionada ou de outros materiais explicativos em normas de auditoria.  
 NBC TA 240 – Responsabilidade do Auditor em Relação a Fraude, no Contexto da Auditoria 
de Demonstrações Contábeis, item 39; 
 NBC  TA  250 – Consideração  de  Leis  e  Regulamentos  na Auditoria  de  Demonstrações 
Contábeis, item 16; 
 NBC TA 450 – Avaliação das Distorções Identificadas durante a Auditoria, item 14; 
 NBC TA 501 – Evidência de Auditoria – Considerações Específicas para Itens Selecionados, 
item 12; 
 NBC TA 540 – Auditoria de Estimativas Contábeis e Divulgações Relacionadas, item 37; 
 NBC TA 550 – Partes Relacionadas, item 26; 
 NBC TA 560 – Eventos Subsequentes, item 9; 
 NBC TA 570 – Continuidade Operacional, item 16(e); 
 NBC  TA  710 – Informações  Comparativas – Valores  Correspondentes  e  Demonstrações 
Contábeis Comparativas, item 9; 
 NBC TA 720 – Responsabilidade do Auditor em Relação a Outras Informações – item 13(c).  
 
Apêndice 2 (ver item A21)  
 
Exemplo de carta de representação  
 
O seguinte exemplo inclui representações formais que são exigidas por esta e outras normas de 
auditoria. Presume-se  nesse  exemplo  que  a  estrutura  de  relatório  financeiro  aplicável  seja  as 
Normas  Internacionais  de  Relatório  Financeiro  (IFRS),  que  o  requisito  da  NBC  TA  570 – 
Continuidade  Operacional de  obter  representação  formal  não  seja  relevante,  e  que  não  haja 
exceções às representações formais solicitadas. Caso tenha havido exceções, as representações 
devem ser modificadas para refletir as exceções. 
 
 
(Papel timbrado da entidade, no exemplo, Cia ABC) 
 
                                                                                                       (Data) 
 
Destinatário (Nome do auditor) 
 
Esta  carta  de  representação  é  fornecida  em  conexão  com  a  sua  auditoria  das  demonstrações 
contábeis da Companhia ABC para o ano findo em 31 de dezembro de 20XX
(1)
, com o objetivo de 
expressar uma opinião se as demonstrações contábeis foram apresentadas adequadamente, em 
todos os aspectos relevantes, em conformidade com as práticas contábeis adotadas no Brasil. 
Para  fins  de  identificação,  as  demonstrações  contábeis  examinadas  por  V.Sas.  apresentam  os 
seguintes valores básicos: 
                                                  X1 $ / X2 $ 
Total do ativo 
Total das exigibilidades 
Patrimônio Líquido 
 

Lucro líquido do exercício findo em  
 
Confirmamos  que  (com  base  em  nosso  melhor  entendimento  e  opinião,  depois  de  feitas  as 
indagações que consideramos necessárias para o fim de nos informarmos apropriadamente): 
 
Demonstrações contábeis 
 
• Cumprimos  nossas  responsabilidades  como  definidas  nos  termos  do  trabalho  de  auditoria 
datado  de  [inserir  data],  pela  elaboração  das  demonstrações  contábeis, de  acordo  com  as 
práticas contábeis adotadas no Brasil e, em particular, que as demonstrações contábeis foram 
apresentadas adequadamente em conformidade com essas práticas. 
• Os  métodos,  os  dados  e  as  premissas  significativas  utilizados  na  elaboração  das  estimativas 
contábeis    e    de    suas    divulgações    relacionadas    são    apropriados    para    alcançar    o 
reconhecimento, a mensuração ou a divulgação que seja razoável no contexto da estrutura de 
relatório financeiro aplicável (NBC TA 540). 
• As  relações e  transações  com  partes  relacionadas  foram  apropriadamente  contabilizados  e 
divulgadas  em  conformidade com  as práticas  contábeis  adotadas  no  Brasil  (ver  também  NBC 
TA 550 – Partes Relacionadas). 
• Todos  os  eventos  subsequentes  à  data  das  demonstrações  contábeis  e  para  os  quais  as 
práticas  contábeis  adotadas  no  Brasil  exigem  ajuste  ou  divulgação  foram  ajustados  ou 
divulgados (ver também NBC TA 560 – Eventos Subsequentes). 
• Os efeitos das distorções não corrigidas são irrelevantes, individual e agregadamente para as 
demonstrações contábeis como um todo. Uma lista das distorções não corrigidas está anexa a 
esta carta de representação (ver também NBC TA 450).  
• [Quaisquer outros assuntos que o auditor possa considerar apropriados (ver item A10)]. 
 
Informações fornecidas 
 
• Nós lhes fornecemos
(2)
: 
o acesso  a  todas  as  informações  das  quais  estamos  cientes  que  são  relevantes  para  a 
elaboração das demonstrações contábeis, tais como registros e documentação e outros; 
o informações adicionais que V.Sas. nos solicitaram para o propósito da auditoria; e 
o acesso  irrestrito  a  pessoas  dentro  da  entidade  das  quais  V.Sas.  determinaram  necessário 
obter evidência de auditoria. 
• Todas as transações foram registradas na contabilidade e estão refletidas nas demonstrações 
contábeis. 
• Divulgamos  a  V.Sas.  os  resultados  de  nossa  avaliação  do  risco  de  que  as  demonstrações 
contábeis possam ter distorção relevante como resultado de fraude (NBC TA 240). 
• Divulgamos  a  V.Sas.  todas  as  informações  relativas  a  fraude  ou  suspeita  de  fraude  de  que 
temos conhecimento e que afetem a entidade e envolvam: 
o administração; 
o empregados com funções significativas no controle interno; ou 
o outros em que a fraude poderia ter efeito relevante sobre as demonstrações contábeis (NBC 
TA 240). 
• Divulgamos  a  V.Sas.  todas  as  informações  relativas  a  alegações  de  fraude  ou  suspeita  de 
fraude  que  afetem  as  demonstrações  contábeis  da  entidade,  comunicadas  por  empregados, 
antigos empregados, analistas, reguladores ou outros (NBC TA 240). 
• Divulgamos  a  V.Sas.  todos  os  casos  conhecidos  de  não  conformidade  ou  suspeita  de  não 
conformidade com leis e regulamentos, cujos efeitos devem ser considerados na elaboração de 
demonstrações contábeis (NBC TA 250). 
• Divulgamos  aos  senhores  a  identidade  das  partes  relacionadas  e  todos  os relacionamentos  e 
transações com partes relacionadas das quais temos conhecimento (NBC TA 550). 
• [Quaisquer outros assuntos que o auditor possa considerar necessário (ver item A11)]. 
 
Assinaturas (presidente (ou principal executivo), diretor financeiro e contador) 
 

(1)
  Adaptar no caso de incluir mais de um período. 
(2)
  Se   o   auditor   incluiu   na   carta   de   contratação   outros   assuntos   relacionados   com   as 
responsabilidades  da  administração  em  conformidade  com  NBC  TA  210,  ele  pode  considerar 
incluir esses assuntos nas representações formais da administração ou dos responsáveis pela 
governança. 
 
 
11.  Altera  o  item 13 e  os  exemplos  de  1  a  4  do Apêndice da  NBC TA  700 – Formação  de 
Opinião  e  Emissão  do  Relatório  do  Auditor  Independente  sobre  as  Demonstrações 
Contábeis, que passam a vigorar com as seguintes redações: 
 
13. O auditor, especificamente, deve avaliar se, segundo os requisitos da estrutura de relatório 
financeiro aplicável: 
(a) as demonstrações contábeis divulgam apropriadamente as principais políticas contábeis 
selecionadas  e  aplicadas.  Ao  realizar  essa  avaliação,  o  auditor  deve  considerar  a 
relevância das políticas contábeis para a entidade e se elas foram elaboradas de forma 
compreensível (ver item A4); 
(b) as  políticas  contábeis  selecionadas  e  aplicadas  são  consistentes  com  a  estrutura  de 
relatório financeiro aplicável e se são apropriadas; 
(c) as  estimativas  contábeis e  divulgações  relacionadas  feitas  pela  administração  são 
razoáveis; 
(d) as informações apresentadas nas demonstrações contábeis são relevantes, confiáveis, 
comparáveis  e  compreensíveis.  Ao  realizar  essa  avaliação,  o  auditor  deve  considerar 
se:  
• as   informações   que   deveriam   ter   sido   incluídas   foram   incluídas   e   se   essas 
informações estão adequadamente classificadas, individualmente ou em conjunto, e 
caracterizadas;  
• a apresentação geral das demonstrações contábeis foi prejudicada pela inclusão de 
informações que não são relevantes ou que obscurecem o devido entendimento dos 
assuntos divulgados (ver item A5); 
(e) as  demonstrações  contábeis  fornecem  divulgações  adequadas  para  permitir  que  os 
usuários  previstos  entendam  o  efeito  de  transações  e  eventos  relevantes  sobre  as 
informações incluídas nas demonstrações contábeis (ver item A6); e 
(f) a  terminologia  utilizada  nas  demonstrações  contábeis,  incluindo  o  título  de  cada 
demonstração contábil, é apropriada. 
 
Apêndice (ver item A19) 
 
Nos  finais  dos  exemplos  de  1  a  4  do  Apêndice, substituir a expressão “[Números de registro no 
CRC da firma de auditoria e do profissional que assina o relatório]” por “[Números de registro no 
CRC da firma de auditoria e do profissional que assina o relatório e sua categoria profissional de 
contador]”. 
 
 
12.  Altera o título do item A23 e o item A24 da NBC TA 701 – Comunicação dos Principais 
Assuntos  de  Auditoria  no  Relatório  do  Auditor  Independente,  que  passam  a  vigorar 
com as seguintes redações: 
 
Julgamentos significativos do auditor relacionados com áreas das demonstrações contábeis 
que envolveram julgamentos significativos da administração, inclusive estimativas contábeis, 
estão sujeitos a alto grau de incerteza na estimativa (ver item 9(b)) 
 
A24.  No  entanto,  usuários das demonstrações  contábeis  têm  ressaltado  seu  interesse  nas 
estimativas contábeis que estão sujeitas a alto grau de incerteza na estimativa (itens 16 e 17 
da  NBC  TA  540 – Auditoria  de  Estimativas  Contábeis e  Divulgações Relacionadas)  e  que 
podem  não  ter  sido  avaliadas  como  riscos  significativos.  Entre  outros  aspectos,  essas 
estimativas dependem fortemente do julgamento da administração e frequentemente são as 

áreas  mais  complexas  das  demonstrações  contábeis,  podendo  exigir  o  envolvimento  tanto 
de  especialista  da  administração  como  de  especialista  do  auditor.  Os  usuários  também 
ressaltaram  que  as  políticas  contábeis  com  efeito  significativo  sobre  as  demonstrações 
contábeis  (e  mudanças  significativas  nessas  políticas)  são  relevantes  para  o  entendimento 
das  demonstrações  contábeis,  principalmente  nos  casos  em  que  as  práticas  da  entidade 
não são condizentes com as de outras entidades do mesmo setor. 
 
 
13.   Altera os itens 25, A14 e A56, inclui a definição de “entidade listada” e exclui a de 
“companhia aberta” no  item  12, e substitui as expressões “companhia(s) aberta(s)” 
por “entidade(s) listada(s)” nos itens 12, 35, 38, A16, A41, A44, A45 e seu título, A46 e 
A47, na NBC PA 01 – Controle de Qualidade para Firmas (Pessoas Jurídicas e Físicas) 
de Auditores Independentes, que passam a vigorar com as seguintes redações: 
 
12.  Nesta Norma, os termos a seguir possuem os significados a eles atribuídos: 
(...) 
Entidade  listada é  a  entidade  que  tem  ações,  cotas  ou  dívidas  cotadas  ou  registradas  em 
bolsa  de  valores  ou  negociadas  de  acordo  com  os  regulamentos  de  bolsa  de  valores 
reconhecida ou outro órgão equivalente. 
(...) 
 
25.  A firma deve estabelecer políticas e procedimentos para: 
(a)  estabelecer  critérios  para  determinar  a  necessidade  de  salvaguardas  para  reduzir  a 
ameaça  de  familiaridade  a  um  nível  aceitável  ao  utilizar  o  mesmo  pessoal  sênior  em 
trabalho de asseguração por longo período de tempo; e 
(b)  exigir, para auditorias de demonstrações contábeis de entidades listadas, a rotatividade 
do  sócio  do  trabalho  e  dos  indivíduos  responsáveis  pela  revisão  do  controle  de 
qualidade  do  trabalho  e,  quando  aplicável,  de  outras  pessoas  sujeitas  a  requisitos  de 
rotatividade,   após   período   especificado   em   conformidade   com   exigências   éticas 
relevantes (ver itens A10 e de A12 a A17). 
 
A14.  A  NBC  PA  400,  itens  540.1  a  540.20A1, reconhece  que  a  ameaça  de  familiaridade  é 
particularmente  relevante  no  contexto  das  auditorias  das  demonstrações  contábeis  de 
entidade  listada.  Para  essas  auditorias,  essa  Norma  exige  a  rotatividade  do  principal 
parceiro de auditoria após um período predefinido, normalmente não superior a sete anos, e 
fornece  padrões  e  orientações  relacionados.  Os  requisitos  nacionais  podem  estabelecer 
períodos de rotação mais curtos. 
 
A56.  Os  requisitos  éticos  relevantes  estabelecem  a  obrigação  do  pessoal  da  firma  de  observar 
durante  todo  o  tempo  a  confidencialidade  das  informações  contidas  na  documentação  do 
trabalho,  a menos  que tenha  sido fornecida  uma  autorização  específica  pelo  cliente  para  a 
sua  divulgação,  ou que  haja  responsabilidades  nos  termos  de  leis,  de  regulamentos  ou  de 
requisitos  éticos  relevantes  para  isso  (ver,  por  exemplo,  o  item  114.1A1 da  NBC  PG  100 – 
Cumprimento  do  Código  de  Ética,  seus  Princípios  e  sua  Estrutura  Conceitual  e  o  item 
R360.26  da  NBC  PG  300 – Profissional  da  Contabilidade  na  Prática  Pública). Leis  ou 
regulamentos  específicos  podem  impor obrigações  adicionais  para  que  o  pessoal  da  firma 
mantenha  a  confidencialidade  do  cliente,  especificamente  nos  casos  em  que  estejam 
envolvidos dados de natureza pessoal.  
 
 
14.  Na NBC TR 2400 – Trabalhos de Revisão de Demonstrações Contábeis: 
(a) inclui os itens A88, A93 e de A95 a A98; 
(b) em  razão  da  inclusão  dos itens A88,  A93  e  de  A95  a  A98,  renumera  os  itens  de 
A88 a A91 existentes para A89 a A92; renumera o item A92 existente para A94; e 
renumera os itens de A93 a A145 existentes para A99 a A151; 
(c) altera os itens 48, 52 e A94 após a renumeração; 

(d) altera as referências relativas a esta Norma, nesta e em outras normas, quando for 
o caso, em razão da inclusão e da renumeração de itens. 
 
48.  As indagações  do  auditor  à  administração  e  outros  dentro  da  entidade,  conforme  o  caso, 
incluem o seguinte (ver itens de A84 a A88):  
(...)  
 
52.  Quando há indicação da efetiva existência ou da suspeita de fraude ou não conformidade 
com leis e regulamentos na entidade, o auditor deve:  
(a) comunicar o assunto, salvo se proibido por lei ou regulamento, para o nível apropriado 
da administração ou para os responsáveis pela governança, conforme o caso (ver item 
A93);  
(b) solicitar  à  administração  a  avaliação  do  efeito,  se  houver,  sobre as  demonstrações 
contábeis;  
(c) considerar o efeito, se houver, da avaliação da administração dos efeitos de fraude ou 
não  conformidade  identificada  ou  suspeita  de  fraude  ou  não  conformidade com  leis  e 
regulamentos, comunicados  ao  auditor  na  sua  conclusão  sobre  as  demonstrações 
contábeis e sobre o seu relatório; e  
(d) determinar  se  leis,  regulamentos  ou  requisitos  éticos  relevantes  (ver  itens de A94 a 
A98):  
(i) exigem que o auditor comunique à autoridade competente externa à entidade; 
(ii) estabelecem  responsabilidades, segundo  as  quais  a  comunicação  à  autoridade 
competente externa à entidade pode ser apropriada nas circunstâncias.  
 
No Brasil, as regras de comunicação de não conformidade ou suspeita de não conformidade 
a  autoridades  externas  à  entidade se  aplicam  somente  nos  casos  em  que  a  legislação 
expressamente estabelece dita obrigação, como ocorre, por exemplo, quanto à obrigação do 
auditor   de   comunicar   suspeita   ou   a   ocorrência   de   não   conformidade   com   leis   e 
regulamentos, conforme determinado por órgãos reguladores para determinados segmentos 
regulados,  tais  como  o  Banco  Central  do  Brasil  e  a  Comissão  de  Valores  Mobiliários,  ou 
ainda  em  decorrência  do  disposto  na Resolução  CFC  n.º  1.530/2017,  que  dispõe  sobre  os 
procedimentos  a  serem  observados  pelos  profissionais  e  organizações  contábeis,  com 
relação  às  obrigações  previstas  na  Lei  n.º  9.613/1998  (sobre  "lavagem"  de  dinheiro).  Em 
todos    os    outros    casos, o    auditor    continua    obrigado    ao    dever    profissional    de 
confidencialidade das informações do cliente (ver item A6 da NBC TA 250). 
 
Planejamento e execução de procedimentos (ver itens 47 e 55) 
 
Indagações (ver itens de 46 a 48) 
 
A88. O  auditor  pode ter responsabilidades  adicionais  nos  termos  de  leis,  de  regulamentos  ou  de 
requisitos éticos relevantes com relação à não conformidade por parte da entidade com leis 
e regulamentos, incluindo fraude, que podem diferir desta Norma ou ir além dela, como, por 
exemplo:  
(a) resposta  à  não  conformidade  identificada  ou  suspeita  de  não  conformidade  com  leis  e 
regulamentos,  incluindo exigências  relacionadas com  comunicações  específicas  com  a 
administração   e   os   responsáveis   pela   governança,   e   considerando   se   medidas 
adicionais são necessárias;  
(b) comunicação  de  não  conformidade  identificada  ou  suspeita  de  não  conformidade  com 
leis  e  regulamentos  ao  auditor,  por  exemplo,  sócio  do  trabalho  de  grupo  (ver,  por 
exemplo, os itens R360.31, R360.32, R360.33, 360.34A1 e 360.35A1 da NBC PG 300; 
e  
(c) exigências  de  documentação  relacionada  com  a  não  conformidade  identificada  ou 
suspeita de não conformidade com leis e regulamentos.  
 
O cumprimento de quaisquer responsabilidades adicionais pode fornecer mais informações 
que  são  relevantes  para  o  trabalho  do  auditor  de  acordo  com  esta  Norma  (por  exemplo, 

informações  relacionadas  com  a  integridade  da  administração  ou,  quando  apropriado,  dos 
responsáveis pela governança).  
 
No  Brasil,  a  Resolução  CFC  n.º  1.530/2017  dispõe  sobre  os  procedimentos  a  serem 
observados  pelos  profissionais  e  organizações  contábeis,  quando  do  exercício  de  suas 
funções,  para  cumprimento  das  obrigações  previstas  na  Lei  n.º  9.613/1998  e  alterações 
posteriores,  que  dispõe  sobre  os  crimes  de  "lavagem"  ou  ocultação  de  bens,  direitos  e 
valores;  a  prevenção  da  utilização  do  sistema  financeiro  para  ilícitos  previstos  nessa  lei;  e 
cria o Conselho de Controle de Atividades Financeiras (Coaf). 
 
Fraudes e não conformidade com leis e regulamentos (ver item 52(a) e (d)) 
 
Comunicação à administração e aos responsáveis pela governança  
 
A93. Em algumas jurisdições, leis ou regulamentos podem restringir a comunicação do auditor de 
certos   assuntos   à   administração   ou   aos   responsáveis   pela   governança.   Leis   ou 
regulamentos  podem,  especificamente,  proibir  a  comunicação,  ou  outra  ação,  que  poderia 
prejudicar a investigação por parte da autoridade competente de ato ilícito, real ou suspeito, 
inclusive  alertando  a  entidade,  por  exemplo,  quando  o  auditor  tiver  que  comunicar  a  não 
conformidade  identificada  ou  suspeita  de  não  conformidade  com  leis  e  regulamentos  à 
autoridade competente de acordo com a lei de prevenção de crime de lavagem de dinheiro. 
Nessas  circunstâncias,  as  questões  consideradas  pelo  auditor  podem  ser  complexas  e  ele 
pode considerar apropriada a obtenção de assessoria legal. O item A88 descreve o contexto 
no Brasil.  
 
Comunicação  de  não  conformidade  identificada  ou  suspeita  de  não  conformidade  com  leis  e 
regulamentos à autoridade competente externa à entidade 
 
A94.  A comunicação de não conformidade identificada ou suspeita de não conformidade com leis 
e  regulamentos  à  autoridade  competente  externa  à  entidade  pode  ser  necessária  ou 
apropriada nas circunstâncias porque:  
(a) leis, regulamentos ou requisitos éticos relevantes requerem que o auditor a comunique;  
(b) o  auditor  determinou  que  a  comunicação  é  uma  ação  apropriada  de  resposta  à  não 
conformidade identificada ou suspeita de não conformidade de acordo com os requisitos 
éticos relevantes (ver item A95); ou  
(c) leis, regulamentos ou requisitos éticos relevantes dão ao auditor o direito de assim fazê-
lo (ver item A96).  
 
A95.  Em  alguns  casos,  os  requisitos  éticos  relevantes  podem  requerer  que  o  auditor  comunique 
ou considere se a comunicação de fraude ou não conformidade identificada ou suspeita de 
fraude  ou  não  conformidade  com  leis  e  regulamentos  à  autoridade  competente  externa  à 
entidade  é  uma  ação  apropriada  nas  circunstâncias.  Por  exemplo,  as  normas  profissionais 
(NBCs  PG  100,  200  e  300  e  NBC  PA  400  e NBC  PO 900)  requerem  que  o  auditor  tome 
medidas para responder à não conformidade identificada ou suspeita de não conformidade 
com  leis  e  regulamentos  e  determinar  se  ações  adicionais  são  necessárias,  o  que  pode 
incluir  a  comunicação  à  autoridade  competente  externa  à  entidade  (ver,  por  exemplo, os 
itens  360.36A2  e  360.36A3  da  NBC  PG  300).  As  normas  profissionais  explicam  que  essa 
comunicação  não  seria  considerada  uma  violação  do  dever  de  confidencialidade  nos  seus 
termos  (ver, por  exemplo,  o  item 114.1A1 da  NBC  PG  100  e o  item  R360.37  da  NBC  PG 
300).  
 
No Brasil, as regras de comunicação de não conformidade ou suspeita de não conformidade 
a  autoridades  externas  à  entidade se  aplicam  somente  nos  casos  em  que  a  legislação 
expressamente estabelece dita obrigação, como ocorre, por exemplo, quanto à obrigação do 
auditor   de   comunicar   suspeita   ou   a   ocorrência   de   não   conformidade   com   leis   e 
regulamentos conforme determinado por órgãos reguladores para determinados segmentos 
regulados,  tais  como  o  Banco  Central  do  Brasil  e  a  Comissão  de  Valores  Mobiliários,  ou 

ainda  em  decorrência  do  disposto  na Resolução  CFC  n.º  1.530/2017,  que  dispõe  sobre  os 
procedimentos  a  serem  observados  pelos  profissionais  e  organizações  contábeis,  com 
relação  às  obrigações  previstas  na  Lei  n.º  9.613/1998  (sobre  "lavagem"  de  dinheiro).  Em 
todos    os    outros    casos, o    auditor    continua    obrigado    ao    dever    profissional    de 
confidencialidade das informações do cliente, nos termos da NBC PG 01 – Código de Ética 
Profissional  do  Contador  e  nas  normas  profissionais  (NBCs  PG  100,  200  e  300  e NBC  PA 
400 e NBC PO 900) (ver item A6 da NBC TA 250). 
 
A96.  Mesmo  se  leis,  regulamentos  ou  requisitos  éticos  relevantes  não  incluírem  exigências  que 
tratam da comunicação de não conformidade identificada ou suspeita de não conformidade, 
eles  podem  dar  ao  auditor  o  direito  de  comunicar  a  não  conformidade  identificada  ou 
suspeita de não conformidade à autoridade competente externa à entidade. 
 
A97.  Em  outras  circunstâncias,  a  comunicação  da  não  conformidade  identificada  ou  suspeita  de 
não  conformidade  com  leis  e  regulamentos  à  autoridade  competente  externa  à  entidade 
pode  ser  impedida  pelo  dever  do  auditor  de  confidencialidade  nos  termos  de  leis,  de 
regulamentos ou de requisitos éticos relevantes. 
 
A98.  A  determinação  requerida  pelo  item  52(d)  pode  envolver  considerações  complexas  e 
julgamentos profissionais. Dessa forma, o auditor pode considerar uma consulta interna (por 
exemplo,  dentro  da  firma  ou  de  firma  da  rede)  ou,  de  forma  confidencial,  consultar  o 
regulador  ou  órgão  profissional  (a  menos  que  isso  seja  proibido  por  lei  ou  regulamento  ou 
que  viole  o  dever  de  confidencialidade).  O  auditor  pode  também  considerar  a  obtenção  de 
assessoria  legal  para  entender  as  suas  opções e  as  implicações  profissionais  ou  legais  de 
se tomar qualquer curso de ação em particular.  
 
 
15.  Na NBC TO 3000 – Trabalho de Asseguração Diferente de Auditoria e Revisão: 
(a) altera os itens 45 e 78; 
(b) inclui os itens A102 e de A194 a A199 e seus títulos; 
(c) em razão da inclusão dos itens A102 e de A194 a A199, renumera os itens de A102 
a A192 existentes para A103 a A193; renumera os itens de A193 a A200 existentes 
para A200 a A207; 
(d) altera as referências relativas a esta Norma, nesta e em outras normas, quando for 
o caso, em razão da inclusão e da renumeração de itens. 
 
45.  O auditor independente deve fazer indagações às partes apropriadas sobre: 
(a) se  eles  têm  conhecimento  de  qualquer  distorção  efetiva,  suspeita  ou  alegadamente 
intencional,  bem  como  com  referência  às  não  conformidades  com  leis  e  regulamentos 
que afetem a informação objeto do trabalho (ver itens A101 e A102);  
(b) se  a  parte  responsável  possui  função  de  auditoria  interna  e,  caso  positivo,  realizar 
indagações adicionais para obter entendimento das atividades e principais constatações 
da função de auditoria interna com respeito à informação objeto do trabalho; e  
(c) se  a  parte responsável utilizou  algum  especialista  na  preparação  da  informação  objeto 
do trabalho. 
 
78.  O  auditor  deve considerar se,  em  conformidade  com  os  termos  da  contratação  e  outras 
circunstâncias  do  trabalho,  algum  assunto  que  chegou  ao  seu  conhecimento  deve  ser 
comunicado  à  parte  responsável,  ao  mensurador  ou  avaliador,  à  parte  contratante,  aos 
responsáveis pela governança ou a outros (ver itens de A193 a A199).  
 
A102. O auditor pode ter responsabilidades adicionais nos termos de leis, de regulamentos ou de 
requisitos éticos relevantes com relação à não conformidade por parte da entidade com leis 
e regulamentos, que podem diferir desta Norma ou ir além dela, como, por exemplo:  
(a) resposta  à  não  conformidade  identificada  ou  suspeita  de  não  conformidade  com  leis  e 
regulamentos,  incluindo exigências  relacionadas com  comunicações  específicas  com  a 

administração   e   aos  responsáveis   pela  governança,   e   considerando  se   medidas 
adicionais são necessárias;  
(b) comunicação  de  não  conformidade  identificada  ou  suspeita  de  não  conformidade  com 
leis e regulamentos ao auditor (ver, por exemplo, os itens R360.31, R360.32, R360.33, 
360.34A1 e 360.35A1 da NBC PG 300); e  
(c) exigências  de  documentação  relacionada  com  a  não  conformidade  identificada  ou 
suspeita de não conformidade com leis e regulamentos. 
 
O  cumprimento  de  quaisquer  responsabilidades  adicionais  pode  fornecer  informações 
adicionais  que  são  relevantes  para  o  trabalho  do  auditor  de  acordo  com  esta  e  qualquer 
outra   norma   (por   exemplo,   informações   relacionadas   com   a   integridade   da   parte 
responsável  ou  dos  responsáveis  pela  governança).  Os  itens de A194 a  A198 tratam  de 
forma mais detalhada das responsabilidades do auditor nos termos de leis, de regulamentos 
ou  de  requisitos  éticos  relevantes  relacionados  com  a  comunicação  de  não  conformidade 
identificada ou suspeita de não conformidade com leis e regulamentos. 
 
Comunicação à administração e aos responsáveis pela governança 
 
A194.  Os  requisitos  éticos  relevantes  podem  incluir  a  exigência  de  comunicação  de  não 
conformidade  identificada  ou  suspeita  de  não  conformidade  com  leis  e  regulamentos  ao 
nível  apropriado  da  administração  ou  aos  responsáveis  pela  governança.  Em  algumas 
jurisdições,  leis  ou  regulamentos  podem  restringir  a  comunicação  do  auditor  de  certos 
assuntos  à  parte  responsável,  à  administração  ou  aos  responsáveis  pela  governança.  Leis 
ou  regulamentos  podem,  especificamente,  proibir  a  comunicação,  ou  outra  ação,  que 
poderia  prejudicar  a  investigação  por  parte  da  autoridade  competente  de  ato  ilícito, real  ou 
suspeito, inclusive alertando a entidade, por exemplo, quando o auditor tiver que comunicar 
a não conformidade identificada ou suspeita de não conformidade à autoridade competente, 
de acordo com a lei de prevenção de crime de lavagem de dinheiro. Nessas circunstâncias, 
as  questões  consideradas  pelo  auditor  podem  ser  complexas  e  ele  pode  considerar 
apropriada a obtenção de assessoria legal.  
 
No Brasil, as regras de comunicação de não conformidade ou suspeita de não conformidade 
a  autoridades  externas  à  entidade se  aplicam  somente  nos  casos  em  que  a  legislação 
expressamente estabelece dita obrigação, como ocorre, por exemplo, quanto à obrigação do 
auditor   de   comunicar  a  suspeita  ou   a  ocorrência  de   não  conformidade   com   leis   e 
regulamentos, conforme determinado por órgãos reguladores para determinados segmentos 
regulados,  tais  como  o  Banco  Central  do  Brasil  e  a  Comissão  de  Valores  Mobiliários,  ou 
ainda  em  decorrência  do  disposto  na Resolução  CFC  n.º  1.530/2017,  que  dispõe  sobre  os 
procedimentos  a  serem  observados  pelos  profissionais  e  organizações  contábeis,  com 
relação  às  obrigações  previstas  na  Lei  n.º  9.613/1998  (sobre  "lavagem"  de  dinheiro).  Em 
todos    os    outros    casos, o    auditor    continua    obrigado    ao    dever    profissional    de 
confidencialidade das informações do cliente. 
 
Comunicação  de  não  conformidade  identificada  ou  suspeita  de  não  conformidade  com  leis  e 
regulamentos à autoridade competente externa à entidade  
 
A195. Leis, regulamentos ou requisitos éticos relevantes podem: 
(a) exigir  que  o  auditor  comunique  a  não  conformidade  identificada  ou  suspeita  de  não 
conformidade com leis e regulamentos à autoridade competente externa à entidade;  
(b) estabelecer   responsabilidades, segundo   as   quais   a   comunicação   à   autoridade 
competente  externa  à  entidade  pode  ser  apropriada  nas  circunstâncias  (ver,  por 
exemplo, os itens 360.36A2 e 360.36A3 da NBC PG 300).  
 
No Brasil, o auditor deve também atentar para os requisitos específicos contidos na NBC PG 
01 – Código  de  Ética  Profissional  do  Contador  e  nas  normas  profissionais  (NBCs  PG  100, 
200 e 300 e NBC PA 400 e NBC PO 900). O item A194 descreve o contexto no Brasil. 
 

A196. A comunicação de não conformidade identificada ou suspeita de não conformidade com leis 
e  regulamentos  à  autoridade  competente  externa  à  entidade  pode  ser  necessária  ou 
apropriada nas circunstâncias porque:  
(a) leis, regulamentos ou requisitos éticos relevantes requerem que o auditor a comunique;  
(b) o  auditor  determinou  que  a  comunicação  é  uma  ação  apropriada  de  resposta  à  não 
conformidade identificada ou suspeita de não conformidade de acordo com os requisitos 
éticos relevantes; ou  
(c) leis, regulamentos ou requisitos éticos relevantes dão ao auditor o direito de assim fazê-
lo. 
 
A197. A comunicação de não conformidade identificada ou suspeita de não conformidade com leis 
e  regulamentos  de  acordo  com  leis,  regulamentos ou  requisitos éticos  relevantes  pode 
incluir não conformidade com leis e regulamentos com a qual o auditor se depara ou da qual 
ele  pode  tomar  conhecimento  na  condução  do  trabalho,  mas  que  pode  não  afetar  a 
informação objeto do trabalho. Nos termos desta Norma, não se espera que o auditor tenha 
nível  de  entendimento  de  leis  e  regulamentos  que  vá  além  daqueles  que  afetam  a 
informação  do  objeto  do  trabalho.  Entretanto,  leis,  regulamentos  ou  requisitos  éticos 
relevantes podem esperar que o auditor aplique o conhecimento, o julgamento profissional e 
sua  experiência  na  resposta  a  essa  não  conformidade.  Se  um  ato  constitui  uma  não 
conformidade  real  é,  em  última  instância,  um  assunto  a  ser  determinado  por  tribunal  ou 
outro órgão adjudicatório apropriado. 
 
A198. Em outras circunstâncias, a comunicação da não conformidade identificada ou suspeita de 
não  conformidade  com  leis  e  regulamentos  à  autoridade  competente  externa  à  entidade 
pode  ser  impedida  pelo  dever  do  auditor  de  confidencialidade  nos  termos  de  leis,  de 
regulamentos  ou  de  requisitos  éticos  relevantes.  Em  outros  casos,  a  comunicação  de  não 
conformidade  identificada  ou  suspeita  de  não  conformidade  à  autoridade  competente 
externa  à  entidade  não  seria  considerada  uma  violação  do  dever  de  confidencialidade  nos 
termos dos requisitos éticos relevantes (ver, por exemplo, o item 114.1A1 da NBC PG 100 e 
o item R360.37 da NBC PG 300).  
 
No Brasil, o auditor deve também atentar para os requisitos específicos contidos na NBC PG 
01 – Código  de  Ética  Profissional  do  Contador  e  nas  normas  profissionais  (NBCs  PG  100, 
200 e 300 e NBC PA 400 e NBC PO 900). Ver item A194. 
 
A199. O auditor pode considerar uma consulta interna (por exemplo, dentro da firma ou de firma 
da  rede),  para  obtenção  de  assessoria  legal  para  entender  às  implicações  profissionais  ou 
legais de se tomar qualquer curso de ação em particular ou consultar, de forma confidencial, 
o regulador ou órgão profissional (a menos que isso seja proibido por lei ou regulamento ou 
que  viole  o  dever  de  confidencialidade)  (ver,  por  exemplo,  o  item  360.39A1  da  NBC  PG 
300).  
 
No  Brasil,  o  auditor  deve também atentar  para  ser  seguido  os  requisitos  específicos 
emanados  pelo  órgão  que  regulamenta  a  profissão  contidos  na  NBC  PG  01 – Código  de 
Ética Profissional do Contador e nas normas profissionais (NBCs PG 100, 200 e 300 e NBC 
PA 400 e NBC PO 900). Ver item A194. 
  
 
16.  Altera o item A53 e os exemplos 1 e 2 do Apêndice 2 na NBC TO 3402 – Relatórios de 
Asseguração  de  Controles  em  Organização  Prestadora  de  Serviços,  que  passam a 
vigorar com as seguintes redações: 
 
A53.  As medidas apropriadas para responder às circunstâncias identificadas no item 56, salvo se 
proibido por leis ou regulamentos, podem incluir:  
• obtenção de assessoria jurídica sobre as consequências de diferentes cursos de ação;  
• comunicação  com  os  responsáveis  pela  governança  da  organização  prestadora  de 
serviços;  

• determinação  quanto  a  comunicar  a  terceiros  (por  exemplo,  leis,  regulamentos  ou 
requisitos éticos relevantes podem requerer que o auditor da organização prestadora de 
serviços comunique à autoridade competente externa à entidade ou ao auditor externo da 
organização  prestadora  de  serviços  (ver,  por  exemplo, os  itens  R360.31,  R360.32, 
R360.33, 360.34A1 e 360.35A1 da NBC PG 300), ou estabeleça responsabilidades sobre 
as quais essa comunicação pode ser apropriada nas circunstâncias);  
• modificação  da  opinião  do  auditor  da  organização  prestadora  de  serviços  ou  adição  de 
parágrafo de Outros Assuntos.  
• retirar-se do trabalho. 
 
No Brasil, as regras de comunicação de não conformidade ou suspeita de não conformidade 
a  autoridades  externas  à  entidade se  aplicam  somente  nos  casos  em  que  a  legislação 
expressamente estabelece dita obrigação, como ocorre, por exemplo, quanto à obrigação do 
auditor   de   comunicar   suspeita   ou   a   ocorrência   de   não   conformidade   com   leis   e 
regulamentos, conforme determinado por órgãos reguladores para determinados segmentos 
regulados,  tais  como  o  Banco  Central  do  Brasil  e  a  Comissão  de  Valores  Mobiliários,  ou 
ainda  em  decorrência  do  disposto  na Resolução  CFC  n.º  1.530/2017,  que  dispõe  sobre  os 
procedimentos  a  serem  observados  pelos  profissionais  e  organizações  contábeis,  com 
relação  às  obrigações  previstas  na  Lei  n.º  9.613/1998  (sobre  "lavagem"  de  dinheiro).  Em 
todos    os    outros    casos, o    auditor    continua    obrigado    ao    dever    profissional    de 
confidencialidade das informações do cliente, nos termos da NBC PG 01 – Código de Ética 
Profissional  do  Contador  e  nas  normas  profissionais  (NBCs  PG  100,  200  e  300  e NBC  PA 
400 e NBC PO 900) (ver item A6 da NBC TA 250).  
 
Apêndice 2 (ver item A47) 
 
Nos  finais  dos  exemplos  1  e  2  do  Apêndice  2, substituir a expressão “[Números  de  registro  no 
CRC da firma de auditoria e do profissional que assina o relatório]” por “[Números de registro no 
CRC da firma de auditoria e do profissional que assina o relatório e sua categoria profissional de 
contador]”. 
 
 
 
17.  Na NBC TSC 4410 – Trabalhos de Compilação de Demonstrações Contábeis: 
(a) altera os itens 21 e 27 e as ilustrações de 1 a 5 do Apêndice 2; 
(b) inclui os itens A22, e seu título, de A23 a A26 e A47; 
(c) em  razão  da inclusão dos  itens  de A22  a A26  e A47,  renumera  os  itens  de A22  a 
A41 para A27 a A46; e renumera os itens de A42 a A63 para A48 a A69; 
(d) altera as referências relativas a esta Norma, nesta e em outras normas, quando for 
o caso, em razão da inclusão e da renumeração de itens. 
 
21.  O profissional deve cumprir com os requisitos éticos relevantes (ver itens de A19 a A26).  
 
27.  O  profissional  deve  informar, tempestivamente, à  administração  ou  aos  responsáveis  pela 
governança,  conforme  for  apropriado,  no  decorrer  do  trabalho  de  compilação,  todos  os 
assuntos referentes ao trabalho que, no seu julgamento, sejam suficientemente importantes 
para merecer a atenção da administração ou dos responsáveis pela governança, conforme 
for apropriado (ver item A41 e A47).  
 
Comunicação  de  não  conformidade  identificada  ou  suspeita  de  não  conformidade  com  leis  e 
regulamentos à autoridade competente externa à entidade  
 
A22. Leis, regulamentos ou requisitos éticos relevantes podem:  
(a) exigir que o profissional comunique a não conformidade identificada ou suspeita de não 
conformidade com leis e regulamentos à autoridade competente externa à entidade;  

(b) estabelecer   responsabilidades, segundo   as   quais   a   comunicação   à   autoridade 
competente  externa  à  entidade  pode  ser  apropriada  nas  circunstâncias  (ver,  por 
exemplo, os itens 360.36A2 e 360.36A3 da NBC PG 300). 
 
A23. A comunicação de não conformidade identificada ou suspeita de não conformidade com leis 
e  regulamentos  à  autoridade  competente  externa  à  entidade  pode  ser  necessária  ou 
apropriada nas circunstâncias porque:  
(a) leis,  regulamentos  ou  requisitos  éticos  relevantes  requerem  que  o  profissional  a 
comunique;  
(b) o profissional determinou que a comunicação é uma ação apropriada de resposta à não 
conformidade identificada ou suspeita de não conformidade de acordo com os requisitos 
éticos relevantes; ou  
(c) leis, regulamentos ou requisitos éticos relevantes dão ao profissional o direito de assim 
fazê-lo. 
 
A24.  Nos  termos  do  item  28  desta  Norma,  não  se  espera  que  o  profissional  tenha  nível  de 
entendimento  de  leis  e  de  regulamentos, além  daquele  necessário  para  poder  conduzir  o 
trabalho  de  compilação.  Entretanto,  leis,  regulamentos  ou  requisitos  éticos  relevantes 
podem  esperar  que  ele  aplique  o  seu  conhecimento,  seu  julgamento  e  sua  experiência  na 
resposta  a  essa  não  conformidade.  Se  um  ato  constitui  uma  não  conformidade  real  é,  em 
última  instância,  um  assunto  a  ser  determinado  por  tribunal  ou  outro  órgão  adjudicatório 
apropriado. 
 
A25. Em algumas circunstâncias, a comunicação da não conformidade identificada ou suspeita de 
não  conformidade  com  leis  e  regulamentos  à  autoridade  competente  externa  à  entidade 
pode  ser  impedida  pelo  dever  do  profissional  de  confidencialidade  nos  termos  de  leis,  de 
regulamentos  ou  de  requisitos  éticos  relevantes.  Em  outros  casos,  a  comunicação  de  não 
conformidade  identificada  ou  suspeita  de  não  conformidade  à  autoridade  competente 
externa  à  entidade  não  seria  considerada  uma  violação  do  dever  de  confidencialidade  nos 
termos dos requisitos éticos relevantes (ver, por exemplo, o item 114.1A1 da NBC PG 100 e 
o item R360.37 da NBC PG 300).  
 
No Brasil, as regras de comunicação de não conformidade ou suspeita de não conformidade 
a  autoridades  externas  à  entidade se  aplicam  somente  nos  casos  em  que  a  legislação 
expressamente estabelece dita obrigação, como ocorre, por exemplo, quanto à obrigação do 
auditor   de   comunicar   suspeita   ou   a   ocorrência   de   não   conformidade   com   leis   e 
regulamentos, conforme determinado por órgãos reguladores para determinados segmentos 
regulados,  tais  como  o  Banco  Central  do  Brasil  e  a  Comissão  de  Valores  Mobiliários,  ou 
ainda  em  decorrência  do  disposto  na Resolução  CFC  n.º  1.530/2017,  que  dispõe  sobre  os 
procedimentos  a  serem  observados  pelos  profissionais  e  organizações  contábeis,  com 
relação  às  obrigações  previstas  na  Lei  n.º  9.613/1998  (sobre  "lavagem"  de  dinheiro).  Em 
todos    os    outros    casos, o    auditor    continua    obrigado    ao    dever    profissional    de 
confidencialidade das informações do cliente, nos termos da NBC PG 01 – Código de Ética 
Profissional  do  Contador  e  nas  normas  profissionais  (NBCs  PG  100,  200  e  300  e NBC  PA 
400 e NBC PO 900). 
 
A26.  O  profissional  pode  considerar  uma  consulta  interna  (por  exemplo,  dentro  da  firma  ou  de 
firma da rede), para obtenção de assessoria legal para entender às implicações profissionais 
ou  legais  de  se  tomar  qualquer  curso  de  ação  em  particular  ou  consultar,  de  forma 
confidencial,  o  regulador  ou  órgão  profissional  (a  menos  que  isso  seja  proibido  por  lei  ou 
regulamento ou que viole o dever de confidencialidade) (ver, por exemplo, o item 360.39A1 
da NBC PG 300).  
 
No Brasil, o auditor deve também atentar para os requisitos específicos contidos na NBC PG 
01 – Código  de  Ética  Profissional  do  Contador  e  nas  normas  profissionais  (NBCs  PG  100, 
200 e 300 e NBC PA 400 e NBC PO 900). 
 

A47.   Os   requisitos   éticos   relevantes   podem   incluir   a   exigência   de   comunicação   de   não 
conformidade  identificada  ou  suspeita  de  não  conformidade  com  leis  e  regulamentos  ao 
nível  apropriado  da  administração  ou  aos  responsáveis  pela  governança.  Em  algumas 
jurisdições,  leis  ou  regulamentos  podem  restringir  a  comunicação  do  profissional  de  certos 
assuntos  à  administração  ou  aos  responsáveis  pela  governança.  Leis  ou  regulamentos 
podem,  especificamente,  proibir  a  comunicação,  ou  outra  ação,  que  poderia  prejudicar  a 
investigação  por  parte  da  autoridade  competente  de  ato  ilícito,  real  ou  suspeito,  inclusive 
alertando  a  entidade,  por  exemplo,  quando  o  profissional  tiver  que  comunicar  a  não 
conformidade  identificada  ou  suspeita  de  não  conformidade  à  autoridade  competente  de 
acordo com a lei de prevenção de crime de lavagem de dinheiro. Nessas circunstâncias, as 
questões  consideradas  pelo  profissional  podem  ser  complexas, e  ele  pode  considerar 
apropriada a obtenção de assessoria legal.  
 
No  Brasil,  a  Resolução  CFC  n.º  1.530/2017  dispõe  sobre  os  procedimentos  a  serem 
observados  pelos  profissionais  e  organizações  contábeis,  quando  do  exercício  de  suas 
funções,  para  cumprimento  das  obrigações  previstas  na  Lei  n.º  9.613/1998  e  alterações 
posteriores,  que  dispõe  sobre  os  crimes  de  "lavagem"  ou  ocultação  de  bens,  direitos  e 
valores;  a  prevenção  da  utilização  do  sistema  financeiro  para  ilícitos  previstos  nessa  lei;  e 
cria o Conselho de Controle de Atividades Financeiras (Coaf). 
 
Apêndice 2 
 
Nos  finais  das  ilustrações  de  1  a  5,  substituir  os  dados  de  identificação  do  profissional  da 
contabilidade existentes pelos seguintes: 
 
[Local  (localidade  do  escritório  de  auditoria  que  emitiu  o  relatório)  e  data  do  relatório  do  auditor 
independente] 
[Nome do auditor independente (pessoa física ou jurídica)] 
[Nome do profissional (sócio ou responsável técnico, no caso de o auditor ser pessoa jurídica)] 
[Números de registro no CRC da firma de auditoria e do profissional que assina o relatório e sua 
categoria profissional de contador] 
[Assinatura do auditor independente] 
 
 
18.  Altera o item 4 da NBC PA 11 – Revisão Externa de Qualidade pelos Pares, que passa 
a vigorar com a seguinte redação: 
 
4.  Esta Norma aplica-se, exclusivamente, aos auditores com registro na Comissão de Valores 
Mobiliários  (CVM)  e/ou  no  Cadastro  Nacional  dos  Auditores  Independentes de  Pessoas 
Jurídicas (CNAI-PJ). 
 
 
Essas alterações, inclusões e exclusões entram em vigor na data de sua publicação. 
  
 
Brasília, 21 de novembro de 2019. 
 
 
Contador Zulmir Ivânio Breda 
Presidente 
 
Ata CFC n.º 1057.
