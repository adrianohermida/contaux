# Revisão NBC 05, que altera a NBC PG 12 (R3)

- Código externo: 2019/revisaonbc05
- Fonte: CFC 2019/REVISAONBC05 — DOU 17/12/2019 (REVOGADA)
- URL fonte: https://www2.cfc.org.br/sisweb/sre/detalhes_sre.aspx?Codigo=2019/REVISAONBC05&arquivo=REVISAONBC05.doc
- Arquivo original: https://www1.cfc.org.br/sisweb/SRE/docs/REVISAONBC05.pdf
- Nome do arquivo: REVISAONBC05.pdf
- Tags: Contábil, NBC, NBC PG, Revisão NBC, Revogada
- Atualizado em: 2026-10-10 14:27:54.238399+00

## Resumo

Revisão NBC 05, que altera a NBC PG 12 (R3)

## Texto integral extraído

NORMA  BRASILEIRA  DE  CONTABILIDADE,  REVISÃO  NBC 05,  DE 5 DE DEZEMBRO DE 
2019 
 
 
Aprova  a  Revisão  NBC 05,  que  altera  a 
NBC  PG  12  (R3) – Educação  Profissional 
Continuada. 
 
 
O CONSELHO FEDERAL DE CONTABILIDADE, no exercício de suas atribuições legais 
e  regimentais  e  com  fundamento  no  disposto  na  alínea  “f”  do  Art.  6º  do  Decreto-Lei  n.º 
9.295/1946,  alterado  pela  Lei  n.º  12.249/2010,  faz  saber  que  foi  aprovada  em  seu  Plenário  a 
Revisão NBC 05, que altera Norma Brasileira de Contabilidade (NBC): 
 
Altera  os itens 17 e 19 e  a  alínea  (e)  do  item  30,  inclui os itens 25A e  44B, a  alínea  (k)  no 
item 26, a alínea (l) no item 30 e o item 7A no Anexo I, altera o item 6 do Anexo I e as tabelas 
II, III e  IV do  Anexo  II e exclui o  Anexo  III na  NBC  PG  12  (R3) – Educação  Profissional 
Continuada, que passam a vigorar com as seguintes redações: 
 
17.  O cumprimento da pontuação exigida nesta Norma, pelos profissionais referidos no item 4, 
deve  ser  comprovado  mediante  a  verificação  das  atividades  constantes  no  relatório  de 
prestação de contas, disponível na área do profissional, e envio mediante Sistema EPC do 
CFC/CRCs.  Nos  casos  em  que  houver  atividades  de  docência,  pós-graduação, cursos 
realizados  no  exterior, produção  intelectual,  participação  em  comissões,  orientação  de 
artigos científicos e trabalhos de conclusão de curso e participação em bancas acadêmicas, 
estas devem ser informadas pelo profissional, também via Sistema EPC. O prazo para envio 
do relatório de atividades é 31 de janeiro do ano subsequente ao ano-base. A comprovação 
das referidas atividades devem ser anexadas no sistema EPC, no item “Minhas Atividades”, 
com exceção dos cursos e eventos credenciados. 
 
19.  As  atividades  de  Educação  Profissional  Continuada  realizadas  no  exterior  devem  ser 
cadastradas e comprovadas no Sistema EPC, por meio de declaração ou certificado emitido 
pela entidade realizadora, traduzido para o idioma português, constando a carga horária, o 
período de realização e o conteúdo programático.  As atividades devem ser informadas tão 
logo tenham sido realizadas e, no máximo, até 31 de janeiro do ano seguinte ao ano-base.  
 
25A. Os representantes da CVM, BCB, Susep e Previc podem participar das reuniões da CEPC-
CFC e CEPC/CRCs, na condição de observadores, com direito a voz e sem direito a voto, 
desde   que   indiquem,   previamente,   a   cada   reunião,   os   nomes   dos   representantes 
designados. 
 
26. A CEPC/CFC tem as seguintes atribuições: 
(a) (...) 
(k) publicar até 30 de junho de cada ano, no DOU, o edital especificando prazo para que os 
profissionais  que  descumpriram  o  PEPC  encaminhem  aos  Conselhos  Regionais  de 
Contabilidade  as  justificativas  de  não  cumprimento.  Adicionalmente,  o  CFC  poderá 
encaminhar, preferencialmente, para o endereço de email indicado pelo profissional na 
base de registro do CFC, a comunicação quanto à publicação do referido edital. 
 
30. A CEPC/CRC ou, na falta desta, a CDP do CRC, tem as seguintes atribuições em relação a 
esta norma: 
(a) (...) 
(e)  monitorar  a  inclusão,  no  sistema web,  do  relatório  de  atividades  dos  profissionais 
referidos no item 4;  
(f) (...) 
(l)  analisar  as  justificativas  de  não  cumprimento  do  PEPC,  conforme  prazo  definido  em 
Edital  específico  e  emitir  seu  parecer,  submetendo-o  à  apreciação  da  CEPC/CFC 

depois  de  aprovado  pela  CDP  e  homologado  pelo  Plenário  do CRC. Os  CRCs  que 
possuírem autonomia ficam dispensados de submeter seus pareceres à apreciação da 
CEPC/CFC, devendo cientificar o interessado sobre a decisão. 
 
44B.  O profissional deve manter atualizados os seus dados cadastrais na base de seu registro no 
Conselho Regional de Contabilidade. 
 
Essas  alterações,  inclusões  e  exclusões  serão incorporadas  na NBC  PG  12  (R3) e entram  em 
vigor na data de sua publicação, produzindo seus efeitos a partir de 1º de janeiro de 2020. 
  
Brasília, 5 de dezembro de 2019. 
 
 
Contador Zulmir Ivânio Breda 
Presidente 
 
Ata CFC n.º 1058. 
 
 
ANEXO I 
DIRETRIZES PARA CREDENCIAMENTO DE CAPACITADORAS, CREDENCIAMENTOS DE 
CURSOS/EVENTOS E DOCUMENTAÇÃO PARA CONTROLE E FISCALIZAÇÃO 
 
 
6.  As capacitadoras devem: 
(...) 
(h) somente  comunicar  aos  participantes  a pontuação  do  curso  ou  evento  quando  o 
processo  de  homologação  estiver  concluído  e  a  pontuação  validada, não  sendo  permitido 
solicitar credenciamento de curso já realizado; 
(ha) (...)  
(i) lançar  em  até  30  (trinta)  dias  após  a  data  de  realização  do  curso/evento,  por  meio  do 
sistema web,  informações  dos  professores  e  dos  participantes  que  se  certificaram  em 
curso/evento. Para  cursos/eventos  credenciados  e  realizados  em  dezembro, a  data  limite 
para o envio das informações será 15 de janeiro do ano seguinte. 
 
7A.  É vedada a modificação de carga horária e conteúdo programático de curso já credenciado.  
 
ANEXO II 
TABELAS DE PONTUAÇÃO 
Tabela II – Docência  
A comprovação de docência deve ser feita mediante apresentação de declaração 
emitida por Instituição de Ensino Superior (IES), contendo disciplina, ementa, carga 
horária e período de realização. 
A atribuição total de pontos para a atividade de docência é limitada 
a 20 (vinte) pontos por ano 
Natureza Características Atribuição de Pontos 
Pós-graduação (lato sensu e 
stricto sensu). 
Disciplinas  relacionadas  ao 
PEPC  ministradas  por  IES 
1 ponto por hora, limitado a 10 
(dez) pontos por disciplina. 

Graduação. 
credenciada pelo MEC. ministrada no ano. 
Observação: A disciplina 
ministrada em mais de uma 
turma, independentemente da 
instituição e do semestre letivo, 
é computada uma vez no ano. 
Cursos, inclusive de extensão, 
ou eventos credenciados. 
 
Participação como 
conferencista,    palestrante, 
painelista, instrutor e 
facilitador em eventos 
nacionais e internacionais. 
 
1 (um) ponto por hora. 
 
 
Tabela III – Atuação como participante  
A atribuição total de pontos para atuação como participante é limitada 
a 20 (vinte) pontos por ano   
A comprovação deve ser feita mediante a apresentação de documentação.    
Natureza Características Requisitos Atribuição de Pontos 
 
 
Comissões 
Técnicas e 
Profissionais; 
grupos de 
estudo no 
Brasil   ou   no 
exterior. 
 
Temas relacionados à Contabilidade, 
à Auditoria, à Perícia e às normas da 
profissão contábil: 
(a) Comissões    Técnicas    e    de 
Pesquisa do CFC, dos CRCs, do 
Ibracon, da FBC, da Abracicon e 
outros órgãos reguladores. 
(b) Comissões    Técnicas    e    de 
Pesquisa    de    instituições    de 
reconhecido prestígio. 
(c)  Comissões, órgãos e comitês de 
orientações    ao    mercado    de 
companhias abertas. 
   
12    (doze) 
meses    ou 
proporção. 
 
 
1 (um) ponto por hora.  
Orientação 
de tese, 
dissertação, 
monografia 
ou artigo 
científico. 
Temas relacionados à Contabilidade, 
à Auditoria, à Perícia e às normas da 
profissão contábil:  
(a) Doutorado 
(b) Mestrado 
(c) Especialização 
(d) Bacharelado. 
 
 
Por 
trabalho. 
 
 
(a) 10 (dez) pontos. 
(b) 7 (sete) pontos. 
(c) 4 (quatro) pontos. 
(d) 3 (três) pontos. 
Participação 
em bancas 
acadêmicas. 
Temas relacionados à Contabilidade, 
à Auditoria, à Perícia e às normas da 
profissão contábil:  
(a) Doutorado 
(b) Mestrado. 
 
Trabalho 
aprovado. 
 
 
(a) 5 (cinco) pontos. 
(b) 3 (três) pontos.  
 
 
 
 
Tabela IV – Produção Intelectual 
 A atribuição total de pontos da produção intelectual é limitada  
a 20 (vinte) pontos por ano 
Natureza Características Atribuição de Pontos 
Publicação, no 
exercício, de   artigos 
em     jornais     e     em 
Matérias    e    artigos    relacionados    à 
Contabilidade, à Auditoria, à Perícia e à 
profissão   contábil   homologados   pela 
Até  3  (três)  pontos  por 
matéria. 

revistas    nacionais    e 
internacionais, de 
forma impressa e 
eletrônica. 
CEPC/CFC. 
Artigos  técnicos  publicados  em  revista 
qualificada   pela Capes ou   jornal   de 
circulação   nacional   e   internacional   e 
homologados pela CEPC/CFC. 
Até  7  (sete)  pontos  por 
artigo. 
Apresentação, no 
exercício,   de   estudos 
ou trabalhos de 
pesquisa     técnica     e 
tese,   dissertação   ou 
monografias 
aprovadas. 
Participação em congressos 
internacionais relacionados à 
Contabilidade, à Auditoria, à Perícia e à 
profissão e aprovados pela CEPC/CFC.  
Até  15  (quinze)  pontos 
por estudo ou trabalho.  
Participação em congressos ou 
convenções   nacionais   relacionados   à 
Contabilidade, à Auditoria, à Perícia e à 
profissão contábil  e que façam  parte do 
PEPC reconhecido pela CEPC/CFC.  
 
Até  10  (dez)  pontos  por 
estudo ou trabalho.  
Autoria de livros. 
Autoria  de livro  publicado,  no  exercício, 
relacionados à Contabilidade, à 
Auditoria,    à    Perícia    e    à    profissão 
contábil, reconhecido pela CEPC/CFC. 
Até 20 (vinte) pontos por 
obra. 
Coautoria de livros. 
Coautoria     de livro     publicado     no 
exercício, relacionados  à  Contabilidade, 
à   Auditoria,   à   Perícia   e   à   profissão 
contábil. 
Até  10  (dez)  pontos  por 
obra. 
Tradução de livros. 
Tradução e adaptação, no exercício, de 
livros publicados no exterior 
relacionados à Contabilidade, à 
Auditoria,    à    Perícia    e    à    profissão 
contábil, aprovados pela CEPC/CFC. 
Até  10  (dez)  pontos  por 
obra.
