# Aprova a Revisão NBC 11

- Código externo: 2021/revisãonbc11
- Fonte: CFC 2021/REVISÃONBC11 — DOU 02/09/2021
- URL fonte: https://www2.cfc.org.br/sisweb/sre/detalhes_sre.aspx?Codigo=2021/REVIS%C3%83ONBC11&arquivo=REVISAONBC11.doc
- Arquivo original: https://www1.cfc.org.br/sisweb/SRE/docs/REVISAONBC11.pdf
- Nome do arquivo: REVISAONBC11.pdf
- Tags: Contábil, NBC, Revisão NBC
- Atualizado em: 2026-10-10 14:27:55.604697+00

## Resumo

Aprova a Revisão NBC 11

## Texto integral extraído

NORMA BRASILEIRA DE CONTABILIDADE, REVISÃO NBC 11, DE 19 DE AGOSTO DE 2021. 
 
 
Aprova  a  Revisão  NBC 11,  que  altera  as 
NBCs TA  200 (R1),  210 (R1),  230 (R1), 
250,  260 (R2),  265,  240 (R1),  300 (R1), 
402,  330 (R1),  500 (R1),  501,  530,  550, 
540 (R2), 600 (R1), 610, 620, 701 e 720 e 
NBC TR 2410. 
 
 
O CONSELHO FEDERAL DE CONTABILIDADE, no exercício de suas atribuições legais 
e  regimentais  e  com  fundamento  no  disposto  na  alínea  “f”  do  Art.  6º  do  Decreto-Lei  n.º 
9.295/1946,  alterado  pela  Lei  n.º  12.249/2010,  faz  saber que  foi  aprovada  em  seu  Plenário  a 
Revisão NBC 11, que altera as Normas Brasileiras de Contabilidade (NBC): 
 
 
1. Na  NBC  TA  200  (R1) – Objetivos Gerais  do Auditor Independente  e  a Condução  da 
Auditoria em Conformidade com Normas de Auditoria: 
(a) inclui os itens A16 e seu título, A42, A46, A69 e seu título e A70; 
(b) em  razão  da  inclusão  dos  itens  A16, A42,  A46,  A69 e A70, renumera  os  itens  de 
A16 a A40 existentes para A17 a A41; de A41 a A43 existentes para A43 a A45; de 
A44 a A65 existentes para A47 a A68; e de A66 a A78 existentes para A71 a A83; 
(c) altera os itens 7, 13, 17, A31, A41, A43, A44, A55, A64, A71 e A72 e seu título, após 
a renumeração; 
(d) altera as referências relativas a esta Norma, nesta e em outras normas, quando for 
o caso, em razão da inclusão e da renumeração de itens. 
  
7. As NBCs  TA contemplam  os  objetivos,  os  requisitos, a  aplicação  e  outros  materiais 
explicativos  que  se  destinam  a  dar  suporte  ao  auditor na  obtenção  de  segurança  razoável. 
As normas de auditoria requerem que o auditor exerça julgamento profissional e mantenha o 
ceticismo profissional ao longo de todo o planejamento e na execução da auditoria e, entre 
outras coisas:  
•   identifique e avalie os riscos de distorção relevante, independentemente de se causados 
por  fraude  ou  erro,  com  base  no entendimento  da  entidade, do  seu  ambiente,  da 
estrutura de relatório financeiro aplicável e do seu sistema de controles internos;  
•   obtenha evidência de auditoria apropriada e suficiente para concluir se existem distorções 
relevantes por meio do planejamento e da aplicação de respostas apropriadas aos riscos 
avaliados; e 
•   forme  uma  opinião  a  respeito  das  demonstrações  contábeis  com  base  em  conclusões 
obtidas da evidência de auditoria.  
 
13.  Para fins das NBCs TA, os seguintes termos possuem os significados atribuídos a seguir:  
(a)  (...) 
(n) risco de  distorção  relevante  é  o  risco  de  que  as  demonstrações  contábeis  contenham 
distorção  relevante  antes  da  auditoria.    Consiste  em  dois  componentes,  descritos  a 
seguir no nível da afirmação (ver item A16):  
(i) risco  inerente  é  a  suscetibilidade  de  uma  afirmação  a  respeito  de  uma  transação, 
saldo   contábil   ou   divulgação,   a   uma   distorção   que   possa   ser   relevante, 
individualmente  ou  em  conjunto  com  outras  distorções,  antes  da  consideração  de 
quaisquer controles relacionados;  
(ii) risco  de  controle  é  o  risco  de  que  uma  distorção  que  possa  ocorrer  em  uma 
afirmação  sobre  uma  classe  de  transações,  saldo  contábil  ou  divulgação  e  que 
possa  ser  relevante,  individualmente  ou  em  conjunto  com  outras  distorções,  não 
seja prevenida, detectada e corrigida tempestivamente pelos controles da entidade.  
(o) (...) 
 

 
17.  Para  obter  segurança  razoável,  o  auditor  deve  obter  evidência  de  auditoria  apropriada  e 
suficiente  para  reduzir  o  risco  de  auditoria  a  um  nível  aceitavelmente  baixo  e, com  isso, 
possibilitar a ele obter conclusões razoáveis e nelas basear a sua opinião (ver itens de A31 
a A57).  
 
Conformidade com requisitos relevantes (ver item 13(n)) 
 
A16. Para fins das NBCs TA, existe risco de distorção relevante quando há possibilidade razoável 
de:  
(a) ocorrer uma distorção (isto é, sua probabilidade); e 
(b) ela ser relevante caso ocorra (isto é, sua magnitude). 
 
A31.  A evidência de auditoria é necessária para sustentar a opinião e o relatório do auditor.  Ela é 
de  natureza  cumulativa e  primariamente  obtida  a  partir  de  procedimentos  de  auditoria 
realizados durante o curso da auditoria.  Contudo, também pode incluir informações obtidas 
de  outras  fontes,  como  auditorias  anteriores  (contanto  que  o  auditor  tenha  determinado  se 
ocorreram mudanças desde a auditoria anterior que possam afetar a sua relevância para a 
auditoria corrente (ver NBC TA 315, item 16)) ou procedimentos de controle de qualidade do 
auditor  para  aceitação  e  continuidade  de  clientes.  Além  de  outras  fontes  dentro  e  fora da 
entidade,  os  registros  contábeis  da  entidade  são  uma  fonte  importante  de  evidência  de 
auditoria. Ademais,  informações  que  possam  ser  usadas  como  evidências  de  auditoria 
podem  ter  sido  elaboradas  por  especialista  empregado  ou  contratado  pela  entidade.  As 
evidências  de  auditoria  abrangem  informações  que  sustentam  e  corroboram  as  afirmações 
da  administração  e  informações  que  contradizem  tais  afirmações.    Além  disso,  em  alguns 
casos, a ausência de informações (por exemplo, a recusa da administração de fornecer uma 
representação  solicitada)  é  usada  pelo  auditor  e,  portanto,  também  constitui  evidência  de 
auditoria.  A  maior  parte  do  trabalho  do  auditor  na  formação  de  sua  opinião  consiste  na 
obtenção e na avaliação da evidência de auditoria.  
 
A41.  O risco inerente é influenciado por fatores de risco inerente. Dependendo do grau em que os 
fatores  de  risco  inerente  afetam  a  suscetibilidade  de  uma  afirmação  à  distorção,  o  nível  de 
risco  inerente  varia  de  acordo  com  uma  escala  que  é  denominada spectrum de  risco 
inerente.    O  auditor  determina  classes  de  transações,  saldos  contábeis  ou  divulgações 
significativas,  e  suas  afirmações  relevantes,  como  parte  do  processo  de  identificação  e 
avaliação  dos  riscos  de  distorção  relevante.  Por  exemplo,  saldos  contábeis  compostos  de 
valores  derivados  de  estimativas  contábeis  sujeitas  à  incerteza  significativa  de  estimativa 
podem  ser  identificados  como  saldos  contábeis  significativos,  e  a  avaliação  do  auditor  do 
risco  inerente  para  os  riscos  relacionados  no  nível  da  afirmação  pode  ser avaliada pelo 
auditor como mais alta devido à alta incerteza de estimativa.  
 
A42.  Circunstâncias  externas  que  geram  riscos  de  negócios  também  podem  influenciar  o  risco 
inerente.  Por  exemplo,  desenvolvimentos  tecnológicos  podem  tornar  obsoleto  um  produto 
específico,   tornando, assim, o   estoque   mais   suscetível   à   distorção   em   relação   à 
superavaliação.    Fatores  na  entidade  e  no  seu  ambiente  relacionados  com várias  ou  todas 
as  classes  de  transações,  saldos  contábeis  ou  divulgações  também  podem  influenciar  o 
risco  inerente  relacionado  com  uma  afirmação  específica.    Tais  fatores  podem  incluir,  por 
exemplo, falta  de  capital  de  giro  suficiente  para a  continuidade  das  operações  ou  um  setor 
em declínio caracterizado por um grande número de fracassos comerciais.  
 
A43.  O  risco  de  controle  é  uma  função  da  efetividade  do  desenho,  da  implementação  e  da 
manutenção  dos  controles  pela  administração  no  tratamento  dos  riscos  identificados  que 
ameaçam o  cumprimento  dos  objetivos  da  entidade,  que  são  relevantes  para  a  elaboração 
das suas demonstrações  contábeis. Contudo,  o  controle  interno,  independentemente  da 
qualidade  da  sua  estrutura  e  operação,  pode  reduzir,  mas  não  eliminar,  os  riscos  de 
distorção  relevante  nas  demonstrações  contábeis,  por  causa  das  limitações  inerentes  aos 
controles. Essas  limitações  incluem,  por  exemplo,  a  possibilidade  de  erros  ou  equívocos 
humanos,   ou   de  controles  contornados   por  conluio  ou  transgressão  inapropriada  da 

 
administração.  Portanto,  algum  risco  de  controle  sempre  existe.    As  normas  de  auditoria 
oferecem  as  condições  nas  quais  existe  a  exigência,  ou  a  possibilidade  de  escolha  pelo 
auditor,  de  testar  a  efetividade  operacional  dos  controles  na  determinação  da  natureza,  da 
época e da extensão de procedimentos substantivos a serem realizados (ver NBC TA 330, 
itens de 7 a 17).  
 
A44.  A  avaliação  dos  riscos  de  distorção  relevante  pode  ser  expressa  em  termos  quantitativos, 
como porcentagens, ou em termos não quantitativos. De qualquer forma, a necessidade de 
que  o  auditor  faça  avaliações  de  risco  apropriadas  é  mais  importante  do  que  as  diferentes 
abordagens  pelas  quais  elas  são  feitas.  As  normas  de  auditoria, normalmente, se  referem 
aos  “riscos  de  distorção  relevante”  em  vez  de  a  risco  inerente  e a risco  de  controle 
separadamente. Contudo,  a  NBC  TA  315 requer  que  o  risco  inerente  seja  avaliado 
separadamente  do  risco  de  controle  para  fornecer  a  base  para  o  planejamento  e  a 
realização de procedimentos adicionais de auditoria para responder aos riscos avaliados de 
distorção relevante no nível da afirmação, de acordo com a NBC TA 330.  
 
A46.  Os  riscos  de  distorção  relevante  são  avaliados  no  nível  da  afirmação  para  determinar  a 
natureza, a época e a extensão dos procedimentos adicionais de auditoria necessários para 
se obter evidência de auditoria apropriada e suficiente (ver NBC TA 330, item 6).  
 
A55.  Considerando  as  abordagens  descritas  no  item  A54,  as  normas  de  auditoria  contêm 
requisitos  para  o  planejamento  e  a  execução  da  auditoria  e  exigem  que  o  auditor,  entre 
outras coisas:  
•   identifique  e  avalie  os  riscos  de  distorção  relevante  nos  níveis  das  demonstrações 
contábeis e da afirmação mediante a realização de procedimentos de avaliação de risco 
e atividades relacionadas (NBC TA 315, itens de 17 a 22); e 
•   aplique  testes  e  outros  meios  para  examinar  populações  de  maneira  que  forneça  base 
razoável  para  que  o  auditor  tire  conclusões  a  respeito  da  população (ver  NBC  TA  330, 
NBC TA 500, NBC TA 520 – Procedimentos Analíticos e NBC TA 530 – Amostragem em 
Auditoria). 
 
A64.  Quando  for  necessário,  a  aplicação  e  outros materiais  explicativos  fornecem  explicação 
adicional  dos  requisitos  de  uma  NBC  TA  e  orientação  para  o  seu  cumprimento.  Em 
particular, eles podem:  
•   explicar mais  precisamente  o  que  um  requisito  significa  ou se  destina  a cobrir,  incluindo 
em algumas normas, como a NBC TA 315, porque um procedimento é requerido; 
•   incluir  exemplos  de  procedimentos  que  possam  ser  apropriados  nas  circunstâncias.  Em 
algumas normas, como a NBC TA 315, os exemplos são apresentados em caixas.  
Embora  tal  orientação  em  si  não  imponha  um  requisito,  ela  é  relevante  para  a  aplicação 
apropriada  dos  requisitos  da  NBC  TA.  A  aplicação  e  outros  materiais  explicativos  também 
podem fornecer informações de suporte sobre assuntos tratados em uma NBC TA.  
 
Considerações sobre escalabilidade 
 
A69  Foram  incluídas  considerações  sobre  escalabilidade  em  algumas  normas  de  auditoria  (por 
exemplo,  NBC  TA  315)  para  ilustrar  a  aplicação  dos  requisitos  a  todas  as  entidades 
independentemente  de  a  sua  natureza  e  as  suas  circunstâncias  serem  menos  ou  mais 
complexas.   Entidades   menos   complexas   são   entidades   às   quais   se   aplicam   as 
características no item A71. 
 
A70.  As  “considerações  específicas  para  entidades  de  pequeno  porte”  incluídas  em  algumas 
normas  de  auditoria  foram  desenvolvidas  tendo  em  mente  primariamente  entidades  não 
listadas  em  bolsa.  Algumas  das  considerações,  porém,  podem  ser  úteis  em  auditorias  de 
entidades abertas de pequeno porte.  
 

 
A71.  Para  fins  de  especificação  das  considerações  adicionais  para  auditorias  de  entidades  de 
pequeno porte, “entidade de pequeno porte” refere-se  à  entidade  que  geralmente  possui 
características qualitativas como: 
(a) concentração  de  propriedade  e  administração  em  pequeno  número  de  indivíduos 
(frequentemente um único indivíduo, uma pessoa natural ou outra empresa que controle 
a entidade, contanto que o proprietário exiba as características qualitativas relevantes); 
e 
(b) uma ou mais das seguintes situações:  
(i) transações diretas ou não complicadas;  
(ii) manutenção de registros simples;  
(iii) poucas linhas de negócios e poucos produtos dentro das linhas de negócios;  
(iv) sistemas de controles internos mais simples;  
(v) poucos níveis de administração com responsabilidade por ampla série de controles; 
ou 
(vi) poucos empregados, muitos deles com ampla série de funções.  
Essas  características  qualitativas  não  são  exaustivas  nem  exclusivas  de  entidades  de 
pequeno porte, e essas entidades não exibem necessariamente todas elas.  
 
Considerações específicas para ferramentas e técnicas automatizadas 
 
A72. Considerações  específicas  para  “ferramentas  e  técnicas  automatizadas”, incluídas  em 
algumas  normas  de  auditoria  (por  exemplo,  NBC  TA  315), foram  desenvolvidas  para 
explicar  de  que modo  que  o  auditor  pode  aplicar  certos requisitos  ao  utilizar  ferramentas  e 
técnicas automatizadas na realização de procedimentos de auditoria.  
 
 
2. Altera o item A18 da NBC TA 210 (R1) – Concordância com os Termos do Trabalho de 
Auditoria, que passa a vigorar com a seguinte redação: 
 
A18.  É a administração que deve determinar que controle interno é necessário para possibilitar a 
elaboração das demonstrações contábeis. O termo “controle interno” abrange uma vasta 
gama  de  atividades  nos  componentes  do  sistema  de  controles  internos,  que  podem  ser 
descritas  como  o  ambiente  de  controle,  o  processo  de  avaliação  de  riscos  da  entidade,  o 
processo  de  monitoramento  do  sistema  de  controles  internos  pela  entidade,  o  sistema  de 
informações  e  comunicação,  e  atividades  de  controle.  Essa  divisão,  contudo,  não  reflete, 
necessariamente, como uma  entidade  específica pode  elaborar,  implementar  e manter  seu 
controle  interno,  ou  como  pode  classificar  qualquer  componente  específico (ver  NBC  TA 
315, item A9 e Apêndice 3). O controle interno da entidade (especificamente, seus registros 
e  sistemas  contábeis)  reflete  as  necessidades  da  administração,  a  complexidade  dos 
negócios,  a  natureza  dos  riscos  a  que  a  entidade  está  sujeita  e  as  leis  ou  regulamentos 
relevantes. 
 
 
3. Altera  o  item A17 da NBC  TA  230 (R1) – Documentação  de Auditoria,  que  passa  a 
vigorar com a seguinte redação: 
 
A17.  Ao  elaborar  a  documentação  de  auditoria, o  auditor  de  entidade  de  pequeno  porte  também 
pode  entender  ser  adequado  e  eficiente  registrar  em  um  único  documento  vários  aspectos 
da  auditoria,  com referências  cruzadas  para  dar  suporte  aos  papéis  de trabalho.  Exemplos 
de  assuntos  que  podem  ser  documentados  em  conjunto  na  auditoria  de  entidade  de 
pequeno  porte  incluem  o  entendimento  da  entidade  e  do  seu  ambiente,  da  estrutura  de 
relatório  financeiro  aplicável  e  do  sistema  de  controles  internos  da  entidade, da  estratégia 
global de auditoria e do plano de auditoria, da materialidade determinada de acordo com a 
NBC  TA  320 – Materialidade  no  Planejamento  e  na  Execução  da  Auditoria,  dos  riscos 
avaliados,  dos  assuntos  significativos  observados  durante  a  auditoria e  das  conclusões 
obtidas.  
 

 
 
4. Altera o item A23 da NBC TA 250 – Consideração de Leis e Regulamentos na Auditoria 
de Demonstrações Contábeis, que passa a vigorar com a seguinte redação: 
 
A23.  Como  requerido  pelo  item  22,  o  auditor  deve  avaliar  as  implicações  de  não  conformidade 
identificada  ou  suspeita  de  não  conformidade  em  relação  a  outros  aspectos  da  auditoria, 
inclusive  a  sua  avaliação  de  risco  e  a  confiabilidade  das  representações  formais.  As 
implicações  de  não  conformidade  identificada  ou  suspeita de  não  conformidade  dependem 
da relação da perpetração e ocultação, se houver, do ato de controles específicos e o nível 
da  administração  ou  indivíduos  que  trabalham  para  a  entidade  envolvida  ou  sob  o  seu 
comando,  especialmente  implicações  decorrentes  do envolvimento  da autoridade mais  alta 
na  entidade. Conforme  observado  no  item  9,  o  cumprimento  por  parte  do  auditor  com  leis, 
regulamentos ou requisitos éticos relevantes pode fornecer informações adicionais que são 
relevantes para as suas responsabilidades, de acordo com o item 22.  
 
 
5. Altera os itens A12 e A13 e o Apêndice 2 da NBC TA 260 (R2) – Comunicação com os 
Responsáveis pela Governança, que passam a vigorar com as seguintes redações: 
 
A12. A comunicação de riscos significativos identificados pelo auditor auxilia os responsáveis pela 
governança  a  entenderem  esses  assuntos  e  porque  eles  foram  determinados  como  sendo 
riscos  significativos.  A  comunicação  de  riscos  significativos  pode  auxiliar  os  responsáveis 
pela  governança  a  cumprirem  sua  responsabilidade  de  supervisionar,  de  modo  geral,  o 
processo de relatórios financeiros.  
 
A13. Os assuntos comunicados podem incluir:  
•   como  o  auditor  planeja  tratar  dos  riscos  significativos  de  distorção  relevante  devido  a 
fraude ou erro;  
•   como o auditor planeja tratar de áreas de maiores riscos avaliados de distorção relevante;  
•   a abordagem do auditor em relação ao sistema de controles internos da entidade;  
•   a aplicação do conceito de materialidade no contexto da auditoria;  
•   (...) 
 
Apêndice 2 (ver itens 16(a), A19 e A20) 
 
(...) 
 
Estimativas contábeis 
 
• Para itens para os quais as estimativas são significativas, assuntos discutidos na NBC TA 540 
– Auditoria de Estimativas Contábeis e Divulgações Relacionadas, incluindo, por exemplo:  
o como  a  administração  identifica transações,  eventos  ou  condições  que  podem  gerar  a 
necessidade de reconhecimento ou divulgação de estimativas contábeis nas demonstrações 
contábeis;  
o (...) 
 
 
6. Altera  os itens 1,  2, A3  e  A8 da NBC  TA  265 – Comunicação  de Deficiências  de 
Controle Interno, que passam a vigorar com as seguintes redações: 
 
1. Esta Norma trata  da  responsabilidade  do  auditor  de  comunicar  apropriadamente,  aos 
responsáveis  pela  governança  e  à  administração,  as  deficiências  de  controle  interno  que 
foram  identificadas  na  auditoria  das  demonstrações  contábeis.  Esta Norma não  impõe 
responsabilidades  adicionais  ao  auditor  na  obtenção  de  entendimento  do  sistema  de 
controles  internos  da  entidade,  assim  como  no  planejamento  e  na  realização  de  testes  de 
controle além dos requisitos da NBC TA 315 e da NBC TA 330.  A NBC TA 260 estabelece 

 
requisitos   adicionais   e   fornece   orientação   sobre   a   responsabilidade   do   auditor   na 
comunicação com os responsáveis pela governança em relação à auditoria.  
 
2. O  auditor  deve  obter  entendimento  do  sistema de  controles  internos  da  entidade  ao 
identificar  e  avaliar  os  riscos  de  distorção  relevante.  Nessas  avaliações  de  risco,  o  auditor 
considera  o  sistema  de  controles  internos  da  entidade  para  planejar  os  procedimentos  de 
auditoria  que  são  apropriados às circunstâncias,  mas  não  para  fins  de  expressar  uma 
opinião  sobre  a  eficácia  do  controle  interno.  O  auditor  pode  identificar  deficiências  de 
controle nos controles internos, não somente durante esse processo de avaliação de risco, 
mas,   também,   em   qualquer   outra etapa   da   auditoria.   Esta Norma especifica   quais 
deficiências  identificadas  pelo  auditor  devem  ser  comunicadas  aos  responsáveis  pela 
governança e à administração.  
 
A3.  Embora  os  conceitos  que  suportam  os  controles  no  componente  de  atividades  de  controle 
em  entidades  de  pequeno  porte  sejam  provavelmente  semelhantes  aos  de  entidades  de 
grande  porte,  a  formalidade  com  que  operam  varia.  Além  disso,  as  entidades  de  pequeno 
porte  podem  determinar  que  certos  tipos  de  controle  não  são  necessários  devido  aos 
controles   aplicados   pela   administração.   Por   exemplo,   a   autoridade   exclusiva   da 
administração  de  conceder  crédito  a  clientes  e  aprovar  aquisições  significativas  pode 
proporcionar  o  controle  efetivo  dos  saldos  contábeis  e  transações  importantes,  diminuindo 
ou eliminando a necessidade de controles mais detalhados.  
 
A8.  Os  controles  podem  ser  planejados  para  operar  individualmente  ou  em  conjunto  para 
prevenir,  ou  detectar  e  corrigir,  as  distorções  de  maneira  eficaz.  Controles  das  contas  a 
receber,  por  exemplo,  podem  consistir  de  controles  automatizados  e  manuais  elaborados 
para  operarem  em  conjunto  para  prevenir,  ou  detectar  e  corrigir,  distorções  no  saldo 
contábil.   A   deficiência  de   controle  interno,  por   si   só,   pode   não  ser   suficientemente 
importante   para   constituir   uma   deficiência   significativa.   Entretanto,   a   combinação   de 
deficiências que afeta o mesmo saldo contábil ou a mesma divulgação, a mesma afirmação, 
ou  o  mesmo  componente  do  sistema  de  controles  internos  da  entidade,  pode  aumentar  os 
riscos de distorção a ponto de gerar uma deficiência significativa.  
 
 
7. Altera os itens 7, 16, 17, 21, 26, 28, 45, A8 e inclui seu título, A19, A20, A21, A23, A26, 
A33, A43 e A44  e os Apêndices 1 e  2 da NBC  TA  240 (R1) – Responsabilidade  do 
Auditor em Relação à Fraude, no Contexto da Auditoria de Demonstrações Contábeis, 
que passam a vigorar com as seguintes redações: 
 
7.  Além disso, o risco de o auditor não detectar uma distorção relevante decorrente de fraude 
da  administração  é  maior  do  que  no  caso  de  fraude  cometida  por empregados,  porque  a 
administração  frequentemente  tem  condições  de  manipular,  direta  ou  indiretamente,  os 
registros   contábeis,   apresentar   informações   contábeis   fraudulentas   ou   transgredir   os 
controles destinados a prevenir fraudes semelhantes, cometidas por outros empregados.  
 
16. A NBC TA 315, itens 17 e 18, requer a discussão entre os membros da equipe encarregada 
do  trabalho  e  que  o  sócio  do  trabalho  determine  os  assuntos  que  devem  ser  comunicados 
aos  membros  da  equipe  não  envolvidos  na  discussão.  Essa discussão  deve  enfatizar, 
especialmente, como  e  em  que  pontos  as  demonstrações  contábeis  da  entidade  são 
suscetíveis  de  distorção  relevante  decorrente  de  fraude,  inclusive  como  a  fraude  pode 
ocorrer.  A discussão deve ocorrer deixando de lado a possível convicção dos membros da 
equipe encarregada do trabalho de que a administração e os responsáveis pela governança 
são honestos e íntegros (ver itens A10 e A11).  
 
17. Ao  aplicar  os  procedimentos  de  avaliação  de  risco  e  atividades  relacionadas  para  obter 
entendimento da entidade e do seu ambiente, da estrutura de relatório financeiro aplicável e 
do sistema de controles internos da entidade, requeridos pela NBC TA 315, o auditor deve 

 
aplicar os procedimentos previstos nos itens de 23 a 43 para obter as informações a serem 
usadas na identificação de riscos de distorção relevante decorrente de fraude.  
 
21.  A  não  ser  que  os  responsáveis  pela  governança  estejam  envolvidos  na  administração  da 
entidade (ver NBC TA 260 – Comunicação com os Responsáveis pela Governança, item 13, 
o  auditor  deve  obter  entendimento  de  como  esses  responsáveis  fazem  a  supervisão  geral 
dos  processos  da  administração  para  identificar  e  responder  aos  riscos  de  fraudes  na 
entidade e dos controles que a administração implantou para mitigar esses riscos (ver itens 
de A19 a A21). 
 
26. Nos  termos  da  NBC  TA  315,  item  28,  o  auditor  deve  identificar  e  avaliar  os  riscos  de 
distorção  relevante  decorrente  de  fraude  nos  níveis  das  demonstrações  contábeis  e  da 
afirmação por tipo de operação, saldo contábil e divulgação. 
 
28. O  auditor  deve  tratar  dos  riscos  avaliados  de  distorção  relevantes  decorrentes  de  fraude 
como riscos significativos e, por conseguinte, na medida em que ainda não tenha sido feito, 
ele  deve  identificar  os  controles  da  entidade  que  tratam desses  riscos  e  avaliar  seu 
planejamento  e  determinar  se  foram  implementados  (ver  itens  A31  e  A32 e  NBC  TA  315, 
item 26(a)(i) e (d)).  
 
45. O auditor deve incluir a seguinte documentação de auditoria (ver NBC TA 230, itens de 8 a 
11 e A6), da sua identificação e avaliação dos riscos de distorção relevante requeridas pela 
NBC TA 315, item 38: 
(a) as  decisões  significativas  tomadas  durante  a  discussão  com  a  equipe  encarregada  do 
trabalho  em  relação  à  suscetibilidade  das  demonstrações  contábeis  da  entidade  a 
distorção relevante decorrente de fraude; 
(b) os  riscos  identificados  e  avaliados  de  distorção  relevante  decorrentes  de  fraude  no 
âmbito das demonstrações contábeis e da afirmação; e 
(c) os  controles  identificados  no  componente  de  atividades  de  controle  que tratam  dos 
riscos avaliados de distorção relevante decorrente de fraude.  
 
Ceticismo profissional (ver itens de 13 a 15) 
 
A8.  Manter ceticismo profissional requer um contínuo questionamento sobre se a informação e a 
evidência de auditoria obtidas sugerem a possibilidade de distorção relevante decorrente de 
fraude.  Isso  inclui  considerar  a  confiabilidade  da  informação  a  ser  utilizada  como  evidência 
de  auditoria  e  os  controles  identificados  no  componente  de  atividades  de  controle,  se 
houver, sobre sua elaboração e manutenção.  Devido às características da fraude, a postura 
de ceticismo profissional do auditor é particularmente importante quando se consideram os 
riscos de distorção relevante decorrente de fraude.  
 
A19.  A NBC TA 315, itens 14(a) e 24(a)(ii), e a NBC TA 610 – Utilização do Trabalho de Auditoria 
Interna estabelecem requisitos  e  oferecem  orientação  nas  auditorias  de entidades  que têm 
uma  função  de  auditoria  interna.  Ao  aplicar  os  requisitos  dessas  normas  de  auditoria,  no 
contexto  de  fraude,  o  auditor  pode  fazer  indagações  sobre  atividades  específicas  do 
departamento, incluindo, por exemplo:  
• os procedimentos  aplicados, se for  o  caso,  pela função  de  auditoria  interna  ao  longo  do 
exercício para detectar fraude;  
• se a administração respondeu satisfatoriamente a quaisquer fatos identificados por meio 
desses procedimentos.  
 
A20.  Os    responsáveis    pela    governança    da    entidade    supervisionam    os    sistemas    de 
monitoramento de risco, controle financeiro e conformidade com a lei.  Em muitos países, as 
práticas   de   governança   corporativa   são   bem   desenvolvidas   e   os   responsáveis   pela 
governança  desempenham  papel  ativo  na  supervisão  geral  da  avaliação  dos  riscos  de 
fraude   e   dos   controles   que   tratam   desses   riscos.   Como   a   responsabilidade   dos 
responsáveis pela governança e pela administração pode variar dependendo da entidade e 

 
do país, é importante que o auditor entenda suas respectivas responsabilidades para obter 
entendimento  da  supervisão  geral  exercida  pelos  indivíduos  apropriados (ver  NBC  TA  260, 
itens de A1 a A8). 
 
 
A21  O  entendimento  da  supervisão  geral  exercida  pelos  responsáveis  pela  governança  pode 
oferecer  subsídios  sobre  a  suscetibilidade  da  entidade  a  fraude  pela  administração,  a 
adequação  dos controles que tratam  dos riscos de  fraude  e  a  competência  e a integridade 
da administração. O auditor pode obter esse entendimento de várias maneiras, por exemplo, 
participando  de  reuniões  onde  ocorram  tais  discussões,  lendo  atas  de  tais  reuniões  ou 
fazendo indagações junto aos encarregados da governança.  
 
 
A23  Além   das   informações   obtidas   com   a   aplicação   de   procedimentos   analíticos,   outras 
informações  obtidas  a  respeito  da  entidade  e  do  seu  ambiente, da  estrutura  de  relatório 
financeiro  aplicável  e  do  sistema  de  controles  internos  da  entidade, podem  ser  úteis  na 
identificação  dos  riscos  de  distorção  relevante  decorrente  de  fraude.  A  discussão  entre 
membros  da  equipe  pode  fornecer  informações  úteis  para  a  identificação  de  tais  riscos. 
Além  disso,  as  informações  obtidas  nos  processos  de  aceitação  e  retenção  do  cliente  pelo 
auditor,  a  experiência  conseguida  em  outros  trabalhos  executados  para  a  entidade,  por 
exemplo,  revisão  das  informações  contábeis  intermediárias,  podem  ser  relevantes  na 
identificação dos riscos de distorção relevante decorrente de fraude.  
 
A26.   Exemplos   de   fatores   de   risco   de   fraude   relacionados   com   informações   contábeis 
fraudulentas  e  apropriação  indébita  de  ativos  são  apresentados  no  Apêndice  1.  Esses 
fatores de risco ilustrativos são classificados com base em três condições que, geralmente, 
estão presentes quando há fraude:  
•   incentivo ou pressão para perpetrar fraude;  
•   oportunidade percebida de cometer fraude; e 
•   capacidade de racionalizar a ação fraudulenta.  
Os  fatores  de  risco  de  fraude  podem  estar  relacionados  com  incentivos,  pressões  ou 
oportunidades  que  surgem  de  condições  que  criam  suscetibilidade  à  distorção,  antes  da 
consideração  dos  controles.  Os fatores  de  risco de  fraude,  que  incluem viés  intencional  da 
administração, são, à medida que afetam o risco inerente, fatores de risco inerente (NBC TA 
315,  item  12(f)). Os  fatores  de  risco  de  fraude  também  podem  estar  relacionados  com 
condições  dentro  do  sistema  de  controles  internos  da  entidade  que  oferecem  oportunidade 
de  cometer  fraude  ou  que  podem  afetar  a  atitude  ou  a  capacidade  da  administração  de 
racionalizar  ações  fraudulentas.  Fatores  de  risco  que  refletem  uma  atitude  que  permite  a 
racionalização  da  ação  fraudulenta  podem  não  ser  suscetíveis  de  observação  pelo  auditor. 
Contudo,  o  auditor  pode  tomar  conhecimento  da  existência  de  tais informações  mediante, 
por exemplo, o entendimento requerido do ambiente de controle da entidade (NBC TA 315, 
item 21). Embora os fatores de risco de fraude descritos no Apêndice 1 abranjam um amplo 
leque  de  situações  que  podem  vir  a  ser  enfrentadas  pelos auditores,  eles  são  apenas 
exemplos e outros fatores de risco podem existir.  
 
A33.  Portanto,   é   importante   que   o   auditor   obtenha   entendimento   dos   controles   que   a 
administração   planejou,   implementou   e   mantém   para   impedir   e   detectar   fraude.   Ao 
identificar os controles que tratam dos riscos de distorção relevante decorrente de fraude, o 
auditor pode descobrir, por exemplo, que a administração escolheu conscientemente aceitar 
os riscos associados à falta de segregação de funções. Informações obtidas da identificação 
desses  controles  e  da  avaliação  do  seu  planejamento  e  determinação  de  que  foram 
implementados também podem ser úteis na identificação de fatores de risco de fraude que 
possam afetar a avaliação do auditor quanto aos riscos de que as demonstrações contábeis 
possam conter distorção relevante decorrente de fraude.  
 
A43.  Além  disso,  a  consideração  por  parte  do  auditor  dos  riscos  de  distorção  relevante, 
associados  com  a  transgressão  inapropriada  dos  controles  dos  lançamentos  no  livro  diário 

 
(NBC TA 315, item 26(a)(ii)) é importante, já que os processos e os controles automatizados 
podem  reduzir  o  risco  de  erro  não  intencional,  mas  não  superar  o  risco  de  que  indivíduos 
possam  transgredir  inadequadamente  tais  processos  automatizados  como,  por  exemplo, 
mudando  os  valores  que  são  automaticamente  transferidos  para  o  razão  geral  ou  para  o 
sistema  de  relatórios  financeiros.    Além  disso,  no  caso  que  se  usa  TI  para  transferir 
informações  de  forma  automática,  pode  haver  pouca  ou  nenhuma  evidência  visível  de  tal 
intervenção nos sistemas de informação. 
 
A44.  Ao  identificar  e  selecionar  lançamentos  no  livro  diário  e  outros  ajustes  para  testar  e 
determinar   o   método   apropriado   de   examinar   o   suporte   subjacente   para   os   itens 
selecionados, os seguintes assuntos são importantes:  
•  Identificação  e  avaliação  dos  riscos  de  distorção  relevante  decorrente  de  fraude – a 
presença   de   fatores   de   risco   de   fraude   e   outras   informações   obtidas   durante   a 
identificação  e a avaliação  pelo  auditor  dos  riscos  de  distorção  relevante  decorrente de 
fraude  pode  auxiliá-lo  a  identificar  classes  específicas  de  lançamentos  no  livro  diário  e 
outros ajustes a serem testados.  
•  Controles  que  foram  implementados  para  lançamentos  no  livro  diário  e  outros  ajustes – 
controles  efetivos  da  elaboração  e  do  registro  de  lançamentos  no  livro  diário  e  outros 
ajustes  podem  reduzir  a  extensão  de  testes  substantivos  necessários,  contanto  que  o 
auditor tenha testado a efetividade operacional dos controles. 
•  Processo de elaboração de informações contábeis da entidade e a natureza da evidência 
que  pode  ser  obtida – para  muitas  entidades,  o  processamento  rotineiro  de  transações 
envolve  uma  combinação de controles  manuais  e  automatizados.  Da  mesma  forma,  o 
processamento de lançamentos no livro diário e outros ajustes podem envolver controles 
manuais e automatizados. No caso que se usa tecnologia da informação no processo de 
elaboração de informação contábil, os lançamentos no livro diário e outros ajustes podem 
só existir em forma eletrônica.  
•  Características   dos   lançamentos no   livro   diário   fraudulentos   ou   outros   ajustes – 
lançamentos  no  livro  diário  inadequados  ou  outros  ajustes  muitas  vezes  têm  uma  única 
característica  de  identificação.  Tais  características  podem  incluir  lançamentos: (a)  feitos 
em  contas  não  relacionadas, não  usuais  ou  raramente  usadas; (b)  feitos  por  indivíduos 
que, geralmente, não fazem lançamentos no livro diário; (c) registrados no fim do período 
ou como lançamento pós-fechamento, com pouca ou nenhuma explicação ou descrição; 
(d) feitos antes ou durante o processo de elaboração das demonstrações contábeis que 
não têm números de conta; ou (e) que contêm números redondos ou números com finais 
constantes.  
•  Natureza   e   complexidade   das   contas – lançamentos   no   livro   diário   ou   ajustes 
inadequados  podem  ser  aplicados  a  contas  que: (a)  contenham  transações  de  natureza 
complexa  ou  incomum,  (b)  contenham  estimativas  e  ajustes  significativos  de  fim  de 
período,  (c)  tenham  sido  suscetíveis  a  distorções  no  passado,  (d)  não  tenham  sido 
conciliadas  tempestivamente  ou  contenham  diferenças  não  conciliadas,  (e)  contenham 
transações  entre  empresas  ou  (f)  estejam  associadas  de  outra  maneira  a  um  risco 
identificado de distorção relevante decorrente de fraude.  Em auditorias de entidades que 
estão   em   várias   localidades   ou   com   vários   componentes,   deve-se   considerar   a 
necessidade de selecionar lançamentos no livro diário de várias localidades.  
•  Lançamentos  no  livro  diário  ou  outros  ajustes  processados  fora  do  curso  normal  do 
negócio – lançamentos no livro diário fora de padrão podem não estar sujeitos à mesma 
natureza  e  à  mesma  extensão  dos  controles  que  os  lançamentos  no  livro  diário  usados 
recorrentemente como vendas, compras e gastos mensais.  
 
Apêndice 1 (ver item A25) 
 
Exemplos de fatores de risco de fraude 
 
Os  fatores  de  risco de  fraude  identificados  neste Apêndice são  exemplos  de  fatores  que  podem 
ser  enfrentados  pelos  auditores  em  uma  grande  variedade  de  situações.  São  apresentados 

 
separadamente   exemplos   relacionados   com   os   dois   tipos   de   fraude   relevantes   para   a 
consideração do  auditor, isto  é,  informações  contábeis  fraudulentas  e  apropriação  indébita  de 
ativos.    Para  cada  um  desses  tipos  de  fraude,  os  fatores  de  risco  são  classificados  ainda  com 
base nas três condições geralmente presentes quando ocorrem distorções relevantes decorrentes 
de  fraude:  (a)  incentivos/pressões,  (b)  oportunidades  e  (c)  atitudes/racionalizações.    Embora  os 
fatores  de  risco  abranjam  amplo  leque  de  situações,  eles  são  apenas  exemplos  e,  portanto,  o 
auditor pode identificar fatores de risco adicionais ou diferentes.  Nem todos esses exemplos são 
relevantes  em  todas  as  circunstâncias  e  alguns  podem  ter  mais  ou  menos  significado  em 
entidades   de   tamanho   diferente   ou   com   características   de   propriedade   ou   circunstâncias 
diferentes.    A  ordem  dos  exemplos  de fatores  de  risco  fornecidos  não  se  destina  a  refletir  sua 
importância relativa ou a frequência da ocorrência.  
Os   fatores   de   risco   de   fraude   podem   estar   relacionados   com   incentivos,   pressões   ou 
oportunidades   que   surgem   de   condições   que   criam   suscetibilidade à   distorção,   antes   da 
consideração  dos  controles  (isto  é,  o  risco  inerente).  Esses  fatores  de  risco  são  fatores  de  risco 
inerente, à medida que afetam o risco inerente, e podem ser decorrentes da tendenciosidade da 
administração.  Os  fatores  de  risco  de  fraude  relacionados  com  oportunidades  também  podem 
surgir de outros fatores de risco inerente identificados (por exemplo, a complexidade ou incerteza 
podem criar oportunidades que resultam em suscetibilidade à distorção decorrente de fraude). Os 
fatores  de risco  de  fraude  relacionados  com  oportunidades  também  podem  estar  relacionados 
com  condições  dentro  do  sistema  de  controles  internos  da  entidade,  tais  como  limitações  ou 
deficiências no controle interno da entidade que criam essas oportunidades. Os fatores de risco de 
fraude relacionados com atitudes ou racionalizações podem surgir, em particular, de limitações ou 
deficiências no ambiente de controle da entidade.  
(...)  
• Alta  rotatividade  da  alta  administração,  departamento  jurídico  ou  dos  responsáveis  pela 
governança. 
 
Deficiências no controle interno como resultado do que segue:  
• Processo de  monitoramento  do  sistema  de  controles  internos  da  entidade  inadequado, 
inclusive    dos    controles    automatizados    e    dos    controles    das    informações    contábeis 
intermediárias (quando há requisito de reporte externo).  
• Altas taxas de rotatividade ou o uso de pessoal de contabilidade, de tecnologia da informação 
ou da função de auditoria interna que não são eficazes. e  
• Sistemas de  contabilidade  e  de  informações  que  não  são  eficazes,  inclusive  situações  que 
envolvam deficiências significativas no controle interno.  
(...) 
 
• Ativos fixos de tamanho pequeno, comercializáveis ou sem identificação clara de propriedade.  
 
Controles inadequados  dos  ativos  podem  aumentar  a  suscetibilidade  à apropriação  indébita  dos 
ativos.  Por exemplo, a apropriação indébita de ativos pode ocorrer por causa do que segue:  
• segregação inadequada de funções ou verificações independentes;  
(...) 
  
Atitudes/racionalizações 
• Desconsideração   da   necessidade   de   monitorar   ou   reduzir   riscos   relacionados   com 
apropriações indébitas de ativos.  
• Desconsideração dos controles de apropriação indébita de ativos mediante a transgressão dos 
controles existentes ou a não tomada de medidas corretivas sobre deficiências conhecidas no 
controle interno. 
(...) 
 
Apêndice 2 (ver item A40)  
 
(...) 
Os seguintes são exemplos específicos de respostas:  

 
(...) 
• Se  o  trabalho  de  especialista  torna-se  particularmente  significativo  no  que  diz  respeito  a  um 
item da demonstração contábil com risco avaliado de distorção relevante decorrente de fraude 
avaliado  como  alto,  realizar  procedimentos  adicionais  relativos  a  algumas  ou  todas  as 
premissas,  métodos  ou  descobertas  do  especialista  para  determinar  que  as  descobertas  são 
razoáveis ou envolver outro especialista para atingir esse propósito.  
(...) 
 
8. Altera o item A21 da NBC TA 300 (R1) – Planejamento da Auditoria de Demonstrações 
Contábeis, que passa a vigorar com a seguinte redação: 
 
A21.  Conforme  mencionado  no  item  A11,  um  memorando  adequado  e  breve pode  servir  como 
documentação da estratégia da auditoria de entidade de pequeno porte.  No caso do plano 
de  auditoria,  programas  de  auditoria  padrão  ou  listas  de  verificação  (ver  item  A19), 
concebidos com base na premissa de que podem existir apenas alguns controles (NBC TA 
315,  item  26(a)),  como  é  o  caso  provável  de  entidade  de  pequeno  porte,  que  podem  ser 
usados  desde  que  sejam  adaptados  às  circunstâncias  do  trabalho,  inclusive  às  avaliações 
de riscos do auditor.  
 
 
9. Altera os itens 1, 3, 7, 10, 11, 12, 14, A19, A22, A29, A30, A33, A34 e  A39 na NBC TA 
402 – Considerações de Auditoria para a Entidade que Utiliza Organização Prestadora 
de Serviços, que passam a vigorar com as seguintes redações: 
 
1.  Esta Norma trata da responsabilidade do auditor da usuária dos serviços de obter evidência 
de  auditoria  apropriada  e  suficiente  quando  a  entidade  utiliza  os  serviços  de  uma  ou  mais 
organizações  prestadoras  de  serviços.  Especificamente,  esta Norma expande  a  explicação 
de  como  o  auditor  da  usuária  dos  serviços aplica  a  NBC  TA  315  e  a  NBC  TA  330  na 
obtenção do entendimento da entidade usuária, incluindo o sistema de controles internos da 
entidade  que  seja  relevante  para  a  elaboração  das  demonstrações  contábeis,  suficiente 
para  identificar  e  avaliar  os  riscos  de distorção  relevante,  no  planejamento  e  na  realização 
de procedimentos adicionais de auditoria que respondam a esses riscos.  
 
3. Os  serviços  prestados  por  organização  prestadora  de  serviços  são  relevantes  para  a 
auditoria  das  demonstrações  contábeis  da  entidade  usuária  quando  esses  serviços,  e  os 
controles deles, fazem parte do sistema de informações da entidade usuária de tais serviços 
que seja relevante para a elaboração das demonstrações contábeis. A maioria dos controles 
da organização prestadora de serviços, provavelmente, faz parte do sistema de informações 
da entidade usuária que seja relevante para a elaboração das demonstrações contábeis, ou 
dos  controles  relacionados,  tais  como  controles  da  salvaguarda  de  ativos.  Os  serviços 
prestados por organização prestadora de serviços são parte do sistema de informações da 
entidade usuária desses serviços se esses serviços afetam algum dos elementos a seguir:  
(a) o   modo   como   as   informações   relacionadas   com   classes   de   transações,   saldos 
contábeis   e   divulgações significativas   trafegam   pelo   sistema   de   informações   da 
entidade   usuária,   seja   manualmente   ou   usando   tecnologia   da   informação   (TI), 
independentemente  de  terem  sido  obtidas  dentro  ou  fora  do  razão  geral  e  dos  razões 
auxiliares.  Isso  inclui  quando  os  serviços prestados  pela  organização  prestadora  de 
serviços afetam o modo como: 
(i) as transações da entidade usuária são iniciadas e como as informações sobre elas 
são  registradas,  processadas,  corrigidas, conforme  necessário,  e  incorporadas  no 
razão geral e divulgadas nas demonstrações contábeis; e 
(ii) as  informações  sobre  eventos  ou  condições,  que  não  sejam  transações,  são 
capturadas,  processadas  e  divulgadas  pela  entidade  usuária  nas  demonstrações 
contábeis;  
(b) os registros contábeis, as contas específicas nas demonstrações contábeis da entidade 
usuária  e  outros  registros  de  suporte  relacionados  com  os  fluxos  de  informações  no 
item 3(a); 

 
(c) o  processo  de  relatórios  financeiros  usado  para  elaborar  as  demonstrações  contábeis 
da  entidade  usuária  a  partir  dos  registros  descritos  no  item  3(b),  inclusive  no  que  se 
refere  a  divulgações  e  estimativas  contábeis  relacionadas  com  classes  de  transações, 
saldos contábeis e divulgações significativas; e 
(d) o ambiente de TI da entidade relevante para as alíneas de (a) a (c) deste item.  
 
7. Os  objetivos  do  auditor  da  usuária,  quando  a  entidade  usuária  utiliza  os  serviços  de 
organização prestadora de serviços, são:  
(a) obter entendimento da natureza e importância dos serviços prestados pela organização 
prestadora de serviços e seus efeitos sobre o sistema de controles internos da entidade 
usuária,  suficiente  para fornecer  uma  base  apropriada  para  a  identificação  e  avaliação 
dos riscos de distorção relevante; e 
(b) planejar e realizar procedimentos adicionais de auditoria que respondam a esses riscos. 
 
10. Quando obtiver entendimento do sistema de controles internos da entidade, de acordo com 
a  NBC  TA  315, item  26(a)  e  (d), o  auditor  da  usuária  deve  identificar  controles  no 
componente de atividades de controle da entidade usuária a partir daqueles referentes aos 
serviços prestados pela organização prestadora de serviços, incluindo os que são aplicados 
às transações processadas por essa organização, e avaliar seu planejamento e determinar 
se foram implementados (ver itens de A12 a A14). 
 
 11. O  auditor  da  usuária  deve  determinar  se  foi  obtido  entendimento  suficiente  da  natureza  e 
importância  dos  serviços  prestados  pela  organização  prestadora  de  serviços  e  seu  efeito 
sobre  o  sistema  de  controles  internos  da  entidade  usuária  para  a auditoria,  para  fornecer 
uma base apropriada para a identificação e a avaliação dos riscos de distorção relevante. 
 
12. Se  o  auditor  da  usuária  não  conseguir  obter  entendimento  suficiente  da  entidade  usuária, 
ele deve obter esse entendimento por meio de um ou mais dos seguintes procedimentos: 
(...) 
(d) utilizar   outro   auditor   para   realizar procedimentos   que   forneçam as   informações 
necessárias sobre os controles da organização prestadora de serviços (ver itens de A15 
a A20). 
 
14. Se o auditor da usuária planeja utilizar o Relatório Tipo 1 ou Relatório Tipo 2 como evidência 
de  auditoria  para permitir  o  seu  entendimento  sobre  o  desenho  e  implementação  dos 
controles na organização prestadora de serviços, ele deve (ver itens A22 e A23):  
(a) (...) 
(b)  avaliar   a suficiência   e   adequação   da   evidência   fornecida   pelo   relatório   para   o 
entendimento dos controles da organização prestadora de serviços; e 
(c) (...) 
 
A19.  Outro  auditor  pode  ser  utilizado  para  realizar  procedimentos  que  forneçam as  informações 
necessárias   sobre   os   controles   relevantes   da   organização   prestadora   de   serviços 
relacionados  com  os  serviços  prestados  para  a  entidade  usuária.  No  caso  de  ter  sido 
emitido  Relatório  Tipo  1  ou  Relatório  Tipo  2,  o  auditor  da  usuária  pode  usar  o  auditor  da 
organização  prestadora  de  serviços  para  realizar  esses  procedimentos, uma  vez  que  já 
existe  uma  relação  entre  esse  auditor e a  organização  prestadora  de  serviços.    O  auditor 
que usa o trabalho de outro auditor pode achar a orientação da NBC TA 600 útil, pois ela se 
refere ao  entendimento  sobre  outro  auditor  (incluindo  a  independência  e  a  competência 
profissional desse auditor), no envolvimento no trabalho desse outro auditor para planejar a 
natureza, a época e a extensão desse trabalho, e à avaliação da suficiência e adequação da 
evidência de auditoria obtida.  
 
A22.  O  Relatório  Tipo  1  ou  Relatório  Tipo 2,  juntamente  com  as  informações  sobre  a  entidade 
usuária, pode auxiliar o auditor da usuária a obter entendimento:  

 
(a) dos aspectos dos controles da organização prestadora de serviços que podem afetar o 
processamento  das  transações  da  entidade  usuária,  incluindo  o  uso  de  organizações 
subcontratadas para prestação de serviços;  
(b) do  fluxo  de  transações  significativas  pela  organização  prestadora  de  serviços  para 
determinar em  quais  etapas  do  processo  das  transações  poderiam  ocorrer  distorções 
relevantes nas demonstrações contábeis da entidade usuária;  
(c) dos  objetivos  dos  controles  da  organização  prestadora  de  serviços  que são  relevantes 
para as afirmações nas demonstrações contábeis da entidade usuária; e 
(d) se   os   controles   da   organização   prestadora   de serviços   foram   adequadamente 
desenhados  e  implementados  para  evitar  ou  detectar  erros  de  processamento  que 
poderiam  resultar  em  distorções  relevantes  nas  demonstrações  contábeis  da  entidade 
usuária.  
O  Relatório  do  Tipo  1  ou  Tipo  2  pode  auxiliar  o  auditor da  usuária  a  obter  entendimento 
suficiente para identificar e avaliar os riscos de distorção relevante.  Entretanto, o Relatório 
Tipo 1 não fornece nenhuma evidência da efetividade operacional dos controles.  
 
A29.  É  requerido  do  auditor  da  usuária,  segundo  a  NBC  TA  330,  planejar  e  realizar  testes  de 
controles  para  obter  evidência  de  auditoria  apropriada  e  suficiente  sobre  a  efetividade 
operacional   de   controles   em   certas   circunstâncias.   No   contexto   de   organização   de 
prestadora de serviços, esse requisito se aplica quando:  
(a) (...) 
 
A30.  Se  o  Relatório  Tipo  2  não  estiver  disponível,  o  auditor  da  usuária  pode  entrar  em  contato 
com a organização prestadora de serviços por meio da entidade usuária para requerer que 
seja  contratado  um  auditor  pela  organização  prestadora  de  serviços  para  fornecer  o 
Relatório Tipo 2 que inclua testes da efetividade operacional dos controles, ou o auditor da 
usuária pode utilizar outro auditor para realizar procedimentos na organização prestadora de 
serviços que testem a efetividade operacional desses controles. O auditor da usuária pode, 
também,  visitar  a  organização  prestadora  de  serviços  e  realizar  testes  dos  controles  se  a 
organização  prestadora  de serviços  concordar.  As  avaliações  de  riscos  do  auditor  da 
usuária baseiam-se na evidência combinada fornecida pelo trabalho de outro auditor e pelos 
procedimentos realizados pelo próprio auditor da usuária.  
 
A33.  Pode  ser  necessário,  também,  que  o  auditor da  usuária  obtenha  evidência  adicional  sobre 
mudanças  significativas  nos  controles da  organização  prestadora  de  serviços  fora  do 
período  coberto   pelo  Relatório   Tipo   2   ou   determine   a   realização  de   procedimentos 
adicionais  de  auditoria.    Os  fatores  relevantes  na  determinação  de  qual  evidência  de 
auditoria  adicional  obter  sobre  os  controles da  organização  prestadora  de  serviços,  que 
estavam  em  operação  fora  do  período  coberto  pelo  relatório  do  auditor  da  organização 
prestadora de serviços, podem incluir:  
•   (...) 
•  a  eficácia  do  ambiente  de  controle  e  o  processo  da  entidade  de  monitoramento  do 
sistema de controles internos.  
 
A34.  Pode  ser  obtida  evidência  adicional  de  auditoria,  por  exemplo,  estendendo  os  testes  dos 
controles pelo período remanescente ou testando o processo da entidade de monitoramento 
do sistema de controles internos.  
 
A39.  O  auditor  da  usuária  deve  comunicar  por  escrito  e  tempestivamente  as  deficiências 
significativas  do  controle  interno  identificadas  durante  a  auditoria  à  administração  e aos 
responsáveis  pela  governança (NBC  TA  265,  itens  9  e  10).  O  auditor  da  usuária  também 
deve    comunicar    tempestivamente    à    administração    em    um    nível    apropriado    de 
responsabilidade  outras  deficiências  do  controle  interno  identificadas  durante  a  auditoria 
que, no  seu julgamento profissional,  são  de  importância  suficiente  para merecer  a  atenção 
da  administração (NBC  TA  265,  item  10).  Os  assuntos  que  o  auditor  da  usuária  pode 
identificar  durante  a  auditoria  e  comunicar  à  administração  e  aos  responsáveis  pela 
governança da entidade usuária incluem:  

 
•   quaisquer controles no processo da entidade de monitoramento do sistema de controles 
internos   que   podem   ser   implementados   pela   entidade   usuária,   incluindo   aqueles 
identificados em decorrência de se obter Relatório Tipo 1 ou Relatório Tipo 2;  
•  (...) 
 
 
10. Na NBC TA 330 (R1) – Resposta do Auditor aos Riscos Avaliados: 
(a) elimina o item A31 existente e inclui os itens A30, A31 e A44; 
(b) em  razão  da  inclusão  dos  itens  A30,  A31  e A44  e  da  eliminação  do  item  A31, 
renumera  os  itens  de  A30 a  A42 existentes  para  A32 a  A43  e de  A43 a  A63 
existentes para A45 a A65; 
(c) altera  os  itens 1, de  6  a  8,  10,  de  13  a  17,  27,  28,  A1,  A4,  A7,  A9,  A10, A18, A20, 
A24, A27, A29, A32, A33, A36, A37, A39, A43 e seu título, A47, A48, A49, A58, A59, 
A62, A64 e A65, após a renumeração; 
(d) altera as referências relativas a esta Norma, nesta e em outras normas, quando for 
o caso, em razão da inclusão e da renumeração de itens. 
 
1. Esta Norma trata  da  responsabilidade  do  auditor  ao  planejar  e  implementar  respostas aos 
riscos  de  distorção  relevante,  identificados  e  avaliados  pelo  auditor, de  acordo  com  a  NBC 
TA  315 – Identificação  e  Avaliação  dos  Riscos  de  Distorção  Relevante, na  auditoria  de 
demonstrações contábeis. 
 
6. O  auditor  deve  planejar  e  realizar  procedimentos  adicionais  de  auditoria,  cuja  natureza, 
época e extensão se baseiam e respondem aos riscos avaliados de distorção relevante no 
nível da afirmação (ver itens de A4 a A8 e de A43 a A54). 
 
7. Ao planejar procedimentos adicionais de auditoria a serem realizados, o auditor deve: 
(a) considerar as razões para a avaliação atribuída ao risco de distorção relevante no nível 
da afirmação para cada classe de transações, saldo contábil e divulgação significativa, 
incluindo: 
(i) a  probabilidade  e  magnitude  da  distorção  devido  às  características  particulares  da 
classe  de  transações,  saldo  contábil ou  divulgação  significativa  (isto  é,  risco 
inerente); e 
(ii) se  a  avaliação  de  risco  leva  em  consideração  os  controles  que tratam  do  risco  de 
distorção relevante (isto é, risco de controle), exigindo assim que o auditor obtenha 
evidência de auditoria para determinar se os controles estão operando efetivamente 
(isto  é,  o  auditor  planeja  testar  a  efetividade  operacional  dos  controles  para 
determinar a natureza, a época e a extensão dos procedimentos substantivos) (ver 
itens de A9 a A18); e 
(b) obter  evidência de  auditoria  mais  persuasiva  quanto  maior  for  a  avaliação  de  risco  do 
auditor (ver item A19). 
 
8. O  auditor  deve  planejar  e  realizar  testes  de  controle  para  obter  evidência de  auditoria 
apropriada e suficiente quanto à efetividade operacional dos controles se: 
(a) a avaliação de riscos de distorção relevante no nível da afirmação pelo auditor inclui a 
expectativa  de  que  os  controles  estão  operando  efetivamente (isto é,  o auditor  planeja 
testar a efetividade operacional dos controles para determinar a natureza, a época e a 
extensão dos procedimentos substantivos); ou 
(b) somente os procedimentos substantivos não conseguem fornecer evidência de auditoria 
apropriada e suficiente no nível da afirmação (ver itens de A20 a A24). 
 
10. Ao planejar e realizar os testes de controle, o auditor deve: 
(a) realizar  outros  procedimentos  de  auditoria  juntamente  com  indagação  para  obter 
evidência de auditoria sobre a efetividade operacional dos controles, incluindo: 
(i) o modo como os controles foram aplicados ao longo do período; 
(ii) a consistência como eles foram aplicados; e 
(iii) por quem ou por quais meios eles foram aplicados (ver itens de A26 a A30); 

 
(b) na medida em que ainda não tenham sido tratados, determinar se os controles a serem 
testados  dependem  de  outros  controles  (controles  indiretos)  e,  caso  afirmativo,  se  é 
necessário obter evidência de auditoria que suporte a operação efetiva desses controles 
indiretos (ver item A32). 
 
13. Para determinar se é apropriado usar evidência de auditoria da efetividade operacional dos 
controles obtida em auditorias anteriores e, caso afirmativo, a duração do período de tempo 
que  pode  decorrer  antes  de  testar  novamente  o  controle,  o  auditor  deve considerar  o 
seguinte: 
(a) a  efetividade  dos  outros  componentes  do  sistema  de  controles  internos  da  entidade, 
incluindo o ambiente de controle, o processo de monitoramento do sistema de controles 
internos pela entidade e o seu processo de avaliação de risco; 
(b) os  riscos  decorrentes  das  características  do  controle,  incluindo  se  ele  é  manual  ou 
automatizado; 
(c) a efetividade dos controles gerais de tecnologia da informação (TI); 
(d) a  efetividade  do  controle  e  sua  aplicação  pela  entidade,  incluindo  a  natureza  e  a 
extensão de desvios na aplicação do controle observados nas auditorias anteriores e se 
houve  mudanças  de  pessoal  que  afetaram  de  forma  significativa  a  aplicação  do 
controle; 
(e) se a falta de alteração em um controle em particular oferece risco devido às mudanças 
de circunstâncias; e 
(f) os riscos de distorção relevante e a extensão da confiança no controle (ver item A36). 
 
14. Se  o  auditor  planeja  usar  a  evidência  de  auditoria  da  auditoria  anterior  a  respeito  da 
efetividade  operacional  de  controles específicos,  o  auditor  deve  estabelecer  se  essa 
evidência  continua  relevante  e  confiável  mediante  a  obtenção  de  evidência  de  auditoria 
quanto à ocorrência, ou não, de  alterações  significativas  nesses  controles  após  a  auditoria 
anterior.   O   auditor   deve   obter essa   evidência   mediante   indagação,   juntamente   com 
observação ou inspeção, para confirmar o entendimento desses controles específicos, e: 
(a) se  houve  alterações  (nos  controles)  que  afetam  a  continuidade  da  relevância  da 
evidência  de  auditoria  de  trabalho anterior,  o  auditor  deve  testar  os  controles  na 
auditoria corrente (ver item A37); 
(b) se não houve essas alterações, o auditor deve testar os controles pelo menos uma vez 
a  cada três  auditorias  e deve  testar  alguns  desses  controles  em  todas  as  auditorias, a 
fim  de  evitar  a  possibilidade  de  testar  todos  os  controles  nos  quais  o  auditor  pretende 
confiar em um único período de auditoria e não testar os controles nos dois períodos de 
auditoria subsequentes (ver itens de A38 a A40). 
 
15. Se  o  auditor  pretende confiar  em  controles  de  um  risco  determinado  como  significativo,  o 
auditor deve testar esses controles no período corrente. 
 
16. Ao  avaliar  a  efetividade  operacional  dos  controles  nos  quais  o  auditor  pretende  confiar,  o 
auditor   deve   avaliar   se   as   distorções que   foram   detectadas   pelos   procedimentos 
substantivos  indicam  que  os  controles  não estão  operando  efetivamente.  A  ausência  de 
detecção  de  distorções  por  procedimentos  substantivos,  entretanto,  não  fornece  evidência 
de auditoria de que os controles relacionados com a afirmação que está sendo testada são 
efetivos (ver item A41). 
 
17. Quando são detectados desvios de controles nos quais o auditor pretende confiar, o auditor 
deve  fazer   indagações   específicas   para   entender   esses   assuntos   e   suas   potenciais 
consequências e deve determinar se (ver item A42): 
(a) os  testes  de  controle  realizados fornecem  uma  base  apropriada  para  se  confiar  nos 
controles; 
(b) são necessários testes adicionais de controle; ou 
(c) os   riscos   de   distorção   relevante   precisam   ser   tratados usando   procedimentos 
substantivos.  
 

 
27. Se o auditor não obteve evidência de auditoria apropriada e suficiente relacionada com uma 
afirmação relevante sobre uma classe de transações, saldo contábil ou divulgação, o auditor 
deve  tentar  obter  evidência  adicional  de  auditoria.  Se  o  auditor  não  conseguir  obter 
evidência apropriada e suficiente, o auditor deve expressar opinião com ressalva ou abster-
se de opinar sobre as demonstrações contábeis.  
 
28. O auditor deve incluir na documentação de auditoria (ver NBC TA 230, itens de 8 a 11 e A6: 
(a) as respostas gerais para tratar dos riscos avaliados de distorção relevante no nível das 
demonstrações  contábeis  e  a  natureza,  a  época  e  a  extensão  dos  procedimentos 
adicionais de auditoria realizados; 
(b) o relacionamento desses procedimentos com os riscos avaliados no nível da afirmação; 
e 
(c) os  resultados  dos  procedimentos  de  auditoria,  incluindo  as  conclusões  nos  casos  em 
que eles não estiverem de outra forma claros (ver item A65). 
 
A1. As  respostas  gerais  para  tratar  dos  riscos  avaliados  de  distorção  relevante  no  nível  das 
demonstrações contábeis podem incluir: 
•  enfatizar para a equipe de auditoria a necessidade de manter o ceticismo profissional; 
 designar   pessoal   mais   experiente   ou   aqueles   com   habilidades   especiais ou   usar 
especialistas; 
•  alterações  na  natureza,  na  época  e  na  extensão  do  direcionamento  e  da  supervisão  da 
equipe encarregada do trabalho e da revisão do trabalho realizado; 
•  incorporar  elementos  adicionais  de  imprevisibilidade  na  seleção  dos  procedimentos 
adicionais de auditoria a serem realizados; 
•  alterações  na  estratégia  global  de auditoria, conforme  requerido  pela  NBC  TA  300,  ou 
nos procedimentos de auditoria planejados, podendo incluir alterações: 
o na determinação pelo auditor de materialidade para realização da auditoria, de acordo 
com a NBC TA 320; 
o nos planos do auditor de testar a efetividade operacional dos controles e a capacidade 
de   persuasão   da   evidência   de   auditoria   necessária   para   suportar   a   confiança 
planejada  sobre  a  efetividade  operacional dos  controles,  em  especial  quando  são 
identificadas deficiências no ambiente de controle ou nas atividades de monitoramento 
da entidade; 
o na  natureza,  na  época  e  na  extensão  dos  procedimentos  substantivos.  Por  exemplo, 
pode  ser  apropriado  realizar  procedimentos  substantivos  na  data  das  demonstrações 
contábeis  ou  em  uma  data  próxima  a  ela quando  o  risco  de  distorção  relevante  for 
avaliado como alto. 
 
A4.  A avaliação do auditor dos riscos identificados de distorção relevante no nível da afirmação 
fornece  base  para  a  consideração  da  abordagem  de  auditoria  apropriada  para  planejar  e 
realizar procedimentos adicionais de auditoria. Por exemplo, o auditor pode determinar que: 
(a) somente  mediante  a  realização  de  testes  de  controle  é  que  o  auditor  pode  obter 
resposta  eficaz  ao  risco  avaliado  de  distorção  relevante  em  uma  afirmação  em 
particular; 
(b) somente a realização de procedimentos substantivos é apropriada para afirmações em 
particular  e,  portanto,  o  auditor  exclui  o  efeito  dos  controles  da  avaliação  do  risco de 
distorção relevante. Isso pode ser porque o auditor não identificou um risco para o qual 
somente os procedimentos substantivos não conseguem fornecer evidência de auditoria 
apropriada  e  suficiente  e,  portanto,  não  precisa  testar  a  efetividade  operacional  dos 
controles.  Portanto,  o  auditor  pode  não  planejar  testar  a  efetividade  operacional  dos 
controles  para  determinar  a  natureza,  a  época  e  a  extensão  dos  procedimentos 
substantivos; ou 
(c) uma  abordagem  combinada,  que  usa  tanto  testes  de  controle  como  procedimentos 
substantivos é uma abordagem eficaz. 
O  auditor  não  precisa  planejar  e  realizar  procedimentos  adicionais  de  auditoria  quando  a 
avaliação  do  risco  de  distorção  relevante  estiver  abaixo  de  um  nível  aceitavelmente  baixo. 
Entretanto,   conforme   requerido   pelo   item   18,   independentemente   da   abordagem 

 
selecionada  e  do  risco  avaliado  de distorção  relevante,  o  auditor  planeja  e  realiza  os 
procedimentos  substantivos  para  cada  classe  de  transações,  saldo  contábil  e  divulgação 
relevante. 
 
A7.  A  extensão  do  procedimento  de  auditoria  se  refere  à  quantidade  a  ser  realizada,  por 
exemplo, o tamanho da amostra ou a quantidade de observações de um controle. 
 
A9.  A NBC TA 315, itens 31 e 34) requer que a avaliação dos riscos de distorção relevante no 
nível  da  afirmação  pelo  auditor  seja  realizada  avaliando-se  o  risco  inerente  e  o  risco  de 
controle. O  auditor  avalia  o  risco  inerente analisando a  probabilidade  e  magnitude  de  uma 
distorção levando em consideração a maneira e o grau em que os fatores de risco inerente 
afetam  a  suscetibilidade  à  distorção  de  afirmações  relevantes.  Os  riscos  avaliados  pelo 
auditor,  incluindo  as  razões  desses  riscos  avaliados,  podem  afetar  tanto  os  tipos  de 
procedimentos de auditoria a serem realizados como sua combinação. Por exemplo, quando 
um risco avaliado é alto, o auditor pode confirmar a integridade dos termos de um contrato 
com a contraparte, além de inspecionar o documento. Além disso, certos procedimentos de 
auditoria  podem  ser  mais  apropriados  para  algumas  afirmações  do  que  para  outras.    Por 
exemplo,  com  relação  à  receita,  os  testes  de  controle  podem  fornecer  mais respostas  ao 
risco  avaliado  de  distorção  relevante  da  afirmação  de  integridade,  enquanto que os 
procedimentos  substantivos  podem  fornecer  mais  respostas  ao  risco  avaliado de distorção 
relevante da afirmação de ocorrência. 
 
A10.  As razões para a avaliação atribuída a um risco são relevantes para determinar a natureza 
dos  procedimentos  de  auditoria.  Por  exemplo,  se  o  risco  avaliado  for  menor  devido  às 
características  particulares  de  uma  classe  de  transações  sem  considerar  os  respectivos 
controles, o auditor pode determinar que somente os procedimentos analíticos substantivos 
fornecem evidência de auditoria apropriada e suficiente.  Por outro lado, se o risco avaliado 
for menor porque o auditor planeja testar a efetividade operacional dos controles e o auditor 
pretende  basear  os  procedimentos  substantivos  nessa  avaliação,  então,  o  auditor  realiza 
testes  desses  controles,  conforme  requerido  no  item  8(a).    Esse  pode  ser  o  caso,  por 
exemplo, para uma classe de transações de características razoavelmente uniformes e não 
complexas   que   são   processadas   e   controladas   de   forma   rotineira   pelo   sistema   de 
informações da entidade. 
 
A18.  No  caso  de  entidades  de  pequeno  porte, é  possível não haver  muitos  controles  que 
poderiam ser identificados pelo auditor ou a extensão na qual sua existência ou operação foi 
documentada pela entidade pode ser limitada. Nesses casos, a aplicação de procedimentos 
adicionais de auditoria que são, principalmente, procedimentos substantivos, pode ser mais 
eficaz.   Em   alguns   casos   raros,   entretanto, a   ausência   de   controles   ou   de   outros 
componentes do sistema de controles internos pode impossibilitar a obtenção de evidência 
de auditoria apropriada e suficiente. 
 
A20.  Os  testes  de  controles  são  realizados  somente  para  aqueles  controles  que  o  auditor 
determinou   serem   devidamente   planejados   para   evitar,   detectar   e   corrigir   distorção 
relevante   em   afirmação   relevante   e   que   o   auditor   planeja   testar.   Se   controles 
substancialmente  diferentes  foram  usados  em  épocas  diferentes  durante  o  período  de 
auditoria, cada um é considerado separadamente. 
 
A24.  Em  alguns  casos,  o  auditor  pode  achar  impossível  planejar  procedimentos  substantivos 
efetivos  que,  por  si só,  forneçam  evidência de auditoria  apropriada  e  suficiente  no  nível  da 
afirmação (ver  NBC  TA  315,  item 33). Isso  pode  ocorrer  quando  a  entidade  conduz  seus 
negócios  usando Tecnologia  da Informação (TI) e nenhuma documentação das transações 
é  produzida  ou  mantida  que  não  aquelas do  sistema  de  TI.    Nesses  casos,  o  item  8(b) 
requer  que  o  auditor  realize  testes  dos controles  que  tratam  do  risco  de  somente  os 
procedimentos  substantivos  não  conseguirem  fornecer  evidência  de  auditoria  apropriada  e 
suficiente. 
 

 
A27.  A natureza do controle em particular influencia o tipo de procedimento necessário para obter 
evidência de auditoria da efetividade operacional do controle.  Por exemplo, se a efetividade 
operacional  é  evidenciada  por  documentação,  o  auditor  pode  decidir  inspecioná-la  para 
obter evidência de auditoria da efetividade operacional. Para outros controles, entretanto, a 
documentação   pode   não   estar   disponível   ou   não   ser   relevante.   Por   exemplo,   a 
documentação  da  operação  pode  não  existir  para  alguns  fatores  do  ambiente  de  controle, 
como delegação de autoridade e responsabilidade, ou para alguns tipos de controles, como 
controles  automatizados.    Nessas  circunstâncias,  a  evidência  de  auditoria  da  efetividade 
operacional pode ser obtida por meio de indagação em conjunto com outros procedimentos 
de auditoria, como observação ou o uso de TAAC. 
 
A29.  Devido  à  consistência inerente  do  processamento  da Tecnologia  da Informação  (TI),  pode 
não  ser  necessário  aumentar  a  extensão  do  teste  de  controle  automatizado.    Pode-se 
esperar  que  o  controle automatizado  funcione  de  forma  consistente, a  menos  que  o 
aplicativo  de  TI  (incluindo tabelas,  arquivos  e  outros  dados  permanentes  usados  pelo 
aplicativo   de   TI)   seja   alterado.   Uma   vez   que   o   auditor   determina   que   o   controle 
automatizado está funcionando conforme pretendido (o que pode ser feito no momento em 
que  o  controle  é  inicialmente  implementado  ou  em  alguma  outra  data),  o  auditor  pode 
considerar  a  realização  de  testes  para  determinar  que  esse  controle  continua  funcionando 
efetivamente. Esses testes podem incluir testar os controles gerais de TI relacionados com o 
aplicativo de TI. 
 
A30.  Da  mesma  forma,  o  auditor  pode  realizar  testes  de  controles  que  tratam  dos  riscos  de 
distorção  relevante  relacionados  com  a  integridade  dos  dados  da  entidade  ou  com  a 
integridade  e  exatidão  de  relatórios  da  entidade  gerados  por  sistema,  ou  para  tratar  dos 
riscos  de  distorção  relevante  para  os  quais  somente  os  procedimentos  substantivos  não 
conseguem fornecer evidência de auditoria apropriada e suficiente. Esses testes de controle 
podem  incluir  testes  de  controles  gerais  de  TI  que  tratam  dos  assuntos  no  item  10(a). 
Quando  esse  é  o  caso,  o  auditor  pode  não  precisar  realizar  nenhum  teste  adicional  para 
obter evidência de auditoria sobre os assuntos no item 10(a). 
 
A31.  Quando o auditor determina que um controle geral de TI é deficiente, ele pode considerar a 
natureza  dos  riscos  relacionados  decorrentes  do  uso  de  TI  que  foram  identificados  de 
acordo com a NBC TA 315, item 26(c)(i), a fim de fornecer a base para o planejamento dos 
procedimentos  adicionais  do  auditor  para  tratar  do  risco  avaliado  de  distorção  relevante. 
Esses procedimentos podem tratar da determinação de: 
•   se  os  riscos  relacionados  decorrentes  de  TI  ocorreram.  Por  exemplo,  se  usuários  têm 
acesso  não  autorizado a um  aplicativo  de  TI  (mas  não  podem  acessar  ou  modificar  os 
registros do sistema que rastreiam o acesso), o auditor pode inspecionar os registros do 
sistema  para  obter  evidência  de  auditoria  de  que  esses  usuários  não  acessaram  o 
aplicativo de TI durante o período; 
•  se há quaisquer controles gerais de TI, substitutos ou redundantes, ou quaisquer outros 
controles  que  tratam  dos  riscos  relacionados  decorrentes  do  uso  de  TI.  Em  caso 
afirmativo, o auditor pode identificar esses controles (se não estiverem já identificados) e, 
portanto, avaliar seu planejamento, determinar que foram implementados e realizar testes 
de sua efetividade operacional. Por exemplo, se um controle geral de TI relacionado com 
acesso de usuários é deficiente, a entidade pode ter um controle substituto pelo qual os 
gestores   de   TI   revisam   relatórios   de   acesso   a   usuários   finais   tempestivamente. 
Circunstâncias em que um controle de aplicativo pode tratar um risco decorrente do uso 
de  TI  podem  incluir  quando  as  informações  que  podem  ser  afetadas pela  deficiência  de 
controle geral de TI podem ser conciliadas com fontes externas (por exemplo, um extrato 
bancário)  ou  fontes  internas  não  afetadas  pela  deficiência  de  controle  geral  de  TI  (por 
exemplo, um aplicativo de TI separado ou uma fonte de dados separada). 
 
A32.  Em algumas circunstâncias, pode ser necessário obter evidência de auditoria que suporte a 
operação  efetiva  dos  controles  indiretos  (por  exemplo,  controles  gerais  de  TI).  Conforme 
explicado  nos  itens de A29  a  A31, da  NBC  TA  315, controles gerais  de  TI  podem  ter  sido 

 
identificados   devido   ao   fato   de   suportarem   a   efetividade operacional   de   controles 
automatizados  ou  a  manutenção  da  integridade  das  informações  usadas  nos  relatórios 
financeiros  da  entidade,  incluindo  relatórios  gerados  por  sistema.  O  requisito  no  item  10(b) 
reconhece que o auditor pode já ter testado determinados controles indiretos para tratar dos 
assuntos no item 10(a). 
 
A33.  Evidência  de  auditoria  relativa  a  um  determinado  momento  pode  ser  suficiente  para  o 
propósito do auditor, por exemplo, quando estiver testando os controles da contagem física 
do estoque no final do período. Se, por outro lado, o auditor pretende confiar em um controle 
durante um período, são apropriados os testes que fornecem evidência de auditoria de que 
o controle operou efetivamente ao longo desse período.  Esses testes podem incluir testes 
de controle no processo de monitoramento do sistema de controles internos pela entidade. 
 
A36.  Em  algumas  circunstâncias,  a  evidência  de  auditoria  obtida  em  auditorias  anteriores  pode 
fornecer evidência de auditoria quando o auditor realiza os procedimentos de auditoria para 
estabelecer que os controles continuam relevantes e confiáveis. Por exemplo, na realização 
da  auditoria  anterior,  o  auditor  pode  ter  determinado que  um  controle  automatizado  estava 
funcionando  conforme  pretendido.    O  auditor  pode obter  evidência  de  auditoria  para 
determinar  se  foram  efetuadas  alterações  no  controle  automatizado  que  afetam  seu 
funcionamento efetivo e contínuo por meio, por exemplo, de indagações à administração e à 
inspeção  de  registros  para  indicar  quais  controles foram  alterados.    A  consideração  da 
evidência  de  auditoria  dessas  alterações  pode  corroborar  o  aumento  ou  a  redução  da 
evidência  de  auditoria  da  efetividade  operacional  dos controles  que  se  espera  obter  no 
período corrente. 
 
A37.  As alterações podem afetar a relevância e a confiabilidade da evidência de auditoria obtida 
em  trabalhos  anteriores  de  forma  que  não  haja  mais  base  para  continuar  a  confiar.    Por 
exemplo,  alterações no sistema  que  permitem  a  emissão  de  novo  relatório  provavelmente 
não  afetam  a  relevância  da  evidência  de  auditoria  obtida  na  auditoria  anterior.  Entretanto, 
uma  alteração  que  faz  com  que  os  dados  sejam  acumulados  ou  calculados  de  forma 
diferente afeta a relevância da evidência de auditoria. 
 
A39.  Em geral, quanto maior for o risco de distorção relevante ou quanto mais alta for a confiança 
nos  controles,  menor  deve  ser  o  lapso  de  tempo  transcorrido,  se  houver.    Os  fatores  que 
podem  reduzir  o  período  para a  realização  de  novo  teste  de  controle  ou  resultar  na  falta 
absoluta  de  confiança na  evidência  de  auditoria  obtida  em  auditorias  anteriores  incluem  o 
seguinte: 
•   ambiente de controle deficiente; 
•   deficiência   no   processo   de   monitoramento   do   sistema   de   controles   internos   pela 
entidade; 
•   elemento manual significativo para controles; 
•   alterações no pessoal que afetam a aplicação do controle de forma significativa; 
•   circunstâncias variáveis que indicam a necessidade de alterações no controle; e 
•   controles gerais deficientes de Tecnologia da Informação (TI). 
 
Procedimentos substantivos (ver itens 6 e 18) 
 
A43.  O  item  18  requer  que  o  auditor  planeje  e  realize  procedimentos  substantivos  para  cada 
classe de transações, saldo contábil e divulgações relevantes. Para classes de transações, 
saldos contábeis e divulgações significativas, procedimentos substantivos podem já ter sido 
realizados porque o item 6 requer que o auditor planeje e realize procedimentos adicionais 
de  auditoria  que  respondam  aos  riscos  avaliados  de  distorção  relevante  no  nível  da 
afirmação. Assim sendo, os procedimentos substantivos devem ser planejados e realizados 
de acordo com o item 18: 

 
•   quando  os  procedimentos  adicionais  de  auditoria  para  classes  de  transações,  saldos 
contábeis ou divulgações significativas planejados e realizados, de acordo com o item 6, 
não incluíram procedimentos substantivos; ou 
•  para  cada  classe  de  transações,  saldo  contábil  ou  divulgação  que  não  seja  uma  classe 
de  transações,  saldo  contábil  ou  divulgação  significativa,  mas  que  foi  identificada  como 
relevante, de acordo com a NBC TA 315, item 36; 
•  esse requisito  reflete  os  fatos  de  que:  (a)  a  avaliação  de  risco  do  auditor  é  questão  de 
julgamento e, portanto, pode não identificar todos os riscos de distorção relevante; e (b) 
há  limitações  inerentes  aos  controles,  incluindo  a  transgressão  dos  controles pela 
administração. 
 
A44.  Nem  todas  as  afirmações  em  uma  classe  de  transações,  saldo  contábil  ou  divulgação 
devem  ser  testadas.  Em  vez  disso,  ao  planejar  procedimentos  substantivos  a  serem 
realizados,  a  consideração  do  auditor  sobre  as  afirmações  nas  quais,  caso  uma  distorção 
fosse  ocorrer,  há  uma  possibilidade  razoável  de  a  distorção  ser  relevante  pode  ajudar  a 
identificar  a  natureza,  a  época  e  a  extensão  apropriadas  dos procedimentos  a  serem 
realizados. 
 
A47.  A avaliação do risco ou a natureza da afirmação é relevante para o planejamento dos testes 
de detalhes.  Por exemplo, os testes de detalhes relacionados com afirmação de existência 
ou  de  ocorrência  podem  envolver  a seleção  a  partir  de  itens  incluídos  em  um  saldo  da 
demonstração contábil e a obtenção da evidência relevante de auditoria.  Por outro lado, os 
testes de detalhes relacionados com a afirmação de integridade podem envolver a seleção a 
partir  de  itens  que  devem  ser  incluídos  no  valor  relevante  da  demonstração  contábil  e  a 
investigação quanto à sua inclusão. 
 
A48.  Como a avaliação de risco de distorção relevante leva em consideração os controles que o 
auditor  planeja  testar,  a  extensão  dos  procedimentos  substantivos  pode  precisar  ser 
aumentada  quando  os  resultados  dos  testes  de  controle  são  insatisfatórios.  Entretanto,  o 
aumento  da  extensão  de  um  procedimento  de  auditoria  é  apropriado  somente  se  o 
procedimento de auditoria em si é relevante para o risco específico.  
 
A49.  Ao planejar os testes de detalhes, a sua extensão é geralmente considerada em termos do 
tamanho  da  amostra.  Entretanto,  outros  assuntos  são  também  relevantes,  incluindo  se  é 
mais eficaz usar outros meios seletivos de teste  (ver NBC TA 500, item 10). 
 
A58.  A  realização  de  procedimentos  substantivos  em  data  intermediária  sem a  realização  de 
procedimentos  adicionais  em  data  posterior  aumenta  o  risco  de  que  o  auditor  não  detecte 
distorção que possa existir no final do período.  Esse risco aumenta à medida que o período 
remanescente é maior. Fatores como os que são apresentados a seguir podem influenciar a 
decisão de realizar procedimentos substantivos em data intermediária: 
•   o ambiente de controle e outros controles; 
•   a disponibilidade, em data posterior, das informações necessárias para os procedimentos 
do auditor; 
•   a finalidade de procedimento substantivo; 
•   o risco avaliado de distorção relevante; 
•   a natureza da classe de transações ou do saldo contábil e as respectivas afirmações; e 
•   a   capacidade   do   auditor   de   realizar   procedimentos   substantivos   apropriados   ou 
procedimentos  substantivos  combinados  com  testes  de  controle  para  cobrir  o  período 
remanescente  para  reduzir  o  risco  de  que  possíveis  distorções  existentes  no  final  do 
período não sejam detectadas. 
 
A59.  Fatores  como  os  que  são  apresentados  a  seguir  podem  influenciar  a  decisão  de  realizar 
procedimentos analíticos substantivos com relação ao período entre a data intermediária e o 
final do período: 

 
•  se  os  saldos  do  final  do  período  de uma  classe  específica  de  transações  ou  de  saldo 
contábeis  são  razoavelmente  previsíveis  com  relação  ao  valor,  significância  relativa  e 
composição; 
•  se os procedimentos da entidade para analisar e ajustar essas classes de transações ou 
saldos  contábeis  em  datas  intermediárias  e  para  estabelecer  que  cortes  contábeis  são 
apropriados; 
•   se  o  sistema  de  informações  fornecerá  informações  referentes  aos  saldos  no  final  do 
período  e  às  transações  do  período  remanescente  que  são  suficientes  para  permitir  a 
investigação de: 
(a) transações ou lançamentos não usuais significativos (incluindo aqueles próximos ao 
final ou no final do período); 
(b) outras   causas   de   flutuações   significativas   ou   flutuações   esperadas   que   não 
ocorreram; e  
(c) alterações na composição das classes de transações ou dos saldos contábeis. 
 
A62.  A auditoria das demonstrações contábeis é um processo acumulativo e contínuo. À medida 
que o auditor realiza procedimentos planejados de auditoria, a evidência de auditoria obtida 
pode   fazer   com   que   ele   modifique   a   natureza,   a   época   ou   a   extensão   de   outros 
procedimentos  planejados  de  auditoria.  Informações  que  diferem  significativamente  das 
informações nas quais a avaliação de risco se baseou podem chamar a atenção do auditor.  
Por exemplo: 
•  a extensão de distorções que o auditor detecta mediante a realização de procedimentos 
substantivos  pode  alterar  sua  opinião  acerca  da  avaliação  de  risco  e  pode  indicar 
deficiência significativa no controle interno; 
•   o  auditor  pode  tomar  conhecimento  de  discrepâncias  nos registros  contábeis  ou  de 
evidências ausentes ou conflitantes; e 
•  os  procedimentos  analíticos  aplicados  na  etapa  de  revisão  global  da  auditoria  podem 
indicar um risco anteriormente não reconhecido de distorção relevante. 
Nessas  circunstâncias,  o  auditor  poderia  ter  que  reavaliar  os  procedimentos  planejados  de 
auditoria com base na consideração revisada dos riscos avaliados de distorção relevante e 
no  efeito  sobre  as  classes  de  transações,  saldos  contábeis  ou  divulgações  significativas  e 
suas  respectivas  afirmações.  A  NBC  TA  315,  item  53, contém  orientação  adicional  para  a 
revisão da avaliação de risco do auditor. 
 
A64.  A opinião do auditor quanto ao que constitui evidência de auditoria apropriada e suficiente é 
influenciada por fatores como os que seguem: 
•  importância da distorção potencial na afirmação e a probabilidade de que ela tenha efeito 
relevante,  individualmente  ou  em  conjunto  com  outras  distorções  em  potencial,  nas 
demonstrações contábeis; 
•  efetividade das respostas e controles da administração para enfrentar os riscos; 
•  experiência  adquirida  durante  auditorias  anteriores  com  relação  a  potenciais  distorções 
semelhantes; 
•  resultados dos procedimentos de auditoria realizados, incluindo se esses procedimentos 
de auditoria identificaram casos específicos de fraude ou erro; 
•  fonte e confiabilidade das informações disponíveis; 
•  persuasividade da evidência de auditoria; 
•  entendimento  da  entidade  e  do  seu  ambiente,  da  estrutura  de  relatório  financeiro 
aplicável e de seu sistema de controles internos. 
 
A65.  A forma  e  a  extensão  da  documentação  de  auditoria  são  uma  questão  de  julgamento 
profissional e são influenciadas pela natureza, porte e complexidade da entidade e por seu 
sistema  de  controles  internos,  disponibilidade  das  informações  da  entidade  e  metodologia 
de auditoria e tecnologia usadas na auditoria. 
 
 

 
11. Altera os itens A1 e A17 da NBC TA 500 (R1) – Evidência de Auditoria, que passam a 
vigorar com as seguintes redações: 
 
A1.  A  evidência  de  auditoria  é  necessária  para  fundamentar  a  opinião  e  o  relatório  do  auditor. 
Ela  tem  natureza  cumulativa  e  é  obtida  principalmente  a  partir  dos  procedimentos  de 
auditoria   realizados   durante   o  curso   do  trabalho.   Contudo,   ela   também   pode   incluir 
informações  obtidas  de  outras  fontes,  como  auditorias  anteriores  (contanto que  o  auditor 
tenha  avaliado  se  essas  informações  permanecem  relevantes  e  confiáveis  como  evidência 
de  auditoria  para  a  atual  auditoria)  ou  procedimentos  de  controle  de  qualidade  da  firma  de 
auditoria  para  aceitação  e  continuidade  de  clientes.  Além  disso, os  registros  contábeis  e 
outras  fontes  internas  e  externas  da  entidade  são  importantes  fontes  de  evidência  de 
auditoria. Informações que podem ser utilizadas como evidência de auditoria podem ter sido 
elaboradas  com  a  utilização  do  trabalho  de  especialista da  administração.  A  evidência  de 
auditoria abrange informações que suportam e corroboram as afirmações da administração 
e  qualquer  informação  que  contradiga  tais  afirmações.   Ademais,  em  alguns  casos,  a 
ausência  de  informações  (por  exemplo,  a  recusa  da administração  em  fornecer  uma 
representação solicitada) é utilizada pelo auditor e, portanto, também constitui evidência de 
auditoria. 
 
A17.  A  observação  consiste  no  exame  do  processo  ou  procedimento  realizado  por  outros,  por 
exemplo,  a  observação  pelo  auditor  da  contagem  do  estoque  pelo  pessoal  da  entidade  ou 
da  realização  de  controles. A  observação  fornece  evidência  de  auditoria  a  respeito  da 
realização  de  processo  ou  procedimento,  mas  é  limitada  ao  ponto  no  tempo  em  que  a 
observação ocorre e pelo fato de que o ato de ser observado pode afetar a maneira como o 
processo  ou  procedimento  é realizado.  Ver  NBC  TA  501  para  orientação  adicional  sobre  a 
observação da contagem de estoque. 
 
 
12. Altera o item A4 da NBC TA 501 – Evidência de Auditoria – Considerações Específicas 
para Itens Selecionados, que passa a vigorar com a seguinte redação: 
 
A4.  Assuntos relevantes para a avaliação das instruções e dos procedimentos da administração 
para  o  registro  e  o  controle  da  contagem  física  do  estoque  incluem  se  eles  tratam,  por 
exemplo: 
•   da  aplicação  de  controles  apropriados, como coleta  de  registros  de  contagem  física  de 
estoque  utilizados,  contabilização  de  registros  de  contagem  física  de  estoque  não 
utilizados e procedimentos de contagem e recontagem; 
•   (...) 
 
 
13. Altera  o  item  A7 e o Apêndice 2 (coluna  FATOR) da NBC  TA  530 – Amostragem  em 
Auditoria, que passam a vigorar com as seguintes redações: 
 
A7.  Ao  considerar  as  características  da população,  para  testes  de  controles,  o  auditor  faz  uma 
avaliação  da  taxa  esperada de  desvio  com  base  no  seu  entendimento dos  controles  ou  no 
exame  de  pequena  quantidade  de  itens  da  população.  Essa  avaliação  é  feita  para 
estabelecer a amostra de auditoria e determinar o tamanho dessa amostra. (...) 
 
Apêndice 2 (ver item A11) 
 
(...) 
 
FATOR 
 
1. Aumento da extensão na qual a avaliação de risco do auditor leva em consideração os planos 
de testar a efetividade operacional dos controles.  
 

 
(...) 
 
 
14. Altera  os itens A9, A12, A20,  A28 e A34 da NBC  TA  550 – Partes  Relacionadas, que 
passam a vigorar com as seguintes redações: 
 
A9. Assuntos  que  podem  ser  tratados  na  discussão  entre  os  membros  da  equipe  encarregada 
do trabalho podem incluir: 
•   (...) 
•   a  importância  que  a  administração  e  os  responsáveis  pela  governança  dedicam  à 
identificação,  contabilização  e  divulgação  apropriada  dos  relacionamentos  e  transações 
com  partes  relacionadas  (se  a  estrutura  de  relatório  financeiro  aplicável  estabelecer 
requisitos  para  partes  relacionadas)  e  o  risco  relacionado  de  que  a  administração 
transgrida os controles. 
 
A12.  Contudo,  quando  a  estrutura  de  relatório  financeiro  não  estabelece  requisitos  para  partes 
relacionadas,  a  entidade  pode  não  ter  sistemas  de  informação  instalados.    Sob  tais 
circunstâncias,  é  possível  que  a  administração  não  tenha  conhecimento da existência  de 
todas  as  partes  relacionadas.    Não  obstante,  o  requisito  de  indagações  especificado  pelo 
item  13  ainda  se  aplica  porque  a  administração  pode  ter  conhecimento  de  partes  que 
cumpram  a  definição  de  partes  relacionadas  exposta  nesta Norma.  Em tal  caso,  porém,  é 
provável  que  as  indagações  do  auditor  quanto  à  identificação  das  partes  relacionadas  da 
entidade   sejam   parte   dos   seus   procedimentos   de   avaliação   de   risco   e   atividades 
relacionadas  realizados   em   conformidade   com   a   NBC   TA   315   para  a   obtenção de 
informações  referentes  a  estrutura  organizacional,  propriedade,  governança  e  modelo  de 
negócio da entidade. 
No  caso  específico  de  relacionamentos  de  controle  comum,  como  é  mais  provável  que  a 
administração  tenha  conhecimento  de  tais  relacionamentos  se eles  tiverem  importância 
econômica para a entidade, é possível que as indagações do auditor sejam mais eficazes se 
elas  se  concentrarem  em  determinar  se  as  partes  com  as  quais  a  entidade  se  envolve  em 
transações   significativas   ou   compartilha   recursos   em grau   significativo   são   partes 
relacionadas. 
 
A20.  É  provável  que  os  controles  em  entidades  de  pequeno  porte  possam  não  ter  nenhum 
processo   documentado   para   lidar   com   relacionamentos   e   transações   com   partes 
relacionadas. O administrador-proprietário  pode  mitigar  alguns  dos  riscos  decorrentes  de 
transações com partes relacionadas, ou aumentar potencialmente esses riscos, por meio de 
envolvimento  ativo  em  todos  os  aspectos  principais  das  transações.  Para  tais  entidades,  o 
auditor pode obter entendimento dos relacionamentos e transações com partes relacionadas 
e  quaisquer  controles  que  possam existir  sobre  eles,  por  meio  de  indagação  junto  à 
administração, combinada com outros procedimentos, tais como observação das atividades 
de  supervisão  geral  e  revisão  da  administração,  e  inspeção  da  documentação  relevante 
disponível. 
 
A28.  Informações  relevantes  sobre  partes  relacionadas  que  podem  ser  compartilhadas  entre  os 
integrantes da equipe encarregada do trabalho incluem, por exemplo: 
•   identificação das partes relacionadas com a entidade; 
•   natureza dos relacionamentos e transações com partes relacionadas; 
•   relacionamentos  ou  transações  significativas  ou  complexas  com  partes  relacionadas  e 
que possam ser determinados os riscos significativos, em particular transações nas quais 
a    administração    ou    os    responsáveis    pela    governança    estejam    envolvidos 
financeiramente. 
 
A34 Dependendo  dos  resultados  dos  procedimentos  de  avaliação  de  risco  do  auditor,  ele  pode 
considerar  apropriado  obter  evidências  de  auditoria  sem  testar  os controles  da  entidade 
sobre relacionamentos e transações com partes relacionadas.  Em algumas circunstâncias, 

 
porém,  pode  não  ser  possível  obter  evidência  de  auditoria  apropriada  e  suficiente  apenas 
pela  realização  de  procedimentos  substantivos  de  auditoria  quanto  aos  riscos  de  distorção 
relevante  associados  aos  relacionamentos  e  transações  com  partes  relacionadas.  Por 
exemplo,  quando  transações  intragrupo  entre  a  entidade  e  os  seus  componentes  são 
numerosas  e  uma  quantidade  significativa  de  informações  sobre  essas  transações  é 
iniciada,  registrada,  processada  ou  reportada  eletronicamente em  sistema  integrado,  o 
auditor   pode   determinar   que   não   é   possível   planejar   procedimentos   de   auditoria 
substantivos eficazes que, por si só, reduziriam os riscos de distorção relevante associados 
com  essas  transações  para  um  nível  aceitavelmente  baixo.    Em  tal  caso,  ao  cumprir  o 
requisito  da  NBC  TA  330,  item  8(b), de  obtenção  de  evidência  de  auditoria  apropriada  e 
suficiente quanto à efetividade operacional dos controles, o auditor deve testar os controles 
da  entidade  sobre  a  integridade  e  precisão  do  registro  dos  relacionamentos  e  transações 
com partes relacionadas. 
 
 
15. Altera os itens 1, 4, 5, 6, 8, 13, 16, 17, 19, A8, A9, A10, A19 e seu título, A20, título do 
item  A23, A24, A28 e  seu  título, A32,  A34, A35, A39,  A44,  A50 e  seu  título,  A51,  A52, 
A53, A54, A59, A60, A65, A66, A68, A70, A79 e A85 e seu título, e o título antes do item 
23 da NBC   TA   540 (R2) – Auditoria   de Estimativas Contábeis   e Divulgações 
relacionadas, que passam a vigorar com as seguintes redações: 
1. Esta Norma trata  das  responsabilidades  do  auditor  em  relação  a  estimativas  contábeis  e 
divulgações  relacionadas  na  auditoria  de  demonstrações  contábeis.    Especificamente,  ela 
inclui  requisitos  e  orientações  referentes  ou  adicionais  ao  modo  como  a  NBC  TA  315 – 
Identificação e Avaliação dos Riscos de Distorção Relevante, a NBC TA 330 – Resposta do 
Auditor  aos  Riscos  Avaliados,  a  NBC  TA  450 – Avaliação  das  Distorções  Identificadas 
durante  a  Auditoria,  a  NBC  TA  500 – Evidência  de  Auditoria e  outras  normas  relevantes 
devem ser aplicadas em relação a estimativas contábeis e divulgações relacionadas. Inclui, 
também,  requisitos  e  orientação  sobre  a  avaliação  de  distorções  de  estimativas  contábeis 
individuais  e  divulgações  relacionadas,  e  indicadores  de  possível  tendenciosidade  da 
administração. 
 
4. A  NBC  TA  315,  item  31, requer  a  avaliação  separada  do  risco  inerente  para  riscos 
identificados  de  distorção  relevante  no  nível  da  afirmação. No  contexto  desta  Norma e 
dependendo da natureza da estimativa contábil específica, a suscetibilidade de distorção em 
uma  afirmação  que  possa  ser  relevante  pode  estar  sujeita  ou  ser  afetada  pela  incerteza, 
complexidade ou subjetividade da estimativa ou outros fatores de risco inerente, bem como 
pela inter-relação entre eles. Conforme explicado na NBC TA 200, item A40, o risco inerente 
é  maior  para  algumas  afirmações  e  respectivas  classes  de  transações,  saldos  contábeis  e 
divulgações do que para outras. Da mesma forma, a avaliação do risco inerente depende do 
grau no qual os fatores de risco inerente afetam a probabilidade ou magnitude da distorção 
e varia de acordo com uma escala que é denominada spectrum de risco inerente (ver itens 
A8, A9, A65 e A66 e Apêndice 1). 
 
5. Esta Norma se refere aos requisitos relevantes da NBC TA 315 e da NBC TA 330 e fornece 
orientação  para  enfatizar   a  importância  das  decisões   do   auditor  sobre  os  controles 
relacionados com as estimativas contábeis, incluindo decisões sobre: 
•   se existem controles a serem identificados pela NBC TA 315, para os quais o auditor seja 
requerido a avaliar seus planejamentos e determinar se foram implementados; e 
•   testar a efetividade operacional dos controles. 
 
6. A NBC TA 315 requer a avaliação separada do risco de controle na avaliação dos riscos de 
distorção relevante no nível da afirmação. Na avaliação do risco de controle, o auditor deve 
levar em consideração se os procedimentos adicionais de auditoria contemplam a confiança 
esperada  na  efetividade  operacional  dos  controles.    Se o auditor  não  planeja  testar  a 
efetividade  operacional  dos  controles,  ou  não  pretende  confiar  na  efetividade  operacional 

 
dos  controles,  a  sua  avaliação  do  risco  de  controle  é  tal  que  a  avaliação  do  risco  de 
distorção relevante é a mesma que a avaliação do risco inerente (ver item A10). 
 
8. O  exercício  do  ceticismo  profissional  em  relação  às  estimativas  contábeis  é  afetado  pela 
consideração do auditor dos fatores de risco inerente, e a sua importância aumenta quando 
as  estimativas  contábeis  estão  sujeitas  a maior  grau  de  incerteza  da  estimativa  ou  são 
afetadas por maior grau de complexidade, subjetividade ou outros fatores de risco inerente. 
Da  mesma  forma,  o  exercício  do  ceticismo  profissional  é  importante  quando  houver  maior 
suscetibilidade à distorção devido à tendenciosidade da administração ou aos outros fatores 
de risco de fraude à medida que eles afetam o risco inerente. (ver item A11). 
 
13. Ao  obter  entendimento  da  entidade, do  seu  ambiente,  da  estrutura  de  relatório  financeiro 
aplicável  e  de  seu  sistema de  controles  internos,  conforme  requerido  pela  NBC  TA  315, 
itens  de  19  a  27, o  auditor  deve  obter  entendimento  dos  seguintes  assuntos  relacionados 
com   estimativas   contábeis   da   entidade. Os   procedimentos   do   auditor   para   obter   o 
entendimento  devem  ser  realizados  na  extensão  necessária  para  obter  evidência  de 
auditoria  que  forneça  uma  base  apropriada  para  a identificação  e  avaliação  dos  riscos  de 
distorção  relevante  nos  níveis  das  demonstrações  contábeis  e  da  afirmação.  (ver  itens de 
A19 a A22). 
 
Obtenção  de entendimento  da  entidade, do  seu  ambiente  e  da  estrutura  de  relatório  financeiro 
aplicável  
(a) As  transações  da  entidade  e  outros  eventos  ou  condições  que  podem  gerar  a 
necessidade  de,  ou  mudanças  nas,  estimativas  contábeis  a  serem  reconhecidas  ou 
divulgadas nas demonstrações contábeis (ver item A23). 
(b) Os   requisitos   da   estrutura   de   relatório   financeiro aplicável   relacionados   com   as 
estimativas   contábeis   (incluindo   os   critérios   de   reconhecimento,   as   bases   de 
mensuração  e  os  requisitos  de  apresentação  e divulgação  relacionadas)  e  o  modo 
como  eles  se  aplicam  no  contexto  da  natureza  e  circunstâncias  da  entidade  e  do  seu 
ambiente,  incluindo  o modo  como  os  fatores  de risco  inerente  afetam  a suscetibilidade 
de afirmações à distorção (ver itens A24 e A25).  
(c) Fatores  regulatórios  relevantes  para  as  estimativas  contábeis  da  entidade,  incluindo, 
quando aplicável, estruturas regulatórias relacionadas com a supervisão prudencial (ver 
item A26). 
(d) A natureza  das  estimativas  contábeis  e  divulgações  relacionadas  que o auditor  espera 
que  sejam  incluídas  nas  demonstrações  contábeis  da  entidade,  com  base  no  seu 
entendimento dos assuntos nas alíneas de (a) a (c) deste item (ver item A27). 
 
Obtenção de entendimento do sistema de controles internos da entidade 
(e) A natureza e a extensão da supervisão e da governança que a entidade possui sobre o 
processo  de  elaboração  de relatório  financeiro  da  administração  relevante  para  as 
estimativas contábeis (ver itens de A28 a A30). 
(f) O   modo   como   a   administração   identifica   a   necessidade   de   habilidades   ou 
conhecimentos especializados relacionados com as estimativas contábeis, e como são 
aplicados, incluindo o uso de especialista (ver item A31). 
(g) O modo como o processo de avaliação de risco da entidade identifica e avalia os riscos 
relacionados com as estimativas contábeis (ver itens A32 e A33). 
(h) O  sistema  de  informações  da  entidade  na  medida  em  que  ele  se  relaciona  com  as 
estimativas contábeis, incluindo: 
(i) o   modo   como   as   informações   relacionadas   com   estimativas   contábeis   e 
divulgações   relacionadas   para   classes   de   transações,   saldos   contábeis   ou 
divulgações  significativas  trafegam  pelo  sistema  de  informações  da  entidade  (ver 
itens A34 e A35); e 
(ii) para    essas    estimativas    contábeis    e    divulgações    relacionadas,    como    a 
administração: 
a. identifica  os  métodos,  as  premissas  ou  as  fontes  de  dados  relevantes,  e  a 
necessidade  de  alteração  nos  mesmos,  que  são  apropriados  no  contexto  da 

 
estrutura    de    relatório    financeiro    aplicável,    incluindo    o    modo    como    a 
administração (ver itens A36 e A37): 
i. seleciona  ou  define  e  aplica  os  métodos  utilizados,  incluindo  o  uso  de 
modelos (ver itens A38 e A39); 
ii. seleciona  as  premissas  a  serem  utilizadas,  incluindo  a  consideração  de 
alternativas, e identifica premissas significativas (ver itens de A40 a A43); e 
iii. seleciona os dados a serem utilizados (ver item A44); 
b. entende o grau de incerteza da estimativa, incluindo a consideração do intervalo 
de possíveis resultados de mensuração (ver item A45); e 
c. trata  da  incerteza  da  estimativa,  incluindo a seleção  de  estimativa  pontual  e 
divulgações  relacionadas  para  inclusão  nas  demonstrações  contábeis (ver  itens 
de A46 a A49). 
(i) Os  controles  identificados  no  componente  de  atividades  de  controle do  processo  da 
administração para a elaboração de estimativas contábeis, conforme descrito na alínea 
(h)(ii) deste item (ver itens de A50 a A54 e NBC TA 315, item 26(a)(i a iv)). 
(j) Como  a  administração  revisa  o  resultado  das  estimativas  contábeis  anteriores  e 
responde aos resultados dessa revisão. 
 
16. Ao identificar e avaliar os riscos de distorção relevante relacionados com estimativa contábil 
e  divulgações  relacionadas  no  nível  da  afirmação,  incluindo  avaliar  separadamente  o  risco 
inerente e o risco de controle no nível da afirmação, conforme requerido pela NBC TA 315, 
itens de 31 a 34, ao identificar os riscos de distorção relevante e avaliar o risco inerente, o 
auditor deve levar em consideração o que segue (ver itens de A64 a A71): 
(a) o grau no qual a estimativa contábil estiver sujeita à incerteza da estimativa (ver itens de 
A72 a A75); e 
(b) o grau no qual os seguintes assuntos forem afetados pela complexidade, subjetividade 
ou outros fatores de risco inerente (ver itens de A76 a A79): 
(i) a  seleção  e  a  aplicação do  método,  das  premissas  e  dos  dados  na  elaboração  da 
estimativa contábil; ou 
(ii) a  seleção  da  administração  da  estimativa  pontual  e  divulgações relacionadas  para 
inclusão nas demonstrações contábeis. 
 
17. O  auditor  deve  determinar  se  algum  dos  riscos  de  distorção  relevante  identificados  e 
avaliados  de  acordo  com  o  item  16  é,  no  seu  julgamento,  risco  significativo. Se  o  auditor 
determinou que existe risco significativo, deve identificar controles que tratam desse risco e 
avaliar  se  esses  controles  foram  planejados  de  maneira  efetiva  e  determinar  se foram 
implementados (ver item A80 e NBC TA 315, itens 26(a)(i) e 32). 
 
19. Conforme requerido pela NBC TA 330, item 8, o auditor deve planejar e realizar testes para 
obter  evidência  de  auditoria  apropriada  e  suficiente  quanto  à  efetividade  operacional  dos 
controles se: 
(a) a avaliação de riscos de distorção relevante no nível da afirmação inclui a expectativa 
de que os controles estão operando efetivamente; ou 
(b) somente os procedimentos substantivos não fornecem evidência de auditoria 
apropriada e suficiente no nível da afirmação. 
Com  relação  às  estimativas  contábeis,  os  testes  desses  controles  pelo  auditor  devem 
responder  às  razões  para  a  avaliação  atribuída  aos  riscos  de  distorção  relevante.  Ao 
planejar  e  realizar  os  testes  de  controle,  o  auditor  deve obter  evidência  de  auditoria  mais 
persuasiva quanto maior for a sua confiança na efetividade do controle (ver itens de A85 a 
A89 e NBC TA 330, item 9). 
 
A8. Os  fatores  de  risco  inerente  são  características  de  eventos  ou  condições  que  afetam  a 
suscetibilidade à  distorção,  independentemente  de  se  causada  por  fraude  ou  erro,  de 
afirmação   sobre   uma   classe   de   transações,   saldo   contábil   ou   divulgação,   antes   da 
consideração dos controles (NBC TA 315, item 12(f)). O Apêndice 1 amplia a explicação da 
natureza  desses fatores  de  risco  inerente  e  suas  inter-relações  no  contexto  da  elaboração 
de estimativas contábeis e sua apresentação nas demonstrações contábeis. 

 
 
A9. Na  avaliação  dos  riscos  de  distorção  relevante  no  nível  da  afirmação,  além  da  incerteza, 
complexidade e subjetividade da estimativa, o auditor leva em consideração o grau no qual 
os  fatores  de  risco  inerente incluídos  na  NBC  TA  315,  item  31, (diferentes  de  incerteza, 
complexidade  e  subjetividade  da  estimativa)  afetam  a  suscetibilidade  de  afirmações  à 
distorção sobre a estimativa contábil. Esses fatores de risco inerentes adicionais incluem: 
•   mudança  na  natureza  ou  nas  circunstâncias  dos  itens  relevantes  das  demonstrações 
contábeis  ou  requisitos  de  estrutura  de  relatório  financeiro  aplicável,  que  pode  gerar a 
necessidade  de  mudanças  no  método,  nas  premissas  ou  nos  dados  utilizados  para 
elaborar a estimativa contábil; 
•   suscetibilidade à distorção devido à tendenciosidade da administração ou a outros fatores 
de  risco  de  fraude  à  medida  que  eles  afetam  o  risco inerente,  na  elaboração  da 
estimativa contábil; e 
•   incerteza, que não incerteza da estimativa. 
 
A10.  Ao avaliar o risco de controle no nível da afirmação de acordo com a NBC TA 315, o auditor 
leva em consideração se ele planeja testar a efetividade operacional dos controles. Quando 
o auditor considera se deve testar a efetividade operacional dos controles, sua avaliação de 
que  os  controles  são  planejados  de  maneira  efetiva  e  foram  implementados  suporta  a  sua 
expectativa  sobre  a  efetividade  operacional  dos controles  ao  estabelecer  o  plano  de  testá-
los. 
 
Obtenção  de  entendimento  da  entidade, do  seu  ambiente, da  estrutura  de  relatório  financeiro 
aplicável e do sistema de controles internos (ver item 13) 
 
A19. Os  itens  de  19 a  27 da  NBC  TA  315  requerem  que  o  auditor  obtenha  entendimento  de 
determinados assuntos sobre a entidade, seu ambiente, sua estrutura de relatório financeiro 
aplicável e seu sistema de controle interno. Os requisitos no item 13 desta Norma referem-
se   mais   especificamente   às   estimativas   contábeis   e   desenvolvem   exigências   mais 
abrangentes na NBC TA 315. 
 
A20.  A natureza, a época e a extensão dos procedimentos do auditor para obter o entendimento 
da  entidade  e  do  seu  ambiente,  da  estrutura  de  relatório  financeiro  aplicável  e  de  seu 
sistema  de controles  internos  relacionados  com  as  estimativas  contábeis  da  entidade, 
podem  depender,  em  maior  ou  menor  grau,  da  extensão  na  qual  o  assunto  individual  se 
aplica  nas  circunstâncias.    Por  exemplo,  a  entidade  pode  ter  poucas  transações, outros 
eventos  ou condições  que  geram  a  necessidade  de  estimativas  contábeis,  nesse  caso,  os 
requisitos de relatório financeiro aplicáveis podem ser simples de aplicar e pode não haver 
fatores   regulatórios   relevantes.   Ainda,   as   estimativas   contábeis   podem   não   exigir 
julgamentos significativos e o processo para a elaboração de estimativas contábeis pode ser 
menos  complexo.  Nessas  circunstâncias,  as  estimativas  contábeis  podem  estar  sujeitas  à 
incerteza,  à  complexidade  ou  à  subjetividade  da  estimativa  ou,  em  menor  grau,  a  outros 
fatores  de  risco  inerente,  ou  serem  afetadas  por  eles,  e  pode  haver  menos  controles 
identificados no componente de atividades de controle. Se esse for o caso, provavelmente, 
os  procedimentos  de  identificação  e  avaliação  de  risco  do  auditor  devem  ser  menos 
extensos   e   podem   ser   obtidos,   principalmente,   por   meio   de   indagações   junto   à 
administração  com  as  responsabilidades  apropriadas  pelas  demonstrações  contábeis,  tais 
como um simples “passo a passo” do processo da administração para a elaboração da 
estimativa contábil (incluindo ao avaliar se os controles identificados nesse processo foram 
planejados de maneira efetiva e ao determinar se os controles foram implementados). 
 
Transações da entidade, outros eventos ou condições (ver item 13(a))  
 
A24.  A  obtenção de  entendimento  dos  requisitos  da  estrutura  de  relatório  financeiro  aplicável 
fornece ao auditor uma base para discussão com a administração e, quando aplicável, com 
os  responsáveis  pela  governança,  sobre  o  modo  como  a  administração  aplicou  esses 

 
requisitos da  estrutura  de  relatório  financeiro  aplicável  relevantes  para  as  estimativas 
contábeis  e  sobre  a sua  determinação  do  auditor  de  se  elas  foram  aplicadas  de  forma 
apropriada. Esse  entendimento  também  pode  ajudar  o  auditor a  se  comunicar  com  os 
responsáveis pela governança quando ele considera uma prática contábil significativa, que é 
aceitável de acordo com a estrutura de relatório financeiro aplicável, como não sendo a mais 
apropriada nas circunstâncias da entidade (ver NBC TA 260, item 16(a)). 
 
Sistema de controles internos da entidade 
 
Natureza e extensão da supervisão e governança (ver item 13(e)) sem alteração 
 
A28.  Ao aplicar a NBC TA 315, item 21(a), o entendimento do auditor da natureza e extensão da 
supervisão e governança que a entidade possui sobre o processo da administração para a 
elaboração  das  estimativas  contábeis  pode  ser  importante  para a  sua  avaliação  requerida 
sobre: 
•   se  a  administração,  com  a  supervisão  dos  responsáveis  pela  governança,  criou  e 
manteve uma cultura de honestidade e comportamento ético;  
•   se  o  ambiente  de  controle  fornece  fundamento  apropriado  para  os  outros  componentes 
do sistema de controles internos, considerando a natureza e o porte da entidade; e 
•   se  as  deficiências  nos  controles  identificadas  no  ambiente  de  controle  enfraquecem  os 
outros componentes do sistema de controles internos. 
 
A32.  Entender  o  modo  como o processo  de  avaliação  de  risco  da  entidade  identifica  e trata  dos 
riscos  relacionados  com  as  estimativas  contábeis  pode  auxiliar  o  auditor  ao  considerar 
mudanças: 
•   nos   requisitos   da   estrutura   de   relatório   financeiro   aplicável   relacionados   com   as 
estimativas contábeis; 
•   na  disponibilidade  ou  natureza  das  fontes  de  dados  que  são  relevantes  na  elaboração 
das estimativas contábeis ou que podem afetar a confiabilidade dos dados utilizados; 
•   nos sistemas de informação ou no ambiente de TI da entidade; e 
•   no pessoal-chave. 
 
A34.  As  classes  de  transações  significativas,  eventos  e  condições  no  escopo  do  item  13(h)  são 
as  mesmas  que  as  classes  de  transações  significativas,  eventos  e  condições  relacionadas 
com  as  estimativas  contábeis  e  divulgações  relacionadas  que  estão  sujeitas  ao  item  25(a) 
da NBC TA 315.  Ao obter entendimento do sistema de informação da entidade na medida 
em que ele se relaciona com as estimativas contábeis, o auditor deve considerar: 
•   se  as  estimativas  contábeis  são  resultantes  do  registro de  transações  de  rotina  e 
recorrentes ou de transações não recorrentes ou não usuais; 
•   como   o   sistema   de   informação   trata da   integridade   das   estimativas contábeis   e 
divulgações  relacionadas,  especificamente  para estimativas  contábeis  relacionadas  com 
passivos. 
 
A35.  Durante a auditoria, o auditor deve identificar classes de transações, eventos ou condições 
que  geram  a  necessidade  de  estimativas  contábeis e divulgações  relacionadas  que  a 
administração não conseguiu identificar. A NBC TA 315, item 22(b), trata das circunstâncias 
em que o auditor identifica riscos de distorção relevante que a administração não conseguiu 
identificar,  incluindo  a  consideração das  implicações  para  a  sua  avaliação  do  processo  de 
avaliação de risco da entidade. 
 
A39.  A  administração  pode  planejar  e  implementar  controles  específicos  com  base  em  modelos 
utilizados   na   elaboração de   estimativas   contábeis,   sejam   eles   modelo   próprio   da 
administração ou modelo externo. Quando o próprio modelo tem alto nível de complexidade 
ou  subjetividade,  como,  por  exemplo,  modelo  de  perda  de  crédito  esperada  ou  modelo  de 
valor justo que utiliza informações de nível 3, pode ser mais provável que os controles que 
tratam  dessa  complexidade  ou  subjetividade  sejam  identificados  como  sendo  relevantes 

 
para  a auditoria.  Quando  há  complexidade  em  relação  aos  modelos,  também  é  mais 
provável que os controles da integridade dos dados sejam controles identificados, de acordo 
com  a  NBC  TA  315.  Os  fatores  que  podem  ser  apropriados  para  o auditor  considerar  na 
obtenção de entendimento do modelo e dos controles identificados relacionados incluem: 
•   como a administração determina a relevância e a precisão do modelo; 
•   a validação  ou  os  testes  retrospectivos  (backtesting)  do  modelo,  incluindo  se  ele  é 
validado  antes  do  uso e  revalidado  em  intervalos  regulares  para  determinar  se  continua 
adequado para o seu uso pretendido.  A validação do modelo por parte da entidade pode 
incluir a avaliação da: 
o solidez teórica do modelo; 
o integridade matemática do modelo; e 
o precisão e integridade dos dados e adequação dos dados e das premissas utilizados 
no modelo; 
•   como  o  modelo  é  alterado  ou  ajustado  de  maneira  apropriada  e  tempestiva  devido  a 
mudanças no mercado ou a outras condições e se há políticas apropriadas de controle de 
alterações do modelo; 
•   se os ajustes, também chamados de sobreposições em determinados setores, são feitos 
no resultado do modelo e se esses ajustes são apropriados nas circunstâncias de acordo 
com  os  requisitos  da  estrutura  de  relatório  financeiro  aplicável.    Quando  os  ajustes  não 
são   apropriados,   eles   podem   ser   indicadores   de   possível   tendenciosidade   da 
administração; e 
•   se   o   modelo   é   documentado   de   maneira   adequada,   incluindo   suas   aplicações 
pretendidas, limitações, parâmetros-chave, dados e premissas requeridos, os resultados 
de  qualquer  validação realizada  do  modelo  e  a  natureza  de  quaisquer  ajustes  feitos  em 
seu resultado e sua base. 
 
A44.  Assuntos   que   o   auditor   deve   considerar   na   obtenção   de   entendimento   de   como   a 
administração seleciona os dados nos quais as estimativas contábeis se baseiam incluem: 
•   a  natureza  e  a  fonte  dos  dados,  incluindo  informações  obtidas  de  fonte  de  informações 
externa; 
•   como a administração avalia se os dados são apropriados; 
•   a precisão e a integridade dos dados; 
•   a consistência dos dados utilizados com os dados utilizados em períodos anteriores; 
•   complexidade  dos  aplicativos  de  TI  ou  outros  aspectos  do  ambiente  de  TI  da  entidade 
utilizados para obter e processar os dados, incluindo quando isso envolve o trabalho com 
grandes volumes de dados; e 
•   como  os  dados  são  obtidos,  transmitidos  e  processados  e  como  sua  integridade  é 
mantida. 
 
Identificação dos controles sobre o processo da administração para a elaboração de estimativas 
contábeis (ver item 13(i)) 
 
A50.  O  julgamento  do  auditor  na  identificação  dos  controles  no  componente  de  atividades  de 
controle   e,   portanto,   da   necessidade   de   avaliar   o   planejamento   desses   controles   e 
determinar  se  eles  foram  implementados,  refere-se  ao  processo  da  administração  descrito 
no item 13(h)(ii). O auditor pode não identificar controles relacionados com aspectos do item 
13(h)(ii). 
 
A51.  Como   parte   da   identificação   dos   controles,   e   da   avaliação   do seu   planejamento  e 
determinação de se eles foram implementados, o auditor pode considerar: 
•   o  modo  como  a  administração  determina  a  adequação  dos  dados  utilizados  para 
desenvolver  as  estimativas  contábeis, incluindo  quando  a  administração  utiliza  fonte  de 
informações externa ou dados que não estão no razão geral ou nos razões auxiliares; 
•   a  revisão  e  a  aprovação  de  estimativas  contábeis,  incluindo  as  premissas  ou  os  dados 
utilizados  na  sua  elaboração,  pelos  níveis  pertinentes  da  administração  e,  quando 
adequado, pelos responsáveis pela governança; 

 
•   a  segregação  das  funções  entre  os  responsáveis  pela  elaboração  das  estimativas 
contábeis  e  aqueles  que  comprometem  a  entidade  com  as  respectivas  transações, 
incluindo  se  a  atribuição  de  responsabilidades  leva em consideração,  de  maneira 
apropriada, a natureza da entidade e de seus produtos e serviços.  Por exemplo, no caso 
de  uma  grande  instituição  financeira,  a  relevante  segregação  de  funções  pode  consistir 
em função independente responsável pela estimativa e validação da precificação do valor 
justo dos produtos financeiros da entidade preparadas por indivíduos cujas remunerações 
não estejam vinculadas a esses produtos; e 
•   a  eficiência   do   desenho   dos   controles.   Geralmente,   pode   ser  mais   difícil   para   a 
administração  desenhar  os  controles  que  tratam  da  subjetividade  e  da  incerteza  da 
estimativa de forma a efetivamente evitar, ou detectar e corrigir, distorções relevantes do 
que  desenhar  controles  que  tratam  da  complexidade. Os  controles  que  tratam  da 
subjetividade e da incerteza da estimativa podem ter que incluir mais elementos manuais 
que  podem  ser  menos  confiáveis  que  os  controles automatizados, uma  vez  que  eles 
podem ser mais facilmente contornados, ignorados ou transgredidos pela administração.  
A  efetividade do  desenho  dos  controles  que tratam  da complexidade  pode  variar 
dependendo do motivo e da natureza da complexidade.  Por exemplo, pode ser mais fácil 
desenhar  controles  mais  eficazes  relacionados  com  método  que  é usado  de  forma 
rotineira ou controles da integridade dos dados. 
 
A52.  Quando  a  administração faz  uso  extensivo  da  tecnologia  da  informação na  elaboração  das 
estimativas  contábeis,  é  provável  que a  identificação  dos  controles  no  componente  de 
atividades  de  controle  incluam  controles  gerais  de  TI  e controles  de  processamento  de 
informações. Esses controles podem tratar de riscos relacionados: 
•   a  se os  aplicativos  de  TI  ou  outros  aspectos  do  ambiente  de  TI  têm  a  capacidade  de 
processar grandes volumes de dados e se estão configurados de forma apropriada; 
•   a  cálculos  complexos  na  aplicação  de  método.    Quando  diversos  aplicativos  de  TI  são 
necessários para  processar  transações  complexas,  são  feitas  conciliações  regulares 
entre os aplicativos de TI, particularmente quando eles não têm interfaces automatizadas 
ou podem estar sujeitos à intervenção manual; 
•   a se o desenho e a calibração dos modelos são avaliados periodicamente; 
•   à extração completa e precisa de dados referentes às estimativas contábeis dos registros 
da entidade ou de fontes de informações externas; 
•   a  dados,  incluindo  o  fluxo  completo  e  preciso  de  dados  no  sistema  de  informação  da 
entidade, a adequação de qualquer modificação nos dados utilizados na elaboração das 
estimativas  contábeis,  a  manutenção  da  integridade  e  segurança  dos  dados; aos  riscos 
relacionados  com  o  processamento  ou  registro  dos  dados,  quando  utilizadas  fontes  de 
informações externas; 
•   a  se  a  administração  tem  controles  de  acesso,  alteração  e  manutenção  de  modelos 
individuais  para  manter  a  trilha  de  auditoria  forte  das versões  de  modelos  aprovadas  e 
evitar o acesso não autorizado a esses modelos ou alterações nos mesmos; e 
•   a  se  há  controles  apropriados  para  a transferência  de  informações relacionadas  com  as 
estimativas   contábeis   para   o   razão   geral,   incluindo   controles apropriados   dos 
lançamentos no livro diário. 
 
A53. Em alguns setores, como o bancário ou o de seguros, o termo governança pode ser utilizado 
para descrever atividades dentro do ambiente de controle, o processo de monitoramento do 
sistema de controles internos pela entidade e outros componentes do sistema de controles 
internos, conforme descrito na NBC TA 315, Apêndice 3. 
 
A54. Para as entidades que têm função de auditoria interna, seu trabalho pode ser particularmente 
útil para o auditor na obtenção de entendimento: 
•   da natureza e da extensão do uso das estimativas contábeis por parte da administração; 
•   do desenho e da implementação de controles que tratam dos riscos relacionados com os 
dados,  com  as  premissas  e  com  os  modelos  utilizados  na  elaboração  das estimativas 
contábeis; 

 
•   dos  aspectos  do  sistema  de  informação  da  entidade  que  gera  os  dados  nos  quais as 
estimativas contábeis se baseiam; e 
•   do  modo  como  os  riscos  relacionados  com  as  estimativas  contábeis  são  identificados, 
avaliados e administrados. 
  
A59.  O objetivo da mensuração das estimativas contábeis do valor justo e de outras estimativas 
contábeis,  com  base  nas  condições  atuais  na  data  da  mensuração,  trata  das  percepções 
sobre  o  valor  em  determinado  momento,  que  pode  mudar  significativa  e  rapidamente  à 
medida  que  o  ambiente  no  qual  a  entidade  atua  também  muda.    O  auditor  pode,  portanto, 
direcionar a revisão para a obtenção de informações que seriam relevantes para identificar e 
avaliar  riscos  de  distorção  relevante.    Por  exemplo,  em  alguns  casos, a  obtenção  de 
entendimento  das  mudanças  nas  premissas  dos  participantes  do  mercado  que  afetaram  o 
resultado  da  estimativa  contábil  do  valor  justo  do  período  anterior  provavelmente  não 
fornece  evidência  de  auditoria  relevante.    Nesse  caso,  a  evidência  de auditoria  pode  ser 
obtida mediante o entendimento dos resultados das premissas (como as projeções de fluxo 
de  caixa)  e  o  entendimento  da  efetividade  do  processo  de  estimativa  utilizado  pela 
administração  no  período  anterior  que  suporta  a  identificação  e  a avaliação  dos  riscos  de 
distorção relevante no período corrente. 
 
A60. A   diferença   entre   o   resultado   da estimativa   contábil   e   o   valor   reconhecido   nas 
demonstrações  contábeis  do  período  anterior  não  representa,  necessariamente,  distorção 
das   demonstrações   contábeis   do   período   anterior. Entretanto,   essa   diferença   pode 
representar uma distorção, se, por exemplo, ela for decorrente de informações que estavam 
disponíveis  para  a  administração  quando  as  demonstrações  contábeis  do  período  anterior 
foram  finalizadas, ou  que  se  poderia,  razoavelmente,  esperar  que  tivessem  sido  obtidas  e 
levadas em consideração no contexto da estrutura de relatório financeiro aplicável (NBC TA 
560 – Eventos  Subsequentes,  item  14).    Essa  diferença  pode  levantar  dúvidas  sobre  o 
processo da administração  para  considerar  as  informações  na  elaboração  das  estimativas 
contábeis.  Como  resultado,  o  auditor  pode  reavaliar  qualquer  plano  de  testar  controles 
relacionados  e  a  avaliação  relacionada  do  risco  de  controle  ou  pode  determinar  que  uma 
evidência de auditoria mais persuasiva precisa ser obtida sobre o assunto. Muitas estruturas 
de  relatórios financeiros  contêm  orientação  para  distinguir  entre  mudanças  em  estimativas 
contábeis   que   constituem   distorções   e   aquelas   que   não   constituem   distorções, e o 
tratamento contábil que deve ser seguido em cada caso. 
 
A65.  O  item  A44 da  NBC  TA  200  afirma  que  as  normas  de  auditoria  normalmente  se  referem  a 
“riscos  de  distorção  relevante”  em  vez  de  a  risco  inerente  e  risco  de  controle 
separadamente.  A  NBC  TA  315, itens  31  e  34, requer  a  avaliação  separada  do  risco 
inerente e do risco de controle para fornecer uma base para o planejamento e a realização 
de  procedimentos  adicionais  de  auditoria  para  responder  aos  riscos  de  distorção  relevante 
no nível da afirmação, incluindo os riscos significativos, de acordo com o a NBC TA 330. 
 
A66.  Na  identificação  dos  riscos  de  distorção  relevante  e  na  avaliação  do  risco  inerente  para 
estimativas  contábeis  de  acordo  com  a  NBC  TA  315, item  31(a), o  auditor  deve  levar  em 
consideração  os  fatores  de  risco  inerente  que  afetam  a  suscetibilidade  de  afirmações  à 
distorção  e  o  modo  como eles  afetam.    A  consideração  do  auditor  dos  fatores  de  risco 
inerente também pode fornecer informações a serem utilizadas: 
•   na avaliação da probabilidade e magnitude da distorção (isto é, quando o risco inerente é 
avaliado no spectrum de risco inerente); e 
•   na determinação dos motivos para a avaliação atribuída aos riscos de distorção relevante 
no nível da afirmação e de se os procedimentos adicionais de auditoria, de acordo com o 
item 18, respondem a esses motivos. 
 
A68.  A  importância  e  a relevância  dos fatores  de risco  inerente  podem  variar  de  uma estimativa 
para  outra.   Da mesma forma,  os  fatores  de  risco  inerente  podem,  seja  individualmente  ou 
em  conjunto,  afetar  as  estimativas  contábeis  simples  em  menor  grau,  e  o  auditor  pode 

 
identificar menos riscos ou avaliar o risco inerente próximo ao limite inferior do spectrum de 
risco inerente. 
 
A70.  Os   eventos   ocorridos   após   a   data   das   demonstrações   contábeis podem   fornecer 
informações  adicionais  relevantes  para  a  avaliação  do  auditor  dos  riscos  de  distorção 
relevante  no  nível  da  afirmação.  Por  exemplo,  o  resultado  da  estimativa  contábil  pode  se 
tornar  conhecido  durante  a  auditoria.  Nesses  casos,  o  auditor  pode  avaliar  ou  revisar  a 
avaliação  dos  riscos  de  distorção  relevante  no  nível  da  afirmação,  independentemente  de 
como  os  fatores  de  risco  inerente  afetam  a  suscetibilidade  de  afirmações  à  distorção 
relacionada com a estimativa contábil (NBC TA 315, tem 37). Os eventos ocorridos após a 
data  das  demonstrações  contábeis  também  podem  influenciar  a  escolha  do  auditor  da 
abordagem  de  teste  da  estimativa  contábil,  de  acordo  com  o  item  18.  Por  exemplo,  para 
uma  simples  provisão  para  bônus  que  se  baseia  em  percentual direto  da  remuneração  de 
empregados  específicos,  o  auditor  pode  concluir  que  há  complexidade  ou  subjetividade 
relativamente pequena na elaboração da estimativa contábil e, portanto, pode avaliar o risco 
inerente  no  nível  da  afirmação  próximo  do  limite  inferior  do spectrum de  risco  inerente  O 
pagamento   de   bônus  após  o  final   do período   pode   fornecer   evidência  de   auditoria 
apropriada e suficiente com relação aos riscos avaliados de distorção relevante no nível da 
afirmação. 
 
A79.  O  grau  de  subjetividade  associada  à  estimativa  contábil  influencia  a  suscetibilidade  da 
estimativa  contábil  à  distorção  devido  à  tendenciosidade  da  administração  ou  a  outros 
fatores de risco de fraude à medida que eles afetam o risco inerente. Por exemplo, quando a 
estimativa  contábil estiver  sujeita  a  alto  grau  de  subjetividade,  é  provável  que  a  estimativa 
contábil  seja  mais  suscetível  à  distorção  devido  à  tendenciosidade  da  administração  e  à 
fraude  e  isso  pode resultar  em  amplo  intervalo  de  resultados  de  mensuração  possíveis.    A 
administração pode selecionar uma estimativa pontual desse intervalo que seja inapropriada 
nas circunstâncias ou que seja influenciada de forma inapropriada pela tendenciosidade não 
intencional  ou  intencional  da  administração  e  que  apresenta,  portanto,  distorção.    Para 
auditorias    recorrentes,    indicadores    de    possível    tendenciosidade    da    administração 
identificados durante a auditoria de períodos anteriores podem influenciar o planejamento e 
os procedimentos de avaliação de risco no período corrente. 
 
Quando o auditor pretende confiar na efetividade operacional dos controles (ver item 19) 
 
A85.  Testar a efetividade operacional dos controles pode ser apropriado quando o risco inerente 
for  avaliado  como  o  mais  alto  no spectrum de  risco  inerente,  inclusive  para  os riscos 
significativos.    Esse  pode  ser  o  caso  quando  a  estimativa  contábil  estiver  sujeita  a,  ou  for 
afetada  por,  alto  grau  de  complexidade.    Quando  a  estimativa  contábil  for  afetada  por  alto 
grau   de   subjetividade   e,   portanto,   requerer   julgamento   significativo   por   parte   da 
administração, as limitações inerentes à efetividade do desenho dos controles podem levar 
o  auditor a  focar  mais  nos  procedimentos  substantivos  do  que  no  teste da  efetividade 
operacional dos controles. 
 
 
16. Altera os itens 17, A6, A23, e os apêndices 2 e 5 da NBC TA 600 (R1) – Considerações 
Especiais – Auditorias de Demonstrações Contábeis de Grupos, Incluindo o Trabalho 
dos Auditores dos Componentes, que passam a vigorar com as seguintes redações: 
 
17. É  requerido  que  o  auditor  identifique e  avalie  os  riscos  de  distorção  relevante  por  meio  da 
obtenção de entendimento da entidade, do seu ambiente, da estrutura de relatório financeiro 
aplicável  e  do  sistema  de  controles  internos (NBC  TA 315 – Identificação  e  Avaliação  dos 
Riscos de Distorção Relevante). A equipe encarregada do trabalho do grupo deve: 
(...) 
 
A6.  A equipe encarregada do trabalho do grupo também pode identificar um componente como 
tendo probabilidade de incluir riscos significativos de distorção relevante nas demonstrações 

 
contábeis  do  grupo  por  causa  de  sua  natureza  ou  circunstâncias.  Por  exemplo,  um 
componente  poderia  ser  responsável  por  operações  de  câmbio  do  grupo  e,  assim,  expor  o 
grupo  a  risco  significativo  de  distorção  relevante,  embora  esse  componente  não  tenha 
importância financeira individual para o grupo. 
 
A23.  A NBC TA 315, itens de A62 a A64 e Apêndice 1, contém orientação sobre assuntos que o 
auditor pode considerar ao obter entendimento de fatores setoriais, regulamentares e outros 
fatores  externos  que  afetam  a  entidade,  incluindo  a  estrutura  de  relatório  financeiro 
aplicável,  a  natureza  da  entidade,  objetivos,  estratégias  e  riscos  do  negócio  relacionados, 
bem  como  a  medição  e  a  revisão  do  desempenho  financeiro  da  entidade.  O  Apêndice  2 
contém   orientação   sobre   assuntos   específicos   de   grupo,   inclusive   o   processo   de 
consolidação. 
 
Apêndice 2 (ver item A23) 
 
(...) 
Controles abrangentes no nível do grupo 
 
1. Controles abrangentes no nível do grupo podem incluir uma combinação do seguinte: 
•   (...) 
•   controles  dentro  do  sistema  de  TI  que  sejam  comuns  para  todos  ou  para  alguns  dos 
componentes; 
•   controles  dentro  do  processo de  monitoramento  do  sistema  de  controles  internos  do 
grupo, incluindo atividades da função de auditoria interna e programas de auto-avaliação; 
•   (...) 
 
Apêndice 5 (ver item A58) 
 
•   (...) 
Assuntos que são relevantes para a condução do trabalho do auditor do componente: 
•   constatações  decorrentes  dos  testes  de controle  realizados  pela  equipe encarregada  do 
trabalho  em  sistema  de  processamento  que  seja  comum para  todos  ou  alguns  dos 
componentes, e testes de controle a serem realizados pelo auditor do componente; 
•   (...) 
 
 
17. Altera os itens 7, A3, A10 e A21 da NBC TA 610 – Utilização do Trabalho de Auditoria 
Interna, que passam a vigorar com as seguintes redações: 
 
7. A NBC TA 315 trata do modo como o conhecimento e a experiência da função de auditoria 
interna podem contribuir  no  entendimento  do  auditor  independente  da  entidade  e  do  seu 
ambiente,  da  estrutura  de  relatório  financeiro  aplicável  e  do  seu  sistema de  controles 
internos,  e  na  identificação  e  avaliação  dos  riscos  de  distorção  relevante.    A  NBC  TA  315, 
item A116, explica, também, como a comunicação efetiva entre o auditor interno e o auditor 
independente  cria  um  ambiente  no  qual  o  auditor  independente pode  ser  informado  sobre 
assuntos significativos que podem afetar o seu trabalho. 
 
A3. Além   disso,   aqueles   na   entidade   com   deveres   e   responsabilidades   operacionais   e 
gerenciais  fora  da  função  de  auditoria  interna  normalmente  enfrentariam  ameaças  à  sua 
objetividade que os impediriam de serem tratados como parte da função de auditoria interna 
para fins desta Norma, embora possam realizar controles que podem ser testados de acordo 
com a NBC TA 330, item 10. Por esse motivo, os controles de monitoramento realizados por 
gerente-proprietário  não  seriam  considerados  como  equivalentes à função  de  auditoria 
interna. 
 

 
A10.  A   aplicação   de   abordagem   sistemática   e   disciplinada   ao   planejamento,   realização, 
supervisão, revisão e documentação das suas atividades distingue as atividades da função 
de auditoria interna dos outros controles de monitoramento que podem ser realizados dentro 
da entidade. 
 
A21.  Como mencionado na NBC TA 315, item 124(l), os riscos significativos são riscos avaliados 
próximo ao limite superior do spectrum de risco inerente e, portanto, a capacidade do auditor 
independente  de  utilizar  o  trabalho  da função  de  auditoria  interna  relacionado  com  esses 
riscos  significativos  será  limitada  aos  procedimentos  que  envolvem  julgamento  limitado. 
Além  disso,  quando  os  riscos  de  distorção  relevante  não  são  baixos,  é  improvável  que 
somente  o  uso  do  trabalho  da função  de  auditoria  interna  reduza  o risco da  auditoria  a  um 
nível  aceitavelmente  baixo  e  elimine  a  necessidade  do  auditor  independente  de  realizar 
diretamente alguns testes. 
 
 
18. Altera o item A4 da NBC TA 620 – Utilização do Trabalho de Especialistas, que passa a 
vigorar com a seguinte redação: 
 
A4. Um  especialista  do  auditor  pode  ser  necessário  para  ajudar  o  auditor  em  um  ou  mais  dos 
assuntos a seguir: 
•   obtenção  de  entendimento  da  entidade, do  seu  ambiente,  da  estrutura  de  relatório 
financeiro aplicável e do seu sistema de controles internos; 
•   (...) 
 
 
19. Altera  o  item  A20 da NBC  TA  701 – Comunicação  dos Principais Assuntos  de 
Auditoria  no Relatório  do Auditor Independente,  que  passa  a  vigorar  com  a  seguinte 
redação: 
 
A20.  A  NBC  TA  315,  item  12(l), define risco  significativo  como  risco  de  distorção  relevante 
identificado  para  o  qual  a  avaliação  do  risco  inerente  está  próxima  ao  limite  superior  do 
spectrum de risco inerente devido à extensão na qual os fatores de risco inerente afetam a 
combinação  de  probabilidade  de  ocorrência  de  distorção  e  a  magnitude  da  distorção  em 
potencial  caso  a  distorção  ocorra.  As  áreas  de  julgamento  significativo  da  administração e 
as  transações  significativas  e  não  usuais  podem,  frequentemente,  ser  identificadas  como 
riscos  significativos.    Riscos  significativos  são,  portanto,  áreas  que  frequentemente  exigem 
atenção significativa do auditor. 
 
 
20. Altera os itens A31 e A51 da NBC TA 720 – Responsabilidades do Auditor em Relação 
a Outras Informações, que passam a vigorar com as seguintes redações: 
 
A31.  O  conhecimento  do  auditor  obtido  na  auditoria  inclui  o  seu  entendimento  a  respeito  da 
entidade e do seu ambiente, da estrutura de relatório financeiro aplicável e do seu sistema 
de controles internos, obtido de acordo com a NBC TA 315 – Identificação e Avaliação dos 
Riscos de Distorção Relevante, itens de 19 a 27. A NBC TA 315 estabelece o entendimento 
requerido do auditor, que inclui questões como a obtenção de entendimento:  
(a) da  estrutura  organizacional,  de  propriedade  e  de  governança  da  entidade  e  de  seu 
modelo  de  negócio,  incluindo  a  extensão  na  qual  o  modelo  de  negócio  integra  a 
utilização de TI; 
(b) de fatores do setor de atividades, regulamentares e outros fatores externos relevantes; 
e  
(c) das  medidas  relevantes  utilizadas interna  e  externamente  para  avaliar  o  desempenho 
financeiro da entidade. 
 
A51.  Ao ler as outras informações, o auditor pode tomar conhecimento de novas informações que 
têm implicações para: 

 
•   o  entendimento  do  auditor  da  entidade  e  do  seu  ambiente,  da  estrutura  de  relatório 
financeiro aplicável e do seu sistema de controles internos que pode, portanto, indicar a 
necessidade de revisão da sua avaliação de risco. 
•   (...) 
 
 
21. Inclui o item 3A na NBC TR 2410 – Revisão de Informações Intermediárias Executada 
pelo Auditor da Entidade, que passa a vigorar com a seguinte redação: 
 
3A.  Esta Norma é destinada à revisão de informações intermediárias executada pelo auditor da 
entidade.   No   entanto,   deve   ser   aplicada   e   adaptada   conforme   necessário   nas 
circunstâncias, quando   o   auditor   da   entidade   se   compromete   a   revisar   informações 
contábeis  históricas  que  não  sejam  informações  contábeis  intermediárias  de  cliente  de 
auditoria. 
 
 
22.  Nos  exemplos  1  e  2  do  Apêndice  da  NBC  TA  510  (R1),  nos  exemplos  de  1  a  3  do 
Apêndice da NBC TA 570, no Apêndice 1 da NBC TA 600 (R1), nos exemplos de 1 a 5 
do Apêndice da NBC TA 705, nos apêndices 3 e 4 da NBC TA 706, nos exemplos de 1 
a 4 do Apêndice da NBC TA 710 (R1), nos exemplos de 1 a 7 do Apêndice 2 da NBC TA 
720,  nos  exemplos  de  1  a 3  do  Apêndice  da  NBC  TA  800,  nos  exemplos  de  1  a  3  do 
Apêndice 2 da NBC TA 805, nos exemplos de 1 a 5 do Apêndice da NBC TA 810, nos 
anexos de I a III do CTA 03, nos anexos de I a III do CTA 04, no Anexo do CTA 05, nos 
anexos I e II do CTA 08, nos anexos I e II do CTA 12, no Anexo do CTA 13, no Anexo I 
do  CTA  21,  no  Anexo  do  CTA  24,  nos  apêndices  de  4  a  7,  2  vezes  cada,  da  NBC  TR 
2410,  nos  anexos  de  I a  III do  CTR  02,  no Apêndice  da  NBC TO  3420,  no Anexo II  do 
CTO 01, no Anexo I do CTO 02, alterar, no final de cada documento, o texto de “... no 
CRC da firma de auditoria e do profissional que assina o relatório” para “... no CRC da 
firma de auditoria e do profissional que assina o relatório e sua categoria profissional 
de contador”. No final dos anexos I, II e IV do CTA 23, incluir a categoria profissional 
de  contador  do  responsável técnico.  No final das  ilustrações  de  1  a 7  do Apêndice  II 
da  NBC  TR  2400,  incluir  a  expressão “[Números  de  registro  no  CRC  da  firma  de 
auditoria  e  do  profissional  que  assina  o  relatório  e  sua  categoria  profissional  de 
contador]”. 
 
 
Essas alterações, inclusões e exclusões serão incorporadas nas respectivas normas e entram em 
vigor na data de sua publicação, devendo ser aplicadas aos relatórios de auditoria emitidos sobre 
as demonstrações contábeis referentes aos exercícios ou períodos que se iniciam em, ou após, 1º 
de janeiro de 2022. 
  
Brasília, 19 de agosto de 2021. 
 
 
Contador Zulmir Ivânio Breda 
Presidente 
 
Ata CFC n.º 1.077.
