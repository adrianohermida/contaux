# Aprova a Revisão NBC 10, que altera a NBC TG 06(R3).

- Código externo: 2021/revisãonbc10
- Fonte: CFC 2021/REVISÃONBC10 — DOU 27/07/2021
- URL fonte: https://www2.cfc.org.br/sisweb/sre/detalhes_sre.aspx?Codigo=2021/REVIS%C3%83ONBC10&arquivo=REVISAONBC10.doc
- Arquivo original: https://www1.cfc.org.br/sisweb/SRE/docs/REVISAONBC10.pdf
- Nome do arquivo: REVISAONBC10.pdf
- Tags: Contábil, NBC, NBC TG, Revisão NBC
- Atualizado em: 2026-10-10 14:27:54.710566+00

## Resumo

Aprova a Revisão NBC 10, que altera a NBC TG 06(R3).

## Texto integral extraído

NORMA BRASILEIRA DE CONTABILIDADE, REVISÃO NBC 10, DE 17 DE JUNHO DE 2021
Aprova a Revisão  NBC  10, que altera a
NBC TG 06(R3).
O CONSELHO FEDERAL DE CONTABILIDADE, no exercício de suas atribuições legais
e regimentais e com fundamento no disposto na alínea “f” do Art. 6º do Decreto-Lei n.º 9.295/1946,
alterado pela Lei n.º 12.249/2010, faz saber que foi aprovada em seu Plenário a Revisão NBC 10,
que altera Norma Brasileira de Contabilidade (NBC):
1.Altera as alíneas (b) e (c) do item 46B e inclui os itens C1C, C20BA, C20BB e C20BC 
da NBC TG 06 (R3) – Arrendamentos, que passam a vigorar com as seguintes 
redações:
46B. O expediente prático do item 46A aplica-se apenas aos Benefícios Concedidos em
Contrato de Arrendamento que ocorram como consequência direta da pandemia da Covid-
19 e somente se todas as seguintes condições forem satisfeitas:
(a)a alteração nos pagamentos do arrendamento resulta em uma contraprestação revista
para o arrendamento que é substancialmente igual ou inferior à contraprestação para o
arrendamento imediatamente anterior à alteração;
(b)qualquer   redução   nos   pagamentos   de   arrendamento   afeta   apenas   os   pagamentos
originalmente devidos em ou antes de 30 de junho de 2022 (por exemplo, um benefício
concedido em um arrendamento cumpriria esta condição se resultasse em pagamentos de
arrendamento  reduzidos  em ou antes de  30 de  junho  de 2022  e em pagamentos  de
arrendamento aumentados que se estendam após 30 de junho de 2022); e
(c)não há alteração substancial de outros termos e condições do contrato de arrendamento.
Apêndice C
...
Data de Vigência
C1C.  A  Revisão  NBC   10,  aprovada  em  17  de  junho  de  2021,  referente  a  Benefícios
Relacionados à Covid-19 Concedidos para Arrendatários em Contratos de Arrendamento
que vão além de 30 de junho de 2021, modificou o item 46B e acrescentou os itens C20BA e
C20BB.
Benefício em contrato de arrendamento relacionada à Covid-19 para arrendatários
C20BA. O arrendatário deve aplicar o Benefício Relacionado à Covid-19 Concedido em
Contratos   de   Arrendamento  que   vão   além   de   30   de   junho   de   2021  (ver   item   C1B)
retrospectivamente, reconhecendo o efeito cumulativo da aplicação inicial dessa revisão
como um ajuste no saldo inicial dos lucros acumulados (ou outro componente do patrimônio
líquido, conforme apropriado) no início do período em que o arrendatário aplicar a revisão
pela primeira vez.
C20BB.   No   período   em   que   o   arrendatário   aplicar,   pela   primeira   vez,   o   Benefício
Relacionado à Covid-19 Concedido em Contratos de Arrendamento que vão além de 30 de
junho de 2021, o arrendatário não precisa divulgar a informação requerida pelo item 28 (f) da
NBC TG 23 – Políticas Contábeis, Mudança de Estimativa e Retificação de Erro.
C20BC. Ao aplicar o item 2 desta Norma, o arrendatário deve aplicar o expediente prático do
item 46A de forma consistente para os contratos que atenderem as condições e tiverem
características e estiverem em circunstâncias similares, independentemente de o contrato
ter se tornado elegível para o expediente prático referente Benefícios Relacionados à Covid-
19 Concedidos para Arrendatários em Contratos de Arrendamento (conforme descrito no
item C1A) ou após 30 de junho de 2021 (conforme descrito no item C1C).

Essas alterações e inclusões serão incorporadas à NBC TG 06 (R3) e entram em vigor na data de
sua publicação, produzindo seus efeitos a partir de 02 de agosto de 2021, aplicando-se aos
exercícios iniciados em, ou após, 1º de janeiro de 2021.
 
Brasília, 17 de junho de 2021.
Contador Zulmir Ivânio Breda
Presidente
Ata CFC n.º 1.076.
