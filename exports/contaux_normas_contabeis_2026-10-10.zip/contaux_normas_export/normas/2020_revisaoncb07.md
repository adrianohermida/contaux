# Aprova Revisão NBC 07, altera NBCTG 06 (R3) - Operações de A

- Código externo: 2020/revisaoncb07
- Fonte: CFC 2020/REVISAONCB07 — DOU 15/07/2020
- URL fonte: https://www2.cfc.org.br/sisweb/sre/detalhes_sre.aspx?Codigo=2020/REVISAONCB07&arquivo=REVISAONBC07.doc
- Arquivo original: https://www1.cfc.org.br/sisweb/SRE/docs/REVISAONBC07.pdf
- Nome do arquivo: REVISAONBC07.pdf
- Tags: Contábil, NBC, Revisão NBC
- Atualizado em: 2026-10-10 14:27:54.308293+00

## Resumo

Aprova Revisão NBC 07, altera NBCTG 06 (R3) - Operações de A

## Texto integral extraído

NORMA BRASILEIRA DE CONTABILIDADE, REVISÃO NBC 07, DE 06 DE JULHO DE 2020 
 
 
Aprova  a  Revisão  NBC  07, que  altera  a  NBC 
TG 06 (R3). 
 
 
O CONSELHO FEDERAL DE CONTABILIDADE, no exercício de suas atribuições legais 
e  regimentais  e  com  fundamento  no  disposto  na  alínea  “f”  do  Art.  6º  do  Decreto-Lei  n.º 
9.295/1946,  alterado  pela  Lei  n.º  12.249/2010, 
faz  saber  que  foi  aprovada ad  referendum  do 
Plenário
 a Revisão NBC 07, que altera as seguintes normas: 
 
 
1.   Inclui  os  itens  46A,  46B,  60A,  C1A,  C20A,  e  seu título,  e  C20B  na  NBC  TG  06  (R3)  – 
Arrendamentos, que passam a vigorar com as seguintes redações: 
 
46A.  Como  expediente  prático,  o  arrendatário  pode  optar  por  não  avaliar  se  um  Benefício 
Relacionado  à  Covid-19  Concedido  para  Arrendatário em  Contrato  de  Arrendamento,  que 
atenda  aos  requisitos  do  item  46B,  é  uma  modificação  do  contrato  de  arrendamento.  O 
arrendatário  que  fizer  essa  opção  deve  contabilizar  qualquer  mudança  no  pagamento  do 
arrendamento  resultante  do  benefício  concedido  no  contrato  de  arrendamento  da  mesma 
forma  que  contabilizaria  a  mudança  aplicando  esta  Norma  se  a  mudança  não  fosse  uma 
modificação do contrato de arrendamento. 
 
46B.    O  expediente  prático  do  item  46A  aplica-se  apenas  aos  Benefícios  Concedidos  em 
Contrato de Arrendamento que ocorram como consequência direta da pandemia da Covid-
19 e somente se todas as seguintes condições forem satisfeitas: 
(a) a  alteração  nos  pagamentos  do  arrendamento  resulta  em  uma  contraprestação 
revista para o arrendamento que é substancialmente igual ou inferior à contraprestação para 
o arrendamento imediatamente anterior à alteração; 
(b) qualquer redução nos pagamentos de arrendamento afeta apenas os pagamentos 
originalmente  devidos  em  ou  antes  de  30  de  junho  de  2021  (por  exemplo,  um  benefício 
concedido  em  um  arrendamento cumpriria  esta condição  se  resultasse em  pagamentos  de 
arrendamento  reduzidos  em  ou  antes  de  30  de  junho  de  2021  e  em  pagamentos  de 
arrendamento aumentados que se estendam após 30 de junho de 2021); e 
(c) não  há  alteração  substancial  de  outros  termos  e  condições  do  contrato  de 
arrendamento. 
 
 60A. Se o arrendatário aplicar o expediente prático do item 46A, deve divulgar: 
(a) que  aplicou  o  expediente  prático  a  todos  os  Benefícios  Concedidos  em  Contratos 
de  Arrendamento  que  atenderam  às  condições  do  item 46B  ou,  se  não  aplicou  a  todos  os 
benefícios, informações sobre a natureza dos contratos para os quais aplicou o expediente 
prático (ver item 2); e 
(b) o  montante  reconhecido  no  resultado    do  período  que  refletir  as  mudanças  nos 
pagamentos  ocasionadas  pelos  benefícios  concedidos com  relação  aos  contratos  de 
arrendamento para os quais foi aplicado o expediente prático do item 46A. 
 
Apêndice C 
... 
Data de Vigência  
 
C1A.  A  revisão  NBC  07,  referente  a  Benefícios  Relacionados  à  Covid-19  Concedidos  para 
Arrendatários em Contratos de Arrendamento, aprovada pelo CFC em 2020, acrescentou os 
itens 46A, 46B, 60A, C20A e C20B. 
 
Benefício em contrato de arrendamento relacionada à Covid-19 para arrendatários 
 

 
 
C20A.  O  arrendatário  deve  aplicar  o  Benefício  Relacionado  à  Covid-19  Concedido  em 
Contrato  de  Arrendamento  (ver  item  C1A)  retrospectivamente,  reconhecendo  o  efeito 
cumulativo  da  aplicação  inicial  dessa  revisão  como um  ajuste  no  saldo  inicial  dos  lucros 
acumulados (ou outro componente do patrimônio líquido, conforme apropriado) no início do 
período em que o arrendatário aplicar a revisão pela primeira vez. 
 
C20B. No período em que o arrendatário aplicar, pela primeira vez, o Benefício Relacionado 
à Covid-19 Concedido em Contrato de Arrendamento, o arrendatário não precisa divulgar a 
informação  requerida  pelo  item  28(f)  da  NBC  TG  23  -  Políticas  Contábeis,  Mudança  de 
Estimativa e Retificação de Erro. 
 
 
Esta  Revisão  entra  em  vigor  na  data  de  sua  publicação,  produzindo  efeitos  para  os 
períodos iniciados em, ou após, 1º de janeiro de 2020 e àqueles cujas demonstrações 
contábeis  não  tenham  sido  autorizadas  para  divulgação  na  data  da  aprovação  da 
Revisão. 
  
 
Brasília, 06 de julho de 2020. 
 
 
Contador Zulmir Ivânio Breda 
Presidente
