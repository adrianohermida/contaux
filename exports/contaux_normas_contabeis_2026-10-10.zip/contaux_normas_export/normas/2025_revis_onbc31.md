# Aprova a Revisão NBC 31, que altera outras normas.

- Código externo: 2025/revisãonbc31
- Fonte: CFC 2025/REVISÃONBC31 — DOU 25/02/2026
- URL fonte: https://www2.cfc.org.br/sisweb/sre/detalhes_sre.aspx?Codigo=2025/REVIS%C3%83ONBC31&arquivo=RevisaoNBC31.docx
- Arquivo original: https://www1.cfc.org.br/sisweb/SRE/docs/RevisaoNBC31.pdf
- Nome do arquivo: RevisaoNBC31.pdf
- Tags: Contábil, NBC, Revisão NBC
- Atualizado em: 2026-10-10 14:27:59.809896+00

## Resumo

Aprova a Revisão NBC 31, que altera outras normas.

## Texto integral extraído

SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
1 
 
NORMA BRASILEIRA DE CONTABILIDADE, REVISÃO NBC 31, DE 13 DE NOVEMBRO DE 2025 
 
Aprova a Revisão NBC 31, que altera as seguintes normas: 
NBC TG 37 (R5), NBC TG 10 (R3), NBC TG 15 (R4), NBC TG 31 
(R4), NBC TG 40 (R3), NBC TG 22 (R2), NBC TG 48, NBC TG 
36 (R3), NBC TG 19 (R2), NBC TG 45 (R3), NBC TG 46 (R2), 
NBC TG 47, NBC TG 06 (R3), NBC TG 50, NBC TG 16 (R2), NBC 
TG 03 (R3), NBC TG 23 (R2), NBC TG 24 (R2), NBC TG 32 (R4), 
NBC TG 27 (R4), NBC TG 33 (R2), NBC TG 07 (R2), NBC TG 02 
(R3), NBC TG 05 (R3), NBC TG 35 (R2), NBC TG 18 (R4), NBC 
TG 42, NBC TG 39 (R5), NBC TG 41(R2), NBC TG 21 (R4),  NBC 
TG 04 (R4), NBC TG 28 (R4), NBC TG 29 (R2), ITG 12, ITG 13 
(R2), ITG 15, ITG 01 (R1), ITG 20, ITG 07 (R1), ITG 09 (R2), 
ITG 16 (R2), ITG 18, ITG 19, ITG 21, ITG 22, ITG 17.  
 
O CONSELHO FEDERAL DE CONTABILIDADE, no exercício de suas atribuições legais e regimentais 
e com fundamento no disposto na alínea f do art. 6º do Decreto-Lei nº 9.295, de 27 de maio de 1946, 
alterado pela Lei nº 12.249, de 11 de junho de 2010, faz saber que foi aprovada em seu Plenário a Revisão 
NBC  31,  equivalente  a  Revisão  de  Pronunciamentos  Técnicos  n.º  28,  aprovada  pelo  Comitê  de 
Pronunciamentos Contábeis (CPC), que altera as Normas Brasileiras de Contabilidade (NBC): 
 
1. Inclui os itens 32(za) e 39AI e altera os itens IN9, 1, 3, 4, 4A, 5, 22, 32 e D30 e os Apêndices A e D 
na NBC TG 37 (R5) - Adoção Inicial das Normas Internacionais de Contabilidade, que passam a 
vigorar com as seguintes redações: 
Introdução 
IN9. Finalmente,  este  CFC  relembra  o  conteúdo  da  NBC  TG  ESTRUTURA  CONCEITUAL  -  Estrutura 
Conceitual para a Elaboração e Apresentação das Demonstrações ContábeisRelatório Financeiro 
e da NBC TG 26 – Apresentação das Demonstrações Contábeis NBC TG 23 – Base de Preparação 
das  Demonstrações  Contábeis.  Eles  correspondem  ao  contido  nos  documentos  do  IASB 
Framework for the Preparation and Presentation of Financial StatementsConceptual Framework 
for Financial Reporting e IAS 1 – Presentation of Financial StatementsIAS 8 – Basis of Preparation 
of  Financial  Statements,  onde  é  expressa  e  repetidamente  exigida  a  contínua  obediência  da 
prevalência  da  essência sobre  a forma.  E  isso  a ponto,  de  caso  a  adoção  de  qualquer  Norma, 
Interpretação  ou  Comunicado  provoque  deformação  das  demonstrações  contábeis  de  tal 
maneira que a efetiva realidade não seja devidamente apresentada, a entidade não deve aplicar 
esse  documento,  no  seu  todo  ou  em  parte,  substituindo-o  pelo  procedimento  julgado  mais 
apropriado  à   situação   para   que   as   demonstrações   contábeis   atinjam   seu   objetivo.   Os 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
2 
 
procedimentos,  inclusive  de  fundamentação  e  evidenciação,  relativos  a  essa  situação  que  se 
espera seja extremamente rara, devem ser devidamente divulgados como citado no item 19 da 
NBC TG 26 6E da NBC TG 23. 
Objetivo 
1 O objetivo desta Revisão é garantir que as primeiras demonstrações contábeis de uma entidade 
de  acordo  com  as Normas  Internacionais de  Contabilidade  emitidas pelo  IASB  – International 
Accounting Standards Board,  doravante  referenciadas  como  IFRSs  – International Financial 
Reporting Standards,  e  as  demonstrações  contábeis  intermediárias  para  os  períodos  parciais 
cobertos  por  essas  demonstrações  contábeis  contenham  informações  de  alta  qualidade  que: 
 
(a) sejam  transparentes  para  os  usuários  e  comparáveis  em  relação  a  todos  os  períodos 
apresentados; 
(b) proporcionem um ponto de partida adequado para as contabilizações de acordo com as 
Normas de Contabilidade IFRS IFRSs; e 
(c) possam ser geradas a um custo que não supere os benefícios. 
Alcance 
 ... 
3 As   primeiras   demonstrações   contábeis   de   uma   entidade   em   IFRSs   são   as   primeiras 
demonstrações anuais em que a entidade adota as IFRSs, declarando de forma explícita e sem 
ressalvas, que essas demonstrações estão em conformidade com tais Normas de Contabilidade 
IFRSIFRSs. As demonstrações contábeis de acordo com as IFRSs são as primeiras demonstrações 
contábeis da entidade em IFRSs quando, por exemplo, a entidade: 
(a) tiver apresentado suas demonstrações contábeis anteriores mais recentes: 
 ... 
(ii) em conformidade com as IFRSs em todos os aspectos, exceto pelo fato de que 
nessas  demonstrações  não  está  contida  uma  declaração  explícita  e  sem 
ressalvas  de  que  elas  estão  de  acordo  com  as Normas  de  Contabilidade 
IFRSIFRSs;  
(iii) contenham uma declaração explícita de cumprimento de algumas, porém não 
com todas as Normas de Contabilidade IFRS IFRSs; 
 ... 
(c) tiver elaborado um conjunto de demonstrações contábeis de acordo com as IFRSs para 
fins de consolidação, mas que não é o conjunto completo de demonstrações contábeis 
elaboradas  de  acordo  com  a  IFRS  18  (NBC  TG  51  – Apresentação e Divulgação nas 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
3 
 
Demonstrações Contábeis) a IAS 1 – Presentation of Financial Statements (NBC TG 26 – 
Apresentação das Demonstrações Contábeis);  
 ... 
4 Esta Revisão deve ser aplicado quando a entidade adota pela primeira vez as IFRSs. Esta Revisão 
não deve ser aplicado, por exemplo, quando a entidade: 
(a) tenha  interrompido  a  apresentação  de  demonstrações  contábeis  de  acordo  com 
requisitos  societários,  tendo  antes  apresentado-as  bem  como  outro  conjunto  de 
demonstrações  contábeis  que  continha  uma  declaração  explícita  e  sem  ressalvas  de 
conformidade com as Normas de Contabilidade IFRSIFRSs; 
(b) tenha  apresentado  demonstrações  contábeis  em  anos  anteriores  de  acordo  com  os 
requerimentos  societários  nas  quais  estava  contida  uma  declaração  explícita  e  sem 
ressalvas de conformidade com as Normas de Contabilidade IFRSIFRSs; ou 
(c) tenha  apresentado  demonstrações  contábeis  em  anos  anteriores  nas  quais  estava 
contida uma declaração explícita e sem ressalvas de conformidade com as Normas de 
Contabilidade IFRSIFRSs,  independentemente  de  os  auditores  terem  ressalvado  as 
demonstrações auditadas. 
4A Independente dos  requerimentos dos  itens  2  e  3,  a  entidade  que  tenha aplicado  as  IFRSs em 
suas demonstrações contábeis anteriores, mas que a sua mais recente demonstração contábil 
não  contém  declaração  explícita  e  sem  ressalvas  de  que  essas  demonstrações  estão  em 
conformidade com as Normas de Contabilidade IFRSIFRSs, deve aplicar esta Norma ou, ainda, 
aplicar  as  IFRSs  retrospectivamente  de  acordo  com  IAS  8  – Accounting Policies, Changes in 
Accounting Estimates and Errors Basis of Preparation of Financial Statements (NBC TG 23 – Base 
de  Preparação  das  Demonstrações  Contábeis  Políticas  Contábeis,  Mudança  de  Estimativa  e 
Retificação de Erro).  
 ... 
5 Esta Revisão não é aplicável às mudanças de políticas contábeis feitas por entidade que já aplica 
as IFRSs. Nesse caso, tais mudanças estão sujeitas às: 
 
(a) exigências relativas às mudanças nas políticas contábeis conforme IAS 8 – Accounting 
Policies, Changes in Accounting Estimates and Errors (NBC TG 23 – Políticas Contábeis, 
Mudança de Estimativa e Retificação de Erro); e 
 ... 
Apresentação e evidenciação 
 ... 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
4 
 
Informação comparativa 
 ... 
Informação comparativa e resumo histórico divergente das IFRSs 
22 Algumas   entidades   apresentam   resumos   históricos   de   dados   específicos   para   períodos 
anteriores àquele em que, pela primeira vez, apresentaram informação comparativa integral de 
acordo  com  as  IFRSs.  Esta  Revisão  não  exige  tais  resumos  para  cumprir  as  exigências  de 
reconhecimento   e   mensuração   das   IFRSs.   Além   disso,   algumas   entidades   apresentam 
informação  comparativa  de  acordo  com  os  critérios  contábeis  anteriores  assim  como  a 
informação comparativa exigida pela IFRS 18 (NBC TG 51) IAS 1 (NBC TG 26 – Apresentação das 
Demonstrações Contábeis).  Nas demonstrações contábeis que  contiverem  resumos  históricos 
ou informações comparativas de acordo com os critérios contábeis anteriores, a entidade deve: 
 ... 
Explicação da transição para as IFRSs 
 ... 
Demonstrações contábeis intermediárias 
32 Para  cumprir  com  o  disposto  no  item  23,  quando  a  entidade  apresenta  suas  demonstrações 
contábeis intermediárias, de acordo com a  IAS 34  – Interim Financial Reporting  (NBC TG 21 – 
Demonstração   Intermediária)   para   a   parte   do   período   coberto   pelas   suas   primeiras 
demonstrações contábeis  em  IFRSs,  a  entidade  deve  atender,  adicionalmente  ao  exigido pela 
aos requisitos da IAS 34 (NBC TG 21), as seguintes exigências salvo se de outro modo declarado, 
bem como os seguintes requisitos: 
 
(za) A entidade deve apresentar cada título que espera utilizar na aplicação da IFRS 18 (NBC 
TG  51)  e  os  subtotais  exigidos  pelos  itens  de  69  a  74  desta  norma,  não  obstante  os 
requisitos do item 10 da IAS 34 (NBC TG 21). A entidade deve aplicar os requisitos do 
item  10  da  IAS  34  (NBC  TG  21)  para  títulos  e  subtotais  nas  demonstrações  contábeis 
condensadas  depois  de  ter  emitido  as  suas  primeiras  demonstrações  contábeis  de 
acordo com a IFRS 18 (NBC TG 51). 
 ... 
Início de vigência 
 ... 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
5 
 
39AJ A Revisão NBC 31, aprovada pelo CFC em 10 de outubro de 2025, alterou os itens IN9, 1, 3, 4, 
4A, 5, 22, 32, D30 e E2, alterou o Apêndice A e incluiu a letra (za) ao item 32. A entidade deve 
aplicar essas alterações quando aplicar o NBC TG 51. 
 ... 
Apêndice A – Glossário de termos utilizados na Revisão 
... 
Primeiras demonstrações contábeis em IFRSs são as primeiras demonstrações contábeis anuais nas quais 
a entidade adota as Normas de Contabilidade IFRSIFRSs por meio de declaração explícita e sem ressalvas 
de conformidade com as Normas de Contabilidade IFRSIFRSs. 
... 
Normas Internacionais de Contabilidade IFRS (IFRSs)  são  normas  contábeis  e  interpretações  adotadas 
pelo  IASB  (International Accounting Standards Board)  e  elas  compreendem  as  International  Financial 
Reporting Standards (IFRSs) emitidas pelo IASB, as International Accounting Standards (IASs) emitidas 
pelo  seu  antecessor,  o  IASC  (International Accounting Standards Committee)  e  as  Interpretações 
desenvolvidas  pelo  IFRIC  (International Financial Reporting Interpretations Committee)  e  pelo  seu 
antecessor,  o  SIC  (Standing  Interpretations  Committee). As  Normas  de  Contabilidade  IFRS  eram 
anteriormente conhecidas como Normas Internacionais de Relatório Financeiro, IFRS, IFRSs e Normas 
IFRS. 
 ... 
Apêndice D - Isenções de outras IFRS 
 ... 
Hiperinflação severa 
 ... 
D30 Quando  a  data  de  normalização  da  moeda  funcional   se  encontrar  dentro  do  período 
comparativo de 12 meses, o período comparativo pode ser inferior a 12 meses, desde que um 
conjunto completo de demonstrações contábeis (conforme requerido pelo item 10 da IFRS 18 
(NBC TG  51)  IAS  1,  (NBC TG  26  –  Apresentação das  Demonstrações  Contábeis)  seja  fornecido 
para esse período mais curto. 
 ... 
 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
6 
 
2. Inclui uma nota de rodapé ao item 59B na NBC TG 10 (R3) - Pagamento Baseado em Ações, que 
passa a vigorar com as seguintes redações: 
 
Uma nota de rodapé é acrescentada à “NBC TG 23 – Políticas Contábeis, Mudança de Estimativa e 
Retificação de Erro” no item 59B. O novo texto está sublinhado. 
 
* Quando emitiu a Revisão NBC 31 em 10 de outubro de 2025, o NBC TG alterou o título da NBC 
TG 23 para Base de Preparação das Demonstrações Contábeis. 
3. Altera os itens 50 e B64.  inclui o item 64R na NBC TG 15 (R4) – Combinação de Negócios, que 
passam a vigorar com as seguintes redações: 
Método de aquisição 
 ... 
Período de Mensuração 
 ... 
50 Após  o  encerramento  do  período  de  mensuração,  o  adquirente  deve  revisar  os  registros 
contábeis  da  combinação  de  negócios  somente  para  corrigir  erros,  em  conformidade  com  o 
disposto na NBC TG 23 – Base de Preparação das Demonstrações Contábeis Políticas Contábeis, 
Mudança de Estimativa e Retificação de Erro. 
 ... 
Vigência e transição 
Vigência 
 ... 
64R  A Revisão NBC 31, aprovada pelo CFC em 10 de outubro de 2025, alterou os itens 50 e B64. A 
entidade deve aplicar essas alterações quando aplicar a NBC TG 51. 
 ... 
Apêndice B 
Orientação de aplicação 
 ... 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
7 
 
Divulgações (aplicação dos itens 59 e 61) 
B64 Para cumprir os objetivos do item 59, o adquirente deve divulgar as informações a seguir para 
cada combinação de negócios que ocorrer ao longo do período de reporte: 
... 
(q) as seguintes informações: 
 ... 
Para o caso de ser impraticável a divulgação de qualquer das informações exigidas pela alínea 
(q), o adquirente deve divulgar esse fato e explicar por que sua divulgação é impraticável. Esta 
Revisão  utiliza  o  termo  “impraticável”  com  o  mesmo  significado  da  NBC  TG  23  – Base de 
Preparação  das  Demonstrações  Contábeis  Políticas  Contábeis, Mudança  de Estimativas  e 
Retificação de Erro. 
4. Altera os itens 2, 3, 5A, 5B, 13, 17, 26A, 33 a 36A, 38 e 39, os títulos antes dos itens 31 e 38 e 
inclui o item 44N na NBC TG 31 (R4) – Ativo Não Circulante Mantido para Venda e Operação 
Descontinuada, que passam a vigorar com as seguintes redações: 
Alcance 
2 Os requisitos de classificação, e de apresentação e divulgação desta Revisão aplicam-se a todos 
os ativos não circulantes reconhecidos e a todos os grupos de ativos mantidos para  venda da 
entidade.  Os  requisitos  de  mensuração  desta  Revisão  aplicam-se  a  todos  os  ativos  não 
circulantes reconhecidos e aos grupos de ativos mantidos para venda (tal como definido no item 
4), com exceção dos ativos listados no item 5, que devem continuar a ser mensurados de acordo 
com as normas específicas aplicáveis. 
 
3 Os  ativos  classificados  como  não  circulantes,  de  acordo  com  a  NBC  TG  51  – Apresentação e 
Divulgação  nas  Demonstrações  Contábeis  NBC  TG  26– Apresentação  das  Demonstrações 
Contábeis, não devem ser reclassificados para ativos circulantes enquanto não satisfizerem aos 
critérios de classificação como mantidos para venda de acordo com esta Revisão. Os ativos de 
uma  classe  que  a  entidade  normalmente  consideraria  como  não  circulante,  e  que  sejam 
adquiridos para revenda, não devem ser classificados como circulantes, a não ser que satisfaçam 
aos critérios de classificação como mantidos para venda de acordo com esta Revisão. 
... 
 
5A A classificação, apresentação, e a mensuração e divulgação requeridas nesta Revisão aplicáveis 
a ativo não circulante (ou grupo de ativos) classificado  como  mantido para venda também se 
aplicam a ativo não circulante (ou grupo de ativos) que seja classificado como destinado a ser 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
8 
 
distribuído  aos  sócios  na  sua  condição  de  proprietários  (mantido  para  distribuição  aos 
proprietários). 
 
5B Esta  Revisão  especifica  as  divulgações  requeridas  sobre  ativos  não  circulantes  (ou  grupos  de 
ativos)  classificados  como  mantidos  para  venda  ou  operações  descontinuadas.  Divulgações 
exigidas  por  outras Normas  não  se  aplicam  a  esses  ativos  (ou  grupos  de  ativos) a  menos que 
essas Normas exijam: 
(a) divulgação  específica  a  respeito  dos  ativos  não  circulantes  (ou  grupos  de  ativos) 
classificados como mantidos para venda ou operações descontinuadas; ou 
(b) divulgação  sobre  mensuração  de  ativos  e  passivos  de  grupo  de  ativos  mantidos  para 
venda que não estejam dentro do alcance das exigências de mensuração desta Revisão 
e que essas divulgações não estejam já disponíveis em outras notas às demonstrações 
contábeis. 
Divulgações  adicionais  sobre  ativos  não  circulantes  (ou  grupos  de  ativos)  classificados  como 
mantidos para venda ou operações descontinuadas podem ser necessárias para o atendimento 
aos  requisitos  gerais  de  divulgação  da  NBC  TG  51  e  os  requisitos  da  NBC  TG  23  – Base de 
Preparação das Demonstrações Contábeis  NBC TG 26, em particular os itens 6A e 31A da NBC 
TG 23 15 e 125 dessa Norma. 
Classificação de ativo não circulante como mantido para venda Classificação de ativo não circulante 
(ou grupos de ativos) como mantido para venda ou mantido para distribuição a sócios 
 ... 
Ativo não circulante a ser baixado 
13 A entidade não deve classificar como mantido para venda o ativo não circulante ou o grupo de 
ativos  destinado  a  ser  baixado.  Isso  se  deve  ao  fato  de  o  seu  valor  contábil  ser  recuperado 
principalmente  por  meio  do  uso  contínuo.  Contudo,  se  o  grupo  de  ativos  classificado  como 
mantido para venda que será baixado satisfizer aos critérios do item 32(a) a (c), a entidade deve 
apresentar  ou  divulgar  os  resultados  e  os  fluxos  de  caixa  do  ativo  mantido  para  venda  como 
operações descontinuadas, de acordo com os itens 33 e 34, na data na qual ele deixar de ser 
usado. Os ativos não circulantes a serem baixados incluem ativos que devem ser usados até o 
final da sua vida econômica e ativos não circulantes que devem ser fechados em vez de vendidos. 
 ... 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
9 
 
Mensuração de ativo não circulante classificado como mantido para venda Mensuração de ativo não 
circulante (ou grupos de ativos) classificado como mantidos para venda 
Mensuração de ativo não circulante mantido para venda Mensuração de ativo não circulante 
(ou grupos de ativos) 
 ... 
17 Quando se espera que a venda ocorra após um ano, a entidade deve mensurar as despesas de 
venda  pelo  valor  presente.  Qualquer  aumento  no  valor  presente  das  despesas  de  venda  que 
resulte da passagem do tempo deve ser classificado apresentado nos resultados como despesa 
financeira, aplicando-se no que couber as disposições da NBC TG 12 – Ajuste a Valor Presente 
aplicando  os  requisitos  da  NBC  TG  51  relativos  a  receitas  e  despesas  decorrentes  da 
remensuração de um ativo não circulante (ou grupo de ativos) classificado como mantido para 
venda. 
 ... 
Alteração em plano de venda ou em plano de distribuição aos proprietários 
 ... 
26A Se a entidade  reclassificar um ativo (ou  grupo de ativos) diretamente de mantido para venda 
para mantido para distribuição aos proprietários, ou diretamente de mantido para distribuição 
aos  proprietários  para  mantido  para  venda,  então,  a  mudança  na  classificação  deve  ser 
considerada como continuação do plano original de alienação. A entidade: 
(a) não  deve  seguir  a  orientação  dos  itens  27  a  29  para  contabilizar  essa  mudança.  A 
entidade  deve  aplicar  os  requisitos  de  classificação,  apresentação,  e  mensuração  e 
divulgação desta Revisão aplicáveis ao novo método de alienação; 
 ... 
... 
Apresentação e divulgação 
 ... 
Apresentação de operação Operação descontinuada 
31 Um componente  da  entidade  compreende  operações  e  fluxos  de  caixa  que  podem  ser 
claramente  distinguidos,  operacionalmente  e  para  fins  de  divulgação  nas  demonstrações 
contábeis, do resto da entidade. Em outras palavras, um componente da entidade terá sido uma 
unidade geradora de caixa ou um grupo de unidades geradoras de caixa enquanto mantido em 
uso. 
 ... 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
10 
 
33 A entidade deve apresentar ou evidenciar: 
... 
(b) análise da quantia única referida na alínea (a) com: 
(i) as  receitas,  as  despesas  e  o  resultado  antes  dos  tributos  das  operações 
descontinuadas; 
(ii) as despesas com os tributos sobre o lucro relacionadas conforme exigido pelo 
item 81(h) da NBC TG 32 – Tributos sobre o Lucro; 
(iii) os ganhos ou as perdas reconhecidas na mensuração pelo valor justo menos as 
despesas de venda ou na alienação de ativos ou de grupo de ativos mantidos 
para venda que constitua a operação descontinuada; e 
(iv) as despesas de imposto de renda tributos sobre o lucro relacionadas conforme 
exigido pelo item 81(h) da NBC TG 32. 
 A análise pode ser apresentada na demonstração do resultado ou divulgada nas notas 
explicativas ou na demonstração do resultado. Se for apresentada na demonstração do 
resultado, deve ser classificada apresentada na categoria de operações descontinuadas 
em seção identificada e que esteja relacionada com as operações descontinuadas, isto 
é, separadamente das operações em continuidade. A análise não é exigida para grupos 
de ativos mantidos para venda que sejam controladas recém-adquiridas que satisfaçam 
aos critérios de classificação como  destinadas à venda no momento da aquisição  (ver 
item 11). 
(c) os fluxos de caixa líquidos atribuíveis às atividades operacionais, de investimento e de 
financiamento  de  operações  descontinuadas.  Essas  informações  Essas  evidenciações 
podem ser apresentadas na demonstração dos fluxos de caixa ou divulgadas nas notas 
explicativas ou nos quadros das demonstrações contábeis. Essas evidenciações não são 
exigidas  para  grupos  de  alienação  que  sejam  subsidiárias  recém-adquiridas  que 
atendam aos critérios para serem classificadas como mantidas para venda na aquisição 
(ver item 11). 
(d) o montante do resultado das operações continuadas e o das operações descontinuadas 
atribuível  aos  acionistas  controladores.  Essas  informações  podem  Essa  evidenciação 
pode  ser  apresentadas  na  demonstração  do  resultado  ou  divulgadas  ser  apresentada 
alternativamente nas notas explicativas que tratam do resultado. 
33A Se  a  entidade  apresentar  a  demonstração  do  resultado  do  período  como  uma  demonstração 
separada, conforme descrito no item 12(b) da NBC TG 5110A da NBC TG 26, uma categoria seção 
identificada  como  relacionada  às  operações  descontinuadas  deve  ser  apresentada  na  nessa 
demonstração do resultado. 
34 A entidade deve reapresentar apresentar novamente as apresentações e divulgações do item 
33  para  períodos  anteriores  apresentados  nas  demonstrações  contábeis,  de  forma  que  as 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
11 
 
apresentações  e   divulgações  se  relacionem  com  todas  as  operações  que  tenham  sido 
descontinuadas à data do balanço do último período apresentado. 
35 Os   ajustes   efetuados   no   período   corrente   nos   montantes   anteriormente   classificados 
apresentados  na  categoria  de  operações  descontinuadas  em  operações  descontinuadas,  que 
estejam diretamente relacionados com a baixa de operação descontinuada em período anterior 
também devem ser classificados separadamente na categoria de operações descontinuadas nas 
operações  descontinuadas.  A  natureza  e  o  montante  desses  ajustes  devem  ser  divulgados. 
Exemplos de circunstâncias em que esses ajustes podem ocorrer incluem o seguinte: 
 ... 
36 Se a entidade deixar de classificar um componente como mantido para venda, os resultados das 
operações do componente anteriormente classificado apresentado na categoria de operações 
descontinuadas  em  operações  descontinuadas,  de  acordo  com  os  itens  33  a  35,  devem  ser 
reclassificados e incluídos no resultado das operações em continuidade em todos os períodos 
apresentados.  Os  montantes  relativos  a  períodos  anteriores  devem  ser descritos  como  tendo 
sido novamente apresentados. 
36A A entidade que esteja compromissada com plano de venda do controle de uma controlada deve 
apresentar ou divulgar as informações requeridas nos itens 33 a 36 quando a controlada for um 
grupo de ativos e passivos mantidos para venda dentro da definição de operação descontinuada 
conforme o item 32. 
 ... 
Ativo Apresentação de ativo não circulante ou grupo de ativos classificado como mantido 
para venda 
38 A  entidade  deve  apresentar  o  ativo  não  circulante  classificado  como  mantido  para  venda 
separadamente  dos  outros  ativos  no  balanço  patrimonial.  Os  passivos  de  grupo  de  ativos 
classificado  como  mantido  para  venda  devem  ser  apresentados  separadamente  dos  outros 
passivos  no  balanço  patrimonial.  Esses  ativos  e  passivos  não  devem  ser  compensados  nem 
apresentados  em  um  único  montante.  As  principais  classes  de  ativos  e  passivos  classificados 
como  mantidos  para  venda  devem  ser  apresentadas  divulgadas  separadamente  no  balanço 
patrimonial  ou  divulgadas  nas  notas  explicativas,  exceto  conforme  permitido  pelo  item 39.  A 
entidade deve apresentar separadamente qualquer receita ou despesa acumulada reconhecida 
diretamente no patrimônio líquido (outros resultados abrangentes) relacionada a um ativo não 
circulante ou a um grupo de ativos classificado como mantido para venda. 
39 Se  o  grupo  de  ativos  mantido  para  venda  for  controlada  recém-adquirida  que  satisfaça  aos 
critérios de classificação como destinada à venda no momento da aquisição (ver item 11), não é 
exigida a apresentação ou divulgação das principais classes de ativos e passivos.  
 ... 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
12 
 
Data de vigência 
 ... 
44N A Revisão NBC 31, aprovada pelo CFC em 10 de outubro de 2025, alterou os itens 2, 3, 5A, 5B, 
13, 17, 26A, 33–36A, 38 e 39, e os títulos antes dos itens 31 e 38. A entidade deverá aplicar essas 
alterações quando aplicar a NBC TG 51. 
 
5. Altera os itens 3, 8, 20, 21, 24C, 24E, 24F, 24G, B5, B7 e B46 e inclui os itens 19A, 19B e 44KK na 
NBC TG 40 (R3) - Instrumentos Financeiros: Evidenciação, que passam a vigorar com as seguintes 
redações: 
Alcance 
3 Esta  Revisão  deve  ser  aplicado  por  todas  as  entidades  a  todos  os  instrumentos  financeiros, 
exceto: 
... 
(f) instrumentos  que  são  necessariamente  classificados  como  instrumentos  patrimoniais 
de  acordo  com  os  itens  16A  e  16B  ou  itens  16C  e  16D  da  NBC  TG  39  –  Instrumentos 
Financeiros:  Apresentação.  Contudo,  as  divulgações  requeridas  pelos  itens  19A  e  19B 
são requeridas para esses instrumentos. 
 ... 
Significância de instrumentos financeiros para a posição patrimonial e financeira e para a análise do 
desempenho 
 ... 
Balanço Patrimonial 
Categorias de ativos financeiros e passivos financeiros 
8 O  valor  contábil  de  cada  categoria  a  seguir,  como  especificado  na  NBC  TG  48,  deve  ser 
apresentado divulgado no balanço patrimonial ou divulgado nas notas explicativas: 
 ... 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
13 
 
Instrumentos financeiros classificados como patrimônio líquido de acordo com os itens 16A e 
16B ou itens 16C e 16D da NBC TG 39 (R5)  
19A Para   instrumentos   financeiros   com   opção   de   venda   classificados   como   instrumentos 
patrimoniais  de  acordo  com  os  itens  16A  e  16B  da  NBC  TG  39,  uma  entidade  divulgará  (na 
medida em que não tenha divulgado em outro lugar): 
(a) dados quantitativos resumidos sobre o valor classificado como patrimônio líquido; 
(b) seus  objetivos,  políticas  e  processos  para  gerenciar  a  sua  obrigação  de  recomprar  ou 
resgatar   os   instrumentos,   quando   for   obrigada   a   fazê-lo   pelos   titulares   desses 
instrumentos, incluindo quaisquer alterações em relação ao período anterior; 
(c) a  saída  de  caixa  esperada  por  ocasião  do  resgate  ou  recompra  dessa  classe  de 
instrumentos financeiros; e 
(d) informações sobre como a saída de caixa esperada por ocasião do resgate ou recompra 
foi determinada. 
19B Se  uma  entidade  tiver  reclassificado  quaisquer  dos  seguintes  instrumentos  financeiros  entre 
passivos  financeiros  e  patrimônio  líquido,  ela  divulgará  o  valor  reclassificado  para/de  cada 
categoria (passivos financeiros ou patrimônio líquido) e a época e o motivo dessa reclassificação: 
(a) um  instrumento  financeiro  com  opção  de  venda  classificado  como  um  instrumento 
patrimonial aplicando os itens 16A e 16B da NBC TG 39, ou 
(b) um instrumento que impõe à entidade uma obrigação  de entregar a uma outra parte 
uma parcela pro rata dos ativos líquidos da entidade apenas por ocasião da liquidação 
da entidade e que é classificado como um instrumento patrimonial aplicando os itens 
16C e 16D da NBC TG 39. 
Demonstrações do resultado e do resultado abrangente 
Itens de receita, despesa, ganho e perda 
20 A  entidade  deve  apresentar,  observados  os  requisitos  de  apresentação  da  NBC  TG  51  – 
Apresentação e Divulgação nas Demonstrações Contábeis, divulgar os seguintes itens de receita, 
despesa,  ganho  e  perda,  quer  na  demonstração  do  resultado  abrangente  ou  divulgá-las  nas 
notas explicativas: 
 ... 
Outras divulgações 
Políticas contábeis 
21 De acordo com o item 27A da NBC TG 23 – Base de Preparação das Demonstrações Contábeis 
117  da  NBC  TG  26  – Apresentação das Demonstrações Contábeis,  a  entidade  deve  divulgar  a 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
14 
 
informação de política contábil material. Espera-se que as informações sobre a base (ou bases) 
de  mensuração  para  instrumentos  financeiros  usados  na  preparação  das  demonstrações 
contábeis sejam informações materiais de política contábil. 
Contabilidade de hedge 
 ... 
Efeitos da contabilização de hedge sobre a posição financeira e sobre o desempenho 
 ... 
24C A  entidade  deve  divulgar,  em  forma  de  tabela,  os  seguintes  valores  separadamente  por 
categoria de risco para os tipos de hedge: 
... 
(b) para hedges de fluxo de caixa e hedges de investimento líquido em operação no exterior: 
...  
(iv) o  valor  reclassificado  da  reserva  de hedge  de  fluxo  de  caixa  ou  da  reserva  de 
conversão   de   moeda   estrangeira   para   o   resultado   como   ajuste   de 
reclassificação (ver NBC TG 51 NBC TG 26) (diferenciando entre os valores para 
os quais a contabilização de hedge tinha sido anteriormente utilizada, mas para 
os  quais  os  fluxos  de  caixa  futuros  protegidos  não  devem  mais  ocorrer,  e  os 
valores que foram transferidos porque o item protegido afetou o resultado); 
(v) a  rubrica  na  demonstração  do  resultado  abrangente  que  inclui  o  ajuste  de 
reclassificação (ver NBC TG 51 NBC TG 26); e 
 ... 
24E A entidade deve fornecer a conciliação de cada componente do patrimônio líquido e a análise 
de outros resultados abrangentes de acordo com a NBC TG 51 NBC TG 26, que, consideradas em 
conjunto:  
 ... 
24F A  entidade  deve  fornecer  divulgar  as  informações  exigidas  no  item  24E,  separadamente,  por 
categoria  de  risco.  Essa  desagregação  por  risco  pode  ser  divulgada  fornecida  nas  notas 
explicativas às demonstrações contábeis. 
Opção para designar a exposição de crédito como mensurada ao valor justo por meio do 
resultado 
24G Se a entidade designou o instrumento financeiro, ou parte desse instrumento, como mensurado 
ao valor justo por meio do resultado porque utiliza derivativo de crédito para gerenciar o risco 
de crédito desse instrumento financeiro, a entidade deve divulgar: 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
15 
 
... 
(c) ao   descontinuar   a   mensuração   do   instrumento   financeiro,   ou   de   parte   desse 
instrumento, como ao valor justo por meio do resultado, o valor justo desse instrumento 
financeiro que se tornou o novo valor contábil de acordo com o item 6.7.4 da NBC TG 
48  e  o  respectivo  valor  nominal  ou  principal  (exceto  para  fornecer  informações 
comparativas de acordo com a NBC TG 51 NBC TG 26, a entidade não precisa continuar 
essa divulgação em períodos subsequentes). 
 ... 
Data de vigência e transição 
 ... 
44KK     A Revisão NBC 31, aprovada pelo CFC em 10 de outubro de 2025, alterou os itens 3, 8, 20, 21, 
24C,  24E,  24F,  24G,  B5,  B7  e  B46,  e  acrescentou  os  itens  19A  e  19B  e  um  subtítulo 
correspondente. A entidade aplicará essas alterações quando aplicar o NBC TG 51. 
 ... 
Apêndice B 
Guia de aplicação 
Classes de instrumentos financeiros e nível de divulgação (item 6) 
 ... 
Outras divulgações – políticas contábeis (item 21) 
B5 O item 21 requer que a divulgação de informação de política contábil material, que espera incluir 
informações sobre  a base  de mensuração para instrumentos financeiros usada na elaboração 
das demonstrações contábeis. Para instrumentos financeiros, essa evidenciação inclui: 
... 
O item 27G da NBC TG 23 – Base de Preparação das Demonstrações Contábeis 122 da NBC TG 
26 também requer que as entidades evidenciem, na nota explicativa sobre as políticas contábeis 
significativas  ou  outras  notas  explicativas,  os  julgamentos,  excetuando  aqueles  envolvendo 
estimativas,  que  a  administração  realizou  no  processo  de  aplicar  as  políticas  contábeis  da 
entidade   e   que   possuem   impacto   mais   significativo   nos   montantes   reconhecidos   nas 
demonstrações contábeis. 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
16 
 
Natureza e extensão dos riscos oriundos de instrumentos financeiros 
(itens 31 a 42) 
 ... 
Divulgação quantitativa (item 34) 
B7 O  item  34(a)  requer  a  divulgação  de  informações  quantitativas  sumarizadas  a  respeito  da 
exposição   da   entidade   baseada   na   informação   fornecida   internamente   para   o   pessoal 
administrativo chave da entidade. Quando a entidade usa vários métodos para administrar sua 
exposição de risco, deve evidenciar informações que forneçam a informação mais relevante e 
confiável.  A  NBC  TG  23 – Políticas Contábeis, Mudança de Estimativa e Retificação de Erro 
discute os termos relevância e confiabilidade. 
 ... 
Desreconhecimento (itens 42C a 42H) 
 ... 
Compensação de ativos financeiros e passivos financeiros (itens 13A a 13F) 
 ... 
Divulgação dos valores líquidos apresentados no balanço patrimonial (item 13C(c)) 
 ... 
B46 Os valores que devem ser divulgados pelo item 13C(c) devem ser conciliados com os valores de 
rubricas individuais apresentados no balanço patrimonial. Por exemplo, se a entidade que aplica 
os requisitos da NBC TG 51 agrega ou desagrega os valores apresentados em determina que a 
agregação  ou  desagregação  de  valores  de  rubricas  de  demonstrações  contábeis  individuais 
quando  a  entidade  fornece  os  valores  requeridos  pelo  item  13C(c)  fornece  informações  mais 
relevantes, ela deve conciliar esses os valores agregados ou desagregados divulgados no item 
13C(c) para os valores de rubricas individuais apresentados no balanço patrimonial. 
 
Uma nota de rodapé é acrescentada ao final do item 44II. O novo texto está sublinhado. 
 
* Quando emitiu a Revisão NBC 31, a NBC TG transferiu os requisitos de divulgar informação de 
política contábil material da NBC TG 26 para a NBC TG 23. 
 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
17 
 
6. Altera o item 23 e inclui o item 36D na NBC TG 22 (R2) – Informações por Segmento, que passam 
a vigorar com as seguintes redações: 
Divulgação 
 ... 
Informações sobre lucro ou prejuízo, ativo e passivo 
23 A entidade deve divulgar o valor do lucro ou prejuízo de cada segmento divulgável. A entidade 
deve divulgar o valor total dos ativos e passivos de cada segmento divulgável se esse valor for 
apresentado regularmente ao principal gestor das operações. A entidade deve divulgar também 
as  seguintes  informações  sobre  cada  segmento  se  os  montantes  especificados  estiverem 
incluídos  no  valor  do  lucro  ou  prejuízo  do  segmento  revisado  pelo  principal  gestor  das 
operações, ou for regularmente apresentado a este, ainda que não incluído no valor do lucro ou 
prejuízo do segmento: 
... 
(f) itens materiais de receita e despesa divulgados de acordo com o item 42 da NBC TG 51 
– Apresentação e Divulgação nas Demonstrações Contábeis item  42  da  NBC  TG  26  – 
Apresentação das Demonstrações Contábeis; 
 ... 
Transição e data de vigência 
 ... 
36D A Revisão NBC 31, aprovada pelo CFC em 10 de outubro de 2025, alterou o item 23. A entidade 
aplicará essas alterações quando aplicar o NBC TG 51. 
 
7. Altera os itens 5.6.5, 5.6.7, 5.7.10, 6.5.11, 6.5.12, 6.5.14, 6.5.15, 6.7.2 e B4.1.2A e inclui o item 
7.1.11 na NBC TG 48 – Instrumentos Financeiros, que passam a vigorar com as seguintes 
redações: 
Capítulo 5 – Mensuração 
 ... 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
18 
 
5.6 Reclassificação de ativo financeiro 
 ... 
5.6.5     Se a entidade reclassificar o ativo financeiro da categoria de mensuração ao valor justo por meio 
de outros resultados abrangentes para a categoria de mensuração ao custo amortizado, o ativo 
financeiro  deve  ser  reclassificado  ao  seu  valor  justo  na  data  da  reclassificação.  Entretanto,  o 
ganho  ou  a  perda  acumulada  anteriormente  reconhecida  em  outros  resultados  abrangentes 
deve ser transferido do patrimônio líquido e ajustado contra o valor justo do ativo financeiro na 
data  da  reclassificação.  Como  resultado,  o  ativo  financeiro  deve  ser  mensurado  na  data  da 
reclassificação como se tivesse sempre sido mensurado ao custo amortizado. Esse ajuste afetará 
outros resultados abrangentes, mas não afetará o resultado e, portanto, não deve ser ajuste de 
reclassificação (ver NBC TG 51 – Apresentação e Divulgação nas Demonstrações Contábeis NBC 
TG 26 – Apresentação das Demonstrações Contábeis). A taxa de juros efetiva e a mensuração 
de perdas de crédito esperadas não devem ser ajustadas como resultado da reclassificação (ver 
item B5.6.1). 
 ... 
5.6.7     Se a entidade reclassificar o ativo financeiro da categoria de mensuração ao valor justo, por meio 
de outros resultados abrangentes para a categoria de mensuração ao valor justo por meio do 
resultado o ativo financeiro deve continuar a ser mensurado ao valor justo. O ganho ou a perda 
acumulada,   anteriormente   reconhecido   em   outros   resultados   abrangentes,   deve   ser 
reclassificado do patrimônio líquido para o resultado como ajuste de reclassificação (ver NBC TG 
51 NBC TG 26) na data da reclassificação. 
5.7 Ganhos e perdas 
 ... 
Ativo mensurado ao valor justo por meio de outros resultados abrangentes 
5.7.10   O ganho ou a perda em ativo financeiro mensurado ao valor justo por meio de outros resultados 
abrangentes,  de  acordo  com  o  item  4.1.2A,  deve  ser  reconhecido  em  outros  resultados 
abrangentes,  exceto  ganhos  ou  perdas  por  redução  ao  valor  recuperável  (ver  Seção  5.5)  e 
ganhos  e  perdas  de  câmbio  (ver  itens  B5.7.2  e  B5.7.2A),  até  que  o  ativo  financeiro  seja 
desreconhecido ou reclassificado. Quando o ativo financeiro for desreconhecido, o ganho ou a 
perda  acumulado,  anteriormente  reconhecido  em  outros  resultados  abrangentes,  deve  ser 
reclassificado do patrimônio líquido para o resultado como ajuste de reclassificação (ver NBC TG 
51 NBC TG 26). Se o ativo financeiro for reclassificado da categoria de mensuração ao valor justo 
por  meio de  outros  resultados abrangentes,  a entidade  deve  contabilizar o  ganho  ou  a  perda 
acumulado, reconhecido anteriormente em outros resultados abrangentes, de acordo com os 
itens  5.6.5  e  5.6.7.  Os  juros  calculados  utilizando  o  método  de  juros  efetivos  devem  ser 
reconhecidos no resultado.  

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
19 
 
 ... 
Capítulo 6 – Contabilização de Hedge 
 ... 
6.5 Contabilização de relação de proteção que se qualifica 
 ... 
Hedge de fluxo de caixa 
6.5.11   Enquanto o hedge de fluxo de caixa atender aos critérios de qualificação do item 6.4.1, a relação 
de proteção deve ser contabilizada da seguinte forma: 
... 
(d) o valor acumulado na reserva de hedge de fluxo de caixa, de acordo com a alínea (a), 
deve ser contabilizado, conforme segue: 
(i) se    a    transação    prevista    protegida    resultar    subsequentemente    no 
reconhecimento  de  ativo  não  financeiro  ou  passivo  não  financeiro,  ou  a 
transação prevista protegida para ativo não financeiro ou passivo não financeiro 
tornar-se um compromisso firme para o qual a contabilização de hedge do valor 
justo  deve  ser  aplicada,  a  entidade  deve  transferir  esse  valor  da  reserva  de 
hedge de fluxo de caixa e deve incluí-la diretamente no custo inicial ou em outro 
valor contábil do ativo ou  do passivo. Isso não  é ajuste de  reclassificação (ver 
NBC TG 51 NBC TG 26) e, portanto, não afeta outros resultados abrangentes; 
(ii) para hedges  de fluxo  de  caixa que  não  sejam  aqueles  cobertos  pelo  inciso  (i), 
esse valor deve ser reclassificado da reserva de hedge de fluxo de caixa para o 
resultado como ajuste de reclassificação (ver NBC TG 51 NBC TG 26) no mesmo 
período  ou  períodos  durante  os  quais  os  fluxos  de  caixa  futuros  esperados 
protegidos afetam o resultado (por exemplo, nos períodos em que a despesa ou 
a receita de juros é reconhecida ou quando ocorre a venda prevista); 
(iii) contudo, se esse valor for uma perda e a entidade espera que a totalidade ou 
qualquer parcela dessa perda não deva ser recuperada em um ou mais períodos 
futuros, ela imediatamente deve reclassificar o valor, que não se espera que seja 
recuperado, no resultado como ajuste de reclassificação (ver NBC TG 51 NBC TG 
26). 
 
6.5.12   Quando a entidade descontinuar a contabilização de hedge para hedge de fluxo de  caixa (ver 
itens 6.5.6 e 6.5.7(b)), ela deve contabilizar o valor acumulado na reserva de hedge de fluxo de 
caixa, de acordo com o item 6.5.11(a), conforme abaixo: 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
20 
 
... 
(b) se não se espera mais que ocorram fluxos de caixa futuros protegidos, esse valor deve 
ser imediatamente reclassificado da reserva de hedge de fluxo de caixa para o resultado 
como um ajuste de reclassificação (ver NBC TG 51 NBC TG 26). Ainda se espera que um 
fluxo de caixa futuro protegido, que deixou de ser altamente provável, ocorra. 
Hedges de investimento líquido em operação no exterior 
 ... 
6.5.14   O ganho ou perda acumulada no instrumento de hedge, relacionado à parcela efetiva do hedge 
que tiver sido acumulado na reserva de conversão de moeda estrangeira, deve ser reclassificado 
do patrimônio líquido para o resultado como ajuste de reclassificação (ver NBC TG 51 NBC TG 
26), de acordo com os itens 48 e 49 da NBC TG 02, na alienação ou alienação parcial da operação 
no exterior. 
Contabilização do valor de opção no tempo 
6.5.15   Quando  a  entidade  separar  o  valor  intrínseco  e  o  valor  do  contrato  de  opção  no  tempo  e 
designar como instrumento de hedge somente a alteração no valor intrínseco da opção (ver item 
6.2.4(a)), ela deve contabilizar o valor da opção no tempo, conforme abaixo especificado  (ver 
itens B6.5.29 a B6.5.33): 
... 
(b) a  alteração  no  valor  justo  do  valor  da  opção,  no  tempo  que  cobre  o  item  protegido 
relativo à transação, deve ser reconhecida em outros resultados abrangentes na medida 
em  que  se  relacione  com  o  item  protegido  e  deve  ser  acumulada  em  componente 
separado  do  patrimônio  líquido.  A  alteração  acumulada  no  valor  justo  decorrente  do 
valor  da  opção,  no  tempo  que  tem  sido  acumulado  em  componente  separado  de 
patrimônio líquido (“valor”), deve ser contabilizada da seguinte forma: 
(i) se o item protegido resultar, subsequentemente, no reconhecimento de ativo 
não financeiro ou passivo não financeiro, ou compromisso firme para ativo não 
financeiro ou passivo não financeiro, para o qual a contabilização de hedge do 
valor justo deve ser aplicada, a entidade deve transferir o valor do componente 
separado do patrimônio líquido e deve incluí-lo diretamente no custo inicial ou 
em  outro  valor  contábil  do  ativo  ou   do  passivo.  Isso   não  é   ajuste  de 
reclassificação  (ver NBC TG 51 NBC TG 26)  e,  portanto,  não  afeta  outros 
resultados abrangentes; 
(ii) para  relação de proteção que não sejam  aquelas cobertas pelo inciso (i), esse 
valor  deve  ser  reclassificado  do  componente  separado  do  patrimônio  líquido 
para o resultado, como ajuste de reclassificação (ver NBC TG 51 NBC TG 26) no 
mesmo  período  ou  períodos  durante  os  quais  os  fluxos  de  caixa  futuros 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
21 
 
esperados  protegidos  afetam  o  resultado  (por  exemplo,  quando  ocorre  uma 
venda prevista); 
(iii) entretanto,  se  não  se  espera  que  a  totalidade  ou  parte  desse  valor  seja 
recuperada em um ou mais períodos futuros, o valor que não se espera que seja 
recuperado  deve  ser  imediatamente  reclassificado  para  o  resultado,  como 
ajuste de reclassificação (ver NBC TG 51 NBC TG 26); 
(c) a alteração no valor justo do valor de opção no tempo que cobre item protegido, relativo 
a período de tempo, deve ser reconhecida em outros resultados abrangentes na medida 
em  que  se  relacione  com  o  item  protegido  e  deve  ser  acumulada  em  componente 
separado do patrimônio líquido. O valor no tempo na data de designação da opção como 
instrumento de hedge, na medida em que se relaciona com o item protegido, deve ser 
amortizado  de  forma  sistemática  e  racional  ao  longo  do  período  durante  o  qual  o 
instrumento  de hedge  para  o  valor  intrínseco  da  opção  possa  afetar  o  resultado  (ou 
outros resultados abrangentes, se o item protegido for instrumento patrimonial para o 
qual  a  entidade  escolheu  apresentar  alterações  no  valor  justo  em  outros  resultados 
abrangentes, de acordo com o item 5.7.5). Portanto, em cada período contábil, o valor 
da amortização deve ser reclassificado do componente separado do patrimônio líquido 
para o resultado, como ajuste de reclassificação (ver NBC TG 51 NBC TG 26). Entretanto, 
se a contabilização de um hedge for descontinuada para a relação de hedge que inclui a 
mudança no valor intrínseco da opção como o instrumento de hedge, o valor líquido (ou 
seja,  incluindo  amortização  acumulada)  que  tem  sido  acumulado  no  componente 
separado do patrimônio líquido deve ser imediatamente reclassificado para o resultado, 
como ajuste de reclassificação (vide NBC TG 51 NBC TG 26). 
 ... 
6.7 Opção de designar a exposição de crédito como mensurada ao valor justo por meio do resultado 
 ... 
Contabilização de exposição de crédito designada ao valor justo por meio do resultado 
6.7.2     Se o instrumento financeiro for designado de acordo com o item 6.7.1 como mensurado ao valor 
justo por meio do resultado após seu reconhecimento inicial, ou não tiver sido anteriormente 
reconhecido, a diferença no momento da designação entre o valor contábil, se houver, e o valor 
justo deve ser imediatamente reconhecida no resultado. Para ativos financeiros mensurados ao 
valor justo por meio de outros resultados abrangentes, de acordo com o item 4.1.2A, o ganho 
ou a perda acumulada, reconhecido anteriormente em outros resultados abrangentes, deve ser 
imediatamente   reclassificado   do   patrimônio   líquido   para   o   resultado,   como   ajuste   de 
reclassificação (ver NBC TG 51 NBC TG 26). 
 ... 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
22 
 
Capítulo 7 – Data de vigência e transição 
7.1 Data de vigência 
 ... 
7.1.11   A Revisão NBC 31, aprovada pelo CFC em 10 de outubro de 2025, alterou os itens 5.6.5, 5.6.7, 
5.7.10,  6.5.11,  6.5.12,  6.5.14,  6.5.15,  6.7.2  e  B4.1.2A.  A  entidade  aplicará  essas  alterações 
quando aplicar a NBC TG 51. 
 ... 
Apêndice B 
Orientação de aplicação 
 ... 
Classificação (Capítulo 4) 
Classificação de ativo financeiro (Seção 4.1) 
Modelo de negócio da entidade para gestão de ativo financeiro 
 ... 
B4.1.2A O  modelo  de  negócios  da  entidade  refere-se  a  como  a  entidade  gerencia  seus  ativos 
financeiros  para  gerar  fluxos  de  caixa.  Ou  seja,  o  modelo  de  negócios  da  entidade 
determina se os fluxos de caixa resultam do recebimento de fluxos de caixa contratuais, 
venda de ativos financeiros ou ambos. Consequentemente, essa avaliação não é realizada 
com base em cenários que a entidade não espera razoavelmente que ocorram, tal como 
os denominados “cenários de estresse” ou “piores hipóteses”. Por exemplo, se a entidade 
espera  vender  determinada  carteira  de  ativos  financeiros  somente  em  cenário  de 
estresse,  esse  cenário  não  afeta  a  avaliação  da  entidade  do  modelo  de  negócios  para 
esses  ativos  se  a  entidade,  razoavelmente,  espera  que  esse  cenário  não  ocorra.  Se  os 
fluxos de caixa são realizados de forma diferente das expectativas da entidade na data 
em que a entidade avaliou o modelo de negócios (por exemplo, se a entidade vende mais 
ou  menos  ativos  financeiros  do  que  esperava  quando  classificou  os  ativos),  isso  não 
origina erro de período anterior nas demonstrações contábeis da entidade (ver NBC TG 
23  –  Base de Preparação das Demonstrações ContábeisPolíticas Contábeis, Mudança de 
Estimativa e Retificação de Erro)  nem  altera  a  classificação  dos  ativos  financeiros 
remanescentes  mantidos  nesse  modelo  de  negócios  (ou  seja,  aqueles  ativos  que  a 
entidade reconheceu em períodos anteriores e ainda mantém), uma vez que a entidade 
considerou  todas  as  informações  relevantes  disponíveis  na  época  em  que  realizou  a 
avaliação  do  modelo  de  negócios.  Contudo,  quando  a  entidade  avaliar  o  modelo  de 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
23 
 
negócios  para  ativos  financeiros  recentemente  concedidos  ou  comprados,  ela  deve 
considerar  informações  sobre  como  os  fluxos  de  caixa  foram  realizados  no  passado, 
juntamente com todas as demais informações relevantes. 
 
Uma nota de rodapé é acrescentada à “NBC TG 23 – Políticas Contábeis, Mudança de Estimativa e 
Retificação de Erro” no item 7.2.1. O novo texto está sublinhado. 
 
* Quando emitiu a Revisão NBC 31 em 10 de outubro de 2025, a NBC TG alterou o título do NBC 
TG 23 para Base de Preparação das Demonstrações Contábeis. 
8. Inclui uma nota de rodapé no item C2 no NBC TG 36 (R3) - Demonstrações Consolidadas, que 
passam a vigorar com as seguintes redações: 
 
Uma nota de rodapé é acrescentada à “NBC TG 23 – Políticas Contábeis, Mudança de Estimativa e 
Retificação de Erro” no item C2. O novo texto está sublinhado. 
 
* Quando emitiu a Revisão NBC 31 em 10 de outubro de 2025, a NBC TG alterou o título da NBC 
TG 23 (R2) para Base de Preparação das Demonstrações Contábeis. 
9. Inclui uma nota de rodapé no item C1B na NBC TG 19 (R2) – Negócios em Conjunto, que passam 
a vigorar com as seguintes redações: 
 
Uma nota de rodapé é acrescentada à “NBC TG 23 – Políticas Contábeis, Mudança de Estimativa e 
Retificação de Erro” no item C1B. O novo texto está sublinhado. 
 
* Quando emitiu a Revisão NBC 31, em 10 de outubro de 2025, o NBC TG alterou o título da NBC 
TG 23 (R2) para Base de Preparação das Demonstrações Contábeis. 
 
10. Altera o item B14 e inclui o item C1E na NBC TG 45 (R3) - Divulgação de Participações em Outras 
Entidades, que passam a vigorar com as seguintes redações: 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
24 
 
Apêndice B 
Guia de aplicação 
 ... 
Informações financeiras resumidas para controladas, empreendimentos controlados em conjunto 
(joint ventures) e coligadas (itens 12 e 21) 
 ... 
B14 As informações financeiras resumidas, divulgadas apresentadas de acordo com os itens B12 e 
B13, devem ser os valores incluídos nas demonstrações contábeis, elaboradas em conformidade 
com as Normas, Interpretações e Comunicados da NBC TG, do empreendimento controlado em 
conjunto (joint venture) ou da coligada (e não a parcela da entidade sobre esses valores). Se a 
entidade  contabilizar  sua  participação  no  empreendimento  controlado  em  conjunto  (joint 
venture) ou na coligada usando o método da equivalência patrimonial: 
(a) os valores incluídos nas demonstrações contábeis, elaboradas em conformidade com os 
Normas, Interpretações e Comunicados da NBC TG, do empreendimento controlado em 
conjunto (joint venture) ou da coligada devem ser ajustados para refletir ajustes feitos 
pela  entidade  ao  utilizar  o  método  da  equivalência  patrimonial,  como,  por  exemplo, 
ajustes ao valor justo feitos por ocasião da aquisição e ajustes para refletir diferenças 
nas políticas contábeis; 
(b) a  entidade  deve  fornecer  uma  conciliação  das  informações  financeiras  resumidas 
divulgadas apresentadas com o valor contábil de sua participação no empreendimento 
controlado em conjunto (joint venture) ou na coligada. 
 ... 
Apêndice C 
Data de vigência e transição 
 ... 
C1E A Revisão NBC 31, aprovada pelo CFC em 10 de outubro de 2025, alterou o item B14. A entidade 
deve aplicar essas alterações quando aplicar a NBC TG 51. 
 
11. Altera o item 51 e inclui o item C7 na NBC TG 46 (R2) - Mensuração do Valor Justo, que passam 
a vigorar com as seguintes redações: 
 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
25 
 
Mensuração 
 ... 
Aplicação a ativos financeiros e passivos financeiros com posições de compensação em riscos 
de mercado ou risco de crédito da contraparte 
 ... 
51 Para utilizar a exceção do item 48, a entidade deve tomar uma decisão sobre a política contábil 
de  acordo  com  a  NBC  TG  23  – Base de Preparação das Demonstrações Contábeis Políticas 
Contábeis, Mudança de Estimativa e Retificação de Erro. A entidade que utilizar a exceção deve 
aplicar essa política contábil, incluindo sua política para alocação de ajustes para refletir o spread 
entre os preços de compra e de venda (vide itens 53 a 55) e de ajustes de crédito (vide item 56), 
se for o caso, de forma consistente de período a período para uma carteira específica. 
 ... 
Apêndice C 
Disposições Transitórias 
 ... 
C7 A Revisão NBC 31, aprovada pelo CFC em 10 de outubro de 2025, alterou o item 51. A entidade 
aplicará essas alterações quando aplicar o NBC TG 51. 
 
12. Altera o item 43 e inclui o item C1D na NBC TG 47 - Receita de Contrato com Cliente, que passam 
a vigorar com as seguintes redações: 
 
Reconhecimento 
 ... 
Satisfação de obrigação de performance 
 ... 
Mensuração do progresso para a satisfação completa de obrigação de performance 
 ... 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
26 
 
Métodos para a mensuração do progresso 
 ...43    À  medida  que  as  circunstâncias  se  modifiquem  ao  longo  do  tempo,  a  entidade  deve 
atualizar  a  sua  mensuração  do  progresso  para  refletir  quaisquer  alterações  no  resultado  da 
obrigação de performance.  Essas  alterações  na mensuração  do  progresso  da  entidade devem 
ser contabilizadas como mudança na estimativa contábil de acordo com a NBC TG 23 – Base de 
Preparação  das  Demonstrações  ContábeisPolíticas  Contábeis,  Mudança  de  Estimativa  e 
Retificação de Erro. 
 ... 
Apêndice C 
Data de vigência e transição 
Data de vigência 
 ... 
C1D A Revisão NBC 31, aprovada pelo CFC em 10 de outubro de 2025, alterou o item 43. A entidade 
aplicará essas alterações quando aplicar a NBC TG 51. 
 
Uma nota de rodapé é acrescentada à “NBC TG 23 – Políticas Contábeis, Mudança de Estimativa e 
Retificação de Erro” no item C3(a). O novo texto está sublinhado. 
 
* Quando emitiu a Revisão NBC 31, em 10 de outubro de 2025, o NBC TG alterou o título do NBC 
TG 23 para Base de Preparação das Demonstrações Contábeis. 
 
13. Altera o item 49 e inclui o item C1E na NBC TG 06 (R3) - Arrendamentos, que passam a vigorar 
com as seguintes redações: 
Arrendatário 
 ... 
Apresentação 
 ... 
49 Na  demonstração  do  resultado  e  de  outros  resultados  abrangentes,  o  arrendatário  deve 
apresentar despesas de juros sobre o passivo de arrendamento separadamente do encargo de 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
27 
 
depreciação para o ativo de direito de uso. O item 61 da NBC TG 51 – Apresentação e Divulgação 
nas Demonstrações Contábeis exige que uma entidade classifique na categoria de financiamento 
da demonstração do resultado as despesas Despesas de juros sobre o passivo de arrendamento, 
identificado  pela  entidade  que  aplica  o item  36(a)é  um  componente  de despesas financeiras, 
que o item 82(b) da NBC TG 26 – Apresentação das Demonstrações Contábeis requer que seja 
apresentado  separadamente  na  demonstração  de  lucro  ou  prejuízo  e  outros  resultados 
abrangentes. 
 ... 
Apêndice C 
Data de vigência e transição 
Data de vigência 
 ... 
C1E A Revisão NBC 31, aprovada pelo CFC em 10 de outubro de 2025, alterou o item 49. A entidade 
aplicará essas alterações quando aplicar a NBC TG 51. 
 
Uma nota de rodapé é acrescentada à “NBC TG 23 – Políticas Contábeis, Mudança de Estimativa e 
Retificação de Erro” no item C5(a). O novo texto está sublinhado. 
 
* Quando emitiu a Revisão NBC 31, em 10 de outubro de 2025, a NBC TG alterou o título da NBC 
TG 23 para Base de Preparação das Demonstrações Contábeis. 
 
14. Altera os itens 91, 96, 103 e B129 e inclui o item C2B na NBC TG 50 - Contratos de Seguro, que 
passam a vigorar com as seguintes redações: 
 
Reconhecimento e apresentação da demonstração do resultado (itens B120 a B136) 
 ... 
Receita ou despesa financeira com seguro (ver itens B128 a B136) 
 ... 
91 Se a entidade transfere o grupo de contratos de seguro ou desreconhece o contrato de seguro, 
aplicando o item 77: 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
28 
 
(a) ela  deve  reclassificar  no  resultado  como  ajuste  de  reclassificação  (ver NBC TG 51  – 
Apresentação e Divulgação nas Demonstrações ContábeisNBC TG 26– Apresentação das 
Demonstrações Contábeis)  quaisquer  valores  remanescentes  do  grupo  (ou  contrato) 
que  foram  anteriormente  reconhecidos  no  resultado  abrangente  porque  a  entidade 
escolheu a política contábil prevista no item 88(b); 
(b) ela  não  deve  reclassificar  no resultado  como  ajuste  de  reclassificação  (ver NBC TG 51 
NBC TG 26)  quaisquer  valores  remanescentes  do  grupo  (ou  contrato)  que  foram 
anteriormente  reconhecidos  no  resultado  abrangente  porque  a  entidade  escolheu  a 
política contábil prevista no item 89(b). 
 ... 
Divulgação 
 ... 
96 Os itens 41 a 43 da NBC TG 51 Os itens 29 a 31 da NBC TG 26 definem os requisitos referentes à 
materialidade  e  agregação  e  desagregação  de  informações.  São  exemplos  de  características 
bases  de  agregação  que  podem  ser  apropriadas  como  uma  base  para  desagregar  para 
informações divulgadas sobre contratos de seguro: 
(a) tipo de contrato (por exemplo, importantes linhas de produtos); 
(b) área geográfica (por exemplo, país ou região); ou 
(c) segmento reportável, conforme definido na NBC TG 22 – Informações por Segmento. 
Explicação de valores reconhecidos 
 ... 
103 A entidade deve divulgar, separadamente, nas conciliações requeridas no item 100 cada um dos 
seguintes valores referentes a seguro, se aplicável: 
... 
(c) componentes  de  investimento  excluídos  das  receitas  de  seguro  e  das  despesas  de 
seguro  (combinados  com  reembolsos  de  prêmios,  a  menos  que  os  reembolsos  de 
prêmios  sejam  divulgados  apresentados  como  parte  dos  fluxos  de  caixa  no  período 
descrito no item 105(a)(i)). 
 ... 
Apêndice B 
Orientação de aplicação 
 ... 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
29 
 
Receita ou despesa financeira com seguro (itens 87 a 92) 
 ... 
B129     Os  itens  88  e  89  exigem  que  a  entidade  faça  a  escolha  da  política  contábil  quanto  a  se  deve 
desagregar  receitas  ou  despesas  financeiras  de  seguro  para  o  período  entre  o  resultado  e  o 
resultado  abrangente.  A  entidade  deve  aplicar  sua  escolha  de  política  contábil  a  carteiras  de 
contratos  de  seguro.  Ao  avaliar  a  política  contábil  apropriada  para  a  carteira  de  contratos  de 
seguro,  aplicando  o  item  13  da  NBC  TG  23  – Base  de  Preparação  das  Demonstrações 
ContábeisPolíticas Contábeis, Mudança de Estimativa e Retificação de Erro,  a  entidade  deve 
considerar para cada carteira os ativos que a entidade mantém e como contabiliza esses ativos. 
 ... 
Apêndice C 
Data de vigência e transição 
Data de vigência 
 ... 
C2B A Revisão NBC 31, aprovada pelo CFC em 10 de outubro de 2025, alterou os itens 91, 96, 103 e 
B129. A entidade aplicará essas alterações quando aplicar o NBC TG 51. 
 
Uma nota de rodapé é acrescentada à “NBC TG 23 – Políticas Contábeis, Mudança de Estimativa e 
Retificação de Erro” no item C3(a). O novo texto está sublinhado. 
 
* Quando emitiu a Revisão NBC 31, em 10 de outubro de 2025, o NBC TG alterou o título da NBC 
TG 23 (R2) para Base de Preparação das Demonstrações Contábeis. 
 
15. Altera o item 39 e inclui o item 40H na NBC TG 16 (R2) - Estoques, que passam a vigorar com as 
seguintes redações: 
Divulgação 
 ... 
39 Algumas   entidades   classificam   despesas   por   natureza   na   categoria   operacional   da 
demonstração do adotam um formato para resultado de uma forma que resulta em valores que 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
30 
 
estão  sendo  apresentados  divulgados  que  não  são  o  custo  de  estoques  reconhecido  como 
despesa durante o período. De acordo com esse formato, a entidade apresenta uma análise de 
despesas utilizando uma classificação baseada na natureza das despesas. Nesse caso, a entidade 
deve  apresentar  divulgar  os  custos  reconhecidos  como  despesas  item  a  item,  por  natureza: 
matérias-primas e outros materiais, benefícios aos empregados custos de mão-de-obra e outros 
custos, juntamente com o valor da diferença líquida entre estoques iniciais e finais do período. 
 
Data de vigência 
 ... 
40H A Revisão NBC 31, aprovada pelo CFC em 10 de outubro de 2025, alterou o item 39. A entidade 
aplicará essas alterações quando aplicar o NBC TG 51. 
 
16. Altera os itens 6, 10, 12, 14, 16, 17, 18, 20, 20A, 31, 32, 34A, 35, 46 e 47, inclui os itens 33A, 34B, 
34C, 34D e 64 e exclui os itens 33 e 34 na NBC TG 03 (R3) - Demonstração dos Fluxos de Caixa, 
que passam a vigorar com as seguintes redações: 
 
Definições 
6 Os seguintes termos são usados nesta Revisão, com os significados abaixo especificados: 
... 
Atividades de investimento são as referentes à aquisição e à venda de ativos de longo prazo e de 
outros  investimentos  não  incluídos  nos  equivalentes  de  caixa  e  o  recebimento  de  juros  e 
dividendos conforme descrito nos itens 34A a 34D. 
 ... 
Apresentação da demonstração dos fluxos de caixa 
10 A demonstração dos fluxos de caixa deve apresentar os fluxos de caixa do período classificados 
por atividades operacionais, de investimento e de financiamento. Ao elaborar a demonstração 
dos fluxos de caixa, uma entidade aplicará esta Revisão e também aplicará os requisitos gerais 
para demonstrações contábeis nos itens de 9 a 43, 113 e 114 da NBC TG 51 – Apresentação e 
Divulgação nas Demonstrações Contábeis. 
 ... 
12 Uma única transação pode incluir fluxos de caixa classificados em mais de uma atividade. Por 
exemplo, quando o pagamento à vista de um empréstimo inclui principal e juros, o elemento de 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
31 
 
juros  pode  ser  classificado  como  uma  atividade  operacional  e  o  elemento  de  principal  é 
classificado como uma atividade de financiamento. 
Atividades operacionais 
 ... 
14 Os  fluxos  de  caixa  advindos  das  atividades  operacionais  são  basicamente  derivados  das 
principais atividades geradoras de receita da entidade. Portanto, eles geralmente resultam de 
transações e de outros eventos que entram na apuração do lucro líquido ou prejuízo. Exemplos 
de fluxos de caixa que decorrem das atividades operacionais são: 
(a) recebimentos à vista pela venda de bens e prestação de serviços; 
(b) recebimentos à vista provenientes de royalties, honorários, comissões e outras receitas; 
(c) pagamentos à vista a fornecedores por bens e serviços; 
(d) pagamentos à vista a empregados e em seu nome; 
(e) [excluído] 
(f) pagamentos ou restituições à vista referentes a impostos sobre a renda, a menos que 
possam   ser   especificamente   associados   a   atividades   de   financiamento   e   de 
investimento; e 
(g) recebimentos e pagamentos de caixa de contratos mantidos para negociação imediata 
ou disponíveis para venda futura. 
(h) recebimentos de caixa de dividendos e recebimentos e pagamentos de caixa de juros 
conforme descrito nos itens 34B a 34D. 
Algumas transações, como a venda de item do imobilizado, podem resultar em ganho ou perda, 
que  é  incluído  na  apuração  do  lucro  líquido  ou  prejuízo.  Os  fluxos  de  caixa  relativos  a  tais 
transações  são  fluxos  de  caixa  provenientes  de  atividades  de  investimento.  Entretanto, 
pagamentos em caixa para a produção ou a aquisição de ativos mantidos para aluguel a terceiros 
que,  em  sequência,  são  vendidos,  conforme  descrito  no  item  68A  da  NBC  TG  27  -  Ativo 
Imobilizado,  são  fluxos  de  caixa  advindos  das  atividades  operacionais.  Os  recebimentos  de 
aluguéis  e das  vendas subsequentes de tais  ativos  são  também fluxos  de caixa  das  atividades 
operacionais. 
 ... 
Atividades de investimento 
16 A  apresentação  divulgação  em  separado  dos  fluxos  de  caixa  advindos  das  atividades  de 
investimento é importante em função de tais fluxos de caixa representarem a extensão em que 
os dispêndios de recursos são feitos pela entidade com a finalidade de gerar lucros e fluxos de 
caixa no futuro. Somente desembolsos que resultam em ativo reconhecido nas demonstrações 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
32 
 
contábeis são passíveis de classificação como atividades de investimento. Exemplos de fluxos de 
caixa advindos das atividades de investimento são: 
(a) pagamentos em caixa para aquisição de ativo imobilizado, intangíveis e outros ativos de 
longo   prazo.   Esses   pagamentos   incluem   aqueles   relacionados   aos   custos   de 
desenvolvimento ativados e aos ativos imobilizados de construção própria.; 
(b) recebimentos de caixa resultantes da venda de ativo imobilizado, intangíveis e outros 
ativos de longo prazo.; 
(c) pagamentos em caixa para aquisição de instrumentos patrimoniais ou instrumentos de 
dívida  de  outras  entidades  incluindo  e  participações  societárias  em  coligadas  e joint 
ventures (exceto   aqueles   pagamentos   referentes   a   títulos   considerados   como 
equivalentes de caixa ou aqueles mantidos para negociação imediata ou futura).; 
(d) recebimentos  de  caixa  provenientes  da  venda  de  instrumentos  patrimoniais  ou 
instrumentos  de  dívida  de  outras  entidades  incluindo  e  participações  societárias  em 
coligadas  e  empreendimentos  em  conjunto  (exceto  aqueles  recebimentos  referentes 
aos   títulos   considerados   como   equivalentes   de   caixa   e   aqueles   mantidos   para 
negociação imediata ou futura).; 
(e) adiantamentos   em   caixa   e   empréstimos   feitos   a   terceiros   (exceto   aqueles 
adiantamentos e empréstimos feitos por instituição financeira).; 
(f) recebimentos   de   caixa   pela   liquidação   de   adiantamentos   ou   amortização   de 
empréstimos concedidos a terceiros (exceto aqueles adiantamentos e empréstimos de 
instituição financeira).; 
(g) pagamentos à vista referentes a contratos de futuros, contratos a termo, contratos de 
opções e contratos de swap, exceto quando esses contratos sejam mantidos para fins 
de negociação ou comercialização ou quando os pagamentos sejam classificados como 
atividades de financiamento.; e 
(h) recebimentos de caixa por contratos futuros, a termo, de opção e swap, exceto quando 
tais  contratos  forem  mantidos  para  negociação  imediata  ou  venda  futura,  ou  os 
recebimentos forem classificados como atividades de financiamento. 
(i) recebimentos de caixa de juros e dividendos conforme descrito nos itens 34A a 34D. 
Quando um contrato for contabilizado como proteção (hedge) de posição identificável, os fluxos 
de caixa do contrato devem ser classificados do mesmo modo como foram classificados os fluxos 
de caixa da posição que estiver sendo protegida. 
Atividades de financiamento 
17 A   apresentação   divulgação   separada   dos   fluxos   de   caixa   advindos   das   atividades   de 
financiamento é importante por ser útil na predição de exigências de fluxos futuros de caixa por 
parte de fornecedores de capital à entidade. Exemplos de fluxos de caixa advindos das atividades 
de financiamento são: 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
33 
 
(a) caixa recebido pela emissão de ações ou outros instrumentos de patrimônio; 
(b) pagamentos em caixa a investidores para adquirir ou resgatar ações da entidade; 
(c) caixa  recebido  pela  emissão  de  debêntures,  empréstimos,  notas  promissórias,  outros 
títulos de dívida, hipotecas e outros empréstimos de curto e longo prazos; 
(d) amortização de empréstimos e financiamentos; e 
(e) pagamentos   em   caixa   pelo   arrendatário   para   redução   do   passivo   relativo   a 
arrendamento; 
(f) pagamentos em caixa de dividendos conforme descrito no item 33A; e 
(g) pagamentos em caixa de juros conforme descrito nos itens 34A a 34D. 
Apresentação dos fluxos de caixa de atividades operacionais 
18 A   entidade   deve   apresentar   os   fluxos   de   caixa   das   atividades   operacionais,   usando 
alternativamente: 
(a) o  método  direto,  segundo  o  qual  as  principais  classes  de  recebimentos  brutos  e 
pagamentos brutos são divulgadas; ou 
(b) o método indireto, pelo qual o lucro líquido ou o prejuízo operacional é ajustado pelos 
para: 
(i) efeitos de transações que não envolvem caixa;, 
(ii) pelos efeitos de quaisquer diferimentos ou apropriações por competência sobre 
recebimentos  de  caixa  ou  pagamentos  em  caixa  operacionais  passados  ou 
futuros;, 
(iii) receitas ou despesas classificadas na categoria operacional na demonstração do 
resultado  para  as  quais  os  fluxos  de  caixa  associados  são  classificados  como 
fluxos de caixa de atividades de investimento ou de financiamento; e 
(iv) fluxos de caixa de atividades operacionais para os quais as receitas ou despesas 
associadas não são classificadas na categoria operacional da demonstração do 
resultado e pelos efeitos de itens de receita ou despesa associados com fluxos 
de caixa das atividades de investimento ou de financiamento. 
 ... 
20 De acordo com o método indireto, o fluxo de caixa líquido advindo das atividades operacionais 
é determinado ajustando o lucro líquido ou prejuízo operacional quanto aos efeitos de: 
(a) variações  ocorridas  no  período  nos  estoques  e  nas  contas  operacionais  a  receber  e  a 
pagar; 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
34 
 
(b) itens que não afetam o caixa, como depreciação, provisões e, impostos diferidos, ganhos 
e perdas cambiais não realizados classificados na categoria operacional e resultado de 
equivalência patrimonial quando aplicável; e 
(c) receitas  ou  despesas  classificadas  na  categoria  operacional  na  demonstração  do 
resultado  todos  os  outros  itens  tratados  tratadas  como  fluxos  de  caixa  advindos 
advindas das atividades de investimento e de financiamento; e. 
(d) fluxos de caixa operacionais, tais como tributos sobre o lucro (de acordo com o item 35), 
para os quais as receitas ou despesas correspondentes não são classificadas na categoria 
operacional na demonstração do resultado. 
Alternativamente,  o  fluxo  de  caixa  líquido  advindo  das  atividades  operacionais  pode  ser 
apresentado pelo método indireto, mostrando-se as receitas e despesas classificadas divulgadas 
na demonstração do resultado, ou resultado abrangente e as variações ocorridas no período nos 
estoques  e  nas  contas  operacionais  a  receber  e  a  pagar  e  quaisquer  outros  fluxos  de  caixa 
operacionais  para  os  quais  as  correspondentes  receitas  ou  despesas  não  são  classificadas  na 
categoria operacional. 
 
20A A  conciliação  entre  o  lucro  ou  prejuízo  operacional  líquido  e  o  fluxo  de  caixa  líquido  das 
atividades  operacionais  deve  ser  fornecida,  obrigatoriamente,  caso  a  entidade  use  o  método 
direto para  apurar  o  fluxo  líquido  das  atividades  operacionais.  A  conciliação  deve  apresentar, 
separadamente,  por  categoria,  os  principais  itens  a  serem  conciliados,  à  semelhança  do  que 
deve  fazer  a  entidade  que  usa  o  método  indireto  em  relação  aos  ajustes  ao  lucro  líquido  ou 
prejuízo operacional para apurar o fluxo de caixa líquido das atividades operacionais. 
... 
Juros e dividendos 
31 Os fluxos de caixa referentes a juros, dividendos e juros sobre capital próprio recebidos e pagos 
devem  ser  apresentados  separadamente.  Cada  um  deles  deve  ser  classificado  de  maneira 
consistente, de período a período, aplicando os itens 32, 33A e 34A a 34Dcomo decorrentes de 
atividades operacionais, de investimento ou de financiamento. 
 
32 O montante total dos juros pagos durante o período é incluído divulgado na demonstração dos 
fluxos de caixa, quer tenha sido reconhecido como despesa na demonstração do resultado, quer 
tenha sido capitalizado, conforme a NBC TG 20 – Custos de Empréstimos. 
 
33 [Excluído]Os juros pagos e recebidos e os dividendos e os juros sobre o capital próprio recebidos 
são  comumente  classificados  como  fluxos  de  caixa  operacionais  em  instituições  financeiras. 
Todavia, não há consenso sobre a classificação desses fluxos de caixa para outras entidades. Os 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
35 
 
juros pagos e recebidos e os dividendos e os juros sobre o capital próprio recebidos podem ser 
classificados como fluxos de caixa operacionais, porque eles entram na determinação do lucro 
líquido ou prejuízo. Alternativamente, os juros pagos e os juros, os dividendos e os juros sobre 
o capital próprio recebidos podem ser classificados, respectivamente, como fluxos de caixa de 
financiamento  e  fluxos de  caixa de  investimento,  porque  são  custos de  obtenção de  recursos 
financeiros ou retornos sobre investimentos. 
33A A  entidade  deve  classificar  os  dividendos  pagos  como  fluxos  de  caixa  das  atividades  de 
financiamento. 
34 [Excluído]Os dividendos e os juros sobre o capital próprio pagos podem ser classificados como 
fluxo  de  caixa  de  financiamento  porque  são  custos  da  obtenção  de  recursos  financeiros. 
Alternativamente, os dividendos e os juros sobre o capital próprio pagos podem ser classificados 
como componente dos fluxos de caixa das atividades operacionais, a fim de auxiliar os usuários 
a  determinar  a  capacidade  de  a  entidade  pagar  dividendos  e  juros  sobre  o  capital  próprio 
utilizando os fluxos de caixa operacionais. 
34A Esta Revisão encoraja fortemente as entidades a classificarem os juros, recebidos ou pagos, e os 
dividendos  e  juros  sobre  o  capital  próprio  recebidos  como  fluxos  de  caixa  das  atividades 
operacionais,  e  os  dividendos  e  juros  sobre  o  capital  próprio  pagos  como  fluxos  de  caixa  das 
atividades de financiamento. Alternativa diferente deve ser seguida de nota evidenciando esse 
fato. A entidade, que não as entidades descritas no item 34B, deve classificar: 
(a) juros  pagos  (conforme  descrito  no  item  32)  como  fluxos  de  caixa  das  atividades  de 
financiamento. 
(b) juros e dividendos recebidos como fluxos de caixa das atividades de investimento. 
34B A  entidade  que  investe  em  ativos  ou  concede  financiamento  a  clientes  como  atividade  de 
negócios  principal  (conforme  determinado  pela aplicação  dos itens  B30 a  B41  da NBC  TG  51) 
determinará  como  classificar  os  dividendos  recebidos,  os  juros  recebidos  e  os  juros  pagos  na 
demonstração dos fluxos de caixa, referindo-se sobre como – aplicando a NBC TG 51 – classifica 
a  receita  de  dividendos,  a  receita  de  juros  e  as  despesas  com  juros  na  demonstração  do 
resultado.  A  entidade  classificará  o  total  de  cada  um  destes  fluxos  de  caixa  em  uma  única 
categoria  na  demonstração  dos  fluxos  de  caixa  (ou  seja,  como  atividades  operacionais,  de 
investimento ou de financiamento). 
34C Ao aplicar o item 34B, se a entidade classificar o total de cada uma das receitas de dividendos, 
receitas de juros e despesas de juros em uma única categoria da demonstração do resultado, a 
entidade classificará o total de cada um dos dividendos recebidos, juros recebidos e juros pagos 
como fluxos de caixa decorrentes da atividade associada na demonstração dos fluxos de caixa. 
Por  exemplo,  se  uma  entidade  classificar  todas  as  suas  despesas  de  juros  na  categoria  de 
financiamento da demonstração do resultado, a entidade classificaria todos os seus juros pagos 
como fluxos de caixa das atividades de financiamento. 
34D Ao  aplicar  a  NBC  TG  51,  a  entidade  pode  ser  obrigada  a  classificar  cada  uma  das  receitas  de 
dividendos, receitas de juros e despesas de juros em mais de uma categoria da demonstração 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
36 
 
do resultado. Nesse caso, ao aplicar o item 34B, a entidade fará uma escolha de política contábil 
para  classificar  os  fluxos  de  caixa  correspondentes  em  uma  das  atividades  associadas  na 
demonstração dos fluxos de caixa. Por exemplo, se uma entidade classificar despesas com juros 
na  categoria  operacional  e  na  categoria  de  financiamento  da  demonstração  do  resultado,  a 
entidade classificará todos os seus juros pagos de acordo com a sua política contábil como fluxos 
de caixa das atividades operacionais ou fluxos de caixa das atividades de financiamento. 
Impostos sobre a renda e contribuição social sobre o lucro líquido 
35 Fluxos  de  caixa  referentes  a  tributos  sobre  o  lucro  devem  ser  apresentados  divulgados 
separadamente e  devem ser classificados como fluxos de caixa das atividades operacionais, a 
menos  que  possam  ser  identificados especificamente  como atividades  de  financiamento  e  de 
investimento. 
 ... 
Componentes de caixa e equivalentes de caixa 
 ... 
46 Em  função  da  variedade  de  práticas  de  gestão  de  caixa  e  de  produtos  bancários  ao  redor  do 
mundo,  e  com  vistas  a  atentar  para  a  NBC  TG  23  –  Base  de  Preparação  das  Demonstrações 
Contábeis NBC TG 26 – Apresentação das Demonstrações Contábeis, a entidade deve divulgar a 
política que adota na determinação da composição do caixa e equivalentes de caixa. 
47 O  efeito  de  qualquer  mudança  na  política  para  determinar  os  componentes  de  caixa  e 
equivalentes  de  caixa,  como,  por  exemplo,  a  mudança  na  classificação  dos  instrumentos 
financeiros  previamente  considerados  como  parte  da  carteira  de  investimentos  da  entidade, 
deve ser apresentado de acordo com a NBC TG 23  – Políticas Contábeis, Mudança de Estimativa 
e Retificação de Erro. 
 ... 
Data de vigência e transição 
 ... 
64 A Revisão NBC 31, aprovada pelo CFC em 10 de outubro de 2025, alterou os itens 6, 10, 12, 14, 
16, 17, 18, 20, 20A, 31, 32, 35, 46 e 47, acrescentou os itens 33A e de 34B a 34D, e excluiu os 
itens 33 e 34. A entidade aplicará essas alterações quando aplicar a NBC TG 51. 
 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
37 
 
17. Altera o título da norma e do item 28 e os itens 1, 3, 5 e 11. Exclui o item 2. Inclui os itens 3A, 
6A, 6B, 6C, 6D, 6E, 6F, 6G, 6H, 6J, 6K, 6L, 6M, 6N, 27A, 27B, 27C, 27D, 27E, 27F, 27G, 27H, 27I, 
31A, 31B, 31C, 31D, 31E, 31F, 31G, 31H, 31I e 54J na NBC TG 23 (R2) - Políticas Contábeis, 
Mudança de Estimativa e Retificação De Erro, que passam a vigorar com as seguintes redações: 
 
NBC TG 23  
Base de Preparação das Demonstrações Contábeis Políticas Contábeis, Mudança de Estimativa e 
Retificação de Erro 
Objetivo 
1 O objetivo desta Revisão é definir critérios para a seleção e a mudança de políticas contábeis, 
juntamente  com  o  tratamento  contábil  e  divulgação  de  mudança  nas  políticas  contábeis,  a 
mudança  nas  estimativas  contábeis  e  a  retificação  de  erro.  A  Revisão  tem  como  objetivo 
melhorar a relevância e a confiabilidade das demonstrações contábeis da entidade, bem como 
permitir  sua  comparabilidade  ao  longo  do  tempo  com  as demonstrações  contábeis de outras 
entidades. melhorar a relevância e confiabilidade das demonstrações contábeis da entidade, e 
a comparabilidade dessas demonstrações contábeis ao longo do tempo e com demonstrações 
contábeis  de  outras  entidades,  prescrevendo  a  base  de  elaboração  das  demonstrações 
contábeis que inclui: 
(a) assuntos gerais; 
(b) os critérios para seleção, mudança e divulgação das políticas contábeis; e 
(c) o tratamento contábil e divulgação de mudanças nas políticas contábeis, mudanças nas 
estimativas contábeis e a retificação de erro. 
 
2 [Excluído]Os requisitos de divulgação relativos a políticas contábeis, exceto aqueles que digam 
respeito a mudança nas políticas contábeis, são estabelecidos na NBC TG 26 – Apresentação das 
Demonstrações Contábeis. 
Alcance 
3 Esta  Revisão  deve  ser  aplicado  na  determinação  da  base  de  preparação  das  demonstrações 
Contábeis, incluindo seleção e na aplicação de políticas contábeis, bem como na contabilização 
de mudança nas políticas contábeis, de mudança nas estimativas contábeis e de retificação de 
erros de períodos anteriores. 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
38 
 
3A A  NBC  TG  21  –  Demonstração  Intermediária  estabelece  os  requisitos  para  a  apresentação  e 
divulgação das demonstrações contábeis intermediárias condensadas. Os itens de 6A a 6N desta 
Revisão também se aplicam a essas demonstrações contábeis intermediárias. 
 ... 
Definições 
5 Os termos que se seguem são usados nesta Revisão com os seguintes significados: 
... 
Informação  Material  é  definida  definido  no  Apêndice  A  da  NBC  TG  51  – Apresentação e 
Divulgação nas Demonstrações Contábeis  item  7  da  NBC  TG  26  e  .  Material  é  utilizado  nesta 
Revisão com o mesmo significado. 
 ... 
Base de preparação – assuntos gerais 
Apresentação apropriada e conformidade com as Normas, Interpretações e Comunicados da NBC TG 
6A As   demonstrações   contábeis   devem   apresentar   adequadamente   a   posição   financeira   e 
patrimonial,  o  desempenho e  os fluxos de  caixa  da  entidade. Para  apresentação  adequada,  é 
necessária a representação fidedigna dos efeitos das transações, outros eventos e condições de 
acordo  com  as  definições  e  critérios  de  reconhecimento  para  ativos,  passivos,  receitas  e 
despesas  como  estabelecidos na  NBC  TG 00 –  Estrutura  Conceitual  para Relatório  Financeiro. 
Presume-se  que  a  aplicação  das  normas,  interpretações  e  comunicados  da  NBC  TG,  com 
divulgação   adicional   quando   necessária,   resulta   em   demonstrações   contábeis   que   se 
enquadram como representação apropriada. 
 
6B A   entidade   cujas   demonstrações   contábeis   estão   em   conformidade   com   as   Normas, 
Interpretações e Comunicados da NBC TG deve declarar de forma explícita e sem reservas essa 
conformidade  nas  notas  explicativas.  A  entidade  não  deve  afirmar  que  suas  demonstrações 
contábeis  estão  de  acordo  com  essas  Normas,  Interpretações  e  Comunicados  a  menos  que 
cumpra todos os seus requisitos. 
 
6C Em   praticamente   todas   as   circunstâncias,   a   representação   apropriada   é   obtida   pela 
conformidade  com  as  Normas,  Interpretações  e  Comunicados  da  NBC  TG  aplicáveis.  A 
representação apropriada também exige que a entidade: 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
39 
 
(a) escolha  e  aplique  políticas  contábeis  de  acordo  com  esta  Revisão.  Esta  Revisão 
estabelece uma hierarquia na orientação que a administração deve seguir na ausência 
das Normas, Interpretações e Comunicados que se aplique especificamente a um item. 
(b) apresente  informação,  incluindo  suas  políticas  contábeis,  de  forma  que  proporcione 
informação relevante, confiável, comparável e compreensível. 
(c) proporcione  divulgações  adicionais  quando  o  cumprimento  dos  requisitos  específicos 
contidos  nas  Normas,  Interpretações  e  Comunicados  da  NBC  TG  for  insuficiente  para 
permitir que os usuários compreendam o impacto de determinadas transações, outros 
eventos  e  condições  sobre  a  posição  financeira  e  patrimonial  e  o  desempenho  da 
entidade. 
 
6D A  entidade  não  pode  retificar  políticas  contábeis  inadequadas  por  meio  da  divulgação  das 
políticas  contábeis  utilizadas  ou  por  meio  de  notas  explicativas  ou  qualquer  outra  divulgação 
explicativa. 
 
6E Em  circunstâncias  extremamente  raras,  nas  quais  a  administração  vier  a  concluir  que  a 
conformidade com um requisito da norma, interpretação ou comunicado da NBC TG conduziria 
a uma apresentação tão enganosa que entraria em conflito com o objetivo das demonstrações 
contábeis estabelecido na NBC TG 00, a entidade não deve aplicar esse requisito e deve seguir 
o disposto no item 6F, a não ser que esse procedimento seja terminantemente vedado do ponto 
de vista legal e regulatório.  
 
6F Quando a entidade não aplicar um requisito das Normas, Interpretações e Comunicados da NBC 
TG de acordo com o item 6E, deve divulgar: 
(a) que  a  administração  concluiu  que  as  demonstrações  contábeis  apresentam  de  forma 
apropriada  a  posição  financeira  e  patrimonial,  o  desempenho  e  os  fluxos  de  caixa  da 
entidade; 
(b) que  aplicou  as  normas,  interpretações  e  comunicados  da  NBC  TG,  exceto  pela  não 
aplicação de um requisito específico com o propósito de obter representação adequada; 
(c) o título da norma, interpretação ou comunicado da NBC TG que a entidade não aplicou, 
a  natureza  dessa  exceção,  incluindo  o  tratamento  que  a  Norma,  Interpretação  e 
Comunicado da NBC TG exigiria, a razão pela qual esse tratamento seria tão enganoso 
que entraria em conflito com o objetivo das demonstrações Contábeis, estabelecido na 
NBC TG 00, e o tratamento efetivamente adotado; e 
(d) para  cada  período  apresentado,  o  impacto  financeiro  da  não  aplicação  da  norma, 
interpretação  ou  comunicado  da  NBC  TG  vigente  em  cada  item  nas  demonstrações 
contábeis que teria sido informado, caso tivesse sido cumprido o requisito não aplicado. 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
40 
 
 
6G Quando a entidade não aplicar um requisito de uma Norma, Interpretação ou Comunicado da 
NBC  TG  em  período  anterior,  e  esse  procedimento  afetar  os  montantes  reconhecidos  nas 
demonstrações contábeis do período corrente, ela deve proceder à divulgação estabelecida nos 
itens 6F(c) e 6F(d). 
 
6H O item 6G se aplica, por exemplo, quando a entidade deixa de adotar em um período anterior 
determinado  requisito  para  a  mensuração  de  ativos  ou  passivos,  contido  em  uma  Norma, 
Interpretação ou Comunicado da NBC TG, e esse procedimento tem impactos na mensuração 
de  alterações  de  ativos  e  passivos  reconhecidos  nas  demonstrações  contábeis  do  período 
corrente.  
 
6I Em  circunstâncias  extremamente  raras,  nas  quais  a  administração  vier  a  concluir  que  a 
conformidade com requisito da  norma, interpretação  ou comunicado da NBC TG conduziria a 
uma  apresentação  tão  enganosa  que  entraria em  conflito  com  o  objetivo  das  demonstrações 
contábeis estabelecido na NBC TG 00, mas a estrutura regulatória vigente proibir a não aplicação 
do  requisito,  a  entidade  deve,  na  maior  extensão  possível,  reduzir  os  aspectos  inadequados 
identificados  no  cumprimento  estrito  da  norma,  interpretação  ou  comunicado  da  NBC  TG 
divulgando: 
(a) o título da norma, interpretação ou comunicado da NBC TG em questão, a natureza do 
requisito e as razões que levaram a administração a concluir que o cumprimento desse 
requisito tornaria as demonstrações contábeis tão enganosas que entraria em conflito 
com o objetivo das demonstrações contábeis estabelecido na NBC TG 00; e 
(b) para cada período apresentado, os ajustes de cada item nas demonstrações contábeis 
que  a  administração  concluiu  serem  necessários  para  se  obter  uma  representação 
apropriada. 
 
6J Para a finalidade dos itens de 6E a 6I, um item de informação entra em conflito com o objetivo 
das  demonstrações  contábeis  quando  não  representa  fidedignamente  as  transações,  outros 
eventos e condições a que se propõe representar, ou que se poderia esperar razoavelmente que 
representasse e, consequentemente, seria provável que influenciasse as decisões econômicas 
tomadas pelos usuários das demonstrações contábeis. Ao avaliar se o cumprimento de requisito 
específico  da  norma,  interpretação  ou  comunicado  da  NBC  TG  resultaria  em  divulgação  tão 
distorcida  a  ponto  de  entrar  em  conflito  com  o  objetivo  das  demonstrações  contábeis, 
estabelecido na NBC TG 00, a administração deve considerar: 
(a) a  razão  pela  qual  o  objetivo  das  demonstrações  contábeis  não  é  alcançado  nessa 
circunstância particular; e 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
41 
 
(b) como as circunstâncias da entidade diferem das circunstâncias de outras entidades que 
cumprem  o  requisito.  Se  outras  entidades  em  circunstâncias  similares  cumprem  o 
requisito, há um pressuposto refutável de que o cumprimento do requisito por parte da 
entidade  não  resultaria  em  divulgação  tão  enganosa  e,  portanto,  não  entraria  em 
conflito com o objetivo das demonstrações contábeis, estabelecido na NBC TG 00.  
Continuidade 
6K Ao Quando da elaboração das demonstrações contábeis, a administração deve fazer a avaliação 
da  capacidade  da  entidade  continuar  em  operação  no  futuro  previsível.  As  demonstrações 
contábeis devem ser elaboradas no pressuposto da continuidade, a menos que a administração 
tenha  intenção  de  liquidar  a  entidade  ou  cessar  seus  negócios,  ou  ainda  não  possua  uma 
alternativa realista senão a descontinuidade de suas atividades. Quando a administração tiver 
ciência,  ao  fazer  a  sua  avaliação,  de  incertezas  relevantes  relacionadas  com  eventos  ou 
condições que possam lançar dúvidas significativas acerca da capacidade da entidade continuar 
em   operação   no   futuro   previsível,   essas   incertezas   devem   ser   divulgadas.   Quando   as 
demonstrações contábeis não forem elaboradas no pressuposto da continuidade, esse fato deve 
ser  divulgado,  juntamente  com  as  bases  sobre  as  quais  as  demonstrações  contábeis  foram 
elaboradas e a razão pela qual não se pressupõe a continuidade da entidade.  
 
6L Ao  avaliar  se  o  pressuposto  de  continuidade  é  apropriado,  a  administração  deve  levar  em 
consideração toda a informação disponível sobre o  futuro, que é o período mínimo (mas não 
limitado  a  esse  período)  de  doze  meses  a  partir  da  data  do  balanço.  O  grau  de  consideração 
depende dos  fatos de  cada  caso.  Quando a  entidade  tiver histórico de  operações  lucrativas  e 
pronto  acesso  a  recursos  financeiros,  a  conclusão  acerca  da  adequação  do  pressuposto  da 
continuidade pode ser atingida sem análise pormenorizada. Em outros casos, a administração 
pode  necessitar  da  análise  de  vasto  conjunto  de  fatores  relacionados  com  a  rentabilidade 
corrente e esperada, cronogramas de liquidação de dívidas e potenciais fontes alternativas de 
financiamentos para que possa suportar sua conclusão de que o pressuposto de continuidade 
no futuro previsível é adequado para essa entidade. 
Regime de competência 
6M A  entidade  deve  elaborar  as  suas  demonstrações  contábeis,  exceto  para  as  informações  de 
fluxos de caixa, utilizando-se do regime de competência. 
 
6N Quando  o  regime  de  competência  é  utilizado,  os  itens  devem  ser  reconhecidos  como  ativos, 
passivos,  patrimônio  líquido,  receitas  e  despesas  (elementos  das  demonstrações  contábeis) 
quando  satisfazem  às  definições  e  aos  critérios  de  reconhecimento  para  esses  elementos 
contidos na NBC TG 00.  
 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
42 
 
Políticas contábeis 
Seleção e aplicação de políticas contábeis 
 ... 
11 Ao exercer os julgamentos descritos no item 10, a administração deve consultar e considerar a 
aplicabilidade das seguintes fontes por ordem decrescente: 
... 
(b) as definições, os critérios de reconhecimento e os conceitos de mensuração para ativos, 
passivos,  receitas  e  despesas  contidos  na  na  NBC  TG  00  –  Estrutura  Conceitual para 
Relatório Financeiro.  
 ... 
Divulgação 
Divulgação de seleção e aplicação de política contábil 
27A A entidade deve divulgar informações materiais da política contábil (ver item 7). As informações 
de política contábil são materiais se, quando consideradas em conjunto com outras informações 
incluídas  nas  demonstrações  contábeis  da  entidade,  pode-se  razoavelmente  esperar  que 
influenciem as decisões que os principais usuários das demonstrações contábeis para fins gerais 
tomam com base nessas demonstrações contábeis.  
 
27B As  informações  de  política  contábil  que  se  relacionam  com  transações,  outros  eventos  ou 
condições imateriais e não precisam ser divulgadas. As informações de política contábil podem, 
no  entanto,  ser  materiais  devido  à  natureza  das  transações  relacionadas,  outros  eventos  ou 
condições, mesmo que os valores sejam imateriais. No entanto, nem todas as informações de 
política  contábil  relacionadas  a  transações  materiais,  outros  eventos  ou  condições  são  em  si 
materiais.  
 
27C Espera-se  que  as  informações  de  política  contábil   sejam  materiais  se  os  usuários  das 
demonstrações contábeis da entidade precisarem delas para compreender outras informações 
relevantes nas demonstrações contábeis. Por exemplo, é provável que a entidade considere as 
informações  da  política  contábil  como  materiais  para  suas  demonstrações  contábeis  se  essas 
informações se relacionarem as transações, outros eventos ou condições materiais e:  
(a) a  entidade  alterou  a  sua  política  contábil  durante  o  período  das  demonstrações 
contábeis  e  esta  mudança  resultou  numa  alteração  material  da  informação  nas 
demonstrações contábeis; 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
43 
 
(b) a entidade escolheu a política contábil de uma ou mais opções permitidas pelas Normas, 
Interpretações  e  Comunicados  da  NBC  TG  –  tal  situação  poderia  surgir  se  a  entidade 
optasse por mensurar a propriedade para investimento pelo custo histórico em vez do 
valor justo;  
(c) a política contábil foi desenvolvida de acordo com esta Revisão na ausência da Norma, 
Interpretação ou Comunicado da NBC TG que se aplique especificamente; 
(d) a política contábil refere-se a uma área para a qual a entidade é deve fazer julgamentos 
ou pressupostos significativos ao aplicar uma política contábil, e a entidade divulga esses 
julgamentos ou pressupostos de acordo com os itens 27G e 31A; ou 
(e) a  o  reconhecimento  contábil  requerido  para  eles  é  complexo  e  os  usuários  das 
demonstrações  contábeis  da  entidade  não  entenderiam  essas  transações  materiais, 
outros eventos ou condições - tal situação poderia surgir se a entidade aplicar mais de 
uma NBC TG a uma classe de transações materiais. 
 
27D As informações de política contábil que se concentram em como a entidade aplicou os requisitos 
de outras Normas da NBC TG às suas próprias circunstâncias fornecem informações específicas 
da  entidade  que  são  mais  úteis  para  os  usuários  das  demonstrações  contábeis  do  que  as 
informações padronizadas, ou informações que apenas duplicam ou resumem os requisitos das 
Normas da NBC TG.  
 
27E Se a entidade divulgar informações de política contábil imateriais, tais informações não devem 
obscurecer informações de política contábil materiais. 
 
27F A conclusão da entidade de que as informações de política contábil são imateriais não afeta os 
requisitos  de  divulgação  relacionados  estabelecidos  em  outras  normas,  interpretações  e 
comunicados da NBC TG. 
 
27G A entidade deve divulgar, juntamente com sua informação de política contábil material ou em 
outras  notas  explicativas,  os  julgamentos  realizados,  com  a  exceção  dos  que  envolvem 
estimativas  (ver  item  31A),  que  a  administração  fez  no  processo  de  aplicação  das  políticas 
contábeis  da  entidade  e  que  têm  efeito  mais  significativo  nos  montantes  reconhecidos  nas 
demonstrações contábeis.  
 
27H No processo de aplicação das políticas contábeis da entidade, a administração exerce diversos 
julgamentos,  além  dos  que  envolvem  estimativas,  que  podem  afetar,  significativamente,  os 
montantes  reconhecidos  nas  demonstrações  contábeis.  Por  exemplo,  a  administração  exerce 
julgamento ao definir: 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
44 
 
(a) quando substancialmente todos os riscos e benefícios significativos da propriedade de 
ativos  financeiros  e,  para  arrendadores,  os  ativos  sujeitos  a  arrendamento   são 
transferidos para outras entidades; 
(b) se, em essência, determinadas vendas de bens decorrem de acordos de financiamento 
e, portanto, não dão origem a receitas de venda; e 
(c) se os termos contratuais de  ativo financeiro derem origem, em datas especificadas, a 
fluxos de caixa que constituam exclusivamente pagamentos de principal e juros sobre o 
valor do principal em aberto. 
 
27I Algumas  divulgações  feitas  de  acordo  com  o  item  27G  são  requeridas  por  outras  Normas, 
Interpretações ou Comunicados emitidos pela NBC TG. Por exemplo, a NBC TG 45 – Divulgação 
de Participações em Outras Entidades requer que a entidade divulgue os julgamentos que foram 
feitos  ao  determinar  se a  entidade  controla  outra  entidade.  A NBC TG 28  –  Propriedade para 
Investimento  requer  a  divulgação  dos  critérios  utilizados  pela  entidade  para  distinguir  a 
propriedade  de  investimento  da  propriedade  ocupada  pelo  proprietário  e  da  propriedade 
mantida para venda no curso ordinário dos negócios, nas situações em que a classificação das 
propriedades é difícil. 
Divulgação de mudanças na política contábil 
28 Quando  a  adoção  inicial  da  Norma,  Interpretação  ou  Comunicado  tiver  efeitos  no  período 
corrente ou em qualquer período anterior, exceto se for impraticável determinar o montante a 
ser ajustado, ou puder ter efeitos em períodos futuros, a entidade deve divulgar: 
 ... 
 
Divulgação de fontes de incerteza na estimativa 
31A A entidade deve divulgar, nas notas explicativas, informação acerca dos pressupostos relativos 
ao  futuro  e  outras  fontes  principais  de  incerteza  nas  estimativas  ao  término  do  período  de 
reporte  que  possuam  risco  significativo  de  provocar  ajuste  material  nos  valores  contábeis  de 
ativos e passivos ao longo do próximo exercício social. Com respeito a esses ativos e passivos, as 
notas explicativas devem incluir detalhes elucidativos acerca:  
(a) da sua natureza; e 
(b) do seu valor contábil ao término do período de reporte. 
 
31B A  Definir  os  montantes  de  alguns  ativos  e  passivos  exige  a  estimativa  dos  efeitos  de  eventos 
futuros incertos sobre esses ativos e passivos ao término do período de reporte. Por exemplo, 
na  ausência  de  preços  de  mercado  recentemente  observados,  passam  a  ser  necessárias 
estimativas orientadas para o futuro para mensurar o valor recuperável de ativos do imobilizado, 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
45 
 
o efeito da obsolescência tecnológica nos estoques, provisões sujeitas ao  futuro resultado de 
litígio em curso e passivos de longo prazo de benefícios a empregados, tais como obrigações de 
pensão. Essas estimativas envolvem pressupostos sobre esses assuntos, como o risco associado 
aos fluxos de caixa ou taxas de desconto, futuras alterações em salários e futuras alterações nos 
preços que afetam outros custos.  
 
31C Os pressupostos e outras fontes da incerteza das estimativas divulgados de acordo com o item 
31A relacionam-se com as estimativas que exigem os julgamentos mais difíceis, subjetivos ou 
complexos  da  administração.  À  medida  em  que  o  número  de  variáveis  e  pressupostos  que 
afetam  a  possível  futura  solução  das  incertezas  aumenta,  esses  julgamentos  tornam-se  mais 
subjetivos e complexos, aumentando, por consequência, a probabilidade de ajuste material nos 
valores contábeis de ativos e passivos.  
 
31D As divulgações descritas no item 31A não são requeridas para ativos e passivos que tenham risco 
significativo  de  que  seus  valores  contábeis  possam  sofrer  alteração  significativa  ao  longo  do 
próximo  exercício  social  se,  ao  término  do  período  das  demonstrações  contábeis,  forem 
mensurados pelo valor justo com base em preço cotado em mercado ativo para ativo ou passivo 
idêntico.  Nesse  caso,  os  valores  justos  podem  alterar-se  materialmente  ao  longo  do  próximo 
exercício social, mas essas alterações não serão fruto de pressupostos ou de outras fontes da 
incerteza das estimativas ao término do período das demonstrações contábeis.  
 
31E As divulgações descritas no item 31A devem ser apresentadas de forma a ajudar os usuários das 
demonstrações  contábeis  a  compreender  os  julgamentos  que  a  administração  fez  acerca  do 
futuro e sobre outras principais fontes de incerteza das estimativas. A natureza e a extensão da 
informação  a  ser  divulgada  variam  de  acordo  com  a  natureza  dos  pressupostos  e  outras 
circunstâncias. Exemplos desses tipos de divulgação são os que seguem: 
(a) a natureza dos pressupostos ou de outras incertezas nas estimativas; 
(b) a   sensibilidade   dos   valores   contábeis   aos   métodos,   pressupostos   e   estimativas 
subjacentes ao respectivo cálculo, incluindo as razões para essa sensibilidade; 
(c) a solução esperada de incerteza e a variedade de desfechos razoavelmente possíveis ao 
longo do próximo exercício social em relação aos valores contábeis dos ativos e passivos 
impactados; e 
(d) uma explicação de alterações feitas nos pressupostos adotados no passado no tocante 
a esses ativos e passivos, caso a incerteza permaneça sem solução. 
 
31F Esta  Revisão  não  requer  a  divulgação  de  projeções  ou  orçamentos  ao  fazer  as  divulgações 
descritas no item 31A. 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
46 
 
 
31G Por  vezes,  é  impraticável  divulgar  a  extensão  dos  possíveis  efeitos  de  um  pressuposto  ou  de 
outra  fonte  principal  de  incerteza  das  estimativas  ao  término  do  período  de  reporte.  Nessas 
circunstâncias,   a   entidade   deve   divulgar   que   é   razoavelmente   possível,   com   base   no 
conhecimento existente, que os valores dos respectivos ativos ou passivos ao longo do próximo 
exercício social tenham que sofrer ajustes materiais em função da observação de uma realidade 
distinta  em  relação  àqueles  pressupostos  assumidos.  Em  todos  os  casos,  a  entidade  deve 
divulgar  a  natureza  e  o  valor  contábil  do  ativo  ou  passivo  específico  (ou  classe  de  ativos  ou 
passivos) afetado por esses pressupostos.  
 
31H As   divulgações   descritas   no   item   27G   acerca   de   julgamentos   específicos   feitos   pela 
administração no processo de aplicação das políticas contábeis da entidade não se relacionam 
com as divulgações das principais fontes da incerteza das estimativas descritas no item 31A.  
 
31I A  divulgação  de  alguns  dos  pressupostos  do  item  31A  é  requerida  por  outras  Normas, 
Interpretações  ou  Comunicados  Técnicos  emitidos  pela NBC  TG.  Por exemplo,  a  NBC TG  25  – 
Provisões, Passivos Contingentes e Ativos Contingentes requer a divulgação, em circunstâncias 
específicas, de pressupostos importantes relativos a futuros eventos que afetem determinadas 
provisões.  A  NBC  TG  46  –  Mensuração  do  Valor  Justo  requer  a  divulgação  de  pressupostos 
significativos  (incluindo  as  técnicas  de  avaliação  e  as  informações)  que  a  entidade  aplica  na 
mensuração do valor justo de ativos e de passivos que sejam avaliados pelo valor justo.  
Data de vigência e transição 
 ... 
54J A Revisão NBC 31, aprovada pelo CFC em 10 de outubro de 2025, alterou os itens 1, 3, 5 e 11, 
acrescentou  os  itens  3A,  6A–6N,  27A–27I  e  31A–31I  e  títulos  e  subtítulos  relacionados, 
acrescentou  um  subtítulo  acima  do  item  28  e  excluiu  o  item  2.  A  entidade  aplicará  essas 
alterações quando aplicar a NBC TG 51. 
18. Altera os itens 13 e 16 e inclui o item 23D na NBC TG 24 (R2) - Evento Subsequente, que passam 
a vigorar com as seguintes redações: 
 
Reconhecimento e mensuração 
 ... 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
47 
 
Dividendos 
 ... 
13 Se  forem  declarados  dividendos  após  o  período  contábil  a  que  se  referem  as  demonstrações 
contábeis, mas antes da data da autorização de emissão dessas demonstrações esses dividendos 
não  devem  ser  reconhecidos  como  passivo  ao  final  daquele  período,  em  virtude  de  não 
atenderem  aos  critérios  de  obrigação  presente  na  data  das  demonstrações  contábeis  como 
definido na NBC TG 25 – Provisões, Passivos Contingentes e Ativos Contingentes. Tais dividendos 
devem ser divulgados nas notas explicativas em conformidade com a NBC TG 51 – Apresentação 
e Divulgação nas Demonstrações Contábeis NBC TG 26 – Apresentação das Demonstrações 
Contábeis. 
Continuidade 
 ... 
16 A NBC TG 23 – Base de Preparação das Demonstrações Contábeis NBC TG 26 – Apresentação das 
Demonstrações Contábeis especifica as divulgações exigidas se: 
(a) as  demonstrações  contábeis  não  forem  elaboradas  com  base  no  pressuposto  de 
continuidade; ou 
(b) a administração estiver ciente de incertezas relacionadas a eventos ou condições que 
possam  gerar  dúvidas  significativas  sobre  a  capacidade  de  a  sociedade  continuar  em 
operação.  Os  eventos  e  as  condições  que  requerem  divulgação  podem  surgir  após  o 
período contábil a que se referem as demonstrações contábeis. 
 ... 
Data de vigência 
 ... 
23D A  Revisão  NBC 31,  aprovada pelo  CFC  em  10 de outubro de  2025,  alterou  os  itens 13  e  16.  A 
entidade aplicará essas alterações quando aplicar o NBC TG 51. 
 
19. Altera o texto do subtítulo “objetivo”, os itens 62A, 77, 78 e 81 e inclui o item 98N na NBC TG 32 
(R4) - Tributos Sobre o Lucro, que passam a vigorar com as seguintes redações: 
 
Objetivo 
 ... 
Esta  Revisão  exige  que  a  entidade  contabilize  os  efeitos  fiscais  das  transações  e  de  outros 
eventos  da  mesma  maneira  que  ela  contabiliza  as  próprias  transações  e  os  outros  eventos. 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
48 
 
Assim,  para  transações  e  outros  eventos  reconhecidos  no  resultado,  quaisquer  efeitos  fiscais 
relacionados  também  são  reconhecidos  no  resultado.  Para  transações  e  outros  eventos 
reconhecidos  fora  do  resultado  (tratados  como  outros  resultados  abrangentes  dentro  do 
patrimônio líquido – ver NBC TG 51 – Apresentação e Divulgação nas Demonstrações Contábeis 
26   –   Apresentação   das   Demonstrações   Contábeis   sobre   a   demonstração   do   resultado 
abrangente),  quaisquer  efeitos  fiscais  relacionados  também  devem  ser  reconhecidos  fora  do 
resultado   (em   outros   resultados   abrangentes   ou   diretamente   no   patrimônio   líquido, 
respectivamente).  Similarmente,  o  reconhecimento  de  ativos  e  passivos  fiscais  diferidos  em 
combinação de negócios afeta o valor do ágio derivado da expectativa de rentabilidade futura 
(goodwill) advindo daquela combinação de negócios ou o valor do ganho de compra vantajosa 
(barganha) reconhecida. 
 ... 
 
Reconhecimento de tributo diferido e corrente 
 ... 
Itens reconhecidos fora da demonstração do resultado 
 ... 
62A As  Normas,  Interpretações  e  Comunicados  do  CFC  exigem  ou  permitem  que  itens  específicos 
sejam creditados ou debitados diretamente no patrimônio líquido. Exemplos desses itens são: 
(a) ajuste no balanço de abertura de lucros retidos resultantes tanto de mudança na política 
contábil que é aplicada retrospectivamente ou da correção de erro (ver a NBC TG 23 – 
Base de Preparação das Demonstrações Contábeis Políticas Contábeis, Mudança de 
Estimativa e Retificação de Erro); e 
(b) valores   advindos   de   reconhecimento   inicial   do   componente   de   patrimônio   de 
instrumento financeiro híbrido (ver item 23). 
 ... 
Apresentação 
 ... 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
49 
 
Despesa Tributária 
Despesa (receita) tributária relacionada a itens reconhecidos no resultado de atividades 
ordinárias (operacionais) 
77 A despesa (receita) tributária relacionada a itens reconhecidos em resultado de operações em 
continuidade atividades ordinárias (operacionais) deve ser apresentada na categoria de tributos 
sobre o lucro na demonstração do resultado. 
 ... 
Diferenças de câmbio sobre ativos e passivos denominados em moeda estrangeira e passivos 
decorrentes de tributos sobre o lucro ativo ou passivo diferido no exterior 
78 A  NBC  TG  02  –  Efeitos  das  Mudanças  nas  Taxas  de  Câmbio  e  Conversão  de  Demonstrações 
Contábeis exige que determinadas diferenças de câmbio sejam reconhecidas como receita ou 
despesa, mas não especifica onde tais diferenças devem ser apresentadas na demonstração do 
resultado  abrangente.  Consequentemente,  onde  Se  as  diferenças  de  câmbio  sobre  ativos  e 
passivos denominados em moeda estrangeira decorrentes de tributos sobre o lucro ativos ou 
passivos  de  tributo  estrangeiro  diferidos  forem  reconhecidas  na  demonstração  do  resultado 
abrangente de acordo com a NBC TG 02, tais diferenças podem também devem ser classificadas 
aplicando   os   requisitos   do   item   67  da   NBC   TG   51   – Apresentação  e  Divulgação  nas 
Demonstrações Contábeis como despesa (receita) de tributo diferido, se aquela apresentação 
for considerada como sendo a mais útil para os usuários das demonstrações contábeis. 
Divulgação 
 ... 
81 O que está descrito a seguir também deve ser divulgado separadamente: 
... 
(ab) valor  do  tributo  sobre  o  lucro  relacionado  a  cada  componente  de  outros  resultados 
abrangentes (ver o item 62 e o item 93 da NBC TG 51 da NBC TG 26 – Apresentação das 
Demonstrações Contábeis);  
...  
(h) com relação a operações descontinuadas, a despesa tributária relacionada a: 
(i) ganho ou perda com a descontinuidade; e 
(ii) resultado  das  atividades  normais  (operacionais)  da  operação  descontinuada 
para  o  período,  juntamente  com  os  valores  correspondentes  a  cada  período 
anterior apresentado; 
 ... 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
50 
 
Data de vigência 
 ... 
98N A Revisão NBC 31, aprovada pelo CFC em 10 de outubro de 2025, alterou o texto do subtítulo 
“objetivo”, os itens 62A, 77 (e seu respectivo subtítulo) e 78 (e seu respectivo subtítulo) e o item 
81. A entidade aplicará essas alterações quando aplicar o NBC TG 51. 
 
 
Uma nota de rodapé é acrescentada à “NBC TG 23 – Políticas Contábeis, Mudança de Estimativa e 
Retificação de Erro” no item 98H. O novo texto está sublinhado. 
 
* Quando  emitiu  a  Revisão  NBC  31,  a NBC TG  alterou  o  título  da  NBC  TG  23  para Base de 
Preparação das Demonstrações Contábeis. 
 
20. Altera o item 51 e inclui o item 81O na NBC TG 27 (R4) – Ativo Imobilizado, que passam a vigorar 
com as seguintes redações: 
Mensuração após o reconhecimento 
 ... 
Depreciação 
 ... 
Valor depreciável e período de depreciação 
 ... 
51 O valor residual e a vida útil de um ativo são revisados pelo menos ao final de cada exercício e, 
se as expectativas diferirem das estimativas anteriores, a mudança deve ser contabilizada como 
mudança de estimativa contábil, segundo a NBC TG 23 – Base de Preparação das Demonstrações 
Contábeis políticas Contábeis, Mudança de Estimativa e Retificação de Erro. 
 ... 
Data de vigência 
 ... 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
51 
 
81O A Revisão NBC 31, aprovada pelo CFC em 10 de outubro de 2025, alterou o item 51. A entidade 
aplicará essas alterações quando aplicar o NBC TG 51. 
 
21. Altera os itens 25, 134, 158 e 171 e inclui o item 180 na NBC TG 33 (R2) - Benefícios a Empregados, 
que passam a vigorar com as seguintes redações: 
Benefícios de curto prazo aos empregados 
 ... 
Divulgação 
25 Embora  esta  Revisão  não  exija  divulgações  específicas  acerca  de  benefícios  de  curto  prazo  a 
empregados,  outras  normas podem  exigi-las.  Por  exemplo,  a  NBC  TG  05  -  Divulgação  sobre 
Partes Relacionadas exige divulgação acerca de benefícios concedidos aos administradores da 
entidade. A NBC TG 51 – Apresentação e Divulgação nas Demonstrações Contábeis NBC TG 26– 
Apresentação das Demonstrações Contábeis  exige  a  divulgação de  despesas  com benefícios a 
empregados. 
 ... 
Benefícios pós-emprego: planos de benefício definido 
 ... 
Apresentação 
 ... 
Componente financeiro de custo de benefício definido 
134 O item 120 exige que a entidade reconheça o custo do serviço e os juros líquidos sobre o valor 
líquido de passivo (ativo) de benefício definido em resultado. Esta Revisão não especifica como 
a entidade deve apresentar o custo do serviço e os juros líquidos sobre o valor líquido de passivo 
(ativo) de benefício definido. A entidade deve apresentar esses componentes de acordo com o 
estabelecido na NBC TG 51 NBC TG 26. 
 ... 
Outros benefícios de longo prazo a empregados 
 ... 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
52 
 
Divulgação 
158 Embora esta Revisão não exija divulgações específicas sobre outros benefícios de longo prazo 
aos empregados, outras Normas podem requerer tais divulgações. Por exemplo, a NBC TG 05 – 
Divulgação sobre Partes Relacionadas requer divulgações sobre benefícios a empregados para 
os administradores da entidade. A NBC TG 51 NBC TG 26 – Apresentação das Demonstrações 
Contábeis requer a divulgação das despesas de benefícios aos empregados. 
Benefícios rescisórios 
 ... 
Divulgação 
171 Embora  esta  Revisão  não  exija  divulgações  específicas  sobre  benefícios  rescisórios,  outras 
Normas  emitidos  pela  NBC  TG  podem  exigir  tais  divulgações.  Por  exemplo,  a  NBC  TG  05  – 
Divulgação  sobre  Partes  Relacionadas  exige  divulgações  sobre  os  benefícios  rescisórios  de 
administradores  da  entidade.  A  NBC  TG  51 NBC TG 26 – Apresentação das Demonstrações 
Contábeis exige a divulgação das despesas de benefícios aos empregados. 
Transição e data de vigência 
 ... 
180 A Revisão NBC 31, aprovada pelo CFC em 10 de outubro de 2025, alterou os itens 25, 134, 158 
e 171. A entidade aplicará essas alterações quando aplicar o NBC TG 51. 
 
Uma nota de rodapé é acrescentada à “NBC TG 23 – Políticas Contábeis, Mudança de Estimativa e 
Retificação de Erro” no item 173. O novo texto está sublinhado. 
 
* Quando emitiu a Revisão NBC 31, em 10 de outubro de 2025, o NBC TG alterou o título do NBC 
TG 23 para Base de Preparação das Demonstrações Contábeis. 
 
22. Altera os itens 16, 29 e 32 e inclui o item 49 na NBC TG 07 (R2) – Subvenção e Assistência 
Governamentais, que passam a vigorar com as seguintes redações: 
Subvenção governamental 
 ... 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
53 
 
16 É  fundamental  pelo  regime  de  competência  que  as  subvenções  governamentais  sejam 
reconhecidas  no  resultado  de  forma  sistemática,  ao  longo  dos  períodos  nos  quais  a  entidade 
reconhece como despesas os respectivos custos que as subvenções pretendem compensar. O 
reconhecimento de subvenções governamentais no resultado com base no seu recebimento não 
está de acordo com a premissa do regime de competência (ver NBC TG 23 – Base de Preparação 
das Demonstrações Contábeis) e somente seria aceitável se não existisse outra base para alocar 
uma subvenção a períodos que não fossem aqueles em que ela foi recebida. É fundamental, pelo 
regime de competência, que a receita de subvenção governamental seja reconhecida em bases 
sistemáticas  e  racionais,  ao  longo  do  período  necessário  e  confrontada  com  as  despesas 
correspondentes.  Assim,  o  reconhecimento  da  receita  de  subvenção  governamental  no 
resultado no momento de seu recebimento somente é admitido nos casos em que não há base 
de alocação da subvenção ao longo dos períodos beneficiados. 
 ... 
Apresentação da subvenção relacionada a na demonstração do resultado 
29 A subvenção relacionada a resultado é classificada e apresentada na demonstração do resultado 
de acordo com a NBC TG 51 – Apresentação e Divulgação nas Demonstrações Contábeis, quer 
separadamente sob um título geral tal como receita, quer, alternativamente, como dedução da 
despesa relacionada. A subvenção é algumas vezes apresentada como crédito na demonstração 
do  resultado,  quer  separadamente  sob  um  título  geral  tal  como  “outras  receitas”,  quer, 
alternativamente, como dedução da despesa relacionada. A subvenção, seja por acréscimo de 
rendimento proporcionado ao empreendimento, ou por meio de redução de tributos ou outras 
despesas, deve ser registrada na demonstração do resultado no grupo de contas de acordo com 
a sua natureza. 
 ... 
Perda da subvenção governamental 
32 Uma  subvenção  governamental  que  tenha  que  ser  devolvida  deve  ser  contabilizada  como 
revisão  de  estimativa  contábil  (ver  NBC  TG  23  –  Base  de  Preparação  das  Demonstrações 
Contábeis). O reembolso deve ser aplicado em primeiro lugar contra qualquer crédito diferido 
não  amortizado relacionado  à  subvenção.  Na  medida  em  que  o reembolso  exceda  tal  crédito 
diferido,   ou   quando   não   exista   crédito   diferido,   o   reembolso   deve   ser   reconhecido 
imediatamente  como  despesa.  O  reembolso  de  subvenção  relacionada  a  ativo  deve  ser 
registrado aumentando o valor escriturado do ativo ou reduzindo o saldo da receita diferida pelo 
montante reembolsável. A depreciação adicional acumulada que deveria ter sido reconhecida 
até a data como despesa na ausência da subvenção deve ser imediatamente reconhecida como 
despesa.  Uma  subvenção  governamental  que  tenha  que  ser  devolvida  deve  ser  contabilizada 
como  revisão  de  estimativa  contábil  (ver NBC TG 23  – Políticas Contábeis, Mudança de 
Estimativa e Retificação de Erro).  O  reembolso  deve  ser  aplicado  em  primeiro  lugar  contra 
qualquer  crédito  diferido  não  amortizado  relacionado  à  subvenção.  Na  medida  em  que  o 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
54 
 
reembolso exceda tal crédito diferido, ou quando não exista crédito diferido, o reembolso deve 
ser reconhecido imediatamente como despesa. O reembolso de subvenção relacionada a ativo 
deve ser registrado aumentando o valor escriturado do ativo ou reduzindo o  saldo da receita 
diferida pelo montante reembolsável. A depreciação adicional acumulada que deveria ter sido 
reconhecida  até  a  data  como  despesa  na  ausência  da  subvenção  deve  ser  imediatamente 
reconhecida como despesa. 
 ... 
Data de vigência 
 ... 
49 A Revisão NBC 31, aprovada pelo CFC em 10 de outubro de 2025, alterou os itens 16, 29 e 32. A 
entidade aplicará essas alterações quando aplicar a NBC TG 51. 
 
23. Altera o item 48 e inclui o item 60N na NBC TG 02 (R3) - Efeitos das Mudanças nas Taxas de 
Câmbio e Conversão de Demonstrações Contábeis, que passam a vigorar com as seguintes 
redações: 
Uso de moeda de apresentação diferente da moeda funcional 
 ... 
Baixa total ou parcial de entidade no exterior 
48 Na baixa de entidade no exterior, o montante acumulado de variações cambiais relacionadas a 
essa entidade no exterior, reconhecido em outros resultados abrangentes e registrado em conta 
específica   do   patrimônio   líquido,   deve   ser   transferido   do   patrimônio   líquido   para   a 
demonstração do resultado (como ajuste de reclassificação) quando o ganho ou a perda na baixa 
for   reconhecido   (a   esse   respeito   ver a  NBC  TG  51   – Apresentação  e  Divulgação  nas 
Demonstrações Contábeis NBC TG 26– Apresentação das Demonstrações Contábeis). 
 ... 
Disposições transitórias 
 ... 
60N A Revisão NBC 31, aprovada pelo CFC em 10 de outubro de 2025, alterou o item 48. A entidade 
aplicará essas alterações quando aplicar o NBC TG 51. 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
55 
 
 
Uma nota de rodapé é acrescentada à “NBC TG 23 – Políticas Contábeis, Mudança de Estimativa e 
Retificação de Erro” no item 60. O novo texto está sublinhado. 
 
* Quando emitiu a Revisão NBC 31 em 10 de outubro de 2025, o NBC TG alterou o título da NBC 
TG 23 para Base de Preparação das Demonstrações Contábeis. 
 
 
24. Altera o item 20 e inclui o item 28D na NBC TG 05 (R3) - Divulgação sobre Partes Relacionadas, 
que passam a vigorar com as seguintes redações: 
Divulgações 
Todas as entidades 
 ... 
20 A classificação de montantes a pagar e a receber de partes relacionadas em diferentes categorias 
conforme requerido no item 19 é uma extensão dos requerimentos de divulgação da NBC TG 51 
– Apresentação e Divulgação nas Demonstrações Contábeis NBC TG 26 – Apresentação das 
Demonstrações contábeis, para informações a serem apresentadas no balanço patrimonial ou 
divulgadas nas notas explicativas que o acompanham. As categorias de partes relacionadas são 
ampliadas para proporcionar uma análise mais abrangente dos saldos entre partes relacionadas, 
aplicando-a a transações com essas partes. 
 ... 
Disposições transitórias 
 ... 
28D A Revisão NBC 31, aprovada pelo CFC em 10 de outubro de 2025, alterou o item 20. A entidade 
aplicará essas alterações quando aplicar o NBC TG 51. 
 
25. Inclui uma nota de rodapé ao item 18G na NBC TG 35 (R2) - Demonstrações Separadas, que passa 
a vigorar com a seguinte redação: 
 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
56 
 
Uma nota de rodapé é acrescentada à “(conforme definido na NBC TG 23 – Políticas Contábeis, 
Mudança de Estimativa e Retificação de Erro” no item 18G. O novo texto está sublinhado. 
 
* Quando emitiu a Revisão NBC 31, em 10 de outubro de 2025, a NBC TG alterou o título da NBC 
TG 23 para Base de Preparação das Demonstrações Contábeis. 
 
26. Altera o item 10 e inclui o item 45L na NBC TG 18 (R4) - Investimentos em Coligada e em 
Empreendimento Controlado em Conjunto, que passam a vigorar com as seguintes redações: 
Método de equivalência patrimonial 
10 Pelo método da equivalência patrimonial, o investimento em coligada ou em empreendimento 
controlado em conjunto deve ser inicialmente reconhecido pelo custo e o seu valor contábil será 
aumentado  ou  diminuído  pelo  reconhecimento  da  participação  do  investidor  nos  lucros  ou 
prejuízos do período, gerados pela investida após a aquisição. A participação do investidor no 
lucro ou prejuízo do período da investida deve ser reconhecida no resultado do investidor. As 
distribuições recebidas da investida reduzem o valor contábil do investimento. Ajustes no valor 
contábil  do  investimento  também  são  necessários  pelo  reconhecimento  da  participação 
proporcional  do  investidor  nas  variações  de  saldo  dos  componentes  dos  outros  resultados 
abrangentes da investida. Tais variações incluem aquelas decorrentes da reavaliação de ativos 
imobilizados,  e  das  diferenças  de  conversão  em  moeda  estrangeira,  quando  aplicável.  A 
participação  do  investidor  nessas  mudanças  deve  ser  reconhecida  em  outros  resultados 
abrangentes  do  investidor  (ver NBC TG 51  – Apresentação e Divulgação nas Demonstrações 
Contábeis NBC TG 26 – Apresentação das Demonstrações Contábeis). 
 ... 
Disposições transitórias 
 ... 
45L A Revisão NBC 31, aprovada pelo CFC em 10 de outubro de 2025, alterou o item 10. A entidade 
aplicará essas alterações quando aplicar a NBC TG 51. 
27. Altera os itens  8  e  25  e inclui  o item  42  na NBC  TG  42 -  Contabilidade  em  Economia 
Hiperinflacionária, que passam a vigorar com as seguintes redações: 
 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
57 
 
Atualização monetária das demonstrações contábeis 
 ... 
8 As  demonstrações  contábeis  da  entidade  cuja  moeda  funcional  é  a  moeda  de  uma  economia 
hiperinflacionária, sejam elas baseadas na abordagem de custo histórico ou na abordagem de 
custo  corrente,  serão  atualizadas  em  termos  de unidade de  mensuração  corrente  no  final  do 
período de relatório. Os valores correspondentes para o período anterior exigidos pela NBC TG 
51  – Apresentação e Divulgação nas Demonstrações Contábeis NBC TG 26– Apresentação das 
Demonstrações Contábeis e quaisquer informações referentes aos períodos anteriores também 
devem ser apresentados em termos da unidade de mensuração corrente no final do período de 
relatório.  Para  fins  de  apresentação  de  valores  comparativos  em  moeda  de  apresentação 
diferente,  os  itens  42(b)  e  43  da  NBC  TG  02  –  Efeitos  das  Mudanças  nas  Taxas  de  Câmbio  e 
Conversão de Demonstrações Contábeis são aplicáveis. 
 ... 
Demonstrações contábeis pelo custo histórico 
Balanço patrimonial 
 ... 
25 No final do primeiro período e em períodos subsequentes, todos os componentes do patrimônio 
líquido devem ser atualizados monetariamente pela aplicação do Índice Geral de Preços, desde 
o início do período ou da data de contribuição, se posterior. As mutações do patrimônio líquido 
durante o período devem ser divulgadas de acordo com a NBC TG 51 NBC TG 26. 
 ... 
Vigência 
 ... 
42 A  Revisão  NBC  31,  aprovada  pelo  CFC  em  10  de  outubro  de  2025,  alterou  os  itens  8  e  25.  A 
entidade aplicará essas alterações quando aplicar a NBC TG 51. 
 
28. Altera os itens 34, 39, 40, 41 e AG29 e inclui o item 97U na NBC TG 39 (R5) - Instrumentos 
Financeiros: Apresentação, que passam a vigorar com as seguintes redações: 
Apresentação 
 ... 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
58 
 
Ações em tesouraria (ver também item AG36) 
 ... 
34 O montante de ações em tesouraria mantidas deve ser apresentado divulgado separadamente 
no  balanço  ou  na  demonstração  das  mutações  do  patrimônio  líquido  ou  divulgado  nas  notas 
explicativas,  de  acordo  com  a  NBC  TG  51  – Apresentação e Divulgação nas Demonstrações 
Contábeis NBC TG 26 – Apresentação das Demonstrações Contábeis. A entidade deve divulgar 
informação, de acordo com a NBC TG 05 – Divulgação sobre Partes Relacionadas, se readquirir 
seus próprios instrumentos patrimoniais das partes relacionadas 
Juros, dividendos, perdas e ganhos (ver também item AG37) 
 ... 
39 O  montante  dos  custos  de  transação  contabilizado  como  dedução  do  patrimônio  líquido  no 
período  deve  ser  apresentado  na  demonstração  das  mutações  do  patrimônio  líquido  ou 
divulgado  nas  notas  explicativas  separadamente  de  acordo  com  a  NBC  TG  51 NBC TG 26 – 
Apresentação das Demonstrações Contábeis.  O  montante  relacionado  aos  tributos  incidentes 
sobre o lucro, reconhecido diretamente no patrimônio líquido, deve ser incluído no montante 
total  de  imposto  de  renda,  diferido  ou  corrente,  ou  contabilizado  no  patrimônio  líquido  e 
divulgado de acordo com a NBC TG 32 – Tributos sobre o Lucro. 
 
40.  Dividendos   classificados   como   despesa   podem   ser   apresentados   na   demonstração   dos 
resultados  abrangentes  ou  na  demonstração  do  resultado  em  separado  (se  apresentada)  ou 
divulgados nas notas explicativas, quer em conjunto com juros sobre outros passivos ou em uma 
linha  separada.  Além  dos  requisitos  desta  Norma,  a  apresentação  e  divulgação  de  juros  e 
dividendos  está  sujeita  aos  requisitos  da  NBC  TG  51  26  –  Apresentação  das  Demonstrações 
Contábeis e da NBC TG 40 – Instrumentos Financeiros: Evidenciação. Em algumas circunstâncias, 
devido à diferença entre juros e dividendos, em relação a questões como a dedutibilidade fiscal, 
a  entidade  pode  determinar  que  apresentará  as  despesas  com  juros  separadamente  das 
despesas  de  dividendos  na  demonstração  do  resultado  e  na  demonstração  do  resultado 
abrangente é desejável a divulgação separada deles na demonstração do resultado. A divulgação 
dos efeitos fiscais deve ser feita de acordo com a NBC TG 32 – Tributos sobre o Lucro. 
 
41 Ganhos e  perdas  relacionados a  alterações no  valor  contábil  de  passivo financeiro  devem  ser 
reconhecidos  como  receita  ou  despesa  no  resultado,  mesmo  quando  se  relacionarem  a  um 
instrumento que inclua direito residual nos ativos da entidade em troca de caixa ou outro ativo 
financeiro  (ver  item  18(b)).  De  acordo  com  a  NBC  TG  51 NBC TG 26 – Apresentação das 
Demonstrações Contábeis, a entidade deve apresentar qualquer ganho ou perda decorrente de 
nova  mensuração  de  tal  instrumento  separadamente  na  demonstração  do  resultado  se  essa 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
59 
 
apresentação for necessária para fornecer um resumo estruturado útil das receitas e despesas 
da entidade quando for relevante para a explicação do desempenho da entidade. 
 ... 
Data de vigência e transição 
 ... 
97U A Revisão NBC 31, aprovada pelo CFC em 10 de outubro de 2025, alterou os itens 34, 39, 40, 41 
e AG29. A entidade aplicará essas alterações quando aplicar a NBC TG 51. 
 ... 
Apêndice 
Guia de Aplicação 
NBC TG 39 – Instrumentos Financeiros: Apresentação 
 ... 
Apresentação 
Passivo e patrimônio líquido (itens 15 a 27) 
 ... 
Tratamento nas demonstrações contábeis consolidadas 
AG29    Nas demonstrações contábeis consolidadas, a entidade deve apresentar a participação dos não 
controladores – interesses de outras partes no patrimônio e resultado de suas controladas – de 
acordo com as NBC TG 51 NBC TG 26 – Apresentação das Demonstrações Contábeis e NBC TG 
36   –   Demonstrações   Consolidadas.   Ao   classificar   um   instrumento   financeiro   (ou   um 
componente  dele)  nas  demonstrações  contábeis  consolidadas,  a  entidade  deve  considerar 
todos  os  termos  e  condições  acordadas  entre  os  membros  do  grupo  e  dos  detentores  dos 
instrumentos para determinar se o grupo como um todo possui a obrigação de entregar caixa 
ou outro ativo financeiro relacionado com o instrumento ou liquidá-lo de forma diversa que irá 
resultar  em  uma  classificação  no  passivo.  Quando  uma  controlada  emite  um  instrumento 
financeiro  e  a  empresa  controladora  ou  outra  empresa  do  grupo  contrata  termos  adicionais 
diretamente  com  os  detentores  do  título  (garantia,  por  exemplo),  o  grupo  pode  não  ter 
autonomia sobre distribuições ou resgates. Apesar do fato de que a controlada pode classificar 
de  forma  apropriada  os  instrumentos  sem  consideração  desses  termos  adicionais  em  seus 
balanços individuais, o efeito de outros acordos entre os membros do grupo e os detentores dos 
instrumentos   financeiros   deve   ser   considerado   para   garantir   que   as   demonstrações 
consolidadas reflitam os contratos e as transações nas quais o grupo participa como um todo. 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
60 
 
Na  medida  em  que  houver  uma  obrigação  para  liquidação  ou  uma  provisão  para  tal,  o 
instrumento  (ou  o  componente  que  está  sujeito  à  obrigação)  deve  ser  classificado  como 
instrumento financeiro passivo nas demonstrações contábeis consolidadas. 
 
29. Altera os itens 4A, 13, 67A, 68 e 68A. Exclui 73 e 73A e inclui os itens 73B, 73C e 74F na NBC TG 
41 (R2) - Resultado por Ação, que passam a vigorar com as seguintes redações: 
 
Alcance 
 ... 
4A  Se a entidade apresentar os itens de resultado em uma demonstração de resultado separada de 
uma  demonstração  do  resultado  abrangente,  conforme  o  item  12(b)  da  NBC  TG  51  – 
Apresentação e Divulgação nas Demonstrações Contábeis, ela deve apresentar o resultado por 
ação somente na demonstração de resultado Como a companhia apresenta, conforme os itens 
81 e 82 da NBC TG 26 – Apresentação das Demonstrações Contábeis, os componentes do lucro 
ou prejuízo na demonstração do resultado em separado, ela deve apresentar o resultado por 
ação somente na demonstração do resultado do período. 
 ... 
Mensuração 
Resultado básico por ação 
 ... 
Resultado 
 ... 
13 Todos os itens de receitas e despesas atribuíveis aos titulares de ações ordinárias da entidade 
companhia que forem reconhecidos no período, incluindo despesas com tributos e dividendos 
de  ações  preferenciais  classificadas  como  passivos,  devem  ser  incluídos  na  determinação  de 
lucro ou prejuízo para o período atribuível aos titulares de ações ordinárias (ver NBC TG 51 NBC 
TG 26 – Apresentação das Demonstrações Contábeis). 
 ... 
Apresentação 
 ... 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
61 
 
67A  Se a entidade apresentar itens de resultado em uma demonstração do resultado separada de 
uma demonstração do resultado abrangente, conforme descrito no item 12(b) da NBC TG 51, 
ela  apresentará  o  lucro  básico  e  o  diluído  por  ação,  conforme  exigido  nos  itens  66  e  67,  na 
demonstração do resultado Como a companhia apresenta os componentes do lucro ou prejuízo 
na  demonstração  à  parte  (itens  81  e  82  da  NBC  TG  26  –  Apresentação  das  Demonstrações 
Contábeis), ela deve apresentar resultados por ação básicos e diluídos, como requerido nos itens 
66 e 67 naquela demonstração separada. 
 
68 A  entidade  companhia  que  reportar  operação  descontinuada  deve  apresentar  divulgar  os 
resultados por ação básicos e diluídos relativamente à operação descontinuada, seja na própria 
demonstração do resultado ou deve divulgar essas informações em notas explicativas. 
 
68A Se a entidade apresentar itens de resultado em uma demonstração do resultado separada de 
uma demonstração do resultado abrangente, conforme descrito no item 12(b) da NBC TG 51, 
ela apresentará o lucro básico e o diluído por ação para a operação descontinuada, conforme 
exigido  no  item  68,  na  demonstração  do  resultado  ou  divulgar  essas  informações  nas  notas 
explicativas   Como   a   companhia   apresenta   os   componentes   do   lucro   ou   prejuízo   na 
demonstração  à  parte  (itens  81  e  82  da  NBC  TG  26  –  Apresentação  das  Demonstrações 
Contábeis),  ela  deve  apresentar  os  resultados  por  ação  básicos  e  diluídos  para  a  operação 
descontinuada,  como  requerido  no  item  68,  naquela  demonstração  separada  ou  em  notas 
explicativas. 
 ... 
Divulgação 
 ... 
73 [Excluído]Se Se a companhia divulgar, além dos resultados por ação básico e diluído, valores por 
ação usando um componente relatado na demonstração do resultado diferente do exigido por 
esta Revisão, tais valores devem ser calculados usando  o número médio ponderado de ações 
ordinárias  determinado  de  acordo  com  esta  Revisão.  Os  valores  básico  e  diluído  por  ação 
relativamente a esse componente devem ser divulgados com igual destaque e apresentados em 
notas explicativas. A companhia deve indicar a base segundo a qual o numerador é determinado, 
incluindo  se  os  valores  por  ação  são  antes  ou  depois  dos  tributos.  Se  um  componente  da 
demonstração  do  resultado  for  usado  e  esse  não  for  apresentado  como  item  de  linha  na 
demonstração do resultado, deve ser fornecida conciliação entre o componente usado e o item 
de linha que esteja constando da demonstração do resultado. 
73A [Excluído]O item 73 também se aplica a companhias que divulgam, além do resultado por ação 
básico  e  diluído,  valores  por  ação  usando  um  componente  apresentado  na  demonstração  do 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
62 
 
resultado (como descrito nos itens 81 e 82 da NBC TG 26 – Apresentação das Demonstrações 
Contábeis), que não o requerido por esta Revisão. 
73B Além de apresentar o lucro básico por ação e o lucro diluído por ação exigidos por esta Revisão, 
a  entidade  está  autorizada  a  divulgar  nas  notas  explicativas  os  valores  adicionais  por  ação 
usando uma medida de desempenho como numerador diferente daquele exigido pelos itens 12 
a 18 e 33 a 35. Contudo, esse(s) numerador(es) será(ão) o(s) valor(es) atribuível(s) aos titulares 
de ações ordinárias da controladora de: 
(a) um total ou subtotal nos itens 69, 86 e 118 da NBC TG 51; ou 
(b) uma medida de desempenho definida pela administração, conforme definido no item 
117 da NBC TG 51. 
73C Se, ao aplicar o item 73B, uma entidade divulga um valor adicional por ação, a entidade: 
(a) divulgará os valores básicos e diluídos adicionais por ação com igual destaque. 
(b) calculará  o  valor  adicional  por  ação  utilizando  o  número  médio  ponderado  de  ações 
ordinárias determinado de acordo com esta Revisão. 
(c) divulgará  o  valor  adicional  por  ação  nas  notas  explicativas.  Essas  informações  não 
podem ser apresentadas nas demonstrações contábeis primárias. 
(d) divulgará  as  informações  exigidas  pelos  itens  121  a  125  da  NBC  TG  51  para  os 
numeradores que são medidas de desempenho definidas pela administração. 
Data de vigência 
 ... 
74F A Revisão NBC 31, aprovada pelo CFC em 10 de outubro de 2025, alterou os itens 4A, 13, 67A, 
68,  68A,  acrescentou  os  itens  73B  e  73C  e  excluiu  os  itens  73  e  73A.  A  entidade  deve  aplicar 
essas alterações quando aplicar a NBC TG 51. 
30. Altera os itens 4, 5, 7, 8, 9, 10, 11A, 12, 20, 24 e 43 e inclui os itens 16A(m) e 61 na NBC TG 21 
(R4) - Demonstração Intermediária, que passam a vigorar com as seguintes redações: 
Definições 
4 Os termos a seguir são usados nesta Revisão com os significados especificados: 
... 
Demonstração  contábil  intermediária  significa  uma  demonstração  contábil  contendo  um 
conjunto  completo  de  demonstrações  contábeis  (assim  como  descrito  na  NBC  TG  51  – 
Apresentação e Divulgação nas Demonstrações Contábeis NBC TG 26 – Apresentação das 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
63 
 
Demonstrações Contábeis  ou  um  conjunto  de  demonstrações  contábeis  condensadas  (assim 
como descrito nesta Revisão) de período intermediário. 
Conteúdo da demonstração contábil intermediária 
5 A  NBC  TG  51 NBC TG 26 define  um  conjunto  completo  de  demonstrações  contábeis  como 
incluindo os seguintes componentes: 
(a) demonstração  (ou  demonstrações)  de  desempenho  financeiro  do  período  balanço 
patrimonial ao final do período; 
(b) balanço patrimonial ao final do período; 
demonstrações do resultado:  
(i) do período;  
(ii) abrangente do período; 
(c) demonstração das mutações do patrimônio líquido do período; 
(d) demonstração dos fluxos de caixa do período; 
(e) notas  explicativas  referentes  ao  período  de  reporte,  informação  de  política  contábil 
material e outras informações explicativas; 
(ea) informações comparativas relativas ao com o período anterior, conforme especificado 
nos itens 31 e 32 da NBC TG 5138 e 38A da NBC TG 26;  
(f) balanço patrimonial no início do período anterior, se exigido pelo item 37 da NBC TG 51; 
e 
(g)  demonstração do valor adicionado do período, conforme NBC TG 09 – Demonstração 
do Valor Adicionado, se exigido legalmente ou por algum órgão regulador ou mesmo se 
apresentada voluntariamente. 
... 
A entidade pode usar títulos para as demonstrações diferentes daqueles usados nesta Revisão. 
Por exemplo, uma entidade pode utilizar o título “demonstração da posição financeira” em vez 
de “balanço patrimonial”. 
 
7 Esta Revisão não proíbe ou desencoraja as entidades de divulgarem ou publicarem o conjunto 
completo de demonstrações contábeis (como descrito na NBC TG 51 NBC TG 26 – Apresentação 
das Demonstrações Contábeis) nos seus relatórios intermediários, em vez das demonstrações 
contábeis condensadas e das notas explicativas selecionadas. Esta Revisão também não proíbe 
ou desencoraja as entidades de incluírem nas demonstrações contábeis condensadas mais do 
que  os  itens  mínimos  ou  notas  explicativas  selecionadas  de  acordo  com  esta  Norma.  As 
orientações   de   reconhecimento   e   mensuração   desta   Revisão   também   se   aplicam   às 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
64 
 
demonstrações contábeis completas que sejam apresentadas para os períodos intermediários, 
e   tais   demonstrações   devem   incluir   todas   as   divulgações   requeridas   por   esta   Revisão 
(particularmente as notas explicativas selecionadas do item 16A), assim como também aquelas 
requeridas por outras normas. 
Componentes mínimos da demonstração contábil intermediária 
8 A demonstração contábil intermediária deve incluir, pelo menos, os seguintes componentes: 
(a) demonstração    condensada    (ou    demonstrações    condensadas)   de   desempenho 
financeiro balanço patrimonial condensado; 
(b) balanço  patrimonial  condensado  (b1)  demonstração  condensada  do  resultado  do 
exercício; (b2) demonstração condensada do resultado abrangente; 
(c) demonstração condensada das mutações do patrimônio líquido; 
(d) demonstração condensada dos fluxos de caixa; e 
(e) notas explicativas selecionadas. 
 
8A Se a entidade apresentar itens de resultado em uma demonstração do resultado separada de 
uma demonstração do resultado abrangente, conforme descrito no item 12(b) da NBC TG 51, 
ela deve apresentar as informações condensadas intermediárias a partir da demonstração do 
resultado.  A  demonstração  do  resultado  abrangente  pode  ser  apresentada  como  parte  da 
demonstração  das  mutações  do  patrimônio  líquido.  Ver  a  NBC  TG  26  –  Apresentação  das 
Demonstrações Contábeis.  
Forma e conteúdo da demonstração contábil intermediária 
9 Caso a entidade divulgue ou publique o conjunto completo de demonstrações contábeis no seu 
relatório  intermediário,  a  forma  e  o  conteúdo  dessas  demonstrações  devem  estar  em 
conformidade com os requisitos da NBC TG 51 NBC TG 26 – Apresentação das Demonstrações 
Contábeis, para o conjunto completo de demonstrações contábeis. 
10 Se a entidade divulga ou publica o conjunto de demonstrações contábeis condensadas nos seus 
relatórios intermediários, tais demonstrações condensadas devem incluir, no mínimo, cada um 
dos grupos ou subgrupos de contas e seus totais que foram apresentados nas demonstrações 
contábeis anuais mais recentes e as notas explicativas selecionadas como requeridas por esta 
Revisão.  Ao  elaborar  demonstrações  contábeis  condensadas,  a  entidade  deverá  aplicar  esta 
Revisão e também os requisitos dos itens 41 a 45 da NBC TG 51 e dos itens 6A a 6N da NBC TG 
23  – Base de Preparação das Demonstrações Contábeis.  Linhas  de  itens adicionais devem  ser 
incluídas  caso  suas  omissões  façam  com  que  a  demonstração  contábil  intermediária  fique 
enganosa. 
 ... 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
65 
 
11A Se a entidade apresentar itens de resultado em uma demonstração do resultado separada de 
uma demonstração do resultado abrangente, conforme descrito no item 12(b) da NBC TG 51, 
ela apresentará o lucro básico por ação e o lucro diluído por ação na demonstração do resultado. 
12 A NBC TG 51 NBC TG 26 – Apresentação das Demonstrações Contábeis proporciona orientação 
para  a  estrutura  das  demonstrações  contábeis.  O  Guia  de  Implementação  da  NBC  TG  26  – 
Apresentação das Demonstrações Contábeis ilustra modos pelos quais o balanço patrimonial, a 
demonstração do resultado abrangente e a demonstração das mutações do patrimônio líquido 
devem ser apresentadas. 
 ... 
Outras divulgações 
16A Adicionalmente à divulgação de eventos e transações significativos, de acordo com os itens 15 
a   15C,   a   entidade   deve   incluir   as   seguintes   informações   nas   notas   explicativas   das 
demonstrações contábeis intermediárias ou em qualquer outro lugar dessas demonstrações. As 
seguintes divulgações devem  ser  feitas tanto  nas  demonstrações  contábeis  intermediárias  ou 
incorporadas por referência cruzada a partir das demonstrações contábeis intermediárias para 
outras demonstrações (como comentário da administração ou relatório de risco), que estejam 
disponíveis   para   os   usuários   das   demonstrações   contábeis   nas   mesmas   condições   das 
demonstrações contábeis intermediárias e ao mesmo tempo. Se os usuários das demonstrações 
contábeis  não  têm  acesso  às  informações  incorporadas  por  referência  cruzada,  nas  mesmas 
condições e ao mesmo tempo, o relatório financeiro intermediário está incompleto. Elas devem 
ser  normalmente  divulgadas  com  base  no  valor  acumulado  do  ano  até  a  data  (year-to-date 
basis): 
... 
(m) as divulgações sobre as medidas de desempenho definidas pela administração exigidas 
pelos itens 121 a 125 do NBC TG 51. 
 ... 
Períodos para os quais demonstrações contábeis intermediárias devem ser apresentadas 
20 Demonstrações    contábeis    intermediárias    devem    incluir    as    demonstrações    contábeis 
(condensadas ou completas) para os seguintes períodos: 
... 
(b)  demonstração   (ou   demonstrações)   de   desempenho   financeiro   demonstração   do 
resultado e demonstração do resultado abrangente do período intermediário corrente e 
acumulado no exercício social corrente, comparadas com as dos períodos intermediários 
do exercício social anterior (corrente e acumulado no ano). Conforme permitido na NBC 
TG 51 NBC TG 26 – Apresentação das Demonstrações Contábeis, o relatório intermediário 
pode apresentar para cada período a demonstração (ou demonstrações) de desempenho 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
66 
 
financeiro  a  demonstração  do  resultado  abrangente  pode  ser  apresentada  em  quadro 
demonstrativo próprio ou incluída dentro das mutações do patrimônio líquido; 
 ... 
Materialidade 
 ... 
24 A  NBC  TG  51 NBC TG 26  define  informações  materiais  e  exige  divulgação  separada  de  itens 
materiais,  inclusive  (por  exemplo)  operações  descontinuadas,  e  a  NBC  TG  23 – Políticas 
Contábeis, Mudança de Estimativa e Retificação de Erro requer divulgações separadas de itens 
materiais,  erros  e  alterações  de  políticas  contábeis.  As  duas  Normas  não  contêm  orientações 
quantitativas com relação à materialidade. 
 
24.  A  NBC  TG  51  NBC  TG  26  –  Apresentação  das  Demonstrações  Contábeis  define  informações 
materiais  e  exige  divulgação  separada  de  itens  materiais,  inclusive  (por  exemplo)  operações 
descontinuadas, e a NBC TG 23 – Base de Apresentação das Demonstrações Contábeis Políticas 
Contábeis, Mudança de Estimativa e Retificação de Erro requer divulgações separadas de itens 
materiais,  erros  e  alterações  de  políticas  contábeis.  As  duas  Normas  não  contêm  orientações 
quantitativas com relação à materialidade. definem como material um item se a sua omissão ou 
incorreção puder influenciar decisões econômicas dos usuários das demonstrações contábeis. A 
NBC TG 26 requer divulgações separadas de itens materiais, incluindo (por exemplo) operações 
descontinuadas, e a NBC TG 23 requer divulgação de alterações de estimativas contábeis, erros 
e alterações de políticas contábeis. As duas Normas não contêm orientações quantitativas com 
relação à materialidade. 
 ... 
Reapresentação de demonstrações de períodos intermediários anteriores 
43 A  alteração  de  política  contábil,  que  não  seja  por  especificação  de  nova  NBC  TG,  deve  ser 
refletida: 
(a)  por   reapresentação   das   demonstrações   contábeis   de   períodos   intermediários 
anteriores do exercício social corrente e das demonstrações contábeis comparáveis de 
períodos intermediários de qualquer exercício social anterior que serão reapresentadas 
nas demonstrações contábeis anuais de acordo com a NBC TG 23 – Políticas Contábeis, 
Mudança de Estimativa e Retificação de Erro; ou 
(b)  quando for impraticável determinar os efeitos cumulativos no início do exercício social 
da aplicação da nova política contábil a todos os períodos anteriores, mediante ajuste 
das demonstrações contábeis de períodos intermediários anteriores do exercício social 
corrente  e  das  demonstrações  intermediárias  comparáveis  dos  exercícios  sociais 
anteriores,  por  aplicação  da  nova  política  contábil  prospectivamente  a  partir  da  data 
mais antiga que for praticável. 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
67 
 
Data de vigência 
 ... 
61 A Revisão NBC 31, aprovada pelo CFC em 10 de outubro de 2025, alterou os itens 4, 5, 7, 8, 8A, 
9, 10, 11A, 12, 20, 24 e 43 e acrescentou o item 16A(m). A entidade aplicará essas alterações 
quando aplicar a NBC TG 51. Nas demonstrações contábeis intermediárias no primeiro ano de 
aplicação da NBC TG 51, uma entidade aplicará os itens C4 a C6 do Apêndice C da NBC TG 51. 
 
31. Altera o item 102, inclui o item 130N e altera as referências e o item 5 da Interpretação Técnica 
na NBC TG 04 (R4) - Ativo Intangível, que passam a vigorar com as seguintes redações: 
 
Ativo intangível com vida útil definida 
    ... 
Valor residual 
    ... 
102 A  estimativa  do  valor  residual  baseia-se  no  valor  recuperável  pela  alienação,  utilizando  os 
preços em vigor na data da estimativa para a venda de ativo similar que tenha atingido o final 
de sua vida útil e que tenha sido operado em condições semelhantes àquelas em que o ativo 
será utilizado. O valor residual deve ser revisado pelo menos ao final de cada exercício. Uma 
alteração  no  valor  residual  deve  ser  contabilizada  como  mudança  na  estimativa  contábil,  de 
acordo  com  a  NBC  TG  23  – Base de Preparação das Demonstrações Contábeis Políticas 
Contábeis, Mudança de Estimativa e Retificação de Erro. 
    ... 
Disposições transitórias 
    ... 
130N   A Revisão NBC 31, aprovada pelo CFC em 10 de outubro de 2025, alterou o item 102 e o item 5 
da Interpretação Técnica. A entidade aplicará essas alterações quando aplicar a NBC TG 51. 
 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
68 
 
INTERPRETAÇÃO TÉCNICA DA NBC TG 04  
Ativo Intangível – Custo com Sítio para Internet (Website Costs) 
 
Referências 
• NBC  TG  51  – Apresentação  e  Divulgação  nas  Demonstrações  Contábeis  NBC  TG  26 – 
Apresentação das Demonstrações Contábeis 
• NBC TG 16 – Estoques 
• NBC TG 27 – Ativo Imobilizado 
• NBC TG 06 – Arrendamentos 
• NBC TG 01 – Redução ao Valor Recuperável de Ativos 
• NBC TG 04 – Ativo Intangível 
• NBC TG 15 – Combinação de Negócios 
• NBC TG 47 – Receita de Contrato com Cliente 
Questão 
 ... 
6 Se esta Interpretação não se aplica aos gastos com a aquisição, desenvolvimento e operação de 
hardware  (por  exemplo,  servidores  de  sítio  na  internet,  servidores  de  teste,  servidores  de 
produção  e  conexões  à  internet)  de  sítio  na  internet.  Gastos  dessa  natureza  devem  ser 
contabilizados, de acordo com a NBC TG 27 – Ativo Imobilizado. Além disso, quando a entidade 
incorre  em  gastos  com o  fornecedor de  serviços  da  internet, o qual  realiza a hospedagem do 
sítio da entidade, o gasto deve ser reconhecido como despesa, de acordo com o item 46 da NBC 
TG 51 – Apresentação e Divulgação nas Demonstrações Contábeis NBC TG 26 – Apresentação 
das Demonstrações Contábeis, item 88, e com a NBC TG 00 – Estrutura Conceitual para Relatório 
Financeiro do NBC TG, quando os serviços são recebidos. 
 
32. Altera o item 31 e inclui o item 85l na NBC TG 28 (R4) - Propriedade para Investimento, que 
passam a vigorar com as seguintes redações: 
Mensuração após reconhecimento 
Política contábil 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
69 
 
    ... 
31 A NBC TG 23 – Base de Preparação das Demonstrações Contábeis Políticas Contábeis, Mudança 
de Estimativa e Retificação de Erro afirma que uma alteração voluntária na política contábil deve 
ser feita apenas se a alteração resultar numa apresentação mais apropriada das operações, de 
outros acontecimentos ou de condições nas demonstrações contábeis da entidade. É altamente 
improvável que uma alteração do método do valor justo para o método do custo resulte numa 
apresentação mais apropriada. 
    ... 
Data de vigência 
    ... 
85I A Revisão NBC 31, aprovada pelo CFC em 10 de outubro de 2025, alterou o item 31. A entidade 
aplicará essas alterações quando aplicar a NBC TG 51. 
33. Altera os itens 50 e 53 e inclui o item 66 na NBC TG 29 (R2) - Ativo Biológico e Produto Agrícola, 
que passam a vigorar com as seguintes redações: 
 
Divulgação 
Geral 
 ... 
50 A  entidade  deve  divulgar  apresentar  a  conciliação  das  mudanças  no  valor  contábil  de  ativos 
biológicos entre o início e o fim do período corrente. A conciliação inclui: 
 ... 
53 A atividade agrícola é, frequentemente, exposta aos riscos climáticos, de doenças e outros riscos 
naturais. Se um evento ocorre e dá origem a um item material de receita ou despesa, a natureza 
e o total devem ser divulgados de acordo com a NBC TG 51 – Apresentação e Divulgação nas 
Demonstrações Contábeis NBC TG 26– Apresentação das Demonstrações Contábeis. Exemplos 
de tais eventos incluem surtos de viroses, inundações, seca, geada e praga de insetos. 
 ... 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
70 
 
Data de vigência e transição 
 ... 
66 A  Revisão  NBC 31,  aprovada pelo  CFC  em  10 de outubro  de  2025,  alterou  os  itens 50  e  53. A 
entidade aplicará essas alterações quando aplicar a NBC TG 51. 
 
34. Altera os itens 6 e 8 e inclui as referências e o item 9C na ITG 12 - Mudanças em Passivos por 
Desativação, Restauração e Outros Passivos Similares, que passam a vigorar com as seguintes 
redações: 
Referências 
• NBC TG 06 – Arrendamentos 
• NBC TG 51 – Apresentação e Divulgação nas Demonstrações Contábeis  
• NBC TG 23 – Base de Preparação das Demonstrações Contábeis  
• NBC TG 27 – Ativo Imobilizado   
• NBC TG 20 – Custos de Empréstimos 
• NBC TG 01 – Redução ao Valor Recuperável de Ativos   
• NBC TG 25 – Provisões, Passivos Contingentes e Ativos Contingentes 
 ... 
Consenso 
 ... 
6 Se  o  respectivo  ativo  tiver  sido  mensurado  utilizando  o  método  de  reavaliação  (quando 
legalmente possível): 
... 
(d) A NBC TG 51 – Apresentação e Divulgação nas Demonstrações Contábeis NBC TG 26 – 
Apresentação das Demonstrações Contábeis exige  que  itens  de  outros  resultados 
abrangentes   sejam   apresentados   como   rubricas   na   demonstração   do   resultado 
abrangente   a   divulgação   na   demonstração   do   resultado   abrangente   de   cada 
componente  de  outra  receita  ou  despesa  abrangente.  Ao  cumprir  esse  requisito,  a 
mudança na reserva de reavaliação resultante de mudança no passivo será identificada 
e apresentada divulgada separadamente como tal. 
 ... 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
71 
 
8 A reversão periódica do desconto deverá ser reconhecida no resultado como despesa de juros 
de passivos que surjam de transações que não envolvam apenas a obtenção de financiamento 
custo de financiamento à medida que ocorrer e classificada – aplicando o item 61 da NBC TG 51 
– na categoria de financiamento da demonstração do resultado. A capitalização prevista na NBC 
TG 20 – Custos dos Empréstimos não é permitida. 
 
Data de vigência 
 ... 
9C A  Revisão  NBC  31,  aprovada  pelo  CFC  em  10  de  outubro  de  2025,  alterou  os  itens  6  e  8  e 
adicionou as referências. A entidade aplicará essas alterações quando aplicar a NBC TG 51. 
... 
 
35. Altera as referências na ITG 13 (R2) - Direitos a Participações Decorrentes de Fundos de 
Desativação, Restauração e Reabilitação Ambiental, que passam a vigorar com as seguintes 
redações: 
 
Referências 
• NBC TG 48 – Instrumentos Financeiros 
• NBC TG 36 – Demonstrações Consolidadas 
• NBC TG 19 – Negócios em Conjunto 
• NBC TG 23 – Base de Preparação das Demonstrações ContábeisPolíticas Contábeis, Mudança de 
Estimativa e Retificação de Erro 
• NBC TG 18 – Investimento em Coligada, em Controlada e em Empreendimento em Conjunto 
• NBC TG 25 – Provisões, Passivos Contingentes e Ativos Contingentes 
 
36. Altera as referências na ITG 15 - Passivo Decorrente da Participação em um Mercado Específico 
– Resíduos de Equipamentos Eletroeletrônicos, que passam a vigorar com as seguintes redações: 
 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
72 
 
Referências 
• NBC TG 23 – Base de Preparação das Demonstrações Contábeis Políticas Contábeis, Mudança de 
Estimativa e Retificação de Erro 
• NBC TG 25 – Provisões, Passivos Contingentes e Ativos Contingentes 
 
37. Altera as referências na ITG 01 (R1) - Contratos de Concessão, que passam a vigorar com as 
seguintes redações: 
Referências 
• NBC TG 00 – Estrutura Conceitual para Relatório Financeiro 
• NBC TG 37 – Adoção pela Primeira Vez das Normas Internacionais de Contabilidade 
• NBC TG 40 – Instrumentos Financeiros: Divulgações 
• NBC TG 48 – Instrumentos Financeiros 
• NBC TG 47 – Receita de Contratos com Clientes 
• NBC TG 06 – Arrendamentos 
• NBC TG 23 – Base de Preparação das Demonstrações Contábeis Políticas Contábeis, Mudança de 
Estimativa e Retificação de Erro 
•  NBC TG 27 – Ativo Imobilizado 
• NBC TG 07 – Subvenção e Assistência Governamentais 
• NBC TG 20 – Custos de Empréstimos 
• NBC TG 39 – Instrumentos Financeiros: Apresentação 
• NBC TG 01 – Redução ao Valor Recuperável de Ativos 
• NBC TG 25 – Provisões, Passivos Contingentes e Ativos Contingentes 
• NBC TG 04 – Ativo Intangível 
• ITG 17 – Contratos de Concessão: Evidenciação 
 
38. Altera os itens 10 e as referências e inclui o item 27D na ITG 20 - Limite de ativo de benefício 
definido, requisitos de custeio (funding) mínimo e sua interação, que passam a vigorar com as 
seguintes redações: 
 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
73 
 
Referências 
• NBC  TG  51  – Apresentação  e  Divulgação  nas  Demonstrações  Contábeis  NBC  TG  26 – 
Apresentação das Demonstrações Contábeis 
• NBC TG 23 – Base de Preparação das Demonstrações Contábeis Políticas Contábeis, Mudança de 
Estimativa e Retificação de Erro 
•  NBC TG 33 – Benefícios a Empregados 
• NBC TG 25 – Provisões, Passivos Contingentes e Ativos Contingentes 
 ... 
Consenso 
Disponibilidade de uma restituição ou redução nas contribuições futuras 
 ... 
10 De  acordo  com  a  NBC  TG  23 NBC TG 26 – Apresentação das Demonstrações Contábeis,  a 
entidade deve divulgar informações sobre as principais fontes de incerteza na estimativa ao final 
do  período  das  demonstrações  contábeis  que  tenham  risco  significativo  de  causar  ajuste 
relevante no valor contábil do ativo ou passivo líquido reconhecido no balanço patrimonial. Isso 
poderia incluir a divulgação de quaisquer restrições sobre a atual capacidade de realização do 
superávit  ou  a  divulgação  da  base  utilizada  para  determinar  o  valor  do  benefício  econômico 
disponível. 
 ... 
Data de vigência 
 ... 
27D A Revisão NBC 31, aprovada pelo CFC em 10 de outubro de 2025, alterou o item 10. A entidade 
aplicará essas alterações quando aplicar a NBC TG 51. 
 
39. Altera o item 2 e as referências e inclui o item 21 na ITG 07 (R1) - Distribuição de Lucros In Natura, 
que passam a vigorar com as seguintes redações: 
 
Referências 
• NBC TG 15 – Combinação de Negócios 
• NBC TG 31 – Ativo Não Circulante Mantido para Venda e Operação Descontinuada 
• NBC TG 40 – Instrumentos Financeiros: Evidenciação 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
74 
 
• NBC  TG  51  – Apresentação  e  Divulgação  nas  Demonstrações  Contábeis  NBC  TG  26 – 
Apresentação das Demonstrações Contábeis 
• NBC TG 24 – Evento Subsequente 
• NBC TG 35 – Demonstrações Separadas 
• NBC TG 36 – Demonstrações Consolidadas 
• NBC TG 46 – Mensuração do Valor Justo 
 ... 
Contexto 
 ... 
2.  As  Normas  Brasileiras  de  Contabilidade  (NBC  TG)  não  oferece  orientação  acerca  de  como  a 
entidade deve mensurar distribuições de seus lucros àqueles que façam jus a elas (comumente, 
e aqui, denominados dividendos). A NBC TG 51 – Apresentação e Divulgação nas Demonstrações 
Contábeis  NBC  TG  26  –  Apresentação  das  Demonstrações  Contábeis  requer  que  a  entidade 
apresente   os   detalhes   dos   dividendos   (entenda-se,   para   fins   desta   Revisão,   como 
representativos  de  distribuições  de  lucros  para  as  sociedades  que  não  sejam  por  ações) 
reconhecidos como distribuições para seus acionistas e demais beneficiados na demonstração 
das  mutações  do  patrimônio  líquido  ou  divulgue  nas  notas  explicativas  que  acompanham  as 
demonstrações contábeis. 
 ... 
Data efetiva 
 ... 
21 A Revisão NBC 31, aprovada pelo CFC em 10 de outubro de 2025, alterou o item 2. A entidade 
aplicará essas alterações quando aplicar a NBC TG 51. 
 
40.   Altera os itens 23(b), 26, 34(b) e 69 na ITG 09 (R1) – Demonstrações Contábeis Individuais, 
Demonstrações  Separadas,  Demonstrações  Consolidadas  e  Aplicação  do  Método  da 
Equivalência Patrimonial, que passam a vigorar com as seguintes redações: 
 
23 (b)  o  ágio  por  expectativa  de  rentabilidade  futura  (goodwill)  do  investimento  em  controlada, 
representado pela diferença positiva entre (i) a soma do montante dado em troca do controle 
(valor pago ou a pagar relativo à compra de participação que conferiu o controle) com o valor 
justo de alguma participação pré-existente, se houver; e (ii) a parte da adquirente no valor justo 
dos ativos e passivos da entidade adquirida já líquidos do passivo fiscal diferido (ou acrescido do 
ativo fiscal diferido). Notar que esse goodwill só deve ser classificado no subgrupo de intangíveis 
separadamente no balanço consolidado, nunca no balanço individual, onde deve permanecer 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
75 
 
integrando o saldo contábil do investimento, o qual é apresentado no subgrupo de investimentos 
como ágio por expectativa de rentabilidade futura; afinal, o goodwill assim calculado é pertinente 
à adquirida, pago pela adquirente (nos casos em que houve compra, por exemplo) e para esta, 
individualmente, representa parte do custo de seu investimento, mesmo que sujeito a impairment. 
 
26   No balanço consolidado, o goodwill da combinação deve ficar registrado no subgrupo do ativo 
intangível  separadamente  por  se  referir  à  expectativa  de  rentabilidade  futura  da  controlada 
adquirida,  cujos  ativos  e  passivos  estão  consolidados  nos  da  controladora.  Já  no  balanço 
individual da controladora, a parte desse ágio atribuível à controladora deve integrar o saldo 
contábil do investimento e, portanto, ficar no subgrupo de investimentos do grupo de ativos não 
circulantes, porque, para a investidora, faz parte do seu investimento na aquisição da controlada, 
não sendo um ativo que seja parte de sua posição financeira e patrimonial (como dito atrás, essa 
parte da expectativa de rentabilidade futura é da controlada). O processo de reconhecimento de 
impairment, por outro lado, deve ser aplicado tanto à conta de goodwill no balanço consolidado 
(ver NBC TG 01 – Redução ao Valor Recuperável de Ativos), como à subconta também de ágio 
por expectativa de rentabilidade futura (goodwill) no balanço individual. 
 
34 (b)  a  diferença  mencionada  no  item  23(b),  representada  pelo goodwill  deve  continuar  sendo 
classificada no grupo do intangível separadamente nas demonstrações consolidadas, ajustado 
pelo goodwill atribuível aos não controladores somente se essa participação dos não controladores 
for avaliada ao valor justo. 
  
 Exemplo do ajuste do valor justo dos ativos e passivos na consolidação da data da aquisição do 
controle: (...) 
  
Balanço Consolidado da Cia. A na data da aquisição do controle da Cia. B 
Ativos diversos      $ 2.700(*)   Passivos       $ 1.000 (**) 
Intangível (g Goodwill)     $ 254   Passivo fiscal diferido      $ 90 
 
Capital       $ 1.300 
Part. não controladores    $ 564 (***) 
Totais    $ 2.954         $ 2.954 
 [...] 
  
 Balanço  Consolidado  da  Cia.  A  na  data  da  aquisição  do  controle  da  Cia.  B  (com  a 
participação de não controladores a valor justo) 
Ativos diversos      $ 2.700     Passivos       $ 1.000 
Intangível (g Goodwill)     $ 360   Passivo fiscal diferido      $ 90 
 
Capital       $ 1.300 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
76 
 
Part. não controladores    $ 670 (*) 
Totais    $ 3.060         $ 3.060 
[...] 
 
69.  Nas demonstrações separadas da controladora, se forem apresentadas, as transações de capital 
mencionadas no item 66 devem ser consideradas como alterações dos seus investimentos, quer 
quando avaliados pelo valor justo quer quando pelo custo. 
    [...] 
     
Balanço Consolidado 1 da Cia. A 
Ativos diversos      $ 2.250 
Goodwill (*)     $ 300  Capital         $ 1.500 
Reservas      $ 800 
Participação não controladores   $ 250 
$ 2.550          $ 2.550 
(*) Note-se que o ágio (goodwill) está registrado separadamente, no balanço consolidado, no ativo 
intangível, em nível de conta, e não de subconta como no balanço individual. (...) 
 
    [...] 
 
Segundo a determinação da NBC TG 36, a contabilização desses $ 25 deve ser como redução do 
patrimônio líquido consolidado. Como coerência, e para que o balanço individual tenha o mesmo 
patrimônio líquido que o consolidado, também terá que haver uma redução do patrimônio líquido 
do balanço individual da Cia. A. No caso em questão, essa redução, explicada após se ver, à 
frente, o balanço consolidado, será a relativa ao ágio (goodwill) adicional nessa aquisição, que 
não será tratada como acréscimo ao seu ativo intangível. Entretanto, na prática essas transações 
ocorrem em datas posteriores à data da combinação, de forma que o valor pago pela compra de 
parte a mais do capital da controlada poderá conter não apenas goodwill, como também mais valia 
(a preços correntes). Apesar disso, o que pode ser registrado na conta de investimento pela 
compra  adicional  de  participação  é  somente  o  valor  patrimonial  da  participação  adicional 
comprada, desde que a controladora tenha mensurado a participação dos não controladores a 
valor justo na data da combinação, pois se tiver sido utilizado o critério alternativo, então nas 
demonstrações  consolidadas  o goodwill  existente  deve  ser  totalmente  atribuível  apenas  à 
controladora. 
 
 
41. Altera os itens 11 e as referências e inclui o item 18 na ITG 16 (R2) - Extinção de Passivos 
Financeiros com Instrumentos Patrimoniais, que passam a vigorar com as seguintes redações: 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
77 
 
 
Referências 
• NBC TG 00 – Estrutura Conceitual para Relatório Financeiro 
• NBC TG 10 – Pagamento Baseado em Ações 
• NBC TG 15 – Combinação de Negócios 
• NBC TG 23 – Base de Preparação das Demonstrações Contábeis Políticas Contábeis, Mudança de 
Estimativa e Retificação de Erro 
• NBC  TG  51  – Apresentação  e  Divulgação  nas  Demonstrações  Contábeis  NBC  TG  26 – 
Apresentação das Demonstrações Contábeis 
• NBC TG 48 – Instrumentos Financeiros 
• NBC TG 39 – Instrumentos Financeiros: Apresentação 
• NBC TG 46 – Mensuração do Valor Justo 
 ... 
Consenso 
 ... 
11 A entidade deve apresentar divulgar o ganho ou a perda reconhecido de acordo com os itens 9 
e 10 como item separado na demonstração do resultado ou deve divulgar em nota explicativa. 
Data de transição 
 ... 
18 A Revisão NBC 31, aprovada pelo CFC em 10 de outubro de 2025, alterou o item 11. A entidade 
aplicará essas alterações quando aplicar a NBC TG 51. 
 
42. Altera as referências na ITG 18 – Custos de Remoção de Estéril (Stripping) de Mina de Superfície 
na Fase de Produção, que passam a vigorar com as seguintes redações: 
 
Referências 
• NBC TG 00 – Estrutura Conceitual para Relatório Financeiro 
• NBC TG 04 – Ativo Intangível 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
78 
 
• NBC TG 16 – Estoques 
• NBC  TG  51  – Apresentação  e  Divulgação  nas  Demonstrações  Contábeis  NBC  TG  26 – 
Apresentação das Demonstrações Contábeis 
• NBC TG 27 – Ativo Imobilizado 
 
43. Altera as referências na ITG 19 – Tributos, que passam a vigorar com as seguintes redações: 
 
Referências 
• NBC  TG  51  – Apresentação  e  Divulgação  nas  Demonstrações  Contábeis  NBC  TG  26 – 
Apresentação das Demonstrações Contábeis 
• NBC TG 23 – Base de Preparação das Demonstrações Contábeis Políticas Contábeis, Mudança de 
Estimativas e Retificação de Erro 
• NBC TG 32 – Tributos sobre o Lucro 
• NBC TG 07 – Subvenção e Assistência Governamentais 
• NBC TG 05 – Divulgação sobre Partes Relacionadas 
• NBC TG 21 – Demonstração Intermediária 
• NBC TG 25 – Provisões, Passivos Contingentes e Ativos Contingentes 
• ITG 15 – Passivo Decorrente da Participação em Mercado Específico – Resíduos de Equipamentos 
Eletroeletrônicos 
 
Uma nota de rodapé é acrescentada à “NBC TG 23 – PolíƟcas Contábeis, Mudança de EsƟmaƟva e 
ReƟficação de Erro” no item A2. O novo texto está sublinhado. 
 
* Quando emitiu a Revisão NBC 31 em 10 de outubro de 2025, a NBC TG alterou o título da NBC 
TG 23 (R2) para Base de Preparação das Demonstrações Contábeis. 
 
44. Altera as referências na ITG 21 - Transação em Moeda Estrangeira e Adiantamento, que passam 
a vigorar com as seguintes redações: 
 
Referências 
• NBC TG 00 – Estrutura Conceitual para Relatório Financeiro 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
79 
 
• NBC TG 23 – Base de Preparação das Demonstrações Contábeis Políticas Contábeis, Mudança de 
Estimativa e Retificação de Erro 
• NBC TG 02 – Efeitos das Mudanças nas Taxas de Câmbio e Conversão de Demonstrações 
Contábeis 
 
Uma nota de rodapé é acrescentada à “NBC TG 23 – PolíƟcas Contábeis, Mudança de EsƟmaƟva e 
ReƟficação de Erro” no item A2. O novo texto está sublinhado. 
 
* Quando emitiu a Revisão NBC 31 em 10 de outubro de 2025, o NBC TG alterou o título da NBC 
TG 23 (R2) para Base de Preparação das Demonstrações Contábeis. 
 
45. Altera os itens 14 e A4 e as referências e inclui o item B1A na ITG 22 - Incerteza sobre Tratamento 
de Tributos sobre o Lucro, que passam a vigorar com as seguintes redações: 
 
Referências 
• NBC TG 26 – Apresentação das Demonstrações Contábeis 
• NBC TG 23 – Base de Preparação das Demonstrações Contábeis Políticas Contábeis, Mudança 
de Estimativa e Retificação de Erro 
• NBC TG 24 – Evento Subsequente 
• NBC TG 32 – Tributos sobre o Lucro 
 ... 
Consenso 
 ... 
Mudanças em fatos e circunstâncias 
 ... 
14 A entidade deve refletir o efeito da mudança em fatos e circunstâncias ou de novas informações 
como uma mudança na estimativa contábil, aplicando a NBC TG 23 – Base de Preparação das 
Demonstrações Contábeis Políticas Contábeis, Mudança de Estimativa e Retificação de Erro. A 
entidade  deve  aplicar  a  NBC  TG  24  –  Evento  Subsequente  para  determinar  se  a  mudança 
ocorrida após o encerramento do período contábil é evento que requer ajustes ou não. 
 ... 
Apêndice A – Orientação de Aplicação 
Divulgação 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
80 
 
A4 Quando há incerteza sobre tratamentos de tributos sobre o lucro, a entidade deve determinar 
se deve divulgar: 
(a) julgamentos feitos ao determinar lucro tributável (prejuízo fiscal), base fiscal, prejuízos fiscais 
não utilizados, créditos fiscais não utilizados e alíquotas fiscais, aplicando o item 27G da NBC 
TG 23 122 da NBC TG 26; e 
(b) informações sobre as premissas e informações feitas ao determinar lucro tributável (prejuízo 
fiscal),  base  fiscal,  prejuízos  fiscais  não  utilizados,  créditos  fiscais  não  utilizados  e  alíquotas 
fiscais, aplicando o os itens de 31A a 31E do NBC TG 23 125 a 129 da NBC TG 26. 
 ... 
Apêndice B 
Data de vigência e transição 
Data de vigência 
 ... 
B1A A Revisão NBC 31, aprovada pelo CFC em 10 de outubro de 2025, alterou os itens 14 e A4. A 
entidade aplicará essas alterações quando aplicar a NBC TG 51. 
 
46. Altera as referências na ITG 17 - Contratos de Concessão: Evidenciação, que passam a vigorar 
com as seguintes redações: 
 
Referências 
• NBC  TG  51  – Apresentação  e  Divulgação  nas  Demonstrações  Contábeis  NBC  TG  26 – 
Apresentação das Demonstrações Contábeis 
• NBC TG 27 – Ativo Imobilizado  
• NBC TG 06 – Arrendamentos 
• NBC TG 25 – Provisões, Passivos Contingentes e Ativos Contingentes 
• NBC TG 04 – Ativo Intangível 
• ITG 01 – Contratos de Concessão 
 
Esta  Revisão  entra  em  vigor  na  data  de  sua  publicação,  devendo-se  as  alterações  para  os  exercícios 
iniciados em, ou após, 1º de janeiro de 2027. 
 
Brasília, 13 de novembro de 2025. 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
81 
 
 
CONTADOR AÉCIO PRADO DANTAS JÚNIOR 
Presidente 
Ata CFC nº 1.125.
