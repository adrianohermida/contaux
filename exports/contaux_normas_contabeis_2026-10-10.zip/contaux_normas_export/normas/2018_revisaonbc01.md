# Aprova Revisão NBC 01

- Código externo: 2018/revisaonbc01
- Fonte: CFC 2018/REVISAONBC01 — DOU 06/11/2018
- URL fonte: https://www2.cfc.org.br/sisweb/sre/detalhes_sre.aspx?Codigo=2018/REVISAONBC01&arquivo=REVISAONBC01.doc
- Arquivo original: https://www1.cfc.org.br/sisweb/SRE/docs/REVISAONBC01.pdf
- Nome do arquivo: REVISAONBC01.pdf
- Tags: Contábil, NBC, Revisão NBC
- Atualizado em: 2026-10-10 14:27:53.117743+00

## Resumo

Aprova Revisão NBC 01

## Texto integral extraído

1 
 
NORMA BRASILEIRA DE CONTABILIDADE, REVISÃO NBC 01, DE 18 DE OUTUBRO DE 2018 
 
 
Aprova   a   revisão   das   seguintes   normas   e 
interpretações  técnicas:  NBC  TG  02  (R3),  NBC 
TG  03  (R3),  NBC  TG  04  (R4),  NBC  TG  11 (R2), 
NBC  TG  15  (R4),  NBC  TG  16  (R2),  NBC  TG  18 
(R3), NBC TG 19 (R2), NBC  TG 20 (R2), NBC  TG 
25 (R2),  NBC  TG  26  (R5),  NBC  TG  27 (R4),  NBC 
TG  28 (R4),  NBC  TG  29 (R2),  NBC  TG  32 (R4), 
NBC  TG  33  (R2),  NBC  TG  37  (R5),  NBC  TG  39 
(R5), NBC TG 40 (R3), NBC TG 47, NBC TG 48 e 
ITG 12. 
 
 
O CONSELHO FEDERAL DE CONTABILIDADE, no exercício de suas atribuições legais 
e  regimentais  e  com  fundamento  no  disposto  na  alínea  “f”  do  Art.  6º  do  Decreto-Lei  n.º 
9.295/1946,  alterado  pela  Lei  n.º  12.249/2010,  faz  saber  que  foi  aprovada  em  seu  Plenário  a 
Revisão NBC 01, que altera as seguintes normas e interpretações: 
 
1.  Altera o item 16 na NBC TG 02 (R3) – Efeitos das Mudanças nas Taxas de Câmbio e 
Conversão de Demonstrações Contábeis, que passa a vigorar com a seguinte redação: 
 
16.  A  característica  essencial  de  item  monetário  é  o  direito  a  receber  (ou  a  obrigação  de 
entregar)  um  número  fixo  ou  determinável  de  unidades  de  moeda.  Alguns  exemplos  incluem: 
passivos  de  planos  de  pensão  ou  outros  benefícios  a  empregados  a  serem  pagos  com  caixa; 
provisões  que  devem  ser  liquidadas  em  caixa; passivos  de  arrendamento; e  dividendos  a  serem 
distribuídos  com  caixa,  que  são  reconhecidos  como  passivos.  Da  mesma  forma,  o  contrato  que 
preveja  o  direito  a  receber  (ou  a  obrigação  de  entregar)  um  número  variável  de  instrumentos 
patrimoniais  da  própria  entidade  ou  uma  quantidade  variável  de  ativos,  cujo  valor  justo  a  ser 
recebido (ou a ser entregue) iguala-se ao número fixo ou determinável de unidades de moeda, é 
considerado item monetário. Por outro lado, a característica essencial de item não monetário é a 
ausência  do  direito  a  receber  (ou  da  obrigação  de  entregar)  um  número  fixo  ou  determinável  de 
unidades  de  moeda.  Alguns  exemplos  incluem:  adiantamento  a  fornecedores  de  mercadorias; 
adiantamento a prestadores de serviços; goodwill; ativos intangíveis; estoques; imobilizado; ativo 
de direito de uso; e provisões a serem liquidadas mediante a entrega de ativo não monetário. 
 
 
2.  Altera os itens 17 e 44 na NBC TG 03 (R3) – Demonstração dos Fluxos de Caixa, que 
passam a vigorar com as seguintes redações: 
 
17.  A  divulgação  separada  dos  fluxos  de  caixa  advindos  das  atividades  de  financiamento  é 
importante  por  ser  útil  na  predição  de  exigências  de  fluxos  futuros  de  caixa  por  parte  de 
fornecedores  de  capital  à  entidade.  Exemplos  de  fluxos  de  caixa  advindos  das atividades  de 
financiamento são: 
(a) (...) 
(e) pagamentos em caixa pelo arrendatário para redução do passivo relativo a arrendamento 
mercantil. 
 
44.  Muitas  atividades  de  investimento  e  de  financiamento  não  têm  impacto  direto  sobre  os 
fluxos de caixa correntes, muito embora afetem a estrutura de capital e de ativos da entidade. A 
exclusão de transações que não envolvem caixa ou equivalentes de caixa da demonstração dos 
fluxos  de  caixa  é  consistente  com  o  objetivo  da referida  demonstração,  visto  que  tais  itens  não 
envolvem fluxos de caixa no período corrente. Exemplos de transações que não envolvem caixa 
ou equivalente de caixa são: 
(a) a aquisição de ativos, quer seja pela assunção direta do passivo respectivo, quer seja por 
meio de arrendamento mercantil; 

2 
 
(b) (...) 
 
 
3.  Altera os itens 3 e 6 e, na Interpretação Técnica anexa, o item 6 na NBC TG 04 (R4) – 
Ativo Intangível, que passam a vigorar com as seguintes redações: 
 
3.  Se  outra  norma estabelecer  o  tratamento  contábil  para  um  tipo  específico  de  ativo 
intangível,  a  entidade  deve  aplicar a referida  norma específica em  vez  desta.  Por  exemplo,  esta 
norma não deve ser aplicada nos seguintes casos: 
(a)  (...) 
(c) arrendamentos mercantis de ativo intangível contabilizado de acordo com a NBC TG 06 – 
Operações de Arrendamento Mercantil; 
(d) (...) 
 
6.  Direitos  detidos  por  arrendatário  por  meio  de  contratos  de  licenciamento  para  itens  como 
filmes  cinematográficos,  gravações  em  vídeo,  peças,  manuscritos,  patentes  e  direitos  autorais 
estão dentro do alcance desta norma e devem ser excluídos do alcance da NBC TG 06. 
 
6.  A NBC TG 04 – Ativo Intangível não é aplicável a ativos intangíveis mantidos pela entidade 
para venda no curso normal dos negócios (ver NBC TG 16 e NBC TG 47), nem a arrendamentos 
de  ativos  intangíveis dentro  do  alcance  da  NBC  TG 06.  Consequentemente,  esta  interpretação 
não deve ser aplicada aos gastos com o desenvolvimento ou à operação de sítio na internet (ou 
software de sítio na internet) para venda a outra entidade ou que é contabilizado de acordo com a 
NBC TG 06.  
 
 
4.  Altera o item 4 na NBC TG 11 (R2) – Contratos de Seguro, que passa a vigorar com a 
seguinte redação: 
 
4. A entidade não deve aplicar esta norma para: 
(a) (...) 
(c)  direitos ou obrigações contratuais que dependem do uso, ou do direito de uso, de item não 
financeiro   (por   exemplo,   algumas   taxas   de   licença, royalties,   pagamentos variáveis de 
arrendamentos  mercantis  e  itens  semelhantes),  assim  como  garantia  de  valor  residual  embutido 
em arrendamento (ver NBC TG 06 – Operações de Arrendamento Mercantil, NBC TG 47 e NBC 
TG 04 – Ativo Intangível);  
(d) (...) 
 
 
5.  Altera os itens 14, 17, B32 e B42, inclui os itens 28A, 28B e seu título e 42A e exclui 
os  itens  B28,  B29  e  B30  na  NBC  TG 15  (R4) – Combinação  de  Negócios,  que  passam  a 
vigorar com as seguintes redações: 
 
14. Os itens B31 a B40 fornecem orientações para o reconhecimento de ativos intangíveis. Os 
itens  22  a  28B especificam  os  tipos  de  ativos  identificáveis  e  os  passivos  assumidos,  os quais 
incluem itens para os quais esta norma prevê limitadas exceções ao princípio e às condições de 
reconhecimento. 
 
17. Esta norma prevê duas exceções ao princípio descrito no item 15: 
(a) classificação  de  contrato  de  arrendamento  mercantil em  que  a  adquirida  é  o  arrendador 
como arrendamento operacional ou financeiro, conforme descrito na NBC TG 06 – Operações de 
Arrendamento Mercantil; e 
(b) (...)  
 
Arrendamento em que a adquirida é o arrendatário 
 

3 
 
28A.  O  adquirente  deve  reconhecer  o  ativo  de  direito  de  uso  e  passivos  de  arrendamento  para 
arrendamentos identificados de acordo com a NBC TG 06, no qual a adquirida é o arrendatário. O 
adquirente não é obrigado a reconhecer o ativo de direito de uso e os passivos de arrendamento 
para: 
(a)  arrendamento  para  o  qual  o  prazo  do  arrendamento  (conforme  definido  na NBC  TG 06) 
termina dentro de 12 meses contados da data de aquisição; ou 
(b) arrendamento para o qual o ativo subjacente é de baixo valor (conforme descrito nos itens B3 
a B8 da NBC TG 06). 
 
28B. O  adquirente  deve  mensurar  o  passivo  de  arrendamento  ao  valor  presente  do  saldo  de 
arrendamento  remanescente  (conforme  definido   na  NBC   TG 06)  como   se  o  contrato   de 
arrendamento  adquirido  fosse  um  novo  contrato  de  arrendamento  na  data  de  aquisição.  O 
adquirente deve mensurar o ativo de direito de uso ao mesmo valor do passivo de arrendamento, 
ajustado para refletir os termos favoráveis ou desfavoráveis do arrendamento quando comparado 
com os termos do mercado. 
 
42A.  Quando  a  parte  em  negócio  em  conjunto  (conforme  definido  na  NBC  TG 19)  obtém  o 
controle  de  negócio  que é  operação  conjunta  (conforme  definido  na  NBC  TG 19)  e  teve  direitos 
sobre os ativos e obrigações dos passivos relacionados a essa operação conjunta imediatamente 
anterior à data de aquisição, a transação é uma combinação de negócios alcançada em estágios. 
O  adquirente  deve,  portanto,  aplicar  os  requisitos  para  combinação  de  negócios  realizada  em 
estágios,  incluindo  a  remensuração  de  sua  participação  anterior  na  operação  conjunta  na  forma 
descrita no item 42. Ao fazê-lo, o adquirente deve remensurar toda a sua participação anterior na 
operação conjunta. 
 
B28. Eliminado. 
 
B29. Eliminado. 
 
B30. Eliminado. 
 
B32. O ativo intangível que atende ao critério legal-contratual é identificável mesmo se ele não 
puder ser transferido ou separado da adquirida ou de outros direitos e obrigações. Por exemplo: 
(a) eliminada; 
(b) (...) 
 
B42. Na mensuração do valor justo, na data da aquisição, de ativo tal como edifício ou patente 
que  sejam  objeto  de  arrendamento  mercantil  operacional, em  que  a  adquirida  é  o arrendador,  o 
adquirente deve considerar os termos e as condições do contrato de arrendamento. O adquirente 
não  deve  reconhecer o ativo  ou  passivo  separadamente, se  as  condições  do  arrendamento 
mercantil operacional forem favoráveis ou desfavoráveis em relação às condições de mercado.  
 
 
6.  Altera o item 12 na NBC TG 16 (R2) – Estoques, que passa a vigorar com a seguinte 
redação: 
 
12.  Os custos de transformação de estoques incluem os custos diretamente relacionados com 
as  unidades  produzidas  ou  com  as  linhas  de  produção,  como  pode  ser  o  caso  da  mão  de  obra 
direta. Também incluem a alocação sistemática de custos indiretos de produção, fixos e variáveis, 
que sejam incorridos para transformar os materiais em produtos acabados. Os custos indiretos de 
produção  fixos  são  aqueles que  permanecem  relativamente  constantes  independentemente  do 
volume  de  produção,  tais  como  a  depreciação  e  a  manutenção  de  edifícios  e  instalações  fabris, 
máquinas, equipamentos e ativos de direito de uso utilizados no processo de produção e o custo 
de gestão  e  de administração  da fábrica.  Os  custos  indiretos  de  produção  variáveis  são  aqueles 
que  variam  diretamente,  ou  quase diretamente,  com  o  volume  de  produção,  tais  como  materiais 
indiretos e certos tipos de mão de obra indireta. 
 

4 
 
 
7.  Inclui os itens 14A e 45G a 45K e exclui o item 41 na NBC TG 18 (R3) – Investimento 
em Coligada, em Controlada e em Empreendimento Controlado em Conjunto, que passam a 
vigorar com as seguintes redações: 
 
14A.  A  entidade  também  deve  aplicar a  NBC  TG 48  a  outros  instrumentos  financeiros  em 
coligada, em controlada ou em empreendimento controlado em conjunto, relativamente aos quais 
o  método  da  equivalência  patrimonial  não  é  aplicado.  Esses  instrumentos  incluem  participações 
de longo prazo que, em substância, fazem parte do investimento líquido da entidade em coligada, 
em  controlada  ou  em  empreendimento  controlado  em  conjunto  (ver  item  38).  A  entidade  deve 
aplicar a NBC TG 48 a tais participações de longo prazo antes de aplicar o item 38 e os itens 40 a 
43 desta norma. Ao aplicar a NBC TG 48, a entidade não deve levar em consideração quaisquer 
ajustes no valor contábil de participações de longo prazo decorrentes da aplicação desta norma. 
 
41.  (Eliminado). 
... 
45G.  A  entidade  deve  aplicar  as  alterações  dos  itens  14A  e  41,  retrospectivamente,  de  acordo 
com a  NBC  TG 23  para  períodos  de  relatório  anual  com  início  em  1º  de  janeiro  do  início  da 
vigência dessas alterações, exceto quando especificado nos itens 45H a 45K.  
 
45H.  A  entidade  que  aplicar pela  primeira  vez  as  alterações descritas no  item  45G  ao  mesmo 
tempo em que  aplicar pela  primeira  vez a  NBC  TG 48  deve  aplicar  os  requisitos  de  transição, 
especificados na NBC TG 48, às participações de longo prazo descritos no item 14A. 
 
45I.  A  entidade, que  aplicou  pela  primeira  vez  as  alterações descritas no  item  45G, após  a 
primeira  aplicação  da  NBC  TG 48, deve  aplicar  os  requisitos  de  transição  da  NBC  TG 48 
necessários  para  a  aplicação  dos  requisitos  estabelecidos  no  item  14A  para  as  participações de 
longo prazo. Para esse propósito, as referências à data da aplicação inicial da NBC TG 48 devem 
ser  lidas  como  referentes  ao  início  do  período  de  relatório  anual  em  que  a  entidade  aplicar as 
alterações  pela  primeira  vez  (a  data  da  aplicação  inicial  das  alterações).  A  entidade  não  é 
obrigada a reapresentar os períodos anteriores para refletir a aplicação das alterações. A entidade 
pode reapresentar períodos anteriores somente se for possível sem o uso de percepção posterior. 
 
45J.  Ao  aplicar  pela  primeira  vez  as  alterações descritas no  item  45G,  a  entidade  que  aplica  a 
isenção temporária da NBC TG 48, de acordo com os contratos de seguro da NBC TG 11, não é 
obrigada a reapresentar os períodos anteriores para refletir a aplicação das alterações. A entidade 
pode reapresentar períodos anteriores somente se for possível sem o uso de percepção posterior. 
 
45K. Se a entidade não reapresentar os períodos anteriores, aplicando o item 45I ou o item 45J, 
na  data  da  aplicação  inicial  das  alterações,  deve  reconhecer  em  lucros  acumulados  (ou  outro 
componente do patrimônio líquido, conforme apropriado) qualquer diferença entre: 
(a) o valor contábil anterior das participações de longo prazo descritas no item 14A nessa data; e 
(b) o valor contábil dessas participações de longo prazo nessa data. 
 
 
8.  Inclui o item B33CA na NBC TG 19 (R2) – Negócios em Conjunto, que passa a vigorar 
com a seguinte redação: 
 
B33CA.  A  parte  que  participa,  mas  não  tem  controle  conjunto  de uma operação  conjunta, pode 
obter o controle conjunto da operação conjunta em que a atividade da operação conjunta constitui 
um negócio, conforme definido na NBC TG 15. Nesses casos, participações anteriormente detidas 
em operação conjunta não devem ser remensuradas. 
 
 
9.  Altera  os  itens  6  e  14  na  NBC  TG 20  (R2) – Custos  de  Empréstimos,  que  passam  a 
vigorar com as seguintes redações: 
 

5 
 
6.  Custos de empréstimos podem incluir:  
(a) (...)  
(d) juros  sobre  passivos  de  arrendamento  mercantil  reconhecidos  de  acordo  com a  NBC  TG 
06 – Operações de Arrendamento Mercantil; e 
(e) (...) 
 
14.  À  medida  que  a  entidade  toma  recursos  emprestados  sem  destinação  específica  e  os 
utiliza  com  o  propósito  de  obter  ativo  qualificável,  a  entidade  deve  determinar  o  montante  dos 
custos dos empréstimos elegíveis à capitalização, aplicando uma taxa de capitalização aos gastos 
com  o  ativo.  A  taxa  de  capitalização  deve  ser  a  média  ponderada  dos  custos  dos  empréstimos 
aplicáveis  a todos  os empréstimos  da  entidade  que  estiveram  vigentes  durante  o  período. No 
entanto,  a  entidade  deve  excluir  desse  cálculo  os  custos  de  empréstimos  aplicáveis aos 
empréstimos feitos especificamente com o propósito de obter um ativo qualificável até que todas 
as  atividades  necessárias  para  preparar  esse  ativo  para  uso  ou  venda  pretendidos  estejam 
completas. O montante dos custos de empréstimos, que a entidade capitalizar durante o período, 
não deve exceder o montante dos custos de empréstimos incorridos durante esse período. 
 
 
10.  Altera  o  item  5  na  NBC  TG 25 (R2) – Provisões,  Passivos  Contingentes  e  Ativos 
Contingentes, que passa a vigorar com a seguinte redação: 
 
5.  Quando  outra  norma tratar  de  um  tipo  específico  de  provisão  ou  de  passivo  ou  ativo 
contingente, a entidade deve aplicar essa norma em vez da presente norma. Por exemplo, certos 
tipos de provisões são tratados nas normas relativos a: 
(a) (...) 
(c) arrendamento  mercantil  (ver a  NBC  TG 06 – Operações  de  Arrendamento  Mercantil). No 
entanto,  esta  norma aplica-se  a  qualquer  arrendamento  que  se  torne  oneroso  antes  da  data  de 
início do arrendamento, conforme definido na NBC TG 06. Esta norma também deve ser aplicada 
a  arrendamentos de curto  prazo  e  arrendamentos  para  os  quais  o  ativo  subjacente  é  de  baixo 
valor, contabilizado de acordo com o item 6 da NBC TG 06, e que se tornaram onerosos; 
(d) (...) 
 
 
11.  Altera o item 123 na NBC TG 26 (R5) – Apresentação das Demonstrações Contábeis, 
que passa a vigorar com a seguinte redação: 
 
123. No  processo  de  aplicação  das  políticas  contábeis  da  entidade,  a  administração  exerce 
diversos julgamentos, além das que envolvem estimativas, que podem afetar, significativamente, 
os  montantes  reconhecidos  nas  demonstrações  contábeis.  Por  exemplo,  a  administração  exerce 
julgamento ao definir: 
(a) (...) 
(b)  quando substancialmente  todos os  riscos  e  benefícios  significativos da  propriedade  de 
ativos  financeiros  e,  para  arrendadores, os  ativos  sujeitos  a  arrendamento  são  transferidos  para 
outras entidades; 
(c) (...) 
 
 
12.  Altera  os  itens  5, 6, 10,  29  e  44,  exclui  os  itens  4  e  27  na  NBC  TG 27 (R4) – Ativo 
Imobilizado, que passam a vigorar com as seguintes redações: 
 
4.  Eliminado. 
 
5.  A   entidade   que   use   o   modelo   de   custo   para   propriedade   para   investimento, em 
conformidade com a NBC TG 28 – Propriedade para Investimento, deve utilizar o modelo de custo 
desta norma para propriedade para investimento próprio. 
 
6.    Os seguintes termos são usados nesta norma, com os significados especificados: 

6 
 
(...) 
Ativo imobilizado é o item tangível que: 
(a)  é mantido para uso na produção ou fornecimento de mercadorias ou serviços, para aluguel a 
outros, ou para fins administrativos; e 
(b) se espera utilizar por mais de um período. 
 
10.  A entidade deve avaliar, segundo esse princípio de reconhecimento, todos os seus custos 
com ativos  imobilizados  no  momento  em  que  eles  são  incorridos.  Esses  custos  incluem  custos 
incorridos  inicialmente  para  adquirir  ou  construir  item  do  ativo  imobilizado  e  os  custos  incorridos 
posteriormente  para  renová-lo,  substituir  suas  partes,  ou  dar  manutenção  a ele. O  custo  de  item 
de  imobilizado  pode  incluir  custos  incorridos, relativos  aos  contratos  de  arrendamento  de  ativo, 
que são usados para construir, adicionar a, substituir parte ou serviço a item do imobilizado, tais 
como a depreciação de ativo de direito de uso. 
 
27.  Eliminado. 
 
29.  Quando a opção pelo método de reavaliação for permitida por lei
(1)
, a entidade deve optar 
pelo  método  de  custo  do  item  30  ou  pelo  método  de  reavaliação  do  item  31  como  sua  política 
contábil e deve aplicar essa política a uma classe inteira de ativos imobilizados. 
(1)
 A reavaliação de bens tangíveis e intangíveis não é permitida devido às disposições contidas na 
Lei n.º 11.638/2007, que alterou a Lei n.º 6.404/1976. 
 
44.  A  entidade deve alocar o  valor  inicialmente  reconhecido  de  item  do  ativo  imobilizado  aos 
componentes  significativos  desse  item  e deve depreciá-los separadamente.  Por  exemplo,  pode 
ser adequado depreciar separadamente a estrutura e os motores de aeronave. De forma similar, 
se  o  arrendador  adquire  o  ativo  imobilizado  que  esteja  sujeito  a  arrendamento  mercantil 
operacional,  pode  ser  adequado  depreciar  separadamente  os  montantes  relativos  ao  custo 
daquele item que sejam atribuíveis a condições do contrato de arrendamento mercantil favoráveis 
ou desfavoráveis em relação a condições de mercado. 
 
 
13.  Altera os itens 5, 7, 8, 9, 30, 41, 50, 53, 53A, 54, 56, 60, 61, 62, 67, 74, 75, 77 e 78, inclui 
os itens 19A, 29A e 40A e exclui os itens 3, 6, 25, 26 e 34 na NBC TG 28 (R4) – Propriedade 
para Investimento, que passam a vigorar com as seguintes redações: 
 
3.  Eliminado. 
 
5.  Os termos que se seguem são usados nesta norma com os significados especificados: 
(...) 
Propriedade  para investimento é  a  propriedade  (terreno  ou  edifício – ou  parte  de  edifício – ou 
ambos) mantida (pelo proprietário ou pelo arrendatário como ativo de direito de uso) para auferir 
aluguel ou para valorização do capital ou para ambas e, não, para: 
(a) uso na produção ou fornecimento de bens ou serviços ou para finalidades administrativas; ou  
(b) venda no curso ordinário do negócio. 
 
Propriedade  ocupada  pelo  proprietário é  a  propriedade  mantida  (pelo  proprietário  ou  pelo 
arrendatário como  ativo  de  direito  de  uso)  para  uso  na  produção  ou  fornecimento  de  bens  ou 
serviços ou para finalidades administrativas. 
 
6.  Eliminado. 
 
7.  As  propriedades  para  investimento  são  mantidas  para  obter  rendas  ou  para  valorização  do 
capital  ou  para  ambas,  e  por  isso  classificadas  no  subgrupo  Investimentos,  dentro  do  Ativo  Não 
Circulante.   Por   isso,   a   propriedade   para   investimento   gera   fluxos   de   caixa   altamente 
independentes  dos  outros  ativos  mantidos  pela  entidade.  Isso  distingue  as  propriedades  para 
investimento  de  propriedades  ocupadas  pelos  proprietários.  A  produção  ou o fornecimento  de 

7 
 
bens ou serviços (ou o uso de propriedades para finalidades administrativas) gera fluxos de caixa 
que são atribuíveis não apenas às propriedades, mas também a outros ativos usados no processo 
de  produção  ou  de  fornecimento. A  NBC  TG 27 – Ativo  Imobilizado  aplica-se à propriedade 
própria ocupada  pelo  proprietário e a  NBC  TG 06  aplica-se à propriedade  ocupada  pelo 
proprietário mantida por arrendamento como ativo de direito de uso. 
 
8.  O que se segue são exemplos de propriedades para investimento: 
(a) (...) 
(c) edifício  que  seja  propriedade  da  entidade  (ou ativo  de  direito  de  uso  relativo  a  edifício 
mantido pela entidade) e que seja arrendado sob um ou mais arrendamentos operacionais; 
(d) (...) 
 
9.  Seguem-se  exemplos  de  itens  que  não  são  propriedades  para  investimento,  estando,  por 
isso, fora do alcance desta norma: 
(a) (...) 
(c) propriedade ocupada pelo proprietário (ver NBC TG 27 e NBC TG 06), incluindo (entre outras 
coisas)  propriedade  mantida  para  uso  futuro  como  propriedade  ocupada  pelo  proprietário, 
propriedade mantida para desenvolvimento futuro e uso subsequente como propriedade ocupada 
pelo  proprietário,  propriedade  ocupada  por  empregados  (paguem  ou  não  aluguéis  a taxas  de 
mercado) e propriedade ocupada pelo proprietário ao aguardo de alienação; 
(d) (...) 
 
19A. A propriedade para investimento mantida por arrendatário como ativo de direito de uso deve 
ser reconhecida de acordo com a NBC TG 06. 
 
25.  Eliminado.  
 
26.  Eliminado.  
 
29A. A propriedade para investimento mantida por arrendatário como ativo de direito de uso deve 
ser mensurada inicialmente ao custo de acordo com a NBC TG 06. 
 
30.  Com  as  exceções  indicadas  nos  itens  32A,  a  entidade  deve  escolher  como  sua  política 
contábil  o  método  do  valor  justo,  descrito nos  itens  33  a  55, ou  o  método  do  custo,  descrito no 
item 56, e deve aplicar essa política a todas as suas propriedades para investimento. 
 
34.  Eliminado.  
 
40A. Quando  o  arrendatário  utilizar o  modelo  de valor  justo  para  mensurar  a  propriedade  para 
investimento que é mantida como ativo de direito de uso, deve mensurar o ativo de direito de uso, 
e, não, a propriedade subjacente, ao valor justo. 
 
41.  A  NBC  TG 06 especifica  a  base  do  reconhecimento  inicial  do  custo  de  propriedade para 
investimento  mantida  por  arrendatário  como  ativo  de  direito  de  uso.  O  item  33  exige  que a 
propriedade  para  investimento  mantida  por  arrendatário  como  ativo  de  direito  de  uso seja 
remensurada,  se  necessário,  pelo  valor  justo, se a  entidade  escolher  o  modelo  de  valor  justo. 
Quando  os  pagamentos  de  arrendamento  são efetuados a  taxas  de  mercado,  o  valor  justo  da 
propriedade para investimento mantida por arrendatário como ativo de direito de uso na aquisição, 
líquido de todos os pagamentos de arrendamento esperados (incluindo os relativos a passivos de 
arrendamento reconhecidos),  deve  ser  zero.  Assim,  remensurar o  ativo  de  direito  de  uso  de 
arrendamento do custo, de acordo com a NBC TG 06, para o valor justo, de acordo com o item 33 
(tendo em conta os requisitos do item 50), não deve resultar em qualquer ganho ou perda inicial, a 
não ser que o valor justo seja mensurado em momentos diferentes. Isso pode ocorrer quando for 
feita a escolha para aplicar o método do valor justo após o reconhecimento inicial. 
 

8 
 
50.  Ao determinar o valor justo da propriedade para investimento, a entidade não deve computar 
duplamente  ativos  ou  passivos  que  estejam  reconhecidos  como  ativos  ou  passivos  separados. 
Por exemplo:  
(a) (...) 
(d) o  valor  justo  da  propriedade  para  investimento,  mantida por  arrendatário  como  ativo  de 
direito  de  uso,  reflete  os  fluxos  de  caixa  esperados  (incluindo os  pagamentos  variáveis  de 
arrendamento  que  se  espera  que  se  tornem  exigíveis).  Em  conformidade,  se  a  avaliação  obtida 
para  a  propriedade  for  líquida  de  todos  os  pagamentos  que  se  espera  que  sejam  feitos,  será 
necessário  voltar  a  adicionar qualquer  passivo  de  arrendamento reconhecido  para  atingir  o  valor 
contábil da propriedade para investimento, utilizando o método do valor justo. 
 
53.  Há  presunção  refutável  de  que  a  entidade  pode  confiavelmente  mensurar  o  valor  justo  de 
propriedade  para  investimento  em  base  contínua.  Porém,  em  casos  excepcionais,  quando  a 
entidade  adquire, pela  primeira  vez, a  propriedade  para  investimento  (ou  quando  a  propriedade 
existente se torne pela primeira vez propriedade para investimento na sequência da conclusão da 
construção ou do desenvolvimento, ou após a alteração de uso), há clara evidência de que o valor 
justo  da  propriedade  para  investimento  não é  mensurável  com  confiabilidade  em  base  contínua. 
Isso ocorre quando, e apenas quando, o mercado de propriedades comparáveis está inativo (por 
exemplo, há poucas transações recentes, preços cotados não são atuais ou preços de transação 
observados  indicam  que  o  vendedor  foi  forçado  a  vender)  e  quando  não  estão  disponíveis 
mensurações  alternativas  confiáveis  de  valor  justo  (por  exemplo,  com  base  em  projeções  de 
fluxos  de  caixa  descontados).  Se  a  entidade  concluir  que  o  valor  justo  de  propriedade  para 
investimento em construção não é mensurável com confiabilidade, mas for esperado que o valor 
justo  da  propriedade  seja  mensurável  com  confiabilidade  quando  a  construção  for  concluída,  a 
propriedade  para  investimento  em  construção  deve  ser  mensurada  ao  custo  até  que  seu  valor 
justo se torne confiavelmente mensurável ou a construção seja concluída (o que ocorrer primeiro). 
Se  a  entidade  concluir  que  o  valor  justo  de  propriedade  para  investimento  (outra  que  não  a 
propriedade para investimento em construção) não é confiavelmente mensurável, a entidade deve 
mensurar essa propriedade para investimento utilizando o método do custo da NBC TG 27 – Ativo 
Imobilizado  para  propriedade  para  investimento  própria  ou, de  acordo  com a  NBC  TG 06, para 
propriedade  para  investimento  mantida  por  arrendatário  como  ativo  de  direito  de  uso.  O  valor 
residual da propriedade para investimento deve ser assumido como sendo zero. A entidade deve 
continuar  a  aplicar a  NBC  TG 27  ou a  NBC  TG 06  até  a  alienação  da  propriedade  para 
investimento.  
 
53A.  Uma  vez  que  a  entidade  se  torne  capaz  de  mensurar  confiavelmente  o  valor  justo  de 
propriedade para investimento em construção que tenha sido previamente avaliada ao custo, deve 
mensurar  essa  propriedade  pelo  valor  justo.  Assim  que  a  construção  estiver  completada, 
presume-se  que  o  valor  justo  possa  ser  mensurado  confiavelmente.  Se  esse  não  for  o  caso,  de 
acordo com o item 53, a propriedade deve ser contabilizada pelo método do custo, de acordo com 
a  NBC  TG 27 – Ativo  Imobilizado, para  ativos  próprios,  ou com a  NBC  TG 06,  para  propriedade 
para investimento mantida por arrendatário como ativo de direito de uso. 
 
54.  Nos  casos  excepcionais  em  que  a  entidade  seja  compelida,  pela  razão  dada  no  item  53,  a 
mensurar  a  propriedade  para  investimento, utilizando o  método  do  custo  de  acordo  com a  NBC 
TG 27 ou com a  NBC  TG 06,  ela  deve  mensurar  todas  as  suas  outras  propriedades  para 
investimento pelo valor justo, inclusive as propriedades para investimento em construção. Nesses 
casos, embora a entidade possa usar o método do custo para uma propriedade para investimento, 
a entidade deve continuar a contabilizar cada uma das propriedades restantes usando o método 
do valor justo. 
 
56.  Após  o  reconhecimento  inicial,  a  entidade  que  escolher  o  modelo  do custo  deve  mensurar a 
propriedade para investimento: 
(a)  de  acordo  com a  NBC  TG 31 – Ativo  Não  Circulante  Mantido  para  Venda  e  Operação 
Descontinuada, se atender aos critérios para ser classificado como mantido para venda (ou está 
incluído em grupo para alienação que seja classificado como mantido para venda); 

9 
 
(b) de acordo com a NBC TG 06, se é mantido por arrendatário como ativo de direito de uso e não 
é mantido para venda, de acordo com a NBC TG 31; e 
(c) de acordo com os requisitos da NBC TG 27 para o modelo do custo em todos os outros casos. 
 
60.  Para  a  transferência  de  propriedade  para  investimento  contabilizada  pelo  valor  justo  para 
propriedade ocupada pelo proprietário ou para estoque, o custo considerado da propriedade para 
subsequente contabilização, de acordo com a NBC TG 27, a NBC TG 06 ou a NBC TG 16, deve 
ser o seu valor justo na data da alteração de uso. 
 
61.  Se  o  imóvel  ocupado  pelo  proprietário  se  tornar  propriedade  para  investimento  que  seja 
contabilizada pelo valor justo, a entidade deve aplicar a NBC TG 27 para propriedade própria e a 
NBC TG 06 para propriedade mantida por arrendatário como ativo de direito de uso até a data da 
alteração  do  uso. A  entidade  deve  tratar qualquer  diferença  nessa  data entre  o  valor  contábil  do 
imóvel, de acordo com a NBC TG 27 ou com a NBC TG 06 e o seu valor justo, conforme descrito 
no item 62. 
 
62.  Até a data em que o imóvel ocupado pelo proprietário se torne propriedade para investimento 
contabilizada  pelo  valor  justo,  a  entidade  deve  depreciar  a  propriedade (ou  o  ativo  de  direito  de 
uso) e deve  reconhecer quaisquer  perdas  por  redução  no  valor  recuperável  (impairment)  que 
tenham  ocorrido.  A  entidade deve tratar qualquer  diferença  nessa  data  entre  o  valor  contábil  da 
propriedade, de acordo com a NBC TG 27 ou a NBC TG 06, e o seu valor justo da seguinte forma: 
(a) (...)  
 
67.  A  alienação  de  propriedade  para  investimento  pode  ser  alcançada  pela  venda  ou  pela 
celebração  de  arrendamento  financeiro.  A  data  de  alienação  da  propriedade  para  investimento, 
que é vendida, é a data em que o recebedor obtém o controle da propriedade para investimento, 
de acordo com os requisitos da NBC TG 47, que determinam quando a obrigação de performance 
é  satisfeita. A  NBC  TG 06 é aplicável à  alienação  efetuada  pela  celebração  de  arrendamento 
financeiro e à venda e leaseback. 
 
74.  As  divulgações  indicadas  adiante são aplicáveis adicionalmente  às  enunciadas  na  NBC  TG 
06. De acordo com a NBC TG 06, o proprietário de propriedade para investimento proporciona as 
divulgações  dos  arrendadores  acerca  dos  arrendamentos  que  tenham  celebrado. O  arrendatário 
que detenha  propriedade  para  investimento como  ativo  de  direito de  uso proporciona  divulgação 
dos  arrendatários, como  requerido  pela  NBC  TG 06,  e  divulgação  dos  arrendadores, como 
requerido pela NBC TG 06, para qualquer arrendamento operacional que tenham celebrado. 
 
75.  A entidade deve divulgar: 
(a) (...) 
(b) eliminada; 
(c) (...)  
 
77.  Quando    a    avaliação    obtida    para    propriedade    para    investimento    é    ajustada, 
significativamente, para a finalidade das demonstrações contábeis, como, por exemplo, para evitar 
contagem   dupla   de   ativos   ou   passivos   que   sejam   reconhecidos   como   ativos   e   passivos 
separados, conforme  descrito  no  item  50,  a  entidade  deve  divulgar  a  conciliação  entre  a 
valorização  obtida  e  a  avaliação  ajustada incluída  nas  demonstrações  contábeis,  mostrando 
separadamente  a  quantia  agregada  de  quaisquer passivos de  arrendamento reconhecidos que 
tenham sido novamente adicionados, e qualquer outro ajuste significativo. 
 
78.  Nos  casos  excepcionais  referidos  no  item  53,  quando  a  entidade  mensurar  a  propriedade 
para investimento, usando o método do custo da NBC TG 27 ou de acordo com a NBC TG 06, a 
conciliação  exigida  pelo  item  76  deve  divulgar  as  quantias  relacionadas  com  essa  propriedade 
para  investimento  separadamente  das  quantias  relacionadas  com  outras  propriedades  para 
investimento. Além disso, a entidade deve divulgar: 
(a) (...) 
 

10 
 
 
14.  Altera o item 2 na NBC TG 29 (R2) – Ativo Biológico e Produto Agrícola, que passa a 
vigorar com a seguinte redação: 
 
2. Esta norma não é aplicável em: 
(a) (...) 
(d) ativos   intangíveis   relacionados   com   atividades   agrícolas   (ver NBC   TG 04 – Ativo 
Intangível);  
(e)  ativos  de  direito  de  uso  decorrentes  de  arrendamento  de  terrenos  relacionados  à  atividade 
agrícola (ver NBC TG 06 – Operações de Arrendamento Mercantil). 
 
 
15.  Altera  o  item  20  e  o  título  do exemplo  do item  52B,  exclui  o  item  52B,  exceto  o 
exemplo, e  inclui  o  item  57A  na  NBC  TG 32 (R4) – Tributos  sobre  o  Lucro,  que  passam  a 
vigorar com as seguintes redações: 
 
20.  As normas,  interpretações  e comunicados permitem  ou  exigem  que  determinados  ativos 
sejam  reconhecidos  contabilmente  ao  valor  justo  ou,  quando  permitido  legalmente,  sejam 
reavaliados  (consultar,  por  exemplo, a  NBC  TG 27 – Ativo  Imobilizado, a  NBC  TG 04 – Ativo 
Intangível, NBC TG 48 – Instrumentos Financeiros, a NBC TG 28 – Propriedade para Investimento 
e a NBC TG 06 – Operações de Arrendamento Mercantil). Em algumas jurisdições, a reavaliação 
ou  outra  remensuração  de  ativo  ao  valor  justo  afetam  o  lucro  tributável  (prejuízo  fiscal)  para  o 
período  atual.  Como  resultado,  a  base  fiscal  do  ativo deve  ser ajustada  e  não  surge  nenhuma 
diferença temporária. Em outras jurisdições, a reavaliação ou a remensuração de ativo não afeta o 
lucro tributável no período de reavaliação ou remensuração e, consequentemente, a base fiscal do 
ativo não deve ser ajustada. Entretanto, a recuperação futura do valor contábil resultará em fluxo 
tributável de benefícios econômicos para a entidade, e o valor, que será dedutível para fins fiscais, 
difere  do  valor  daqueles  benefícios  econômicos.  A  diferença  entre  o  valor  contábil  de  ativo 
reavaliado  e  sua  base  fiscal  é  uma  diferença  temporária  e  dá  margem  a  ativo  ou  passivo  fiscal 
diferido. Isso é verdadeiro mesmo se: 
(a) (...) 
 
52B. Eliminado.  
 
Exemplo ilustrativo dos itens 52A e 57A 
 
57A. A entidade deve reconhecer o efeito tributário sobre o rendimento dos dividendos, conforme 
definido na NBC TG 48, quando reconhecer o passivo para pagar o dividendo. O efeito tributário 
sobre  o  rendimento  dos  dividendos  está ligado  mais  diretamente  a  transações  ou a eventos 
passados  que   geraram   lucros   distribuíveis   do   que   às  distribuições   aos   proprietários.   Por 
conseguinte, a entidade deve reconhecer o efeito tributário sobre o rendimento dos dividendos no 
resultado, em outros  resultados  abrangentes  ou em instrumentos  patrimoniais  da  mesma  forma 
que a entidade originalmente reconheceu essas transações ou eventos passados. 
 
 
16.  Altera os itens 57, 99, 120, 123, 125, 126 e 156 e inclui os itens 101A, 122A e 123A na 
NBC  TG 33 (R2) – Benefícios  a  Empregados,  que  passam  a  vigorar  com  as  seguintes 
redações: 
 
57. A  contabilização  de  planos  de  benefício  definido  pela  entidade  envolve  os  seguintes 
passos: 
(...) 
(c) determinar os valores a serem reconhecidos no resultado: 
(i) custo do serviço corrente (ver itens 70 a 74 e 122A); 
(...) 
 

11 
 
99. Quando determinar  o  custo  do  serviço  passado  ou  o  ganho  ou  a  perda  na  liquidação,  a 
entidade  deve  remensurar  o  valor  líquido  de  passivo  (ativo)  de  benefício  definido, utilizando o 
valor  justo  dos  ativos  do  plano  e  as  premissas  atuariais  correntes  (incluindo  taxas  de  juros  de 
mercado e outros preços de mercado correntes) que reflitam: 
(a)  os  benefícios  oferecidos  em  conformidade  com  o  plano e  os  ativos  do  plano antes  da 
alteração, redução (encurtamento/curtailment) ou liquidação do plano; e 
(b) os benefícios oferecidos em conformidade com o plano e os ativos do plano após a alteração, 
redução ou liquidação do plano. 
 
101A.  Quando  ocorrer alteração,  redução  ou  liquidação  do  plano,  a  entidade  deve  reconhecer  e 
mensurar  o  custo  do  serviço  passado,  ou  o  ganho  ou  a  perda  na  liquidação,  de  acordo  com  os 
itens 99 a 101 e 102 a 112. Ao fazê-lo, a entidade não deve considerar o efeito do teto de ativos. 
A entidade deve então determinar o efeito do teto do ativo após a alteração, redução ou liquidação 
do plano e deve reconhecer qualquer alteração nesse efeito, de acordo com o item 57(d). 
 
 
120. A  entidade  deve  reconhecer  os  componentes  de  custo  de  benefício  definido,  exceto  na 
medida  em  que  outra  norma exigir  ou  permitir  a  sua  inclusão  no  custo  do ativo,  da  seguinte 
maneira: 
(a) custo do serviço (ver itens 66 a 112 e 122A) no resultado; 
(b) (...) 
 
122A.  A  entidade  deve  determinar  o  custo  do  serviço  atual utilizando as  premissas  atuariais 
determinadas  no  início  do  período  de  relatório  anual.  No  entanto,  se  a  entidade  remensurar  o 
passivo (ativo) líquido de benefício definido, de acordo com o item 99, ela deve determinar o custo 
do  serviço  atual  pelo  restante  do  período  de  relatório  anual  após  a  alteração,  redução  ou 
liquidação do plano, utilizando as premissas atuariais utilizadas para remensurar o passivo (ativo) 
líquido de benefício definido de acordo com o item 99(b). 
 
123. A  entidade  deve  determinar os  juros  líquidos  sobre  o  valor  líquido  de  passivo  (ativo)  de 
benefício definido, multiplicando o  valor  líquido  de passivo (ativo) de benefício definido pela taxa 
de desconto especificada no item 83.  
 
123A.  Para  determinar  os  juros  líquidos  de  acordo  com  o  item  123,  a  entidade  deve  utilizar  o 
passivo (ativo) líquido de benefício definido e a taxa de desconto determinada no início do período 
de  relatório  anual.  No  entanto,  se  a  entidade  remensurar  o  passivo  (ativo)  líquido  de  benefício 
definido, de acordo com o item 99, a entidade deve determinar os juros líquidos pelo restante do 
período de relatório anual após a alteração, redução ou liquidação do plano, utilizando: 
(a) o passivo (ativo) líquido de benefício definido determinado, de acordo com o item 99(b); e 
(b) a taxa de desconto utilizada para remensurar o passivo (ativo) líquido de benefício definido, de 
acordo com o item 99(b). 
Ao aplicar o item 123A, a entidade também deve levar em consideração quaisquer alterações no 
passivo  (ativo)  líquido  de  benefício  definido  durante  o  período  resultante  de  contribuições  ou de 
pagamentos de benefícios. 
 
125. A  receita  de  juros  sobre  ativos  do  plano  é  o  componente  de  retorno  sobre  os  ativos  do 
plano  e  deve  ser  determinada,  multiplicando-se  o  valor  justo  dos  ativos  do  plano  pela  taxa  de 
desconto especificada no item 123A. A entidade deve determinar o valor justo dos ativos do plano 
no  início  do  período  de  relatório  anual.  No  entanto,  se  a  entidade  remensurar  o  passivo  (ativo) 
líquido  de  benefício  definido,  de  acordo  com  o  item  99,  a  entidade  deve  determinar  a  receita  de 
juros pelo restante do período de relatório anual após a alteração, redução ou liquidação do plano, 
considerando os ativos do plano utilizados para remensurar o passivo (ativo) líquido de benefício 
definido,  de  acordo  com  o  item  99(b).  Ao  aplicar  o  item  125, a  entidade  também  deve  levar  em 
consideração  qualquer  alteração  nos  ativos  do  plano  mantidos  durante  o  período  resultante  de 
contribuições  ou de pagamentos  de  benefícios.  A  diferença  entre  a  receita  de  juros  sobre  ativos 
do plano e o retorno sobre ativos do plano deve ser incluída na remensuração do valor líquido de 
passivo (ativo) de benefício definido. 

12 
 
 
126. Os juros sobre o efeito do teto de ativo (asset ceiling) são parte da mudança total no efeito 
do  teto  de  ativo  (asset  ceiling)  e devem  ser determinados, multiplicando-se  o  efeito  do  teto  de 
ativo (asset ceiling) pela taxa de desconto especificada no item 123A. A entidade deve determinar 
o  efeito  do  teto  de  ativos  no  início  do  período  de  relatório  anual.  No  entanto,  se  a  entidade 
remensurar  o  passivo  (ativo)  líquido  de  benefício  definido,  de  acordo  com  o  item  99,  a  entidade 
deve determinar os juros sobre o efeito do teto do ativo pelo restante do período de relatório anual 
após a alteração, redução ou liquidação do plano, levando em conta qualquer alteração no efeito 
do  limite  de  ativos, determinado  de  acordo  com o  item  101A.  A  diferença  entre  os  juros  sobre  o 
efeito do teto de ativos e a mudança total no efeito do teto de ativo (asset ceiling) deve ser incluída 
na remensuração do valor líquido de passivo (ativo) de benefício definido. 
 
156. Para  outros  benefícios de longo  prazo  a  empregados,  a  entidade  deve  reconhecer  o 
montante  líquido  dos  seguintes  valores  no  resultado,  exceto  se  outra  norma exigir  ou  permitir  a 
inclusão no custo de ativo: 
(a) custo do serviço (ver itens 66 a 112 e 122A); 
(b) (...) 
 
 
17.  Altera os itens 30, B8D, B12, C4, D1, D7, D8B e D9, inclui os itens D9B a D9E e exclui 
o   item   D9A   na   NBC   TG 37   (R5) – Adoção   Inicial   das   Normas   Internacionais   de 
Contabilidade, que passam a vigorar com as seguintes redações: 
 
30.  Quando  a  entidade  fizer  uso,  nas  suas  demonstrações  contábeis  segundo  a  prática 
contábil  brasileira,  do  custo  atribuído  (deemed  cost), em conformidade com a  Interpretação 
Técnica ITG 10 – Interpretação sobre a Aplicação Inicial ao Ativo Imobilizado e à Propriedade para 
Investimento, deve utilizar tais valores em seu balanço patrimonial de abertura em IFRS para ativo 
imobilizado,  para  propriedade  para  investimento ou para  ativo  de  direito  de  uso (ver  itens  D5  e 
D7).  Devem  ser  evidenciadas,  para  cada  linha  no  balanço patrimonial  de  abertura  segundo  esta 
norma: 
(a) (...) 
 
B8D.  A  entidade  deve  aplicar  os  requisitos  referentes  à  redução  ao  valor  recuperável  na  Seção 
5.5 da IFRS 9 (NBC TG 48), retrospectivamente, sujeita ao disposto nos itens B8E a B8G. 
 
B12. Os  requisitos  e  orientações  dos  itens  B10  e  B11  não  impedem  a  entidade  de  utilizar  as 
exceções  descritas  nos  itens  D19  a D19C relativas  a  instrumentos  financeiros anteriormente 
reconhecidos ao valor justo por meio do resultado. 
 
C4.  Quando   a   adotante   pela   primeira   vez   não   aplicar   a   IFRS   3   (NBC   TG 15) 
retrospectivamente às combinações de negócios passadas, esse procedimento tem os seguintes 
efeitos para tais combinações de negócios: 
(a) (...) 
(f) Se  o  ativo  adquirido  ou  passivo  assumido  em  combinação  passada  não  tiver  sido 
reconhecido  pelos critérios  contábeis  anteriores, eles  não  terão  o  custo  atribuído  igual  a  zero  no 
balanço  patrimonial  de  abertura  em IFRS.  Em  vez  disso,  a  adquirente  deve  reconhecer  e 
mensurar  tais  itens  em  seu  balanço  patrimonial  consolidado  nas  mesmas  bases  que  as  IFRS 
exigiriam  para  o  balanço  patrimonial  da  adquirida.  Para  ilustrar:  se  a  adquirente  não  tiver 
capitalizado, em conformidade com os critérios contábeis anteriores, os arrendamentos mercantis 
adquiridos  em  combinação  de  negócios  passada em  que  a  adquirida  era  arrendatária,  a 
adquirente    deve    capitalizar    esses    arrendamentos    em    suas    demonstrações    contábeis 
consolidadas, tal como a IFRS 16 – Leases (NBC TG 06 – Operações de Arrendamento Mercantil) 
exigiria que  a  adquirida  fizesse  em  seu  balanço  patrimonial em  IFRS.  Da  mesma  forma,  se  a 
adquirente não tiver reconhecido o passivo contingente pelos critérios contábeis anteriores, o qual 
ainda  existe  na  data  de  transição  para  as  IFRS,  a  adquirente  deve  reconhecer  tal  passivo 
contingente  a  menos  que  a  IAS  37 – Provisions,  Contingent  Liabilities  and  Contingent  Assets 
(NBC  TG 25 – Provisões,  Passivos  Contingentes  e  Ativos  Contingentes)  não  permita  esse 

13 
 
reconhecimento nas demonstrações contábeis da adquirida. Inversamente, se o ativo ou o passivo 
foi  incluído  no  valor  do  ágio  por  expectativa  de  rentabilidade  futura  (goodwill)  pelos  critérios 
contábeis anteriores, mas que deveria ter sido reconhecido separadamente de acordo com a IFRS 
3  (NBC  TG 15),  tal  ativo  ou  passivo  deve  permanecer  incluído  no  ágio  por  expectativa  de 
rentabilidade  futura  (goodwill), a  menos  que  as  IFRS  exijam  que  ele  seja  reconhecido  nas 
demonstrações contábeis da adquirida. 
(g) (...) 
 
D1.  A entidade pode optar por uma ou mais das seguintes isenções: 
(a) (...) 
(d) arrendamento mercantil (itens D9 e D9B a D9E); 
(e) (...) 
 
D7.  A opção prevista no item D5 também está disponível para: 
(a) propriedades para investimento, se a entidade optar pelo uso do método de custo previsto 
na IAS 40 – Investment Property (NBC TG 28 – Propriedade para Investimento); 
(aa) ativo de direito de uso (NBC TG 06); e 
(b) (...) 
 
D8B. Algumas  entidades  detêm  itens  do  ativo  imobilizado, ativo  de  direito  de  uso ou  intangível 
que são utilizados, ou eram utilizados anteriormente, em operações sujeitas a tarifas reguladas. O 
valor contábil desses itens pode incluir valores que eram determinados de acordo com as práticas 
contábeis  anteriores, mas não  se  qualificam  para  capitalização  de  acordo  com  as IFRS.  Se  for 
esse o caso, a adotante pela primeira vez pode escolher utilizar o valor contábil de acordo com as 
práticas contábeis anteriores desse item na data de transição para as IFRS como custo atribuído. 
Se a entidade aplicar essa isenção a um item, ela não precisa aplicá-la a todos os itens. Na data 
de transição para as IFRS, a entidade deve testar cada item para o qual essa isenção é utilizada 
quanto à redução ao valor recuperável de acordo com a IAS 36 (NBC TG 01 – Redução ao Valor 
Recuperável  de  Ativos).  Para  as  finalidades  deste  item,  as  operações  estão  sujeitas  a  tarifas 
reguladas se fornecerem bens ou serviços a clientes a preços estabelecidos por órgão autorizado, 
qualificado para estabelecer tarifas que vinculam os clientes e que são destinadas a recuperar os 
custos  específicos incorridos  pela  entidade  ao  fornecer  os  bens  ou  serviços  regulados  e  para 
obter  retorno  específico.  O  retorno  específico  pode  ser  um  valor  mínimo  ou  uma  faixa  e  não 
precisa ser retorno fixo ou garantido. 
 
D9.  A adotante primeira vez pode avaliar se o contrato existente na data de transição para as 
IFRS contém arrendamento, aplicando os itens 9 a 11 da NBC TG 06 a esses contratos com base 
em fatos e circunstâncias existentes nessa data. 
 
D9A.  Eliminado.  
 
D9B.   Quando   a  adotante   pela  primeira  vez,   que   é  arrendatária,  reconhecer passivos  de 
arrendamento  e  ativos  de  direito  de  uso,  pode  aplicar  a  seguinte  abordagem  a  todos  os  seus 
contratos de arrendamento (sujeitos aos expedientes práticos descritos no item D9D): 
(a) mensurar o passivo de arrendamento na data de transição para as IFRS. O arrendatário que 
segue essa abordagem deve mensurar esse passivo de arrendamento ao valor presente do saldo 
de  arrendamento  remanescente  (ver  item  D9E),  descontado utilizando a  taxa  de  empréstimo 
incremental do arrendatário (ver item D9E) na data de transição para IFRS; 
(b)  mensurar  o  ativo  de  direito  de  uso  na  data  de  transição  para  as IFRS.  O  arrendatário  deve 
escolher, com base em arrendamento por arrendamento, para mensurar o ativo de direito de uso 
pelo: 
(i)  seu  valor  contábil  como  se a  NBC  TG 06  tivesse  sido  aplicado  desde  a  data  de  início  do 
arrendamento  (ver  item  D9E),  mas  descontado utilizando a  taxa  de  empréstimo  incremental  do 
arrendatário na data de transição para as IFRS; ou 
(ii)  valor  igual  ao  passivo  do  arrendamento,  ajustado  pelo  valor  de  quaisquer  pagamentos  de 
arrendamentos antecipados   ou   de arrendamentos   incorridos   a   pagar, relativos   a   esses 

14 
 
arrendamentos, reconhecidos  no  balanço  patrimonial  imediatamente  antes  da  data  de  transição 
para as IFRS; 
(c) aplicar a NBC TG 01 aos ativos de direito de uso na data da transição para as IFRS. 
 
D9C.  Não  obstante  os  requisitos  do  item  D9B, a  adotante  pela  primeira  vez, que  é  arrendatária, 
deve mensurar o ativo de direito de uso pelo valor justo na data de transição para as IFRS para 
arrendamentos que atendam à definição de propriedade para investimento na NBC TG 28 e são 
mensurados utilizando o modelo de valor justo na NBC TG 28 a partir da data de transição para as 
IFRS. 
 
D9D.  A  adotante  pela  primeira  vez, que  é  arrendatária, pode utilizar um  ou  mais  dos  seguintes 
itens na data de transição para as IFRS, aplicadas com base em arrendamento por arrendamento: 
(a)   aplicar   uma   única   taxa   de   desconto   à   carteira   de   arrendamento   com   características 
razoavelmente  similares  (por  exemplo, prazo de  arrendamento  restante  similar  para  uma  classe 
similar de ativos subjacentes em ambiente econômico similar); 
(b) optar por não aplicar os requisitos do item D9B aos arrendamentos para os quais o prazo de 
arrendamento (ver item D9E) termina dentro de 12 meses da data de transição para as IFRS. Em 
vez  disso,  a  entidade  deve  contabilizar  (incluindo  a  divulgação  de  informações  sobre) esses 
arrendamentos como  se  fossem  arrendamentos de curto  prazo  contabilizados  de  acordo  com  o 
item 6 da NBC TG 06; 
(c)  optar  por  não  aplicar  os  requisitos  do  item  D9B  aos  arrendamentos  para  os  quais  o  ativo 
subjacente é de baixo valor (conforme descrito nos itens B3 a B8 da NBC TG 06). Em vez disso, a 
entidade deve contabilizar (incluindo a divulgação de informações sobre) esses arrendamentos de 
acordo com o item 6 da NBC TG 06; 
(d)  excluir  os  custos  iniciais  diretos  (ver  item  D9E)  da  mensuração  do  ativo  de  direito  de  uso  na 
data da transição para as IFRS; 
(e) utilizar a percepção posterior, como na determinação do prazo do arrendamento, se o contrato 
contiver opções para estender ou encerrar o contrato de arrendamento. 
 
D9E. Pagamento de arrendamento, arrendatário, taxa de empréstimo incremental do arrendatário, 
data  de  início  do  arrendamento,  custos  iniciais  diretos  e  prazo  de  arrendamento  são  termos 
definidos na NBC TG 06 e devem ser utilizados nesta norma com o mesmo significado. 
 
 
18.  Altera  os  itens  AG9,  AG10  e  AG36  na  NBC  TG 39 (R5) – Instrumentos  Financeiros: 
Apresentação, que passam a vigorar com as seguintes redações: 
 
AG9. O  contrato  de  arrendamento  geralmente  cria  o direito  do  arrendador  de  receber,  e  a 
obrigação do arrendatário de pagar, um fluxo de pagamentos que são equivalentes à combinação 
de   principal   e   juros   em   contrato   de   financiamento.   O   arrendador deve contabilizar   seu 
investimento no valor a receber em arrendamento financeiro, em vez do próprio ativo subjacente 
que  está  sujeito  a  arrendamento  financeiro. Por  conseguinte,  o  arrendador  deve  considerar  o 
arrendamento  financeiro  como  instrumento  financeiro. Nos  termos  da  NBC  TG 06,  o  arrendador 
não  deve  reconhecer  seu  direito  a  receber  pagamentos  de  arrendamento  sob  contrato  de 
arrendamento operacional. O arrendador deve continuar a contabilizar o próprio ativo subjacente 
em  vez  de  qualquer  valor  a  receber no  futuro  no  âmbito  do  contrato.  Por  conseguinte,  o 
arrendador não deve considerar o arrendamento operacional como instrumento financeiro, exceto 
no que se refere aos recebimentos individuais correntes a receber e a pagar pelo arrendatário. 
 
AG10.  Ativos tangíveis (como estoques, instalações, terrenos e equipamentos), ativo de direito de 
uso e ativos  intangíveis  (como patentes e marcas) não são ativos financeiros. O controle de tais 
ativos tangíveis, ativos de direito de uso e ativos intangíveis criam a oportunidade de geração de 
caixa  ou  outro  ativo  financeiro,  mas  não  dão  direito  ao recebimento  de  outro  ativo  financeiro  ou 
caixa. 
 
AG36. As   ações   da   própria   entidade   não   devem   ser   reconhecidas   como   ativo   financeiro 
independentemente  da  razão  pela  qual  elas foram  adquiridas.  O  item  33  requer  que  a  entidade 

15 
 
que  adquira  suas  próprias  ações  deduza  esses  instrumentos patrimoniais do  patrimônio  líquido 
(ver também o item 33A). No entanto, quando a entidade mantém suas próprias ações em conta 
em nome de terceiros, como a instituição financeira que mantém suas próprias ações em nome do 
cliente, por exemplo, existe uma relação de agência e como resultado essas ações não devem ser 
incluídas no balanço patrimonial da entidade. 
 
 
19.  Altera   os   itens   29   e   B11D   na   NBC   TG 40   (R3) – Instrumentos   Financeiros: 
Evidenciação, que passam a vigorar com as seguintes redações: 
 
29. Divulgações de valor justo não são exigidas: 
(a) (...) 
(c)  para  contrato  que  contenha  característica  de  participação  discricionária  (como  descrito  na 
NBC  TG 11 – Contratos  de  Seguro)  se  o  valor  justo  dessa  característica  não  puder  ser 
mensurado de maneira confiável; ou 
(d)  para passivos de arrendamento. 
 
B11D. Os  montantes  contratuais  evidenciados  na  análise  de  vencimentos  requeridos pelo  item 
39(a) e (b) são os fluxos de caixa contratuais não descontados, por exemplo: 
(a) passivos brutos de arrendamento (antes de deduzir os encargos financeiros); 
(b) (...) 
 
 
20.  Altera   os   itens   97,   B66   e   B70 e  substitui  a  expressão  “obrigação(ões)  de 
desempenho” por “obrigação(ões)  de performance” na  NBC  TG 47 – Receita  de  Contrato 
com Cliente, que passam a vigorar com as seguintes redações: 
 
97. Os  custos  que  se  referem  diretamente  ao  contrato  (ou  ao  contrato  previsto  específico) 
incluem quaisquer dos seguintes: 
(a) (...) 
(c) alocações  de  custos  que  se  referem  diretamente  ao  contrato  ou  a  atividades  do  contrato 
(por  exemplo,  custos  de  gestão  e  supervisão  do  contrato,  seguro  e  depreciação  de ferramentas, 
equipamentos e ativo de direito de uso utilizados no desempenho do contrato); 
(d) (...) 
 
B66. Se  a  entidade  tiver  obrigação  ou  direito  de  recomprar  o  ativo  (opção  de  compra  ou  a 
termo),  o  cliente  não  obtém  o  controle  do  ativo  porque  está  limitado  em  sua  capacidade  de 
direcionar  o  uso  do  ativo  e  de  obter  praticamente  a  totalidade  dos  benefícios  remanescentes 
desse  ativo,  ainda  que  o  cliente  venha  a  ter  a  posse  física  do  ativo.  Consequentemente,  a 
entidade deve contabilizar o contrato de uma das seguintes formas: 
(a) arrendamento  mercantil  de  acordo  com a  NBC  TG 06,  caso  a  entidade  possa  ou  deva 
recomprar  o  ativo  por  valor  inferior  ao  preço  de  venda  original  do  ativo, a  menos  que  o  contrato 
faça  parte  de  transação  de  venda  e  retroarrendamento (leaseback).  Se  o  contrato  for  parte  de 
transação  de  venda  e  retroarrendamento (leaseback),  a  entidade  deve  continuar  a  reconhecer o 
ativo e deve reconhecer o passivo financeiro para qualquer contraprestação recebida do cliente. A 
entidade deve contabilizar o passivo financeiro de acordo com a NBC TG 48; ou 
(b) (...) 
 
B70. Se a entidade tiver a obrigação de recomprar o ativo a pedido do cliente (opção de venda) 
ao  preço  que  seja  inferior  ao  preço  de  venda  original  do  ativo,  a  entidade  deve  considerar,  no 
início  do  contrato,  se  o cliente  tem  incentivo  econômico  significativo  para  exercer  esse  direito. O 
exercício  desse  direito   pelo  cliente  resultará   no  fato   de   o   cliente, efetivamente, pagar  a 
contraprestação  à  entidade  pelo  direito  de  utilizar  o  ativo  específico  por  um  período  de  tempo. 
Portanto, se o cliente tiver incentivo econômico significativo para exercer esse direito, a entidade 
deve contabilizar o acordo como arrendamento mercantil de acordo com a NBC TG 06, a menos 
que o contrato faça parte de transação de venda e retroarrendamento (leaseback). Se o contrato 
for  parte  de  transação  de  venda  e  retroarrendamento (leaseback),  a  entidade  deve  continuar  a 

16 
 
reconhecer  o  ativo  e  deve  reconhecer  o  passivo  financeiro  para  qualquer  contraprestação 
recebida  do  cliente.  A  entidade  deve  contabilizar  o  passivo  financeiro  de  acordo  com a  NBC  TG 
48. 
 
 
21.  Altera  os  itens  2.1,  B4.1.11, B4.1.12 e  B4.3.8 e  inclui  os  itens  7.2.29  a  7.2.34 e  seu 
título, e B4.1.12A na  NBC  TG 48 – Instrumentos  Financeiros,  que  passam  a  vigorar 
com as seguintes redações: 
 
2.1 Esta  norma deve  ser  aplicada por  todas  as  entidades  a  todos  os  tipos  de  instrumentos 
financeiros, exceto: 
(a) (...) 
(b) direitos e obrigações previstos em arrendamentos aos quais deve ser aplicada a NBC TG 
06 – Operações de Arrendamento Mercantil. Entretanto: 
(i) os    recebíveis    de    arrendamento financeiro    (ou    seja,    investimentos    líquidos    em 
arrendamento financeiro) e recebíveis de arrendamento operacional reconhecidos por arrendador 
estão  sujeitos  aos  requisitos  de  desreconhecimento  e  de  redução  ao  valor  recuperável  desta 
norma; 
(ii) passivos  de  arrendamento  reconhecidos  por  arrendatário  estão  sujeitos  aos  requisitos  de 
desreconhecimento do item 3.3.1 desta norma; e 
(iii) derivativos  que  estão  embutidos  em  arrendamentos  estão  sujeitos  aos  requisitos  de 
derivativos embutidos desta norma; 
(c) (...) 
 
Transição para recursos de pagamento antecipado com compensação negativa 
 
7.2.29  A  entidade  deve  aplicar  a  inclusão  e  as  alterações  dos  itens  B4.1.11(b),  B4.1.12(b)  e 
B4.1.12A de forma retrospectiva de acordo com a NBC TG 23, exceto conforme especificado nos 
itens 7.2.30 a 7.2.34. 
 
7.2.30  A  entidade  que  aplicar pela  primeira  vez  essas  alterações  ao  mesmo  tempo  que  aplicar 
pela primeira vez esta norma deve utilizar o disposto nos itens 7.2.1 a 7.2.28 em vez do disposto 
nos itens 7.2.31 a 7.2.34. 
 
7.2.31 A entidade que aplicar pela primeira vez essas alterações, após a primeira aplicação desta 
norma, deve aplicar os itens 7.2.32 a 7.2.34. A entidade também deve aplicar os outros requisitos 
de  transição  desta  norma  necessários  para  a  aplicação  dessas  alterações.  Para  esse  propósito, 
as referências à data da aplicação inicial devem ser lidas como referentes ao início do período de 
relatório  em  que  a  entidade  aplicar pela  primeira  vez  essas  alterações  (data  de  aplicação  inicial 
dessas alterações). 
 
7.2.32 No que diz respeito à designação de ativo financeiro ou passivo financeiro mensurado ao 
valor justo por meio do resultado, a entidade: 
(a) deve revogar a designação anterior de ativo financeiro mensurado pelo valor justo por meio do 
resultado, se  essa  designação  tiver  sido  feita  anteriormente, de  acordo  com  a  condição  do  item 
4.1.5, mas essa condição não é mais satisfeita como resultado da aplicação dessas alterações; 
(b) pode designar o ativo financeiro conforme mensurado pelo valor justo por meio do resultado, 
se essa designação não tiver cumprido previamente a condição do item 4.1.5, mas essa condição 
está agora satisfeita como resultado da aplicação dessas alterações; 
(c)  deve  revogar  a  designação  anterior  de  passivo  financeiro mensurado  ao  valor  justo  por  meio 
do resultado, se essa designação tiver sido feita anteriormente, de acordo com o disposto no item 
4.2.2(a), mas essa condição não é mais satisfeita como resultado da aplicação dessas alterações; 
e 
(d)  pode  designar  o  passivo  financeiro  mensurado  ao  valor  justo  por meio  do resultado, se  essa 
designação  não  preencher  previamente  a  condição  no  item  4.2.2(a),  mas  essa  condição  está 
agora satisfeita como resultado da aplicação dessas alterações. 
 

17 
 
Essa designação e revogação devem ser feitas com base nos fatos e circunstâncias que existem 
na  data  da  aplicação  pela  primeira  vez  dessas  alterações.  Essa  classificação  deve  ser  aplicada 
retrospectivamente. 
 
7.2.33  A  entidade  não  é  obrigada  a  reapresentar  períodos  anteriores  para  refletir  a  aplicação 
dessas  alterações.  A  entidade  pode  reapresentar  períodos  anteriores  se,  e  somente  se, for 
possível  sem  o  uso  de percepção  posterior, e  as  demonstrações  contábeis  reapresentadas 
refletirem todos os requisitos desta norma. Se a entidade não reapresentar períodos anteriores, a 
entidade deve reconhecer qualquer diferença entre o valor contábil anterior e o  valor contábil no 
início do período de relatório anual – que inclui a data de aplicação inicial dessas alterações – em 
lucros  acumulados  retidos  (ou  outro  componente  do  patrimônio  líquido,  conforme  apropriado)  do 
período de relatório anual que inclui a data da aplicação inicial dessas alterações. 
 
7.2.34 No período de relatório que inclui a data da aplicação inicial dessas alterações, a entidade 
deve  divulgar  as  seguintes  informações na  data  da aplicação inicial  para  cada  classe  de  ativos 
financeiros e passivos financeiros que foram afetados por essas alterações: 
(a)  a  categoria  de  mensuração  anterior  e  o  valor  contábil  determinado  imediatamente  antes  de 
aplicar essas alterações; 
(b)  a  nova  categoria  de  mensuração  e  o  valor  contábil  determinado  após  a  aplicação  dessas 
alterações; 
(c) o valor contábil de quaisquer ativos financeiros e passivos financeiros no balanço patrimonial 
que anteriormente foram designados como mensurados ao valor justo por meio do resultado, mas 
não são mais assim designados; e 
(d)  os  motivos  de  qualquer  designação  ou  redesignação  de  ativos  financeiros  ou  passivos 
financeiros mensurados ao valor justo por meio do resultado. 
 
B4.1.11 Os exemplos a seguir são exemplos de termos contratuais que resultam em fluxos 
de caixa contratuais, que constituem exclusivamente pagamentos de principal e de juros sobre o 
valor do principal em aberto: 
(a) taxa  de  juros  variável, que  consiste em contraprestação  pelo  valor  do  dinheiro  no  tempo, 
pelo  risco  de  crédito  associado  ao  valor  do  principal  em  aberto  durante  período  de  tempo 
específico   (a   contraprestação   pelo   risco   de   crédito   pode   ser   determinada   somente   no 
reconhecimento  inicial,  e  então  pode  ser  fixada)  e  por  outros  custos  e  riscos  básicos de 
empréstimo, bem como pela margem de lucro; 
(b) termo  contratual  que  permite  ao  emitente  (ou  seja,  devedor)  pagar  antecipadamente  o 
instrumento de dívida ou que permite ao titular (ou seja, credor) revender o instrumento de dívida 
ao   emissor   antes   do   seu   vencimento   e   o   valor   do   pagamento   antecipado   representar, 
substancialmente, valores não pagos do principal ou de juros sobre o valor do principal em aberto, 
que podem incluir contraprestação razoável pela rescisão antecipada do contrato; e 
(c) termo  contratual  que  permite  ao  emitente  ou  ao  titular  prorrogar  o prazo contratual  do 
instrumento  de  dívida  (ou  seja,  opção  de  prorrogação)  e  os  termos  da  opção  de  prorrogação 
resultarem  em  fluxos  de  caixa  contratuais  durante  o  período  de  prorrogação,  que  constituam, 
exclusivamente, pagamentos  de  principal  e  de  juros  sobre  o  valor  do  principal  em  aberto,  que 
podem incluir contraprestação adicional razoável pela prorrogação do contrato. 
 
B4.1.12 Apesar  do disposto  no item  B4.1.10,  o  ativo  financeiro,  que,  também,  atenda  à 
condição  descrita  nos  itens  4.1.2(b)  e  4.1.2A(b),  mas  não  faz  isso  somente  como  resultado  do 
termo contratual que permite (ou exige) que o emitente pague antecipadamente o instrumento de 
dívida  ou  permite  (ou  exige)  que  o  titular  revenda  o  instrumento  de  dívida  ao  emitente  antes  do 
vencimento,  é  elegível  para  ser  mensurado  ao  custo  amortizado  ou  ao  valor  justo  por  meio  de 
outros  resultados  abrangentes  (sujeito  ao  cumprimento  da  condição  descrita  no  item  4.1.2(a)  ou 
da condição descrita no item 4.1.2A(a)) se: 
(a) a entidade adquirir ou conceder o ativo financeiro com ágio ou deságio em relação ao valor 
nominal contratual; 
(b) o valor do pagamento antecipado representar substancialmente o valor nominal contratual 
e  juros  contratuais  acumulados  (em  aberto),  que  podem  incluir  contraprestação  razoável  pela 
rescisão antecipada do contrato; e 

18 
 
(c) quando a entidade inicialmente reconhecer o ativo financeiro, o valor justo do elemento de 
pagamento antecipado for insignificante. 
 
B4.1.12A   Para   efeitos   de   aplicação   do disposto   nos   itens   B4.1.11(b)   e   B4.1.12(b), 
independentemente do evento ou circunstância que cause a rescisão antecipada do contrato, uma 
parte pode pagar ou receber compensação razoável pela rescisão antecipada. Por exemplo, uma 
parte  pode  pagar  ou  receber  compensação  razoável  quando  optar  por  rescindir  o  contrato 
antecipadamente (ou, de maneira diferente, por provocar a rescisão antecipada). 
 
B4.3.8 As  características  e  os  riscos  econômicos  do  derivativo  embutido  são  estreitamente 
relacionados às características e riscos econômicos do contrato principal, nos exemplos a seguir. 
Nesses  exemplos,  a  entidade  não  deve  contabilizar  o  derivativo  embutido  separadamente  do 
contrato principal. 
(a) (...) 
(f) O derivativo embutido em contrato de arrendamento principal está estreitamente relacionado 
ao  contrato  principal,  se  o  derivativo  embutido  for representado  por: (i)  índice  relacionado  à 
inflação, como, por exemplo, índice de pagamentos de arrendamento ao índice de preços ao 
consumidor (desde que o arrendamento não seja alavancado e o índice esteja relacionado à 
inflação   no   próprio   ambiente   econômico   da   entidade),   (ii)   pagamentos   variáveis   de 
arrendamento   baseados   nas   respectivas   vendas   ou   (iii)   pagamentos   variáveis   de 
arrendamento baseados em taxas de juros variáveis. 
(g) (...) 
 
 
22.  Altera  o  item  2  na  ITG 12 – Mudanças  em  Passivos  Financeiros,  Restauração  e 
Outros Passivos Similares, que passa a vigorar com a seguinte redação: 
 
2.  Esta interpretação  é  aplicável  às  mudanças  na  mensuração  de  qualquer  passivo  por 
desativação, restauração ou outro passivo similar que: 
(a) seja reconhecido como parte do custo de item do imobilizado, de acordo com a NBC TG 27 
– Ativo Imobilizado, ou como parte do custo de ativo de direito de uso de acordo com a NBC TG 
06; e 
(b) (...) 
 
 
Vigência 
 
Essas alterações entram em vigor na data de sua publicação, produzindo seus efeitos a partir de 
1º de janeiro de 2019. 
 
 
Brasília (DF), 18 de outubro de 2018. 
 
 
Contador Zulmir Ivânio Breda 
Presidente 
 
 
Ata CFC n.º 1.045.
