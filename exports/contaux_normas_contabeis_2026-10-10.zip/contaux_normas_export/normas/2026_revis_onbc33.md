# Aprova a Revisão NBC 33

- Código externo: 2026/revisãonbc33
- Fonte: CFC 2026/REVISÃONBC33 — DOU 17/04/2026
- URL fonte: https://www2.cfc.org.br/sisweb/sre/detalhes_sre.aspx?Codigo=2026/REVIS%C3%83ONBC33&arquivo=Revis%C3%A3o_NBC_33.docx
- Arquivo original: https://www1.cfc.org.br/sisweb/SRE/docs/Revis%c3%a3o_NBC_33.pdf
- Nome do arquivo: Revisão_NBC_33.pdf
- Tags: Contábil, NBC, Revisão NBC
- Atualizado em: 2026-10-10 14:27:59.388011+00

## Resumo

Aprova a Revisão NBC 33

## Texto integral extraído

NORMA BRASILEIRA DE CONTABILIDADE, REVISÃO NBC 33, DE 9 DE ABRIL DE 2026 
                                                                                                        
Aprova  a  Revisão  NBC  33,  que  altera  as 
seguintes normas: NBC TG 03 (R3), NBC TG 
12  (R1), NBC  TG  25  (R2),  NBC  TG  36  (R3), 
NBC TG 37 (R5), NBC TG 40 (R3), NBC TG 48 
e CTG 10.   
 
            O CONSELHO FEDERAL DE CONTABILIDADE, no exercício de suas atribuições legais e regimentais 
e com o fundamento no disposto na alínea f do art. 6º do Decreto-Lei nº 9.295, de 27 de maio de 1946, 
alterado pela Lei nº 12.249, de 11 de junho de 2010, faz saber que foi aprovada em seu Plenário a Revisão 
NBC   33, equivalente   a   Revisão   de   Pronunciamentos   Técnicos   n.º   29,   aprovada   pelo   Comitê   de 
Pronunciamentos Contábeis (CPC), que altera as Normas Brasileiras de Contabilidade (NBC): 
 
1. Inclui  o  item  44F  no  sumário  da  Norma e  o  item  65  e  altera  o  item  37  no NBC  TG 03  (R3) – 
Demonstração dos Fluxos de Caixa, que passam a vigorar com as seguintes redações: 
 
Sumário           Item 
[...] 
 
TRANSAÇÃO QUE NÃO ENVOLVE CAIXA OU EQUIVALENTES DE CAIXA   43 – 44 
ALTERAÇÃO DO PASSIVO DECORRENTE DE ATIVIDADE DE FINANCIAMENTO 44A – 44E 
ACORDOS DE FINANCIAMENTO DE FORNECEDORES     44F 
COMPOMNENTES DE CAIXA E EQUIVALENTES DE CAIXA     45 – 47 
[...] 
 
37 Quando  o  critério  contábil  de  investimento  em  coligada,  empreendimento  controlado  em 
conjunto  ou  controlada  basear-se  no  método  da  equivalência  patrimonial  ou  no método  de 
custo, a entidade investidora fica limitada a apresentar, na demonstração dos fluxos de caixa, os 
fluxos de caixa entre a própria entidade investidora e a entidade na qual participe (por exemplo, 
coligada, empreendimento controlado em conjunto ou controlada), representados, por exemplo, 
por dividendos e por adiantamentos. 
[...] 
 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
2 
 
65 A Revisão NBC nº 33, aprovada pelo CFC em 6 de fevereiro de 2026, alterou o item 37. A entidade 
deve aplicar estas alterações para o período anual de reporte iniciado em, ou após, 1º de janeiro 
de 2026. 
 
2. Altera os itens 1(b) e 7 do NBC TG 12 (R1) – Ajuste a Valor Presente, que passam a vigorar com 
as seguintes redações: 
 
1 O  objetivo  desta Norma é  esclarecer  os  requisitos  básicos  a  serem  observados  quando  da 
apuração do ajuste a valor presente de elementos do ativo e do passivo quando da elaboração 
de   demonstrações   contábeis,   dirimindo   algumas   questões   controversas   advindas   de   tal 
procedimento, do tipo: 
 [...] 
(b) em  que  situações  é  requerida  a adoção ado’ção do  ajuste  a  valor  presente  de  ativos  e 
passivos, se no momento de registro inicial de ativos e passivos, se na mudança da base de 
avaliação de ativos e passivos, ou se em ambos os momentos; 
 [...] 
 
7 É  necessário  observar  que  a  aplicação  do  conceito  de  ajuste  a  valor  presente  nem  sempre 
equipara  o  ativo  ou  o  passivo  a  seu  valor  justo. A  NBC  TG 46  disciplina  os  aspectos  a  serem 
considerados  na  mensuração  do  valor  justo  de  ativos  e  passivos,  incluindo  a  abordagem  de 
receita  como  uma  técnica  de  avaliação  na  qual  pode  se  aplicar  o  conceito  de  valor  presente. 
Quando a mensuração do valor presente for realizada como uma metodologia para mensuração 
de  valor  justo,  o NBC  TG  46 deve  ser  aplicado  em  sua  completude.  No entanto entando,  nas 
situações em que a mensuração do valor presente não seja aplicada como uma medida de valor 
justo  de  ativos  e  passivos  no  contexto  do NBC  TG  46 ou  que  a  mensuração  não  seja  de  outra 
forma disciplinada por outra Norma específico vigente, esta Norma Norma deve ser aplicada. 
 
3. Altera a numeração do exemplo 10A e elimina os exemplos 8 e 9 do Apêndice C do NBC TG 25 
(R2) – Provisões,  Passivos  Contingentes  e  Ativos  Contingentes,  que  passam  a  vigorar  com  as 
seguintes redações: 
 
Exemplo 8 – Contrato oneroso 
Uma   entidade   opera   de   maneira   lucrativa   em   uma   fábrica   arrendada   conforme   arrendamento 
operacional.  Durante  dezembro  de  20X0,  a  entidade  transfere  suas  operações  para  nova  fábrica.  O 
arrendamento da antiga fábrica ainda terá que ser pago por mais quatro anos, não pode ser cancelado e 
a fábrica não pode ser subarrendada para outro usuário. 
 
Obrigação  presente  como  resultado  de  evento  passado  que  gera  obrigação – O  evento  que  gera  a 
obrigação é a assinatura do contrato de arrendamento, que dá origem a uma obrigação legal. (A expressão 
“arrendamento mercantil” foi substituída em toda a norma por “arrendamento” pela Revisão NBC 04). 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
3 
 
 
Uma saída de recursos envolvendo benefícios futuros na liquidação – quando o arrendamento se torna 
oneroso, uma saída de recursos envolvendo benefícios econômicos é provável (até que o arrendamento 
se torne oneroso, a entidade contabiliza o arrendamento de acordo com o NBC TG 06.  
 
Conclusão – Uma  provisão  é  reconhecida  pela  melhor  estimativa  dos  pagamentos  inevitáveis  do 
arrendamento (ver itens 5(c), 14 e 66). 
 
Exemplo 9 – Garantia individual 
 
Em 31 de dezembro de 20X0, a Entidade A dá garantia a certos empréstimos da Entidade B, cuja condição 
financeira naquele momento é sólida. Durante 20X1, a condição financeira da Entidade B se deteriora, e 
em 30 de junho de 20X1 a Entidade B entra em processo de recuperação judicial. 
 
Esse contrato atende à definição de contrato de seguro de acordo com a NBC TG 11, mas está dentro do 
alcance  da  NBC  TG  38 – Instrumentos  Financeiros:  Reconhecimento  e  Mensuração,  porque  também 
atende à definição de contrato de garantia financeira da NBC TG 38. Se o emissor previamente declarou 
explicitamente que trata tais contratos como contratos de seguro e tem utilizado a contabilidade aplicável 
a  contratos  de  seguro,  o  emissor  pode  eleger  aplicar  tanto a NBC  TG  38 quanto a  NBC  TG 11  em  tais 
contratos  de  garantia. A  NBC  TG 11  permite  ao  emissor  continuar  com  as  suas  políticas  contábeis 
existentes  para  contratos  de  seguro  se  determinados  requisitos  mínimos  são  atendidos. A  NBC  TG 11 
também  permite  mudanças  em  políticas  contábeis  que  atendam  a  critérios  específicos.  O  exemplo  a 
seguir  ilustra  uma  política  contábil que a NBC  TG 11 permite e  também  está  em  conformidade  com  os 
requisitos da NBC TG 48 com relação aos contratos de garantia financeira dentro do alcance da NBC TG 
38. 
 
(a) Em 31 de dezembro de 20X0 
 
Obrigação  presente  como  resultado  de  evento  passado  que  gera  obrigação – O  evento  que  gera  a 
obrigação é a concessão da garantia, que dá origem a uma obrigação legal.  
 
Saída de recursos envolvendo benefícios futuros na liquidação – Nenhuma saída de benefícios é provável 
em 31 de dezembro de 20X0. 
 
Conclusão – A garantia é reconhecida pelo valor justo. 
 
(b) Em 31 de dezembro de 20X1 
Obrigação  presente  como  resultado  de  evento  passado  que  gera  obrigação – O  evento  que  gera  a 
obrigação é a concessão da garantia, que dá origem a uma obrigação legal. 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
4 
 
Uma  saída  de  recursos  envolvendo  benefícios  futuros  na  liquidação – Em  31  de  dezembro  de  20X1,  é 
provável  que  uma  saída  de  recursos  envolvendo  benefícios  econômicos  futuros  será  requerida  para 
liquidar a obrigação. 
 
Conclusão – A  garantia  é  posteriormente  mensurada  pelo  maior  dos  seguintes  valores:  (a)  a  melhor 
estimativa  da  obrigação  (ver  itens  14  e  23),  e  (b)  o  valor  inicialmente  reconhecido  menos,  quando 
apropriado, a amortização acumulada de acordo com a NBC TG 47 – Receita de Contrato com Cliente. 
 
Exemplo 10 10A – Caso judicial 
 
4. Inclui o item C1B e altera os itens 9, 25(b), 31, B74, B85L(c), B91 e B99A na NBC TG 36 (R2) – 
Demonstrações Consolidadas, que passam a vigorar com as seguintes redações: 
 
9 Dois ou mais investidores controlam coletivamente a investida quando devem agir em conjunto 
para  dirigir  as  atividades  relevantes.  Nesses  casos,  como  nenhum  investidor  pode  dirigir  as 
atividades  sem  a  cooperação  dos  demais,  nenhum  investidor  individualmente  controla  a 
investida.  Cada  investidor  deve  contabilizar  sua  participação  na  investida  de  acordo com  as 
normas, as interpretações e os comunicados técnicos do CFC relevantes, como, por exemplo, a 
NBC TG 19 – Negócios em Conjunto, NBC TG 18 – Investimento em Coligada, em Controlada e 
em  Empreendimento  Controlado  em  Conjunto  ou NBC  TG 4838 – Instrumentos  Financeiros: 
Reconhecimento e Mensuração. 
 [...] 
 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
5 
 
25 Se a controladora perder o controle da controlada, a controladora deve: 
 
(a)  desreconhecer os ativos e passivos da ex-controlada do balanço patrimonial consolidado; 
(b)  reconhecer    o    investimento    remanescente    na    ex-controlada,    se    houver,    e, 
subsequentemente, contabilizar esse investimento e quaisquer montantes a pagar ou a 
receber da ex-controlada, de acordo com as normas, as interpretações e os comunicados 
técnicos do CFC. Essa participação mantida deve ser remensurada, conforme descrito nos 
itens B98(b)(iii) e B99A. O valor remensurado no momento que esse controle é perdido 
deve ser considerado como o valor justo no reconhecimento inicial de ativo financeiro de 
acordo com a NBC TG 4838 – Instrumentos Financeiros: Reconhecimento e Mensuração 
ou,  quando  apropriado,  como  custo  no  reconhecimento  inicial  de  investimento  em 
coligada ou empreendimento controlado em conjunto, se for o caso; 
[...] 
 
31 Salvo  conforme  descrito  no  item  32,  a  entidade  de  investimento  não  deve  consolidar  as  suas 
controladas nem deve aplicar a NBC TG 15 (R4) quando obtiver o controle de outra entidade. Em 
vez disso, a entidade de investimento deve mensurar esse investimento em controlada ao valor 
justo por meio do resultado, de acordo com a NBC TG 4838. 
 
B74 Esse  relacionamento  não  precisa  envolver  um  acordo  contratual.  Uma  parte  é  agente  de  fato 
quando  o  investidor ou  aqueles  que  dirigem  as  atividades  do  investidor  possuem possui a 
capacidade de instruir essa parte a agir em nome do investidor. A parte pode ainda ser um agente 
de fato quando aqueles que dirigem as atividades do investidor tem a habilidade de dirigir aquela 
parte a atuar em nome do investidor. O Nessas circunstâncias, o investidor deve considerar os 
direitos de tomada de decisões de seu agente de fato e a sua exposição indireta a, ou direitos 
sobre, retornos variáveis por meio do agente de fato, juntamente com os seus próprios, ao avaliar 
o controle da investida. 
[...] 
 
B85L     A fim de satisfazer o requisito do item B85K(a), a entidade de investimento deve: 
 
(a)  optar  por  contabilizar  qualquer  propriedade  para  investimento  utilizando  o  método  do 
valor justo a que se refere a NBC TG 28 (R4) – Propriedade para Investimento; 
(b)  optar pela isenção da aplicação do método da equivalência patrimonial da NBC TG 18 (R4) 
para seus investimentos em coligadas e em empreendimentos controlados em conjunto; 
e 
(c)  mensurar seus ativos financeiros ao valor justo utilizando os requisitos da NBC TG 4838. 
 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
6 
 
B91 A NBC TG 4838 não se aplica a participações em controladas que sejam consolidadas. Quando 
instrumentos contendo direitos de voto potenciais, em essência, concedem atualmente acesso 
aos retornos associados à participação societária em controlada, esses instrumentos não estão 
sujeitos  aos  requisitos  da NBC  TG 4838.  Em  todos  os  outros  casos,  instrumentos  contendo 
direitos de voto potencial em controlada são contabilizados de acordo com a NBC TG 4838. 
 
B99A    Se a controladora perder o controle de controlada que não contém um negócio, tal como definido 
na  NBC  TG  15  (R4),  como  resultado  de  transação  envolvendo  coligada  ou  empreendimento 
controlado em conjunto que é contabilizado utilizando o método da equivalência patrimonial, a 
controladora deve contabilizar o ganho ou a perda de acordo com os itens B98 e B99. O ganho 
ou a  perda  resultante  da  operação  (incluindo  os  valores  previamente  reconhecidos  em  outros 
resultados abrangentes que seriam reclassificados para o resultado de acordo com o item B99) 
deve  ser  reconhecido  no  resultado  da  controladora  apenas  na  extensão  das  participações  dos 
investidores  não  relacionados  nessa  coligada  ou  empreendimento  controlado  em  conjunto.  A 
parte  restante  do  ganho  deve  ser  eliminada  contra  o  valor  contábil  do  investimento  nessa 
coligada  ou  empreendimento  controlado  em  conjunto.  Além  disso,  se  a  controladora  mantém 
investimento    na    antiga    controlada    e    essa    ex-controlada   é    agora    uma    coligada   ou 
empreendimento   controlado   em   conjunto   que   é   contabilizado   utilizando   o   método   da 
equivalência patrimonial, a controladora deve reconhecer parte do ganho ou da perda resultante 
da remensuração do valor justo do investimento mantido na ex-controlada no resultado apenas 
na   extensão   das   participações   dos   investidores   não   relacionados   na   nova   coligada   ou 
empreendimento  controlado  em  conjunto.  A  parte  restante  desse  ganho  ou  perda  deve  ser 
eliminada contra o valor contábil do investimento mantido na ex-controlada. Se a controladora 
mantém investimento na antiga controlada, que agora é contabilizado de acordo com a NBC TG 
4838, a parte do ganho ou da perda resultante da remensuração ao valor justo do investimento 
mantido na ex-controlada deve ser reconhecida integralmente no resultado da controladora. 
 
C1B A  Revisão  NBC  nº  33,  aprovada  pelo  CFC  em 6 de fevereiro de  2026,  alterou  o  item  B74. A 
entidade deve aplicar essas alterações para o período anual de reporte iniciado em, ou após, 1º 
de janeiro de 2026. 
 
5. Inclui  os itens  39AJ  e 39AK  e  altera  os  itens  B5  e  B6  na NBC  TG  37  (R5) – Adoção  Inicial  das 
Normas Internacionais de Contabilidade, que passam a vigorar com as seguintes redações: 
 
[...] 
39AK A Revisão NBC nº 33, aprovada pelo CFC em 6 de fevereiro de 2026, alterou os itens B5 e B6. A 
entidade deve aplicar essas alterações para o período anual de reporte iniciado em, ou após, 1º 
de janeiro de 2026. 
[...] 
 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
7 
 
B5 A entidade não deve incorporar em seu balanço patrimonial de abertura em IFRS a vinculação de 
proteção do tipo que não se qualifica como contabilidade de hedge (proteção) pela IFRS 9 (NBC 
TG 48) (por exemplo, vinculações de proteção em que o instrumento de hedge é a opção lançada 
separada ou a opção lançada líquida ou quando o hedge for a posição líquida em hedge de fluxo 
de caixa para outro risco que não o risco de moeda) (vide item 6.4.1(a) do NBC TG 48). Contudo, 
se a entidade designar a posição líquida como item de hedge (proteção) em conformidade com 
os  critérios  contábeis  anteriores,  ela  pode  designar  um  item  individual  dentro  dessa  posição 
líquida como hedge de acordo com as IFRS, ou a posição líquida se atender aos requisitos no item 
6.6.1 do NBC TG 48, contanto que ela faça isso até a data de transição para as IFRS.  
 
B6 Se, antes da data de transição para as IFRS, a entidade tiver designado a transação como hedge 
(proteção), porém esse hedge não atende aos critérios qualificáveis do item 6.4.1(b) e (c) da 
às  condições  previstas  na IFRS  9  (NBC  TG 48)  para  a  contabilidade  de  hedge  (proteção),  a 
entidade  deve  aplicar  o  disposto  nos  itens  6.5.6  e  6.5.7  da  IFRS  9  (NBC  TG 48)  para 
descontinuar tal contabilidade de hedge (proteção). Transações levadas a efeito antes da data 
de transição para as IFRS não devem ser designadas retrospectivamente como hedge. 
 
6. Inclui os itens 5B a 5D, 20B a 20D, 30A a 30C (incluindo o subtítulo antes do item 30A) e 44LL a 
44PP  e  altera  os  itens  11A,  11B  e  B38  na NBC  TG  40  (R3) – Instrumentos  Financeiros: 
Evidenciação, que passam a vigorar com as seguintes redações: 
 
5B O item 30A se aplica somente a contratos para adquirir energia elétrica que seja dependente 
da natureza e que satisfaçam aos requisitos do item 2.3A da NBC TG 48 e que estejam fora do 
escopo daquela Norma de acordo com os itens B2.7 e B2.8 da NBC TG 48. 
 
5C O item 30B se aplica somente a contratos que satisfaçam os requisitos do item 2.3A da NBC TG 
48 e que tenham sido designados para hedge de fluxo de caixa de acordo com o item 6.10.1 da 
NBC TG 48. 
 
5D O item 30C se aplica somente a contratos que satisfaçam os requisitos do item 2.3A da NBC TG 
48 e que tenham sido iniciados pela entidade em vistas de aquisição de energia elétrica. Esses 
contratos incluem aqueles que estão: 
 
(a) no escopo da NBC TG 48; e 
(b) fora do escopo da NBC TG 48 de acordo com o item 2.4 daquela Norma, incluindo aqueles 
excluídos pelos itens B2.7 e B2.8 daquela Norma. 
[...] 
 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
8 
 
11A Se   a   entidade   tiver   designado   investimentos   em   instrumentos   patrimoniais   para   serem 
mensurados ao valor justo por meio de outros resultados abrangentes, conforme permitido pelo 
item 5.7.5 da NBC TG 48, ela deve divulgar para cada classe de investimento: 
 
(a) que   investimentos   em   instrumentos   patrimoniais   foram   designados   para   serem 
mensurados ao valor justo por meio de outros resultados abrangentes; 
(b) as razões de utilizar essa alternativa de apresentação; 
(c) o valor justo de cada um desses investimentos ao fim do período de relatório; 
(d) os  dividendos  reconhecidos  durante  o  período,  apresentando  separadamente  aqueles 
relativos  a  investimentos  desreconhecidos  durante  o  período  de  relatório  e  aqueles 
relativos a investimentos mantidos ao fim do período de relatório; 
(e) quaisquer  transferências  de  ganho  ou  perda  acumulada  dentro  do  patrimônio  líquido 
durante o período, incluindo as razões dessas transferências; 
(f) o  ganho  ou  perda  na  mensuração  do  valor  justo  apresentada  em  outros  resultados 
abrangentes  durante  o  período,  demonstrando  separadamente  o  ganho  ou  perda  na 
mensuração do valor justo relacionado a investimentos desreconhecidos durante o período 
e o ganho ou perda na mensuração do valor justo relacionado a investimentos mantidos 
na data do balanço. 
 
11B Se a entidade tiver desreconhecido investimentos em instrumentos patrimoniais mensurados ao 
valor justo por meio de outros resultados abrangentes durante o período de relatório, ela deve 
divulgar: 
 
(a) as razões para a alienação dos investimentos; 
(b) o valor justo dos investimentos na data do desreconhecimento; 
(c) o ganho ou a perda acumulada na alienação.; 
(d) quaisquer  transferências  de  ganho  ou  perda  acumulada  dentro  do  patrimônio  líquido 
durante  o  período  relacionado  aos  investimentos  que  foram  desreconhecidos  durante  o 
período de reporte. 
[...] 
 
20B A entidade deve divulgar a informação requerida pelo item 20C por classe de ativos financeiros 
mensurados ao custo amortizado ou ao valor justo por meio de outros resultados abrangentes e 
por classe de passivos financeiros mensurados ao custo amortizado. A entidade deve avaliar o 
nível de detalhe a divulgar, o nível apropriado de agregação e desagregação e se os usuários das 
demonstrações   contábeis   necessitam   de   explicações   adicionais   para   analisar   quaisquer 
informações quantitativas divulgadas. 
 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
9 
 
20C Para permitir a compreensão pelos usuários das demonstrações contábeis dos efeitos de termos 
contratuais  que  possam  alterar  o  montante  dos  fluxos  de  caixa  contratuais  baseados  na 
ocorrência (ou não-ocorrência) de um evento contingente que não se relacione diretamente a 
mudanças em riscos e custos básicos de empréstimo (como o valor do dinheiro no tempo ou risco 
de crédito), a entidade deve divulgar: 
 
(a) uma descrição qualitativa da natureza do evento contingente; 
(b) informações  quantitativas  sobre  possíveis  alterações  nos  fluxos  de  caixa  contratuais  que 
poderiam  resultar  desses  termos  contratuais  (por  exemplo,  a  dispersão  (range)  de 
alterações possíveis); e 
(c) o valor contábil bruto dos ativos financeiros e o custo amortizado dos passivos financeiros 
sujeitos a esses termos contratuais. 
 
20D Por exemplo, a entidade deve divulgar a informação requerida pelo item 20C para uma classe de 
passivos financeiros mensurados ao custo amortizado para os quais os fluxos de caixa contratuais 
se alteram se a entidade alcança reduções em emissões de gases de efeito estufa. 
            [...] 
 
Contratos referenciados em energia elétrica dependente da natureza 
 
30A A  entidade  deve  divulgar  em  uma  única  nota  explicativa  em  suas  demonstrações  contábeis 
informações   sobre   contratos   que   cumpram   com   o   critério   estabelecido   no   item   5B. 
Especificamente,  a  entidade  deve  divulgar  informações  que  permitam  aos  usuários  das  suas 
demonstrações  contábeis  compreender  os  efeitos  que  estes  contratos  possuem  no  montante, 
momento  e  incerteza  de  seus  fluxos  de  caixa  futuros  e  no  seu  desempenho  financeiro.  Para 
alcançar esses objetivos a entidade deve divulgar: 
 
(a) informações sobre aspectos contratuais que exponham a entidade a: 
(i) variabilidade no montante subjacente de energia elétrica (vide item 2.3A da NBC TG 48); 
e 
(ii) o risco de que a entidade seja requerida a adquirir energia elétrica durante um intervalo 
de  tempo  no  qual  a  entidade  não  possa  utilizar  a  energia  elétrica  (vide  item  B2.7) da 
NBC TG 48 
(b) informação sobre compromissos não reconhecidos que surjam destes contratos na data do 
balanço, incluindo: 
(i) fluxos de caixa futuros estimados para a aquisição de energia elétrica destes contratos. 
A entidade deve aplicar julgamento na identificação do número apropriado de intervalos 
de tempo a ser utilizado na divulgação desses fluxos de caixa futuros estimados. e 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
10 
 
(ii) informação  qualitativa  sobre  como  a  entidade  avalia  se  um  contrato  pode  se  tornar 
oneroso (vide NBC TG 25 (R2) – Provisões, Passivos Contingentes e Ativos Contingentes), 
incluindo as premissas que a entidade utiliza ao realizar essa avaliação. 
(c) informações  qualitativas  e  quantitativas  sobre  os  efeitos  no  desempenho  financeiro  da 
entidade no período de reporte. A divulgação baseia-se na informação que é aplicável ao 
período  de  reporte  que  a  entidade  utilizou  para  avaliar  se  realizou  a  compra  líquida  de 
energia elétrica (vide item B2.8 da NBC TG 48). A entidade deve divulgar informações para 
o período de reporte sobre: 
(i) os  custos  oriundos da  aquisição de  energia  elétrica  a  partir  dos  contratos,  divulgando 
separadamente  quanto  da  energia  elétrica  adquirida  não  foi  utilizada  quando  de  sua 
entrega; 
(ii) os recebimentos oriundos da revenda da energia elétrica que não fora utilizada; e 
(iii) os  custos  oriundos  das  compras  de  energia  elétrica  realizadas  para  compensar  as 
revendas de energia elétrica não utilizada. 
 
30B A  entidade  deve  desagregar,  para  seus  contratos  que  cumpram  com os critérios estabelecidos 
no item 5C, a informação que divulga sobre termos e condições de instrumentos de hedge por 
categoria de risco. 
 
30C Se a  entidade  divulga  informação  sobre  outros  contratos  referenciados  em  energia  elétrica 
dependente da natureza conforme descrito no item 5D (incluindo aqueles contratos descritos no 
item 30B) em outras notas explicativas em suas demonstrações contábeis, a entidade deve incluir 
referências cruzadas para essas notas na nota explicativa única requerida pelo item 30A. 
            [...] 
 
44LL A Revisão NBC nº 33, aprovada pelo CFC em 6 de fevereiro de 2026, adicionou os itens 20B, 20C 
e 20D e alterou os itens 11A e 11B. A entidade deve aplicar essas alterações quando aplicar as 
alterações à NBC TG 48, de acordo com os itens 7.1.12 e 7.1.13 da NBC TG 48.  
 
44MM No período de reporte em que a entidade aplica pela primeira vez as alterações do item 44LL da 
Revisão NBC nº 33, a entidade não é requerida a divulgar a informação que seria de outra forma 
requerida pelo item 28(f) da NBC TG 23 (R2). 
 
44NN A Revisão NBC nº 33 alterou o item B38. A entidade deve aplicar estas alterações para o período 
anual de reporte iniciado em, ou após, 1º de janeiro de 2026. 
 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
11 
 
44OO A Revisão NBC nº 33, que também alterou a da NBC TG 48, adicionou os itens 5B a 5D, 30A a 30C 
e  44PP.  A  entidade  deve  aplicar  esses  itens  quando  aplicar  as  alterações à  NBC  TG  48.  Se  a 
entidade não reapresenta a informação comparativa quando aplicar inicialmente as alterações à 
NBC TG 48 de acordo com o item 7.2.51 daquela Norma, a entidade não deve divulgar informação 
comparativa para as divulgações requeridas pelos itens 30A a 30C. 
 
44PP No período de reporte que a entidade aplica pela primeira vez os itens descritos no item 44OO 
da Revisão NBC nº 33 a entidade não é requerida a divulgar a informação quantitativa que seria 
de outra forma requerida pelo item 28(f) da NBC TG 23 (R2). 
             [...] 
 
B38 O item 42G(a) requer que a entidade divulgue o ganho ou a perda no desreconhecimento dos 
ativos financeiros em que a entidade tiver envolvimento contínuo. A entidade deve divulgar se o 
ganho ou a perda no desreconhecimento ocorreu porque os valores justos dos componentes do 
ativo  anteriormente  reconhecido  (ou  seja,  os  juros  no  ativo  desreconhecido  e  os  juros  retidos 
pela  entidade)  eram  diferentes  do  valor  justo  do  ativo  anteriormente  reconhecido  como  um 
todo.  Nessa  situação,  a  entidade  também  deve  divulgar se  as  mensurações  do  valor  justo 
incluíram  dados  significativos não  observáveis que  não  eram  baseados  em  dados  de  mercado 
observáveis, conforme descrito nos itens 72 e 73 do NBC TG 46. item 27A. 
 
7. Inclui os itens 2.3A, 2.3B, 2.8, 6.10.1, 6.10.2, 7.1.12 a 7.1.15, 7.2.47 a 7.2.53, B2.7 e B2.8 e seu 
respectivo  subtítulo  (um  subtítulo  é  também  adicionado  antes  dos  itens  2.4  e  B3.1.2A), 
B3.1.2A,  B3.3.8  a  B3.3.10,  B4.1.8A,  B4.1.10A,  B4.1.16A  e  B4.1.20A  e altera  os  itens  2.1(b)(ii), 
2.6, 5.1.3, B4.1.10, B4.1.13, B4.1.14, B4.1.16, B4.1.17, B4.1.20, B4.1.21, B4.1.23, além do último 
item  do  apêndice  A na  NBC  TG  48 – Instrumentos  Financeiros,  que  passam  a  vigorar  com  as 
seguintes redações: 
 
2.1 Esta  Norma deve  ser  aplicado  por  todas  as  entidades  a  todos  os  tipos  de  instrumentos 
financeiros, exceto: 
[...] 
(b) direitos e obrigações previstos em arrendamentos aos quais deve ser aplicado a NBC TG 06 
(R3) – Arrendamentos. Entretanto: 
(i)  [...] 
(ii)  passivos de arrendamento reconhecidos por arrendatário estão sujeitos aos requisitos 
de desreconhecimento dos itens m 3.3.1 e 3.3.3 desta norma; e 
[...] 
 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
12 
 
2.3A Os  itens  6.10.1,  6.10.2,  B2.7  e  B2.8  se  aplicam  a  contratos  referenciados  em  energia  elétrica 
dependente da natureza. Contratos referenciados em energia elétrica dependente da natureza 
são contratos que expõem a entidade à variabilidade no montante subjacente de energia elétrica 
uma vez que a fonte da geração da energia elétrica é dependente de condições naturais que não 
podem  ser  controladas  (por  exemplo,  o  clima).  Contratos  referenciados  em  energia  elétrica 
dependente  da  natureza  incluem  tanto  contratos  de  compra  e  venda  de  energia  elétrica 
dependente da natureza quanto instrumentos financeiros que façam referência a esta energia 
elétrica. 
 
2.3B A entidade não deve aplicar os itens 6.10.1, 6.10.2, B2.7 e B2.8 por analogia a outros contratos, 
itens ou transações. 
 
Contratos para adquirir ou vender itens não financeiros 
[...] 
 
2.6 Há diversas formas em que um contrato para compra ou venda de item não financeiro pode ser 
liquidado  pelo  valor  líquido  à  vista  ou  por  outro  instrumento  financeiro  ou  pela  troca  de 
instrumentos financeiros. Essas formas incluem: 
   [...] 
O contrato, ao qual seja aplicada a alínea (b) ou (c) não é celebrado para fins de recebimento ou 
entrega de item não financeiro, de acordo com os requisitos de compra, venda ou uso esperados 
da  entidade  e,  consequentemente,  está  dentro  do  alcance desta  norma.  Outros  contratos (os 
quais  incluem  os  contratos  descritos  no  item  2.3A),  aos  quais  se  aplica  o  item  2.4,  devem  ser 
avaliados  para  determinar  se  foram  celebrados  e  continuam  a  ser  mantidos  para  fins  de 
recebimento ou entrega do item não financeiro, de acordo com os requisitos de compra, venda 
ou uso esperados da entidade e, consequentemente, se estão dentro do alcance desta norma. 
[...] 
 
2.8 A entidade deve aplicar os itens B2.7 e B2.8 para avaliar se contratos referenciados em energia 
elétrica dependente da natureza (conforme descrito no item 2.3A) são iniciados e mantidos com 
o propósito de recebimento da energia elétrica de acordo com os requisitos e perspectivas de 
uso da entidade. 
[...] 
 
5.1.3 Apesar do requisito no item 5.1.1, no reconhecimento inicial, a entidade deve mensurar contas 
a  receber  de  clientes pelo  montante  determinado  ao  aplicar  o ao  seu  preço  de  transação 
(conforme  definido na NBC  TG  47),  se  as  contas  a  receber  de  clientes  não  contiverem 
componente de financiamento significativo de acordo com a NBC TG 47 (ou quanto a entidade 
aplicar o expediente prático de acordo com o item 63 da NBC TG 47). 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
13 
 
  [...] 
 
6.10.1 Alguns  contratos  referenciados  em  energia  elétrica  dependente  da  natureza  são  designados 
como  instrumentos  de  hedge  em  hedges  de  transações  envolvendo  energia  elétrica  previstas. 
Em  adição  aos  requisitos  do  item  6.3.7,  para  tal  relação  de  proteção  é  permitido  à  entidade 
designar  como  item  objeto  de  hedge  um  valor  nominal  variável  de  transações  previstas 
envolvendo  energia  elétrica  que  esteja  alinhado  ao  montante  variável  de  energia  elétrica 
dependente  da  natureza  que  se  espera  ser  entregue  pela  geradora  da  energia  elétrica  como 
referenciado no instrumento de hedge. Os demais requisitos de contabilização de hedge deste 
capítulo continuam a se aplicar a tais relações de hedge. 
 
6.10.2 Se  os  fluxos  de  caixa  contratuais  referenciados  em  energia  elétrica  dependente  da  natureza 
designados  como  instrumentos  de  hedge  forem  condicionais  à  ocorrência  de  uma  transação 
prevista que é designada como item de hedge de acordo com o item 6.10.1, se presume que esta 
transação prevista é altamente provável como requerido pelo item 6.3.3. 
[...] 
 
 7.1.12 A Revisão NBC nº 33, aprovada pelo CFC em 6 de fevereiro de 2026, que alterou a NBC TG 48 e a 
NBC TG 40 (R3), adicionou os itens 7.2.47 a 7.2.49, B3.1.2A, B3.3.8 a B3.3.10, B4.1.8A, B4.1.8.10A, 
B4.1.16A  e  B4.1.20A.  Também  alterou  os  itens  B4.1.10,  B4.1.13,  B4.1.14,  B4.1.16,  B4.1.17, 
B4.1.20,  B4.1.21  e  B4.1.23.  A  entidade  deve  aplicar  essas  alterações  para  o  período  anual  de 
reporte iniciado em, ou após, 1º de janeiro de 2026. 
 
7.1.13 Não aplicável. 
 
7.1.14 A Revisão NBC nº 33 também alterou os itens 2.1(b)(ii), 5.1.3 e o Apêndice A. A entidade deve 
aplicar essas alterações para o período anual de reporte iniciado em, ou após, 1º de janeiro de 
2026. 
 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
14 
 
7.1.15 A Revisão NBC nº 33 também incluiu os itens 2.3A, 2.3B, 2.8, 6.10.1, 6.10.2, 7.2.51 a 7.2.53, B2.7 
e  B2.8  e  alterou  o  item  2.6.  A  entidade  deve  aplicar  essas  alterações  para  o  período  anual  de 
reporte iniciado em, ou após, 1º de janeiro de 2026. 
[...] 
 
7.2.47 A entidade deve aplicar as alterações oriundas da Revisão NBC nº 33, especificamente aqueles 
descritos  no  item  7.1.12,  retrospectivamente  de  acordo  com a NBC  TG  23  (R2),  exceto  pelo 
especificado nos itens 7.2.48 e 7.2.49. Para atender aos requisitos destes itens a data de adoção 
inicial refere-se ao início do período de reporte anual no qual a entidade aplica estas alterações 
inicialmente. 
 
7.2.48 A entidade não é requerida a reapresentar períodos anteriores para refletir a aplicação dessas 
alterações  descritas  no  item  7.2.47.  A  entidade  pode  reapresentar  períodos  anteriores  se,  e 
somente  se,  for  possível  fazê-lo  sem  o  uso  de  uma  percepção  posterior.  Se  a  entidade  não 
reapresentar períodos anteriores deve reconhecer os efeitos da adoção inicial dessas alterações 
como  um  ajuste  ao  saldo  de  abertura  dos  ativos  financeiros  e  passivos  financeiros  e  o  efeito 
acumulado,  se  houver,  como  um  ajuste  ao saldo  inicial  de  lucros  acumulados  (ou  outro 
componente do patrimônio líquido, caso apropriado) na data de adoção inicial. 
 
7.2.49 Na data de adoção inicial das alterações ao guia de aplicação no capítulo 4.1. desta norma Técnico 
(classificação  de  ativos  financeiros),  a  entidade  deve  divulgar  para  cada  classe  de  ativos 
financeiros  que  tenham  mudado  sua  categoria  de  mensuração  como  resultado  da  aplicação 
destas alterações: 
 
(a) a  categoria  de  mensuração  e  o  valor  contábil  determinado  imediatamente  antes  da 
aplicação dessas alterações; e 
(b) a categoria de mensuração e o valor contábil determinado imediatamente após a aplicação 
dessas alterações. 
 
7.2.50 A entidade deve aplicar as alterações oriundas da Revisão NBC nº 33 relacionadas a passivos de 
arrendamento  que  são  extintos  em  ou  após  o  início  do  período  anual  de  reporte  no  qual  a 
entidade adota essa alteração inicialmente. 
 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
15 
 
7.2.51 A entidade deve aplicar os itens 2.3A, 2.3B, B2.7 e B2.8 retrospectivamente de acordo com a NBC 
TG 23 (R2) utilizando fatos e circunstâncias na data de adoção inicial (a data na qual a entidade 
adota  inicialmente  essas  alterações).  A  data  de  adoção  inicial  deve  ser  o  início  do  período  de 
reporte, o qual pode ser um período de reporte que não seja anual. A entidade não é requerida 
a  reapresentar  períodos  anteriores  para  refletir  a  aplicação  destas  alterações.  A  entidade  é 
permitida a reapresentar períodos anteriores somente se for possível fazê-lo sem o uso de uma 
percepção  posterior.  Se  a  entidade  não  reapresentar  períodos  anteriores,  deve  reconhecer 
quaisquer diferenças entre o valor contábil anterior e o valor contábil na data da adoção inicial 
destas  alterações  na  abertura  de  lucros  acumulados  (ou  outro  componente  de  patrimônio 
líquido, se apropriado) no início daquele período de reporte. 
 
7.2.52 Se um contrato referenciado em energia elétrica dependente da natureza (como descrito no item 
2.3A) estiver fora do escopo da NBC TG 48 como resultado da aplicação dos requisitos dos itens 
B2.7 e B2.8, a entidade pode, na data de adoção inicial, irrevogavelmente designar esse contrato 
como mensurado ao valor justo por meio do resultado de acordo com o item 2.5. 
 
7.2.53 A  entidade  deve  aplicar  os  itens  6.10.1  e  6.10.2  prospectivamente  a  novas  relações  de  hedge 
designados  em  ou  após  a  data  de  adoção  inicial.  A  entidade  pode,  na  data  de  adoção  inicial, 
descontinuar  uma  relação  de  hedge  na  qual  um  contrato  referenciado  em  energia  elétrica 
dependente da natureza (como descrito no item 2.3A) tenha sido designado como instrumento 
de hedge se o mesmo instrumento de hedge for designado em uma nova relação de hedge de 
acordo com os itens 6.10.1 e 6.10.2. 
[...] 
 
Apêndice A – Definição de termos 
[...] 
Os seguintes termos são definidos no item 11 da NBC TG 39 (R5), no Apêndice A da NBC TG 40 (R3), ou no 
Apêndice A da NBC TG 46 ou no Apêndice A da NBC TG 47 e são utilizados nesta norma com os significados 
especificados na NBC TG 39 (R5), na NBC TG 40 (R3), ou na NBC TG 46 ou na NBC TG 47: 
 
(a) risco de crédito; 
(b) instrumento patrimonial; 
(c) valor justo; 
(d) ativo financeiro; 
(e) instrumento financeiro; 
(f) passivo financeiro; 
(g) preço de transação. 
[...] 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
16 
 
Contratos para aquisição de energia elétrica dependente da natureza 
 
B2.7 Alguns contratos referenciados em energia elétrica dependente da natureza (como descrito no 
item 2.3A) requerem que a entidade compre e aceite o recebimento da energia elétrica gerada. 
Esses  aspectos  contratuais  expõem  a  entidade  ao  risco  de  que  possa  ser requerido  comprar 
energia elétrica durante um intervalo no qual a entidade não pode utilizar a energia elétrica. A 
entidade pode também não ter a habilidade prática de evitar realizar a venda de energia elétrica 
não  utilizada  uma  vez  que  o  desenho  e  a  operação  do  mercado  onde  a  energia  elétrica  é 
transacionada pelo contrato requer que qualquer montante de energia elétrica não utilizada seja 
vendida em um determinado período de tempo. Quando a entidade aplica os requisitos do item 
2.4, essas vendas não são necessariamente inconsistentes com a visão de o contrato ser mantido 
de acordo com as expectativas de uso esperado pela entidade. A entidade iniciou e continua a 
manter o contrato de acordo com seu uso esperado da energia elétrica se a entidade tem sido, e 
espera ser, um comprador líquido de energia elétrica pelo período do contrato. A entidade é um 
comprador líquido de energia elétrica se adquire energia elétrica suficiente para compensar as 
vendas de qualquer volume de energia elétrica não utilizada no mesmo mercado em que vendeu 
a energia elétrica. 
 
B2.8 Na  determinação  se  a  entidade  é  um  comprador  líquido  de  energia  elétrica,  a  entidade  deve 
considerar informações razoáveis e suportáveis (que estejam disponíveis sem custo ou esforço 
excessivo)  sobre  suas  transações  de  energia  elétricas  passadas,  presentes  e  esperadas  para  o 
futuro por um período de tempo razoável. A entidade identifica “um período de tempo razoável” 
considerando  a  variabilidade  do  montante  de  energia  elétrica  que  espera  ser  gerada  no  ciclo 
sazonal das condições naturais e a variabilidade da demanda de energia elétrica da entidade para 
seu ciclo operacional. Ao determinar se a entidade tem sido um comprador líquido, “um período 
de tempo razoável” não deve exceder 12 meses. 
             [...] 
 
Data de reconhecimento inicial ou desreconhecimento 
 
B3.1.2ª Exceto quando  o  item  3.1.2  se  aplicar,  a  entidade  deve  reconhecer  um  ativo  financeiro  ou 
passivo  financeiro  na  data  na  qual  a  entidade  se  torna  parte  das  disposições  contratuais  do 
instrumento (vide item 3.1.1). Um ativo financeiro é desreconhecido na data em que os direitos 
contratuais aos fluxos de caixa do ativo financeiro expiram ou o ativo é transferido (vide item 
3.2.3).  Exceto  quando  a  entidade  elege  aplicar  o  item  B3.3.8,  um  passivo  financeiro  é 
desreconhecido na data de liquidação, que é a data na qual o passivo é extinto, uma vez que a 
obrigação  especificada  no  contrato  é  liquidada,  cancelada  ou  expira  (vide  item  3.3.1)  ou  o 
passivo de outra forma se qualifica para desreconhecimento. 
[...] 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
17 
 
B3.3.8 Independentemente  do  requisito  do  item  B3.1.2A  de  desreconhecer  um  passivo  financeiro  na 
data de liquidação, ao liquidar um passivo financeiro (ou parte dele) usando saldos de caixa por 
meio  de  um  sistema  de pagamentos eletrônico, a  entidade  é  permitida  a considerar  o  passivo 
financeiro (ou parte dele) liquidado antes da data de liquidação se, e somente se, a entidade tiver 
iniciado instruções de pagamento que resultem: 
 
(a) na entidade não possuir a habilidade prática de retirar, paralisar ou cancelar a instrução de 
pagamento; 
(b) na  entidade  não  possuir  a  habilidade  prática  de  acessar  o  caixa  a  ser  utilizado  para  a 
liquidação como resultado da instrução de pagamento; e 
(c) o risco de liquidação associado ao pagamento eletrônico ser avaliado como insignificante. 
 
B3.3.9 Para  os  fins  da  aplicação  do  item  B3.3.8(c),  o  risco  de  liquidação  associado  a  um  sistema  de 
pagamentos  eletrônico  é  insignificante  se  as  suas  características  estabelecem  que  a  conclusão 
das instruções de pagamento segue um processo administrativo padronizado e o período no qual 
os critérios descritos nos itens B3.3.8(a) e (b) são atendidos e o caixa é recebido pela contraparte 
é curto. No entanto, o risco de liquidação não é insignificante se a conclusão das instruções de 
pagamento estiver sujeita à capacidade da entidade de entregar o caixa na data de liquidação. 
 
B3.3.10 A entidade que eleger aplicar o item B3.3.8 para a liquidação de um passivo financeiro (ou parte 
dele)  utilizando  um  sistema  de  pagamentos  eletrônico  deve  aplicar  este  item  a  todas  as 
liquidações realizadas utilizando este mesmo sistema de pagamentos eletrônico. 
[...] 
 
B4.1.8ª Na avaliação se os fluxos de caixa contratuais de um ativo financeiro são consistentes com os 
de um acordo de empréstimo básico, a entidade deve considerar diferentes elementos de juros 
de maneira separada. A avaliação dos juros é focada no que a entidade é compensada, e não 
no  montante  da  compensação  a  ser  recebida  pela  entidade.  Apesar  disso,  o  montante  da 
compensação a ser recebida pela entidade pode indicar que a entidade está sendo compensada 
por algo em adição aos riscos e custos básicos de empréstimo. Fluxos de caixa contratuais são 
inconsistentes com um acordo de empréstimo básico se eles forem indexados a uma variável 
que não for um risco ou custo básico de empréstimo (por exemplo, o valor de um instrumento 
patrimonial ou o preço de uma commodity) ou que represente uma parcela da receita ou lucro 
do devedor, mesmo se tais termos contratuais foram comuns no mercado no qual a entidade 
opera. 
[...] 
 
B4.1.10 Se o ativo financeiro contém termo contratual que possa alterar a época ou o valor de fluxos de 
caixa contratuais (por exemplo, se o ativo pode ser pago antecipadamente antes do vencimento 
ou seu prazo pode ser prorrogado), a entidade deve determinar se os fluxos de caixa contratuais 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
18 
 
gerados  ao  longo  da  vida  do  instrumento  devido  a  esse  termo  contratual  são  exclusivamente 
pagamentos  de  principal  e  de  juros  sobre  o  valor  do  principal  em  aberto.  Para  fazer  essa 
determinação, a entidade deve avaliar os fluxos de caixa contratuais que seriam gerados tanto 
antes,  quanto  depois,  da  alteração  nos  fluxos  de  caixa  contratuais, independentemente  da 
probabilidade de ocorrência de alterações nos fluxos de caixa contratuais. A entidade também 
pode  precisar  avaliar  a  natureza  de  qualquer  evento  contingente  (ou  seja,  acionador)  que 
modifique  a  época  ou  o  valor  dos  fluxos  de  caixa  contratuais.  Embora  a  natureza  do  evento 
contingente  em  si  não  seja  fator determinante  ao  avaliar  se  os  fluxos de  caixa  contratuais  são 
exclusivamente  pagamentos  de  principal e  de  juros,  ela  pode  ser  um  indicador.  Por  exemplo, 
comparar  um  instrumento  financeiro  que  possui  a  taxa  de  juros  reajustada  pela  taxa  mais 
elevada,  se  o  devedor  não  efetuar  um  número  específico  de  pagamentos  com  o  instrumento 
financeiro que possui a taxa de juros reajustada pela taxa mais elevada, se um índice específico 
do patrimônio líquido atingir determinado nível. É mais provável, no primeiro caso, que os fluxos 
de  caixa  contratuais  ao  longo  da  vida  do  instrumento  sejam  exclusivamente  pagamentos  de 
principal e de juros sobre o valor do principal em aberto devido à relação entre pagamentos não 
efetuados e o aumento no risco de crédito. No caso anterior, a natureza do evento contingente 
se  relaciona  diretamente  às,  e  a  alteração  dos  fluxos  de  caixa  contratuais  se  altera  na  mesma 
direção às, mudanças em riscos e custos básicos de empréstimo (ver também o item B4.1.18). 
 
B4.1.10A Em alguns casos, uma característica contingente origina fluxos de caixa contratuais que são 
consistentes com um acordo de empréstimo básico tanto antes quando depois das mudanças 
nos fluxos de caixa contratuais, mas a natureza do evento contingente em si não se relaciona 
diretamente a mudanças nos riscos e custos básicos de empréstimo. Por exemplo, a taxa de 
juros aplicada a um empréstimo pode ser ajustada em um montante específico se o devedor 
atingir uma meta de redução de emissões de carbono especificada no contrato. Nestes casos, 
ao aplicar o item B4.1.10, o ativo financeiro possui fluxos de caixa contratuais que constituem 
exclusivamente pagamentos de principal e juros sobre o montante principal em aberto se, e 
somente  se,  em  todos  os  cenários possíveis  de  acordo  com  o  contrato,  os  fluxos  de  caixa 
contratuais não seriam significativamente diferentes dos fluxos de caixa contratuais em um 
instrumento  financeiro  com  termos  contratuais  idênticos,  mas  que  não  possuem  esta 
característica contingente. Em algumas circunstâncias, a entidade pode ser capaz de realizar 
esta determinação ao efetuar uma avaliação qualitativa. Em outras circunstâncias, pode ser 
necessário realizar uma avaliação quantitativa. Caso esteja claro, com pouca ou sem qualquer 
análise, que os fluxos de caixa contratuais não são significativamente diferentes, a entidade 
não é requerida a realizar uma avaliação detalhada. 
[...] 
 
B4.1.13 Os  exemplos  a  seguir  ilustram  fluxos  de  caixa  contratuais  que  constituem  exclusivamente 
pagamentos de principal e de juros sobre o valor do principal em aberto. A lista de exemplos não 
é exaustiva. 
 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
19 
 
Instrumento Análise 
[...] 
 
Instrumento EA 
 
O    instrumento    EA    é    um 
empréstimo    com    taxa    de 
juros  que  é  ajustada  a  cada 
período  de  reporte  por  um 
número  fixo  de  pontos-base 
caso   o   devedor   atinja   no 
período  de  reporte  anterior 
uma  redução  específica  em 
suas   emissões   de   carbono, 
definida contratualmente. 
 
Os ajustes máximos 
acumulados não podem 
alterar de maneira 
significativa a taxa de juros do 
empréstimo. 
 
 
Os  fluxos  de  caixa  contratuais  constituem  exclusivamente 
pagamentos de principal e juros sobre o montante principal 
em  aberto.  A  entidade  considera  se  os  fluxos  de  caixa 
contratuais que podem surgir tanto antes quanto depois de 
cada  alteração  nos  fluxos  de caixa  contratuais  constituem 
exclusivamente  pagamentos  de  principal  e  juros  (vide  item 
B4.1.10). 
 
Se  o  evento  contingente  de  atingir  a  meta  de  emissões  de 
carbono ocorrer, a taxa de juros é ajustada por um número 
fixo    de    pontos-base,   resultando    em    fluxos    de    caixa 
contratuais  que  são  consistentes  com  os  de  um  acordo  de 
empréstimo  básico.  É  somente  por  conta  da  natureza  do 
evento contingente em si não se relacionar diretamente com 
as alterações nos riscos e custos básicos de empréstimo que 
a entidade não pode concluir – sem análises adicionais – se 
os   fluxos   de   caixa   dos   ativos   financeiros   constituem 
exclusivamente pagamentos de principal e juros. 
 
A entidade então avalia se, em todos os cenários possíveis de 
acordo  com  o  contrato,  os  fluxos  de  caixa  contratuais  não 
seriam  significativamente  diferentes  dos  fluxos  de  caixa 
contratuais de um ativo financeiros com termos contratuais 
idênticos, mas sem a característica contingente associada às 
emissões de carbono (vide item B4.1.10A). 
 
Uma    vez   que    quaisquer    ajustes    durante   a    vida   do 
instrumento não resultariam em fluxos de caixa contratuais 
que seriam significativamente diferentes, a entidade conclui 
que  o  empréstimo  possui  fluxos  de  caixa  contratuais  que 
constituem exclusivamente pagamentos de principal e juros 
sobre o valor do principal em aberto. 
 
B4.1.14 Os exemplos a seguir ilustram fluxos de caixa contratuais que não consistem exclusivamente, em 
pagamentos de principal e de juros sobre o valor do principal em aberto. A lista de exemplos não 
é exaustiva. 
 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
20 
 
Instrumento Análise 
[...] 
 
Instrumento I 
 
O  Instrumento  I  é  um  empréstimo 
com taxa de juros que é ajustada a 
cada    período    de    reporte    para 
acompanhar os movimentos de um 
indexador  de  mercado  relacionado 
ao   preço   do   carbono   durante   o 
período de reporte anterior. 
 
 
Os    fluxos    de    caixa    contratuais    não    constituem 
exclusivamente pagamentos de principal e juros sobre o 
valor do principal em aberto.  
 
Os  fluxos  de  caixa  contratuais  são  indexados  a  uma 
variável  (o  índice  de  preço  de  carbono)  que  não  é  um 
risco ou custo básico de empréstimo. Os fluxos de caixa 
contratuais  são,  desta  forma,  inconsistentes  com  um 
acordo de empréstimo básico (vide item B4.1.8A). 
[...] 
 
B4.1.16 Esse pode ser o caso se o ativo financeiro representar um investimento em ativos ou fluxos de 
caixa  específicos  e,  assim,  os  fluxos  de  caixa  contratuais  não  constituírem  exclusivamente 
pagamentos  de  principal  e  de  juros  sobre  o  valor  do  principal  em  aberto.  Por  exemplo,  se  os 
termos contratuais estipularem que os fluxos de caixa do ativo financeiro aumentam, conforme 
mais veículos utilizarem uma rodovia específica com pedágio, esses fluxos de caixa contratuais 
são  inconsistentes  com  o  acordo  de  empréstimo  básico.  Como  resultado,  o  instrumento  não 
atende  à  condição  descrita  nos  itens  4.1.2(b)  e  4.1.2A(b). Esse  pode  ser  o  caso  quando  a 
pretensão do credor estiver limitada a ativos específicos do devedor ou aos fluxos de caixa de 
ativos específicos (por exemplo, ativo financeiro na modalidade “non recourse”). 
 
B4.1.16ª A situação descrita no item B4.1.15 pode ainda surgir se um ativo financeiro for da modalidade 
“non recourse”. Um ativo financeiro é da modalidade “non recourse” se o direito da entidade 
de  receber  fluxos  de  caixa  está  contratualmente  limitado  aos  fluxos  de  caixa  gerados  por 
ativos  especificados.  Em  outras  palavras,  a  entidade  é  exposta  principalmente  ao  risco  de 
desempenho dos ativos especificados e não ao risco de crédito do devedor. Por exemplo, o 
direito  de  um  credor  de  receber  fluxos  de  caixa  pode  estar  contratualmente  limitado  aos 
fluxos de caixa gerados por ativos especificados de uma entidade estruturada. 
 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
21 
 
B4.1.17 Contudo, o fato de que o ativo financeiro é da modalidade “non recourse” não necessariamente 
impede por si só que esse ativo atenda à condição descrita nos itens 4.1.2(b) e 4.1.2A(b). Nessas 
situações, o credor deve avaliar (“olhar além”) a conexão entre os ativos subjacentes ou fluxos 
de caixa específicos e os fluxos de caixa contratuais do ativo financeiro a ser classificado para 
determinar  se  esses  os  fluxos  de  caixa  contratuais  do  ativo  financeiro,  que  está  sendo 
classificado,  constituem  pagamentos  de  principal  e  de  juros  sobre  o  valor  do  principal  em 
aberto.  A  entidade  deve  ainda  considerar  como  essa  conexão  é  afetada  por  outros  arranjos 
contratuais, como dívida subordinada ou instrumentos patrimoniais emitidos pelo devedor. Se 
os termos do ativo financeiro derem origem a quaisquer outros fluxos de caixa ou limitarem os 
fluxos  de  caixa  de  forma  inconsistente  com  os  pagamentos  de  principal  e  juros,  o  ativo 
financeiro  não  atende  à  condição  descrita  nos  itens  4.1.2(b)  e  4.1.2A(b).  O  fato  de  os  ativos 
subjacentes  serem  ativos  financeiros  ou  ativos  não  financeiros  por  si  só  não  afeta  esta 
avaliação. 
[...] 
 
B4.1.20 Em  alguns  tipos  de  transações na modalidade “non  recourse”, o  emitente  pode  priorizar 
pagamentos    aos    titulares    de    ativos    financeiros,    utilizando    múltiplos    instrumentos 
contratualmente vinculados que podem criar concentrações de risco de crédito (tranches). Cada 
tranche tem uma classificação de subordinação que especifica a ordem em que quaisquer fluxos 
de  caixa  gerados  pelo  emitente  a  partir  do  conjunto  subjacente dos  instrumentos  financeiros 
devem ser alocados à tranche. A priorização dos pagamentos aos detentores destas tranches é 
estabelecida  por  meio  de  uma  estrutura  de  pagamentos  em  cascata  (waterfall)  que  cria 
concentrações de risco de crédito e resulta em uma alocação desproporcional de déficits de caixa 
do conjunto subjacente entre as tranches. Nessas situações, os titulares da tranche têm direito a 
pagamentos de principal e de juros sobre o valor do principal em aberto somente se o emitente 
gerar fluxos de caixa suficientes para atender a tranches de classificação mais alta. Nesses tipos 
de transações, os detentores de uma tranche aplicam os itens B4.1.21 a B4.1.26 em vez do item 
B4.1.17. 
 
B4.1.20A Algumas  transações  que  podem  conter  múltiplos  instrumentos  de  dívida e  aparentar ter  as 
mesmas características descritas no item B4.1.20 são, de fato, acordos de empréstimos que 
são estruturados para prover melhorias na proteção ao crédito para um credor (ou grupo de 
credores).  Por  exemplo,  uma  entidade  estruturada  pode  ser  estabelecida  para  manter  os 
ativos  subjacentes  que  irão  gerar  fluxos  de  caixa  para  realizar  o  pagamento  ao  credor.  A 
entidade estruturada emite instrumentos de dívida júnior e sênior. O credor mantém os títulos 
de dívida sênior e a entidade patrocinadora da entidade estruturada que mantém os títulos 
de dívida júnior não possui a habilidade prática de vender o instrumento júnior sem tornar a 
liquidação  do  instrumento  de  dívida  sênior  exigível.  Os  detentores  destes  instrumentos  de 
dívida aplicam os itens B4.1.7 q B4.1.19 ao invés dos itens B4.1.21 a B4.1.26. 
 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
22 
 
B4.1.21 Nessas Em transações que  contêm  instrumentos  contratualmente  vinculados,  como  as 
descritas no item B4.1.20, a tranche possui características de fluxo de caixa que constituem 
pagamentos de principal e de juros sobre o valor do principal em aberto somente se: 
     [...] 
 
B4.1.23 O  conjunto  subjacente  deve  conter  um  ou  mais  instrumentos  que  tenham  fluxos  de  caixa 
contratuais, que constituam exclusivamente pagamentos de principal e de juros sobre o valor 
do  principal  em  aberto. Para  fins  desta  avaliação,  o  conjunto  subjacente  pode  incluir 
instrumentos  financeiros  que  não  estejam  no  escopo  dos  requisitos  de  classificação  (vide 
seção  4.1)  mas  que  possuam  fluxos  de  caixa  contratuais  que  constituam  exclusivamente 
pagamento  de principal e  juros  sobre o  valor  do principal  em  aberto – por  exemplo,  alguns 
recebíveis de arrendamento. No entanto, recebíveis de arrendamento que estejam sujeitos a 
risco  de  valor  residual  ou  que  compreendam  pagamentos  variáveis  de  arrendamento  que 
estejam indexados a uma variável que não sejam riscos ou custos básicos de empréstimo (por 
exemplo,  uma  taxa  de  aluguel  de  mercado),  não  possuem  fluxos  de  caixa  contratuais  que 
sejam exclusivamente pagamentos de principal e juros sobre o valor do principal em aberto. 
 
8. Altera  os  itens  5,  7  do CTG  10 – Créditos  de  Carbono  (Tco2e),  Permissões  de  Emissão 
(Allowances)  e  Crédito  de  Descarbonização  (CBIO),  que  passam  a  vigorar  com  as  seguintes 
redações: 
 
5 Em função da ausência de tratamento contábil específico para o tema nas Normas Contábeis IFRS 
normas  internacionais  de  relatórios  financeiros (IFRS  Accounting  Standards), este  Comitê 
embasou   este   Comunicado   em   normas,   interpretações   e   comunicados já   existentes   no 
arcabouço  contábil  brasileiro  e  nas  normas  internacionais  de  contabilidade,  em  linha  com  a 
estrutura conceitual para relatórios financeiros, para definição dos tratamentos aqui dispostos. 
 [...] 
 
7 Esta Orientação trata dos critérios contábeis de reconhecimento, mensuração e evidenciação dos 
eventos  econômicos  relacionados  à  participação  ou  atuação  de  entidades  em  mercados 
compulsórios   ou   voluntários   de   créditos   de   carbono   (tCO2e)   (comumente   chamados de 
mercados de créditos de carbono), permissões Permissões de emissão (allowances) e créditos de 
descarbonização  (CBIO).  Tais  eventos  econômicos  estão  comumente  ligados  à  originação, 
negociação  ou  aposentadoria  desses  ativos,  bem  como  situações  que  possam dar  origem  a 
eventuais  passivos  associados  à  participação  de  entidades  nesses  mercados,  decorrentes  de 
obrigações  legais  ou  não  formalizadas.  Os  requerimentos  desta  Orientação  foram  elaborados 
tomando como base a dinâmica, estrutura e funcionamento do mercado de créditos de carbono 
(tCO2e),  permissões  de  emissão  (allowances)  e  créditos  de  descarbonização  (CBIO).  Contudo, 
conforme previsto no item 11(a) da NBC TG 23 (R2), tais requerimentos devem ser consultados 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
23 
 
e  podem  ser  considerados  como  referência  na  contabilização  de  outros  tipos  de  créditos 
ambientais, quer sejam em mercado voluntário ou compulsório (quando instituído), desde que a 
substância econômica dos eventos relacionados sejam similares aos aqui descritos. 
 
Esta  Revisão  entra  em  vigor  na  data  de  sua  publicação,  devendo-se  as  alterações  para  os  exercícios 
iniciados em, ou após, 1º de janeiro de 2026. 
 
          Brasília, 9 de abril de 2026. 
 
 
CONTADOR JOAQUIM DE ALENCAR BEZERRA FILHO 
Presidente 
 
Ata CFC nº 1.131/2026
