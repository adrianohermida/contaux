# Aprova a Revisão NBC 06

- Código externo: 2020/revisaonbc06
- Fonte: CFC 2020/REVISAONBC06 — DOU 29/04/2020
- URL fonte: https://www2.cfc.org.br/sisweb/sre/detalhes_sre.aspx?Codigo=2020/REVISAONBC06&arquivo=REVISAONBC06.doc
- Arquivo original: https://www1.cfc.org.br/sisweb/SRE/docs/REVISAONBC06.pdf
- Nome do arquivo: REVISAONBC06.pdf
- Tags: Contábil, NBC, Revisão NBC
- Atualizado em: 2026-10-10 14:27:54.285673+00

## Resumo

Aprova a Revisão NBC 06

## Texto integral extraído

NORMA BRASILEIRA DE CONTABILIDADE, REVISÃO NBC 06, DE 19 DE MARÇO DE 2020 
 
Aprova   a   Revisão   NBC   06,   que   altera   as 
seguintes  normas:  NBC  TG  38(R3),  NBC  TG 
40(R3) e NBC TG 48. 
 
O CONSELHO FEDERAL DE CONTABILIDADE, no exercício de suas atribuições legais 
e regimentais  e  com  fundamento  no  disposto  na  alínea  “f”  do  Art.  6º  do  Decreto-Lei  n.º 
9.295/1946,  alterado  pela  Lei  n.º  12.249/2010,  faz  saber  que  foi  aprovada  em  seu  Plenário  a 
Revisão NBC 06, que altera as seguintes normas: 
 
1. Inclui os itens de 6.8.1 a 6.8.12 e 7.1.8, e seus títulos, e altera o item 7.2.26 na NBC TG 
48 – Instrumentos Financeiros, que passam a vigorar com as seguintes redações: 
 
Capítulo 6 – Contabilização de hedge  
 
6.8  Exceções  temporárias  da  aplicação  de  requisitos  específicos  de  contabilização 
de hedge 
 
6.8.1 A  entidade  deve  aplicar  os  itens  de  6.8.4  a  6.8.12,  7.1.8  e  7.2.26(d)  a  todas  as 
relações  de  proteção  diretamente  afetadas  pela  reforma  da  taxa  de  juros  de referência. 
Esses  itens  se  aplicam  apenas  a  essas  relações  de  proteção.  A  relação  de  proteção  é 
diretamente  afetada  pela  reforma  da  taxa  de  juros  de  referência  somente  se  a  reforma 
suscitar incertezas sobre: 
(a)  a  taxa  de  juros  de  referência  (especificada contratualmente  ou  não)  designada 
como risco protegido de hedge; e/ou 
(b)  o período ou o valor dos fluxos de caixa baseados na taxa de juros de referência do 
item objeto de hedge ou do instrumento de hedge. 
 
6.8.2 Para  fins  de  aplicação  dos  itens  de  6.8.4 a 6.8.12, o termo “reforma da taxa de 
juros de referência” refere-se  à reforma  de  todo  o  mercado  de  referência  de  taxa  de  juros, 
incluindo a substituição da taxa de juros de referência por taxa de referência alternativa, tal 
como resultante das recomendações estabelecidas no relatório do Financial Stability Board’s 
(Conselho  de  Estabilidade  Financeira), de julho de 2014, ”Reforma das principais taxas de 
juros de referência”. 
 
6.8.3 Os itens de 6.8.4 a 6.8.12 fornecem exceções apenas aos requisitos especificados 
nesses itens. A entidade deve continuar a aplicar todos os outros requisitos de contabilidade 
de hedge às  relações  de proteção diretamente  afetadas  pela  reforma  da  taxa  de  juros  de 
referência. 
 
Requisito altamente provável para hedge de fluxo de caixa 
 
6.8.4 Com o objetivo de determinar se uma transação prevista (ou um componente dela) 
é altamente provável, conforme requerido no item 6.3.3, a entidade deve assumir que a taxa 
de juros de referência, na qual os fluxos de caixa protegidos (especificados contratualmente 
ou  não)  são  baseados,  não  é  alterada  como  resultado  da  reforma  da  taxa  de  juros  de 
referência. 
 
Reclassificação do valor acumulado na reserva de hedge de fluxo de caixa 
 
6.8.5 Para fins de aplicação do requisito no item 6.5.12, a fim de determinar se os fluxos 
de  caixa  futuros  protegidos  irão  ocorrer,  a  entidade  deve  assumir  que  a  taxa  de  juros  de 
referência, na qual os fluxos de caixa protegidos (especificado contratualmente ou não) são 
baseados, não é alterada como resultado da reforma da taxa de juros de referência. 
 
Avaliação da relação econômica entre o item protegido e o instrumento de hedge 

 
 
 
6.8.6  Para  fins  de  aplicação  dos  requisitos  dos  itens  6.4.1(c)(i)  e  de  B6.4.4  a  B6.4.6,  a 
entidade deve assumir que a taxa de juros de referência na qual o fluxo de caixa protegido 
e/ou  o  risco de hedge (especificado  contratualmente  ou  não)  são baseados,  ou  a  taxa  de 
juros de referência no qual se baseiam os fluxos de caixa do  instrumento de hedge, não é 
alterada como resultado da reforma da taxa de juros de referência. 
 
Designação de componente de item como item protegido 
 
6.8.7  A menos que o item 6.8.8 seja aplicável para hedge de componente de referência 
não  contratualmente  especificado  do  risco  de  taxa  de  juros,  a  entidade  deve aplicar  o 
requisito  nos  itens  6.3.7(a)  e  B6.3.8 – que  o  componente  de  risco  seja  identificável 
separadamente – somente no início da relação de proteção. 
 
6.8.8  Quando  a  entidade,  consistente  com  sua  documentação  de hedge,  frequentemente 
redefine (ou seja, descontinua e reinicia) a relação de proteção, porque tanto o instrumento 
de hedge quanto o item de hedge são alterados com frequência (ou seja, a entidade utiliza 
um processo dinâmico no qual os itens de hedge e os instrumentos de hedge utilizados para 
gerenciar essa exposição não permanecem os mesmos por muito tempo), a entidade deve 
aplicar o requisito dos itens 6.3.7(a) e B6.3.8 – que o componente de risco seja identificável 
separadamente – somente  quando  designar  inicialmente  um  item protegido  nessa  relação 
de  proteção.  O  item  protegido  que  foi  avaliado  no  momento  de  sua  designação  inicial  na 
relação  de  proteção,  se era  no momento  do  início  do hedge ou, subsequentemente,  não é 
reavaliado em nenhuma redesignação subsequente na mesma relação de proteção. 
 
Fim da aplicação 
 
6.8.9  A  entidade  deve  cessar, prospectivamente, a  aplicação  do  item  6.8.4  ao  item 
protegido no que primeiro ocorrer: 
(a)  quando  a  incerteza  decorrente  da  reforma  da  taxa  de  juros  de  referência  não 
estiver mais presente no momento e no valor dos fluxos de caixa baseados na taxa de juros 
de referência do item protegido; e 
(b)  quando a relação de proteção do qual o item protegido faz parte for descontinuado. 
 
6.8.10 A  entidade  deve  cessar, prospectivamente, a  aplicação  do  item  6.8.5,  no  que 
primeiro ocorrer: 
(a)  quando  a  incerteza  decorrente  da  reforma  da  taxa  de  juros  de  referência  não 
estiver mais presente no momento e no valor dos fluxos de caixa futuros baseados na taxa 
de juros de referência do item protegido; e 
(b)  quando o valor total acumulado na reserva de hedge de fluxo de caixa referente a 
essa relação de proteção descontinuada for reclassificado para o resultado. 
 
6.8.11 A entidade deve cessar, prospectivamente, de aplicar o item 6.8.6: 
(a)  ao  item  protegido,  quando  a  incerteza  decorrente  da  reforma  da  taxa  de  juros  de 
referência  não  estiver  mais  presente  em  relação  ao  risco  protegido  ou  ao  momento  e  ao 
valor dos fluxos de caixa baseados na taxa de juros de referência do item protegido; e 
(b)  ao  instrumento  de hedge,  quando  a  incerteza  decorrente  da  reforma  da  taxa  de 
juros de referência não estiver mais presente no que diz respeito ao momento e ao valor dos 
fluxos de caixa baseados na taxa de juros de referência do instrumento de hedge. 
Se a relação de proteção da qual o item protegido e o instrumento de hedge fizerem parte 
for descontinuada antes da data especificada no item 6.8.11(a) ou da data especificada no 
item  6.8.11(b),  a  entidade  deve  cessar, prospectivamente, de  aplicar  o  item  6.8.6  àquela 
relação de proteção na data de descontinuação. 
 
6.8.12 Ao designar um grupo de itens como item protegido por hedge, ou uma combinação 
de instrumentos financeiros como instrumento de hedge, a entidade deve deixar de aplicar, 
prospectivamente,  os  itens  de  6.8.4  a  6.8.6  ao  item  individualmente  ou  ao  instrumento 

 
 
financeiro,  de  acordo  com  os  itens  6.8.9,  6.8.10  ou  6.8.11,  conforme  o  caso,  quando  a 
incerteza  decorrente  da  reforma  da  taxa  de  juros  de  referência  não  estiver  mais  presente 
com relação ao risco protegido e/ou ao momento e ao valor dos fluxos de caixa baseado na 
taxa de juros de referência daquele item ou instrumento financeiro. 
 
Capítulo 7 - Data de vigência e transição 
 
7.1 Data de vigência 
 
7.1.8 A Reforma da Taxa de Juros de Referência alterou a NBC TG 48, a NBC TG 38 e a 
NBC  TG 40,  adicionou  a  Seção  6.8  e  alterou  o  item  7.2.26.  A  vigência  dessas  alterações 
será  estabelecida  pelos  órgãos  reguladores  que  o  aprovarem,  sendo  que, para  o  pleno 
atendimento  às  normas  internacionais  de  contabilidade, a  entidade  deve  aplicar  essas 
alterações nos períodos anuais com início em, ou após, 1º de janeiro de 2020.  
 
Transição para a contabilização de hedge (Capítulo 6) 
 
7.2.26 Como  exceção  à  aplicação  prospectiva  dos  requisitos  de  contabilização  de hedge 
deste Pronunciamento, a entidade: 
... 
(d)  deve  aplicar  os  requisitos  da Seção  6.8, retrospectivamente.  Essa  aplicação 
retrospectiva deve ser aplicada apenas àquelas relações de proteção que existiam no início 
do período de relatório em que a entidade aplica esses requisitos pela primeira vez ou foram 
designados a partir de então, e ao valor acumulado na reserva de hedge de fluxo de caixa 
que existia no início do período do relatório em que a entidade aplica esses requisitos pela 
primeira vez. 
 
 
2. Inclui os itens de 102A a 102N e 108G e seus títulos na NBC TG 38 (R3) – Instrumentos 
Financeiros: Reconhecimento e Mensuração, que passam a vigorar com as seguintes 
redações: 
 
Exceções  temporárias  à  aplicação  de  requisitos  específicos  de  contabilidade  de 
hedge 
 
102A  A  entidade  deve  aplicar  os  itens  de  102A  a  102N  e 108G  a  todas  as  relações  de 
proteção  diretamente  afetadas  pela  reforma  da  taxa  de  juros  de  referência.  Esses  itens  se 
aplicam apenas a essas relações de proteção. A relação de proteção é diretamente afetada 
pela reforma da taxa de juros de referência somente se a reforma suscitar incertezas sobre: 
(a)  a  taxa  de  juros  de  referência  (especificada  contratualmente  ou  não)  designada 
como risco protegido; e / ou 
(b)  o período ou o valor dos fluxos de caixa baseados na taxa de juros de referência do 
item objeto de hedge ou do instrumento de hedge. 
 
102B Com o objetivo de aplicar os itens de 102D a 102N, o termo ”reforma da taxa de juros 
de  referência”  refere-se  à  reforma  de  todo  o  mercado  de  taxa  de  juros  de  referência, 
incluindo  a  substituição  da  taxa  de  juros  de  referência  por  uma  taxa  de  referência 
alternativa,  como  resultado  das  recomendações  estabelecidas  no  relatório  do Financial 
Stability Board’s (Conselho  de  Estabilidade  Financeira), de  julho  de  2014,  'Reforma  das 
principais taxas de juros de referência'. 
 
102C  Os  itens  de  102D  a  102N  fornecem  exceções  apenas  aos  requisitos  especificados 
nesses itens. A entidade deve continuar a aplicar todos os outros requisitos de contabilidade 
de hedge às  relações  de  proteção  diretamente  afetadas  pela  reforma  da  taxa  de juros  de 
referência. 
 
Requisito altamente provável para proteção de fluxo de caixa 

 
 
 
102D  Com  o  objetivo  de  aplicar  o  requisito  no  item  88(c)  de  que  uma  transação  prevista 
deva ser altamente provável, a entidade deve assumir que a taxa de juros de referência, na 
qual  os  fluxos  de  caixa  protegidos  (especificados  contratualmente  ou  não)  são  baseados, 
não é alterada como resultado da reforma da taxa de juros de referência. 
 
Reclassificação   do   ganho   ou   da   perda   acumulada   reconhecida   no   resultado 
abrangente 
 
102E Para  fins  de  aplicação  do  requisito  no  item  101(c),  a  fim  de  determinar  se  a 
transação  prevista  não  é  mais  esperada,  a  entidade  deve  assumir  que  a  taxa  de  juros  de 
referência, na qual os fluxos de caixa protegidos (especificado contratualmente ou não) são 
baseados, não é alterada como resultado da reforma da taxa de juros de referência. 
 
Avaliação da eficácia 
 
102F Com  o  objetivo  de  aplicar  os  requisitos  dos  itens  88(b)  e  AG105(a),  a  entidade  deve 
assumir que a taxa de juros de referência sobre a qual os fluxos de caixa protegidos e/ou o 
risco protegido (especificado contratualmente ou não) são baseados ou a taxa de juros, na 
qual os fluxos de caixa do instrumento de hedge se baseiam, não é alterada como resultado 
da reforma da taxa de juros de referência. 
 
102G  Com  o  objetivo  de  aplicar  o  requisito  do  item  88(e),  a  entidade  não  é  obrigada  a 
descontinuar a relação de proteção, porque os resultados reais do hedge não atendem aos 
requisitos  do  item  AG105(b).  Para  evitar  dúvidas,  a  entidade  deve  aplicar  as  outras 
condições  do  item  88,  incluindo  a  avaliação  prospectiva  do  item  88(b),  para  avaliar  se  a 
relação de proteção deve ser descontinuada. 
 
Designação de componente de item como item protegido 
 
102H A menos que o item 102I seja aplicável para hedge de uma parcela de referência não 
contratualmente  especificada  do  risco  de  taxa  de  juros,  a  entidade  deve  aplicar  o  requisito 
dos  itens  81  e  AG99F – que  a  parcela  designada  seja  identificável  separadamente – 
somente no início da relação de proteção. 
 
102I  Quando    a    entidade,    consistente    com    sua    documentação    de hedge, 
frequentemente, redefine (ou seja, descontinua e reinicia) uma relação de proteção, porque 
tanto  o  instrumento  de hedge quanto  o  item  protegido  mudam  com  frequência  (ou  seja,  a 
entidade usa um processo dinâmico no qual os itens protegidos e o hedge de instrumentos 
utilizados para gerenciar essa exposição não permanecem os mesmos por muito tempo), a 
entidade  deve  aplicar  o  requisito  dos  itens  81  e  AG99F – que  a  parcela  designada  seja 
identificável  separadamente – somente  quando  designar  inicialmente  um  item  protegido 
naquela  relação  de  proteção.  O  item  protegido  que foi  avaliado  no  momento  de  sua 
designação  inicial  na  relação  de  proteção,  seja  no  momento  do  início  do hedge ou 
subsequentemente,  não  deve  ser  reavaliado  em  nenhuma  redesignação  subsequente  na 
mesma relação de proteção. 
 
Fim da aplicação 
 
102J A entidade deve cessar, prospectivamente, de aplicar o item 102D ao item protegido: 
(a)  quando  a  incerteza  decorrente  da  reforma  da  taxa  de  juros  de  referência  não 
estiver mais presente no momento e no valor dos fluxos de caixa baseados no parâmetro da 
taxa de juros de referência do item protegido; e 
(b)  quando a relação de proteção da qual o item protegido faz parte for descontinuado. 
 
102K A entidade deve cessar, prospectivamente, de aplicar o item 102E: 

 
 
(a)  quando  a  incerteza  decorrente  da  reforma  da taxa  de  juros  de  referência  não 
estiver  mais  presente  em  relação  ao  momento  e  ao  valor  dos  fluxos  de  caixa  futuros 
baseados no parâmetro da taxa de juros de referência do item protegido; e 
(b)  quando todo o ganho ou a perda acumulado reconhecido no resultado abrangente 
referente a essa relação de proteção descontinuada for reclassificado para o resultado. 
 
102L  A entidade deve cessar, prospectivamente, de aplicar o item 102F: 
(a)  ao  item  protegido,  quando  a  incerteza  decorrente  da  reforma  da  taxa  de  juros  de 
referência  não  estiver  mais  presente  em  relação  ao  risco  protegido  ou  ao  momento  e  ao 
valor dos fluxos de caixa baseados na taxa de juros de referência do item protegido; e 
(b)  ao  instrumento  de hedge,  quando  a  incerteza  decorrente  da  reforma  da  taxa  de 
juros de referência não estiver mais presente em relação ao momento e ao valor dos fluxos 
de caixa baseados na taxa de juros de referência do instrumento de hedge. 
Se a relação de proteção da qual o item protegido e o instrumento de hedge fizerem parte 
for  descontinuada  antes  da  data  especificada  no  item  102L(a)  ou  da  data  especificada  no 
item  102L(b),  a  entidade  deve  cessar,  prospectivamente,  de  aplicar  o  item  102F  a  essa 
relação de proteção na data da descontinuação. 
 
102M A  entidade  deve  cessar,  prospectivamente,  de  aplicar  o  item  102G  à  relação  de 
proteção no início de: 
(a)  quando  a  incerteza  decorrente  da  reforma  da  taxa  de  juros  de  referência  não 
estiver mais presente com relação ao risco protegido e ao momento e ao valor dos fluxos de 
caixa  baseados  na  taxa  de  juros  de  referência  do  item  protegido  ou  do  instrumento  de 
hedge; e 
(b)  quando a relação de proteção à qual a exceção é aplicada for descontinuada. 
 
102N Ao   designar   um   grupo   de   itens   como   item   protegido   por hedge,   ou   uma 
combinação  de  instrumentos  financeiros  como  instrumento  de hedge,  a  entidade  deve 
deixar  de  aplicar, prospectivamente, os  itens  de  102D  a  102G  ao  item  ou  instrumento 
financeiro  individual,  de  acordo  com  os  itens  102J,  102K,  102L  ou  102M,  conforme 
relevante,  quando  a  incerteza  decorrente  da  reforma  da  taxa  de  juros  de  referência  não 
estiver mais presente com relação ao risco protegido e/ou ao momento e ao valor dos fluxos 
de caixa baseados na taxa de juros de referência desse item ou instrumento financeiro. 
 
108G A reforma da taxa de juros de referência, que alterou a NBC TG 48, a NBC TG 38 e 
a  NBC  TG 40,  adicionou  os  itens  de  102A  a  102N.  A  vigência  dessas  alterações  será 
estabelecida   pelos   órgãos   reguladores   que   o   aprovarem,   sendo   que, para   o   pleno 
atendimento  às  normas  internacionais  de  contabilidade, a  entidade  deve  aplicar  essas 
alterações  nos  períodos  anuais  com  início  em,  ou  após,  1º  de janeiro  de  2020.  A  entidade 
deve aplicar essas alterações, retrospectivamente, às relações de proteção que existiam no 
início do período de relatório em que a entidade aplica essas alterações pela primeira vez ou 
foram  designadas  posteriormente,  e  ao  ganho  ou  à  perda  reconhecido  no  resultado 
abrangente  que  existia  no  início  do  período  do  relatório  em que  a  entidade  aplica  essas 
alterações pela primeira vez. 
 
3. Inclui  os  itens  24H, e  seu  título, 44DE  e  44DF  na  NBC  TG 40  (R3) – Instrumentos 
Financeiros: Evidenciação, que passam a vigorar com as seguintes redações: 
 
Incerteza decorrente da reforma da taxa de juros de referência 
 
24H  Para  relações  de  proteção  que  a  entidade  aplica  as  exceções  estabelecidas  nos 
itens  de  6.8.4  a  6.8.12  da  NBC  TG 48  ou  nos  itens  de  102D  a  102N  da  NBC  TG 38,  a 
entidade deve divulgar: 
(a)  as  taxas  de  juros  de  referência significativas  às  quais  as  relações  de  proteção  da 
entidade estão expostas; 
(b)  a  extensão  da  exposição  ao  risco  que  a  entidade  administra  que  é  diretamente 
afetada pela reforma da taxa de juros de referência; 

 
 
(c)  como   a   entidade   está   gerenciando   o   processo   de   transição   para   taxas   de 
referência alternativas; 
(d)  a  descrição  de  premissas  ou  julgamentos  significativos  que  a  entidade  fez  ao 
aplicar  esses  itens  (por  exemplo,  premissas  ou  julgamentos  sobre  quando  a  incerteza 
decorrente  da  reforma  da  taxa  de  juros  de  referência  não  está  mais  presente  no  que  diz 
respeito  ao  momento  e  ao  valor  dos  fluxos  de  caixa  baseados  na  taxa  de  juros  de 
referência); e 
(e)  o valor nominal dos instrumentos de hedge nessas relações de proteção. 
 
44DE Reforma da taxa de juros de referência, que alterou a NBC TG 48, a NBC TG 38 e 
a  NBC  TG 40, adicionou  os  itens  24H  e  44DF.  A  entidade  deve  aplicar  essas  alterações 
quando aplicar as alterações à NBC TG 48 ou à NBC TG 38. 
 
44DF  No período de relatório em que a entidade aplica, pela primeira vez, a reforma da 
taxa  de  juros  de  referência,  a  entidade  não  é  obrigada  a  apresentar  as  informações 
quantitativas  requeridas  pelo  item  28(f)  da  NBC  TG 23 – Políticas  Contábeis,  Mudança  de 
Estimativa e Retificação de Erro. 
 
 
Essas alterações e inclusões entram em vigor na data de sua publicação, produzindo seus 
efeitos a partir de 1º de janeiro de 2020. 
  
 
Brasília, 19 de março de 2020. 
 
 
Contador Zulmir Ivânio Breda 
Presidente 
 
Ata CFC n.º 1061.
