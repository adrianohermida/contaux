# NBCTG R3 Errata

- Código externo: file:2026/06/nbctg_r3_errata.pdf
- Fonte: file:2026/06/NBCTG_R3_Errata.pdf
- URL fonte: https://cfc.org.br/wp-content/uploads/2026/06/NBCTG_R3_Errata.pdf
- Arquivo original: https://cfc.org.br/wp-content/uploads/2026/06/NBCTG_R3_Errata.pdf
- Nome do arquivo: NBCTG_R3_Errata.pdf
- Tags: Contábil, NBC, Errata
- Atualizado em: 2026-10-10 14:28:00.735381+00

## Resumo



## Texto integral extraído

[TEXTO NÃO EXTRAÍDO — consultar o arquivo/URL original indicado acima.]
