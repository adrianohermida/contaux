# NBC TSP ESTRUTURA CONCEITUAL (R1)

- Código externo: 2025/nbctspec(r1)
- Fonte: CFC 2025/NBCTSPEC(R1) — DOU 07/04/2026
- URL fonte: https://www2.cfc.org.br/sisweb/sre/detalhes_sre.aspx?Codigo=2025/NBCTSPEC(R1)&arquivo=NBCTSP_Estrutura(R1).docx
- Arquivo original: https://www1.cfc.org.br/sisweb/SRE/docs/NBCTSP_Estrutura(R1).pdf
- Nome do arquivo: NBCTSP_Estrutura(R1).pdf
- Tags: Contábil, NBC, NBC TSP
- Atualizado em: 2026-10-10 14:28:28.752299+00

## Resumo

NBC TSP ESTRUTURA CONCEITUAL (R1)

## Texto integral extraído

SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
1 
 
NORMA BRASILEIRA DE CONTABILIDADE, NBC TSP ESTRUTURA CONCEITUAL (R1), DE 13 DE 
NOVEMBRO DE 2025 
NBC   TSP   ESTRUTURA   CONCEITUAL (R1) – 
ESTRUTURA CONCEITUAL PARA ELABORAÇÃO 
E  DIVULGAÇÃO  DE  INFORMAÇÃO  CONTÁBIL 
DE  PROPÓSITO  GERAL  PELAS  ENTIDADES  DO 
SETOR PÚBLICO. 
 
O CONSELHO FEDERAL DE CONTABILIDADE, no exercício de suas atribuições legais e regimentais 
e com fundamento no disposto na alínea “f” do art. 6º do Decreto-Lei nº 9.295, de 27 de maio de 1946, 
alterado  pela  Lei  n.º  12.249,  de  11  de  junho  de 2010,  alinhado  com  o  processo  de  convergência  das 
Normas  Brasileiras  de  Contabilidade  e  conforme  acordo  firmado  com  a International  Federation  of 
Accountants (Ifac),  que  autoriza  o  CFC  a  traduzir,  reproduzir  e  publicar  as  normas  internacionais  em 
formato  eletrônico,  faz saber  que  foi  aprovada,  em  seu  Plenário,  a  seguinte  Norma  Brasileira  de 
Contabilidade  (NBC),  em  consonância  com  a Conceptual  Framework  for  General  Purpose  Financial 
Reporting by Public Sector Entities, editada pelo International Public Sector Accounting Standards Board 
da International Federation of Accountants (Ipsasb/Ifac) e revisada de acordo com o IPSASB-HANDBOOK 
2024: 
 
NBC TSP ESTRUTURA CONCEITUAL (R1) – ESTRUTURA CONCEITUAL PARA ELABORAÇÃO E 
DIVULGAÇÃO DE INFORMAÇÃO CONTÁBIL DE PROPÓSITO GERAL PELAS ENTIDADES DO SETOR 
PÚBLICO 
 
Sumário  Item 
Prefácio  1 – 24 
Introdução  1 – 4 
Volume e significância das transações sem contraprestação  5 – 7 
Importância do orçamento aprovado   8 – 9 
Natureza dos programas e longevidade do setor público  10 – 13 
Natureza e propósito dos ativos e passivos no setor público  14 – 17 
Papel regulador de entidades do setor público  18 – 19 
Relacionamento com as estatísticas de finanças públicas (EFP)  20 – 24 
Capítulo 1 – Função, Autoridade e Alcance da Estrutura Conceitual 1.1 – 1.8D 
Função  1.1 
Autoridade  1.2 – 1.3 
Relatório Contábil de Propósito Geral (RCPG)  1.4 – 1.7 
Alcance da estrutura conceitual e das NBCs TSP  1.8 – 1.8D 
Capítulo 2 – Objetivos e Usuários da Informação Contábil de Propósito Geral  2.1 – 2.31 
Objetivos da elaboração e divulgação da informação contábil  2.1 – 2.2 
Usuários dos RCPGs  2.3 – 2.6 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
2 
 
Prestação de contas e responsabilização (accountability) e tomada de decisão  2.7 – 2.10 
Necessidade de informação dos usuários dos serviços e dos provedores de recurso
  
2.11 – 2.13 
Informação fornecida pelos RCPGs  2.14 – 2.28 
Situação patrimonial, desempenho e fluxos de caixa  2.14 – 2.17 
Informação  orçamentária  e  cumprimento  da  legislação  ou  outra  regulamentação 
relativa à captação e à utilização de recursos  
2.18 – 2.21 
Resultado da prestação de serviços  2.22 – 2.24 
Informações financeiras e não financeiras prospectivas  2.25 – 2.27 
Informação explicativa  2.28 
Demonstrações   contábeis   e   a   informação   que   as   aprimore, complemente e 
suplemente 
2.29 – 2.30 
Outras fontes de informação  2.31 
Capítulo 3 – Características Qualitativas  3.1 – 3.42 
Introdução  3.1 – 3.5 
Relevância  3.6 – 3.9 
Representação fidedigna  3.10 – 3.16 
Compreensibilidade  3.17 – 3.18 
Tempestividade  3.19 – 3.20 
Comparabilidade  3.21 – 3.25 
Verificabilidade  3.26 – 3.31 
Restrições acerca da informação incluída nos RCPGs  3.32 – 3.42 
Materialidade  3.32 – 3.34 
Custo-benefício  3.35 – 3.40 
Equilíbrio entre as características qualitativas  3.41 – 3.42 
Capítulo 4 – Entidade que Reporta a Informação Contábil 4.1 – 4.11 
Introdução  4.1 – 4.2 
Características-chave de entidade que reporta a informação contábil  4.3 – 4.11 
Capítulo 5 – Elementos das Demonstrações Contábeis  5.1 – 5.37 
Introdução  5.1 – 5.5 
Propósito  5.1 
Elementos e sua importância  5.2 – 5.4 
Elementos  5.5 
Ativo  5.6 – 5.13 
 Definições de ativo e recurso  5.6 – 5.6B 
 Direitos  5.7 A–5. 7G 
 Potencial de serviço e benefícios econômicos   5.8 – 5.10 
Controlado no presente pela entidade e derivado de um evento passado    5.11 – 5. 13 
Passivo  5.14 – 5.26 
Definição   5.14 – 5.14A 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
3 
 
Obrigações    5.15 – 5.15E 
 Transferência de recursos da entidade   5.16 – 5. 16F 
 Obrigação presente e derivada de evento passado   5.17 – 5.26 
 Ativos e passivos  5.26A – 5.26J 
 Unidade contábil  5.26A – 5.26H 
 Acordos vinculantes que são igualmente não executados  5.26I – 5.26J 
Situação patrimonial líquida, outros recursos e outras obrigações  5.27 – 5.28 
Receita e despesa  5.29 – 5.31 
Superávit ou déficit do exercício  5.32 
Contribuição dos proprietários e distribuição aos proprietários  5.33 – 5.37 
Capítulo 6 – Reconhecimento nas Demonstrações Contábeis  6.1 – 6.10 
Critérios de reconhecimento e sua relação com a evidenciação  6.1 – 6.4 
Definição de elemento  6.5 – 6.6 
Incerteza quanto à mensuração  6.7 – 6.8 
Evidenciação e reconhecimento  6.9 
Desreconhecimento  6.10 
Capítulo 7 – Mensuração de Ativos e Passivos nas Demonstrações Contábeis   7.1 – 7. 75 
Introdução  7.1 
Objetivo da mensuração   7.2 – 7. 24 
 Mensuração inicial 7.5 – 7.7 
 Mensuração subsequente  7.8 – 7. 14 
 Seleção de modelos e de bases de mensuração  7. 15 – 7.19 
 Mensurações específicas e não específicas  7. 20 
 Valores de entrada e de saída  7. 21 – 7.23 
 Nível de agregação ou desagregação para mensuração   7.24 
Bases de mensuração para os ativos   7. 25 – 7. 62 
Custo histórico   7. 26 – 7. 34 
 Base de mensuração de ativos no modelo de valor corrente   7. 35 – 7. 36 
Valor corrente operacional    7. 37 – 7. 44 
 Valor justo  7. 45 – 7. 56 
 Valor em uso  7. 56 – 7. 62 
Bases de mensuração para os passivos   7. 63 – 7. 76 
Custo histórico  7. 64 – 7. 67 
Custo de cumprimento da obrigação   7. 68 – 7. 73 
Valor justo    7. 74 – 7. 75 
Capítulo 8 – Apresentação de Informação no Relatório Contábil de Propósito Geral  8.1 – 8.64 
Introdução  8.1 – 8.3 
Apresentação  8.4 – 8.8 
Seleção da informação  8.9 – 8.35 
Seleção e natureza da informação  8.11 – 8.14 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
4 
 
Informação selecionada para exposição ou evidenciação  8.15 – 8.24 
Princípios aplicáveis à seleção da informação  8.25 – 8.35 
Localização da informação  8.36 – 8.44 
Princípios para a alocação da informação entre diferentes relatórios  8.38 – 8.40 
Princípios para a localização da informação dentro do relatório  8.41 – 8.44 
Organização da informação  8.45 – 8.64 
Natureza da informação relevante para fins de organização  8.47 – 8.53 
Princípios aplicáveis à organização da informação  8.54 – 8.64 
Vigência  
 
Introdução 
1.  A  Estrutura  Conceitual  para  Elaboração  e  Divulgação  de  Informação  Contábil  de  Propósito  Geral 
pelas  Entidades  do  Setor  Público  (Estrutura  Conceitual)  estabelece  os  conceitos  que  devem  ser 
aplicados  no  desenvolvimento  das  demais  Normas  Brasileiras  de  Contabilidade Técnicas  do  Setor 
Público  (NBCs  TSP)  do  Conselho  Federal  de  Contabilidade  (CFC)  destinados  às  entidades  do  setor 
público. Além disso, tais conceitos são aplicáveis à elaboração e à divulgação formal dos Relatórios 
Contábeis de Propósito Geral das Entidades do Setor Público (RCPGs). 
 
2.  O objetivo principal da maioria das entidades do setor público é prestar serviços à sociedade, em 
vez  de  obter  lucros  e  gerar  retorno  sobre  o  capital  para  os  investidores.  Consequentemente,  o 
desempenho  de  tais  entidades  podem  ser  apenas  parcialmente  avaliado  por  meio  da  análise  da 
situação patrimonial,  do  desempenho e dos  fluxos  de  caixa.  Os  RCPGs  fornecem  informações  aos 
seus  usuários  para  subsidiar  os  processos  decisórios  e  a  prestação  de  contas  e  responsabilização 
(accountability).  Portanto,  os  usuários  dos  RCPGs  das  entidades  do  setor  público  precisam  de 
informações para subsidiar as avaliações de algumas questões, tais como: 
 
(a) se a entidade prestou seus serviços à sociedade de maneira eficiente e eficaz; 
(b)  quais  são  os  recursos  atualmente  disponíveis  para  gastos  futuros,  e  até  que  ponto  há 
restrições ou condições para a utilização desses recursos; 
(c) a extensão na qual a carga tributária, que recai sobre os contribuintes em períodos futuros 
para pagar por serviços correntes, tem mudado; e 
(d) se a capacidade da entidade para prestar serviços melhorou ou piorou em comparação com 
exercícios anteriores. 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
5 
 
3.  Os governos geralmente têm amplos poderes, incluindo a capacidade de estabelecer e fazer cumprir 
requisitos  legais  e  alterar  esses  requisitos.  Globalmente,  o  setor  público  varia  consideravelmente 
em  suas  disposições  constitucionais  e  em  suas  metodologias  de  funcionamento.  No  entanto,  a 
governança no setor público, geralmente, envolve a realização de prestação de contas, como, por 
exemplo, a realizada pelo Poder Executivo para o Poder Legislativo. 
 
4.  As seções a seguir destacam as características do setor público selecionadas para serem incluídas no 
desenvolvimento desta Estrutura Conceitual. 
 
Volume e significância das transações sem contraprestação 
5.  Em  uma  transação  sem  contraprestação,  a  entidade  recebe  o  valor  da  outra  parte  sem  dar 
diretamente em troca valor aproximadamente igual. Tais transações são comuns no setor público. 
A  quantidade  e  a  qualidade  dos  serviços  públicos  prestados  a  um  indivíduo ou  a  um  grupo  de 
indivíduos,  normalmente,  não  são  diretamente  proporcionais  ao  volume  de  tributos  cobrados.  O 
indivíduo ou o grupo pode ter que pagar tarifa ou taxa adicional e/ou pode estar sujeito a cobranças 
específicas para ter acesso a determinados serviços. No entanto, essas operações são, geralmente, 
transações sem contraprestação, porque o valor dos benefícios que indivíduo ou grupo de indivíduos 
pode  obter  não  será  aproximadamente  igual  ao  valor  de  quaisquer  cobranças  pagas  por  eles.  A 
natureza das   transações   sem   contraprestação   pode   impactar   a   forma   pela   qual   elas   são 
reconhecidas,  mensuradas  e  evidenciadas,  no  sentido  de  dar  suporte  às  avaliações  por  parte  dos 
usuários dos serviços e dos provedores de recursos. 
 
6.  A  tributação  é  uma  transação  que  ocorre  por  força  de  lei  e,  portanto,  uma  transação  sem 
contraprestação  entre  indivíduos  ou  entidades e  o  governo.  A  distribuição  das  competências 
tributárias entre os níveis de governo não é uniforme e depende da relação entre as competências 
tributárias do Governo federal, dos demais entes federativos e de outras entidades do setor público. 
As   entidades   internacionais   do   setor   público   são   financiadas   principalmente   por   meio   de 
transferências oriundas dos governos. Tal financiamento pode ser regido por tratados e convenções 
e pode também ser voluntário. 
 
7. Os governos e outras entidades do setor público são responsabilizáveis perante os provedores de 
recursos,  especialmente  àqueles  que  proveem  esses  recursos  por  meio  de  tributos  e  de  outras 
transações  compulsórias.  O  objetivo  da  prestação  de  contas  e  responsabilização  (accountability) 
relacionado com a elaboração e divulgação dos RCPGs consta no Capítulo 2, intitulado Objetivos e 
Usuários da Informação Contábil de Propósito Geral das Entidades do Setor Público. 
Importância do orçamento aprovado  

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
6 
 
8. O governo e outras entidades do setor público elaboram orçamentos. No Brasil, a Constituição exige 
a elaboração do orçamento anual, a sua aprovação pelo Poder Legislativo e a sua disponibilização à 
sociedade. A legislação brasileira define o que a peça orçamentária deve conter. A sociedade fiscaliza 
a gestão das entidades públicas diretamente, respaldada pela Constituição, ou indiretamente, por 
meio de representantes. O orçamento aprovado é utilizado como base para a definição dos níveis 
de tributação e de outras receitas, compondo o processo de obtenção de autorização legislativa para 
a realização do gasto público. 
9.  Devido  à  importância  do  orçamento aprovado,  as  informações  que  possibilitam  aos  usuários 
compararem  a  execução  orçamentária  com  o  orçamento  previsto  facilitam  a  análise  quanto  ao 
desempenho  das  entidades  do  setor  público.  Tais  informações  instrumentalizam  a  prestação  de 
contas e a responsabilização (accountability) e fornecem subsídios para o processo decisório relativo 
aos  orçamentos  dos  exercícios  subsequentes.  A  elaboração  de  demonstrativo  que  apresenta  e 
compara  a  execução  do  orçamento  com  o  orçamento  previsto  é  o  mecanismo  normalmente 
utilizado para demonstrar a conformidade com os requisitos legais relativos às finanças públicas. As 
necessidades dos usuários quanto às informações orçamentárias são discutidas no Capítulo 2. 
Natureza dos programas e longevidade do setor público 
10. Muitos   programas   do   setor   público   são   de   longo   prazo,   e   a   capacidade   para   cumprir   os 
compromissos  depende  dos  tributos  e  das  contribuições  a  serem  arrecadados  no  futuro.  Muitos 
compromissos  decorrentes  dos  programas  do  setor  público  e  as  prerrogativas  para cobrar  e 
arrecadar  tributos  futuros  não  se  encaixam  nas  definições  de  ativo  e  passivo  apresentados  no 
Capítulo  5,  intitulado  Elementos  das  Demonstrações  Contábeis.  Portanto,  os  compromissos  e  as 
prerrogativas com essa característica não são reconhecidos nas demonstrações contábeis. 
11. Consequentemente, as demonstrações que evidenciam a situação patrimonial e o desempenho não 
fornecem  todas  as  informações  que  os  usuários  precisam  conhecer  a  respeito  dos  programas  de 
longo prazo. Os efeitos financeiros de determinadas decisões poderão ser observados após muitos 
anos.  Dessa  forma,  os  RCPGs,  ao  conterem  informações  financeiras  prospectivas  acerca  da 
sustentabilidade  em  longo  prazo  das  finanças  e  de  programas  essenciais  da  entidade  do  setor 
público,  são  documentos  necessários  para  fins  de prestação  de  contas  e  responsabilização 
(accountability) e tomada de decisão, como será visto no Capítulo 2. 
12. Embora  o  controle  político  possa  mudar  periodicamente,  os  estados  soberanos,  geralmente,  têm 
existências  muito  longas.  Eles  continuam  a  existir  mesmo  que  passem  por  severas  dificuldades 
financeiras  e  se  tornem  inadimplentes  com  as  obrigações  oriundas  da  sua  respectiva  dívida 
soberana.  Se  os  entes  subnacionais  passarem  por  dificuldades  financeiras,  os  governos  nacionais 
podem, por exemplo, agir como credores em última instância ou podem prestar garantias em larga 
escala para os empréstimos tomados por esses entes. Nesse exemplo, os principais compromissos 
de  prestação  de  serviços  das  entidades  subnacionais  podem  continuar  a  ser  financiados  pelo 
governo nacional (ou central). Em outros exemplos, as entidades do setor público que são incapazes 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
7 
 
de  liquidar  as  suas  obrigações  na  data  de  vencimento  podem  continuar  a  existir  por  meio  da 
reestruturação de suas operações. 
13. A continuidade das entidades do setor público (going concern principle) fundamenta a elaboração 
das demonstrações contábeis. É necessário que a interpretação desse princípio expresse as questões 
discutidas nos itens 11 e 12. 
Natureza e propósito dos ativos e passivos no setor público 
14.  No setor público, a principal razão de se manterem ativos imobilizados e outros ativos é voltada para 
o  potencial  de  serviços  desses  ativos  e,  não,  para  a  sua  capacidade  de  gerar  fluxos  de  caixa
1
.  Em 
razão dos tipos de serviços prestados, uma parcela significativa dos ativos utilizados pelas entidades 
do setor público é especializada, como, por exemplo, os ativos de infraestrutura e os ativos militares. 
Pode  existir  mercado  limitado  para  esses  ativos  e,  mesmo  assim,  eles  podem  necessitar  de  uma 
considerável adaptação para serem utilizados por outros operadores. Esses fatores têm implicações 
para  a  mensuração  desses  ativos.  O  Capítulo  7,  intitulado  Mensuração  de  Ativos  e  Passivos  nas 
Demonstrações Contábeis, discute as bases de mensuração dos ativos no setor público. 
15. Governos e outras entidades do setor público podem manter itens que contribuam para o legado 
cultural e histórico da nação ou da região, como, por exemplo, obras de arte, prédios históricos e 
outros artefatos. Os entes públicos também podem ser responsáveis por parques nacionais e outras 
áreas naturais relevantes com fauna e flora nativas. Esses itens geralmente não são mantidos para 
serem vendidos, mesmo que o mercado para eles exista. Além disso, os governos e as entidades do 
setor público, normalmente, têm a responsabilidade de preservá-los e mantê-los para as gerações 
atuais e futuras. 
16. Governos  frequentemente  exercem  poderes  sobre  recursos  naturais  e  outros  recursos,  como 
reservas  minerais,  água,  áreas  de  pesca,  florestas  e  o  espectro  eletromagnético  (bandas  de 
frequência   de   transmissões   de  telecomunicações).   Esses   poderes   conferem   aos   governos  a 
prerrogativa  de  concessão  de  licenças,  a  obtenção  de royalties ou  a  arrecadação  de  tributos  pela 
utilização desses recursos. A definição e os critérios de reconhecimento de ativo são discutidos nos 
capítulos 5, intitulado Elementos das Demonstrações Contábeis, e 6, intitulado Reconhecimento nas 
Demonstrações Contábeis. 
17. Governos e outras entidades do setor público incorrem em passivos relacionados aos seus objetivos 
de prestação de serviços. Muitos passivos são oriundos de transações sem contraprestação e isso 
inclui  aqueles  relacionados  a  programas  direcionados  ao  fornecimento  de  benefícios  sociais.  Os 
passivos também podem ser oriundos do papel governamental de credor em última instância e de 
 
1
 Muitos ativos do setor público geram fluxos de caixa, mas muitas vezes essa não é a principal razão para mantê-los. 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
8 
 
quaisquer  obrigações  de  transferência  de  recursos  para  afetados  por  desastres.  A  definição  de 
passivo e os critérios de reconhecimento são discutidos nos capítulos 5 e 6. 
Papel regulador das entidades do setor público 
18. Muitos governos e outras entidades do setor público possuem poder de regulação de entidades que 
operam  em  determinados  setores  da  economia,  de  forma  direta  ou  por  meio  de  agências 
reguladoras. A principal razão da regulação é assegurar o interesse público de acordo com objetivos 
definidos  nas  políticas  públicas.  A  intervenção  regulatória  também  pode  ocorrer  quando  existem 
mercados  imperfeitos  ou  falhas  de  mercado  para  determinados  serviços,  ou,  ainda,  para  mitigar 
alguns  fatores,  como,  por  exemplo,  a  poluição.  Essas  atividades  regulatórias  são  conduzidas  de 
acordo com o estabelecido na legislação. 
19. Governos podem também se autorregularem e regularem outras entidades do setor público. Pode 
ser  necessário  um  julgamento  para  determinar  se  a  regulação  cria  direitos  ou  obrigações  para  as 
entidades do setor público, os quais irão requerer o reconhecimento de ativos e passivos, ou se a 
prerrogativa de modificar essa regulação exerce impacto na forma que tais direitos e obrigações são 
contabilizados. O Capítulo 5 aborda os direitos e as obrigações das entidades do setor público. 
Relacionamento com as estatísticas de finanças públicas (EFP) 
20. Muitos  governos  produzem  dois  tipos  de  informações  financeiras ex-post:  (a)  Estatísticas  de 
Finanças  Públicas  (EFP)  do  Setor  Governo  Geral  (SGG),  com  o  propósito  de  permitir  a  análise 
macroeconômica  e  a  tomada  de  decisão;  e  (b)  Demonstrações  Contábeis  de  Propósito  Geral 
(Demonstrações  Contábeis), para  a  prestação  de  contas  e  responsabilização  (accountability)  e 
tomada  de  decisão  ao  nível  da  entidade,  incluindo  as  demonstrações  contábeis  consolidadas  do 
governo. 
21.  (Não convergido). 
22. As demonstrações contábeis e os relatórios de EFP têm muito em comum. Ambas as estruturas de 
relatórios  estão  voltadas  para: (a)  informação  contábil,  baseada  no  regime  de  competência; (b) 
ativos, passivos, receitas e despesas governamentais; e (c) informações abrangentes sobre os fluxos 
de caixa. Há uma considerável sobreposição entre as duas estruturas de relatórios que sustentam 
essas informações. 
23. No entanto, as NBCs TSP e as diretrizes para relatórios de EFP têm objetivos diferentes. O objetivo 
da  elaboração  e  da  divulgação  da  informação  contábil das  entidades  do  setor  público  é  o 
fornecimento  de  informações  úteis  sobre  a  entidade  que  reporta  a  informação,  voltadas  para  os 
usuários dos RCPGs, para fins de prestação de contas e responsabilização (accountability) e para a 
tomada de decisão. Os relatórios de EFP são utilizados, principalmente, para: (a) analisar opções de 
política  fiscal,  definir  essas  políticas  e  avaliar  os  seus  impactos;  (b)  determinar  o  impacto  sobre  a 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
9 
 
economia; e (c) comparar os resultados fiscais nacional e internacionalmente. O foco é a avaliação 
do impacto do SGG e do setor público em geral sobre a economia, no âmbito da estrutura conceitual 
das estatísticas macroeconômicas. 
24. Os objetivos e o alcance distintos levam ao tratamento também distinto de algumas transações e 
eventos.  A  eliminação  das  diferenças  não  fundamentais  para  os  objetivos  das  duas  estruturas 
conceituais e a utilização de um único sistema de informação contábil integrado para gerar tanto as 
demonstrações contábeis quanto os relatórios de EFP podem proporcionar benefícios aos usuários 
em termos de qualidade, tempestividade e compreensibilidade dos relatórios. Essas questões e suas 
implicações foram consideradas no desenvolvimento dos capítulos 2, 4, e 7. 
Capítulo 1 – Função, Autoridade e Alcance da Estrutura Conceitual 
Função 
1.1 A estrutura conceitual estabelece os conceitos que fundamentam a elaboração e a divulgação dos 
Relatórios Contábeis de Propósito Geral das Entidades do Setor Público (RCPGs), os quais devem ser 
elaborados com base no regime de competência. O Conselho Federal de Contabilidade (CFC) aplicará 
estes  conceitos  no  desenvolvimento  das  Normas  Brasileiras  de  Contabilidade Técnicas  do  Setor 
Público (NBCs TSP) e nas demais disposições aplicáveis à elaboração e divulgação dos RCPGs. 
Autoridade 
1.2 (Não convergido). 
1.2A Os  requisitos  obrigatórios  relacionados  ao  reconhecimento, à mensuração  e à apresentação  das 
transações e outros eventos e atividades evidenciados nos RCPGs são especificados nas demais NBCs 
TSP, aplicando-se, subsidiariamente, os conceitos descritos nesta Estrutura Conceitual. 
1.2B  Em  caso  de  eventual  conflito  entre  esta Estrutura Conceitual  e  outras  NBCs  TSP,  prevalecem  as 
disposições específicas vigentes nestas últimas em relação às constantes na primeira.  
1.3 Esta Estrutura Conceitual pode fornecer orientações para lidar com a elaboração e a divulgação da 
informação  contábil que  não  são  tratadas  por  outras  NBCs  TSP  ou  por  outras  disposições  do  CFC 
aplicáveis  às  entidades  do  setor  público.  Nessas  circunstâncias,  os  profissionais  da  contabilidade 
podem consultar e considerar a aplicabilidade das definições, dos critérios de reconhecimento, dos 
princípios de mensuração e de outros conceitos identificados nesta Estrutura Conceitual. 
Relatório Contábil de Propósito Geral (RCPG) 
1.4 Os RCPGs são os componentes centrais da transparência da informação contábil dos governos e de 
outras  entidades  do  setor  público,  aprimorando-a  e  favorecendo-a.  Os  RCPGs  são  relatórios 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
10 
 
contábeis elaborados para atender às necessidades dos usuários em geral, não tendo o propósito 
de atender a finalidades ou necessidades específicas de determinados grupos de usuários. 
1.5  Alguns usuários da informação contábil podem ter a prerrogativa de exigir a elaboração de relatórios 
para  atender  às  suas  necessidades  específicas.  Mesmo  que  esses  usuários  identifiquem  que  a 
informação fornecida pelos RCPGs seja útil aos seus propósitos, esses relatórios não são elaborados 
especificamente para atender a essas necessidades. 
1.6  Os  RCPGs  podem  compreender  múltiplos  relatórios,  cada  qual  atendendo  a  certos  aspectos  dos 
objetivos e do alcance da elaboração e da divulgação da informação contábil. Os RCPGs abrangem 
as  demonstrações  contábeis.  Os  RCPGs  abrangem  também  a  apresentação  de  informações  que 
aprimoram, complementam e suplementam as demonstrações contábeis. 
1.7 O alcance da elaboração e da divulgação da informação contábil estabelece o limite relacionado às 
transações  e  outros  eventos  e  atividades  que  podem  ser  reportados  nos  RCPGs.  O  alcance  da 
elaboração e da divulgação da informação contábil é determinado pela necessidade de informações 
dos  usuários  primários  dos  RCPGs  e  pelos  objetivos  da  elaboração  e  divulgação  da  informação 
contábil.  Os  fatores  que  determinam  o  que  deve  estar  no  alcance  da  informação  contábil  são 
abordados no Capítulo 2. 
Alcance da estrutura conceitual e das NBCs TSP 
1.8 (Não convergido). 
1.8 A  Esta Estrutura Conceitual  e  as  demais  NBCs  TSP  aplicam-se,  obrigatoriamente,  às  entidades  do 
setor  público  quanto  à  elaboração  e  divulgação  dos  RCPGs.  Estão  compreendidos  no  conceito  de 
entidades do setor público: os governos federal, estaduais, distrital e municipais e seus respectivos 
poderes e órgãos autônomos (abrangidos órgãos, secretarias, departamentos, agências, autarquias, 
fundações  instituídas  e  mantidas  pelo  poder  público,  fundos  e  outras  unidades  congêneres  das 
administrações  direta  e  indireta,  inclusive  as  empresas  estatais  dependentes),  os  conselhos,  os 
arranjos interfederativos (consórcios públicos, comitês etc.) e demais unidades afins. 
1.8B  As  empresas  estatais  dependentes  são  empresas  controladas  que  recebem  do  ente  controlador 
recursos  financeiros  para  pagamento  de  despesas  com  pessoal,  despesas  de  custeio  em  geral  ou 
despesas de  capital,  excluídos, no último  caso,  aqueles  provenientes de aumento de participação 
acionária. 
1.8C As empresas estatais independentes são todas as demais empresas controladas pelas entidades do 
setor  público  que  não  se  enquadram  nas  características  expostas  no  item  1.8B,  as  quais,  em 
princípio, não estão no alcance desta Estrutura Conceitual e das demais NBCs TSP (ver item 1.8D). 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
11 
 
1.8D   As   demais   entidades   não   compreendidas   no   item   1.8A,   incluídas   as   empresas   estatais 
independentes,  poderão  aplicar  esta Estrutura Conceitual  e  as  demais  NBCs  TSP  de  maneira 
facultativa ou por determinação dos respectivos órgãos reguladores, fiscalizadores e congêneres. 
Capítulo  2 – Objetivos  e  Usuários  da  Informação  Contábil  de  Propósito  Geral  das  Entidades  do  Setor 
Público 
Objetivos da elaboração e divulgação da informação contábil 
2.1 Os objetivos da elaboração e divulgação da informação contábil estão relacionados ao fornecimento 
de  informações  sobre  a  entidade  do  setor  público  que  são  úteis  aos  usuários  dos  RCPGs  para  a 
prestação de contas e responsabilização (accountability) e tomada de decisão. 
2.2 A elaboração e a divulgação de informação contábil não são um fim em si mesmas. O propósito é 
fornecer  informações  úteis  aos  usuários  dos  RCPGs.  Os  objetivos  da  elaboração  e  divulgação  da 
informação  contábil  são  determinados  com  base  nos  usuários  dos  RCPGs e  suas  necessidades  de 
informações. 
Usuários dos RCPGs 
2.3  Governos e outras entidades do setor público obtêm recursos dos contribuintes, doadores, credores 
por empréstimos e de outros provedores de recursos para serem utilizados na prestação de serviços 
aos cidadãos e aos outros usuários. Essas entidades são responsáveis pela gestão e utilização dos 
recursos perante os usuários desses serviços. Aqueles que proveem os recursos e/ou recebem (ou 
esperam receber) a prestação de serviços também requerem informações que sirvam de base para 
a tomada de decisão. 
2.4 Consequentemente, os RCPGs devem ser elaborados e divulgados, principalmente, para atender às 
necessidades de informações dos usuários dos serviços e dos provedores de recursos, quando esses 
não  detêm  a  prerrogativa  de  exigir  que  a  entidade  do  setor  público  divulgue  as  informações  que 
atendam às suas necessidades de prestação de contas e responsabilização (accountability) e tomada 
de decisões. Os membros do Poder Legislativo são também usuários primários dos RCPGs e utilizam 
extensiva  e  continuamente  esses  relatórios  enquanto  atuam  como  representantes  dos  interesses 
dos usuários de  serviços  e  dos  provedores de  recursos.  Assim,  para  os  propósitos desta  Estrutura 
Conceitual, os usuários primários dos RCPGs são os usuários dos serviços e seus representantes e os 
provedores de recursos e seus representantes (doravante identificados como usuários dos serviços 
e provedores de recursos, a não ser que sejam identificados de outra forma). 
2.5 Os cidadãos recebem os serviços do governo e de outras entidades do setor público e proveem parte 
dos  recursos  para  esse  fim.  Assim,  eles  são  usuários  primários  dos  RCPGs.  Alguns  usuários dos 
serviços  e  alguns  provedores  de  recursos  que  dependem  dos  RCPGs  para  obter  informações  que 
eles  necessitam  para  os  propósitos  de  prestação  de  contas  e  responsabilização  (accountability)  e 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
12 
 
tomada de decisão podem não ser cidadãos, como, por exemplo: indivíduos que pagam tributos e 
recebem   benefícios   e   não   são considerados   cidadãos;   agências   bilaterais   ou   multilaterais; 
provedores de recursos e corporações que realizam transações com o governo, bem como aqueles 
que  financiam  e/ou  se  beneficiam  dos  serviços  fornecidos  por  organizações  governamentais 
internacionais.  Na  maioria  dos  casos,  os  governos  que  proveem  recursos  para  as  organizações 
governamentais  internacionais  são  dependentes  dos  RCPGs daquelas  organizações  para  fins  de 
prestação de contas e responsabilização (accountability) e tomada de decisão. 
2.6 Os  RCPGs,  elaborados  para  atender  às  necessidades  de  informações  dos  usuários  dos  serviços  e 
provedores   de   recursos,   com   a   finalidade   de   prestação   de   contas   e   responsabilização 
(accountability)  e  tomada  de  decisão,  podem  também  fornecer  informações  úteis  para  outros 
indivíduos ou entidades para propósitos distintos. Por exemplo, os responsáveis pelas estatísticas 
de finanças públicas, os analistas, a mídia, os consultores financeiros, os grupos de interesse público 
ou privado podem entender que a informação fornecida pelos RCPGs é útil para os seus propósitos. 
As organizações que possuem a prerrogativa de exigir a elaboração de relatório contábil estruturado 
para atender às suas necessidades específicas de informação podem também utilizar a informação 
fornecida  pelos  RCPGs  para  os  seus  propósitos – como,  por  exemplo:  agências  reguladoras  e 
supervisoras, entidades de auditoria, comissões do Poder Legislativo ou de outro órgão do governo, 
órgãos  centrais  de  orçamento  e  controle,  agências  de  classificação  de risco  e,  em  alguns  casos, 
entidades  emprestadoras  de  recursos  e  de  fomento.  Mesmo  que  esses  outros  indivíduos  ou 
entidades  encontrem  informações  úteis  nos  RCPGs,  eles  não  são  usuários  primários  desses 
relatórios.  Assim,  os  RCPGs  não  são  elaborados  e  divulgados  para  atender  a  necessidades  de 
informações específicas ou particulares. 
Prestação de contas e responsabilização (accountability) e tomada de decisão 
2.7 A  principal  função  dos  governos  e  de  outras  entidades  do  setor  público  é  fornecer  serviços  que 
aprimorem  ou  mantenham  o  bem-estar  dos  cidadãos  e  dos  outros  indivíduos.  Esses  serviços 
incluem, por exemplo: programas e políticas de bem-estar, educação pública, segurança nacional e 
defesa nacional. Na maioria dos casos, esses serviços são fornecidos como resultado de transação 
sem contraprestação
2 
em ambiente não competitivo. 
2.8 Governos e outras entidades do setor público devem prestar contas àqueles que proveem os seus 
recursos,  bem  como  àqueles  que  dependam  deles  para  que  os  serviços  sejam  prestados  durante 
determinado exercício ou em longo prazo. O atendimento das obrigações relacionadas à prestação 
de contas e responsabilização (accountability) requer o fornecimento de informações sobre a gestão 
dos  recursos  da  entidade  confiados  com  a  finalidade  de prestação de  serviços  aos  cidadãos  e  aos 
outros  indivíduos,  bem  como  a  sua  adequação  à  legislação,  regulamentação  ou  outra  norma  que 
 
2
 Transações com contraprestação são transações em que uma entidade recebe ativos ou serviços, ou tem passivos extintos, e 
retribui valor aproximadamente igual a outra entidade em troca. Transações sem contraprestação são transações nas quais uma 
entidade recebe benefícios de outra entidade sem dar valor aproximadamente igual em troca. 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
13 
 
disponha  sobre  a  prestação  dos  serviços  e  outras  operações.  Em  razão  da  maneira  pela  qual  os 
serviços prestados pelas entidades do setor público são financiados (principalmente pela tributação 
e por outras transações sem contraprestação) e da dependência dos usuários dos serviços no longo 
prazo,  o  atendimento  das  obrigações  relacionadas  à  prestação  de  contas  e  responsabilização 
(accountability) requer também o fornecimento de informação sobre o desempenho da prestação 
dos serviços durante o exercício e a capacidade de continuidade dos mesmos em exercícios futuros. 
2.9 Os  usuários dos  serviços  e  os  provedores  de  recursos  também exigem  informações  como  insumo 
para a tomada de decisão, como, por exemplo: 
(a)  credores, doadores e outros que proveem recursos voluntariamente, incluindo transação com 
contraprestação,  tomam  decisões  sobre  se  proveem  recursos  para  dar  suporte  às  atividades 
atuais ou futuras do governo ou de outra entidade do setor público. Em algumas circunstâncias, 
os  membros  do Legislativo  ou  órgão  representativo  semelhante,  que  dependem  dos  RCPGs 
para obter a informação de que necessitam, podem tomar ou influenciar as decisões sobre os 
objetivos da  prestação  do  serviço  dos departamentos,  órgãos ou  programas  do  governo  e os 
recursos alocados para dar suporte à sua realização; e 
(b)  os contribuintes normalmente não proveem recursos ao governo ou a outra entidade do setor 
público voluntariamente ou como resultado de transação com contraprestação. Além disso, em 
muitos  casos,  eles  não  detêm  a  prerrogativa  de  escolher  se  aceitam  ou  não  os  serviços 
prestados pela entidade do setor público ou de escolher um prestador alternativo do serviço. 
Consequentemente, eles têm pouca capacidade direta ou imediata para tomar decisões sobre 
prover recursos ao governo, sobre os recursos a serem alocados para a prestação dos serviços 
por entidade do setor público em particular ou, ainda, se compram ou consomem os serviços 
prestados.  Entretanto,  os  usuários  dos  serviços  e  os  provedores  de  recursos  podem  tomar 
decisões sobre as suas preferências de voto e das representações que delegam aos eleitos ou 
aos órgãos governamentais ― essas decisões, em tese, podem ter implicação na alocação de 
recursos para determinadas entidades, setores ou serviços públicos. 
2.10 A   informação   fornecida   nos   RCPGs   para   fins   de   prestação   de   contas   e   responsabilização 
(accountability) subsidia e contribui para a tomada de decisão. Por exemplo, as informações sobre 
os custos, a eficiência ou a eficácia das atividades de prestação de serviços no passado, o montante 
e as fontes de recuperação de custos e os recursos disponíveis para dar suporte às atividades futuras, 
são  necessárias  para  o  atendimento  da  prestação  de  contas  e  responsabilização  (accountability). 
Essa  informação  também é  útil  para  a  tomada  de  decisão  pelos  usuários  dos  RCPGs,  inclusive  as 
decisões  que  os  doadores  e  outros  patrocinadores  tomam  sobre  o  provimento  de  recursos  à 
entidade. 
Necessidade de informação dos usuários dos serviços e dos provedores de recursos 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
14 
 
2.11  Para  fins  de  prestação  de  contas  e  responsabilização  (accountability)  e  tomada  de  decisão,  os 
usuários de serviço e os provedores de recursos necessitam de informações que possam dar suporte 
às avaliações de questões como: 
(a) o desempenho da entidade durante o exercício como, por exemplo, em: 
(i) satisfazer a sua prestação de serviços e outros objetivos operacionais e financeiros; 
(ii) administrar os recursos pelos quais é responsável; e 
(iii)  estar  em  conformidade  com  a  legislação,  regramentos  orçamentários  ou  com  os 
pronunciamentos  de  outro  órgão  ou  entidade  que  regulamente  a  captação  e  a  utilização 
dos recursos; 
(b) a liquidez (por exemplo, a capacidade de satisfazer as obrigações atuais) e a solvência (por 
exemplo, a capacidade de satisfazer as obrigações em longo prazo) da entidade; 
(c) a sustentabilidade da prestação de serviços pela entidade e de outras operações em longo 
prazo,  e  as  mudanças  decorrentes  como  resultado  das  atividades  da  entidade  durante  o 
exercício, incluindo, por exemplo: 
(i) a capacidade de a entidade de continuar a financiar as suas atividades para satisfazer os 
seus  objetivos  operacionais  em  futuro  (a  sua  capacidade  financeira),  inclusive  as  fontes 
prováveis  de  financiamento  e  a  extensão  na  qual  a  entidade  depende  de  tais  fontes  e, 
portanto, é vulnerável ao financiamento ou a pressões por demandas que estariam fora do 
seu controle; e 
(ii)  os  recursos  físicos  e  outros  disponíveis  atualmente  para  dar  suporte  à  prestação  de 
serviços no futuro (a sua capacidade operacional); e 
(d) a capacidade da entidade de se adaptar a novas situações, devido a mudanças demográficas 
ou  nas  condições  econômicas  nacionais  ou  globais  que  provavelmente  irão  impactar  a 
natureza ou a composição das atividades que realiza ou os serviços que são prestados. 
2.12  A informação que os usuários dos serviços e os provedores de recursos precisam para os propósitos 
citados no item 2.11, provavelmente, se sobrepõe em muitos aspectos. Por exemplo, os usuários de 
serviços exigem informação como insumo para avaliação de questões, tais como se: 
(a)  a  entidade  está  utilizando  os  recursos  com  eficácia,  eficiência  e  economicidade,  e  da 
maneira pretendida, e se tal uso corresponde ao interesse público; 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
15 
 
(b)  o alcance, o volume e o custo dos serviços prestados durante o exercício são apropriados, 
bem como os montantes e as fontes de recuperação dos custos; e 
(c)  a carga tributária atual e outros recursos angariados são suficientes para manter o volume 
e a qualidade dos serviços prestados atualmente. 
Os usuários dos serviços exigem, também, informação sobre as consequências das decisões tomadas 
e das atividades realizadas pela entidade durante o exercício e sobre os recursos disponíveis para 
dar suporte à prestação de serviços em períodos futuros, às atividades e objetivos da prestação de 
serviços, aos montantes e às fontes de recuperação dos custos necessários para dar suporte a essas 
atividades. 
2.13 Os provedores de recursos exigem informação como subsídio para as avaliações sobre se a entidade: 
(a)  está  alcançando  os  objetivos  estabelecidos  de  modo  a  justificar  os  recursos  angariados 
durante o exercício; 
(b)  financiou  as  operações  atuais  a  partir  dos  recursos  angariados  dos  contribuintes,  de 
empréstimos ou de outras fontes no período atual; e 
(c)  provavelmente  necessita  de  recursos  adicionais  (ou  menos  recursos)  no  futuro  e as  fontes 
prováveis desses recursos. 
Os credores por empréstimos e outros credores exigem informação como insumo para avaliações 
da  liquidez  da  entidade  e,  portanto,  se  o  montante  e  o  prazo  para  pagamento  estarão  em 
conformidade  com  o  que  foi  contratado.  Os  doadores  exigem  informação  para  dar suporte  às 
avaliações se a entidade está utilizando os recursos com eficácia, eficiência e economicidade, e da 
maneira pretendida. Eles também exigem informação sobre as atividades previstas de prestação de 
serviços e as necessidades de recursos. 
Informação fornecida pelos RCPGs 
Situação patrimonial, desempenho e fluxos de caixa 
2.14  A  informação  sobre  a  situação  patrimonial  do  governo  ou de outra  entidade  do  setor  público 
possibilita aos usuários identificarem os recursos da entidade e as demandas sobre esses recursos 
na  data  de  divulgação  do  relatório.  Isso  fornece  informação  útil  como  subsídio  às  avaliações  de 
questões, tais como: 
(a) a extensão na qual a administração cumpriu suas obrigações em salvaguardar e administrar 
os recursos da entidade; 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
16 
 
(b) a extensão na qual os recursos estão disponíveis para dar suporte às atividades relativas à 
prestação de serviços futuros e as mudanças durante o exercício relativas ao montante ou 
à composição desses recursos, bem como as demandas sobre esses recursos; e 
(c)  os  montantes  e  o  cronograma  de  fluxos  de  caixa  futuros  necessários  aos  serviços  e  ao 
pagamento das demandas existentes sobre os recursos da entidade. 
2.15  A  informação  sobre  o  desempenho  do  governo  ou  de  outra  entidade  do  setor  público  orienta  as 
avaliações de questões, como, por exemplo, se a entidade adquiriu recursos com economicidade e 
os  utilizou  com  eficácia  e  eficiência  para  atingir  os  seus  objetivos de  prestação  de  serviços.  A 
informação sobre  os  custos  da  prestação  de  serviços  e  os  montantes  e  as  fontes  de  recuperação 
desses custos durante o exercício irá auxiliar os usuários a determinarem se os custos operacionais 
foram  recuperados  a  partir  de,  por  exemplo,  tributos,  cobranças  aos  usuários,  contribuições  e 
transferências, ou se foram financiados pelo aumento do nível de endividamento da entidade. 
2.16  A informação sobre os fluxos de caixa do governo ou de outra entidade do setor público contribui 
para  as  avaliações  do  desempenho  e  da  liquidez  e  da  solvência  da  entidade.  Ela  indica  como  a 
entidade arrecadou e utilizou os recursos durante o período, inclusive os empréstimos tomados e 
pagos,  bem  como  as  suas  aquisições  e  vendas,  por  exemplo,  do  seu  ativo  imobilizado.  Identifica 
também   os   recursos   recebidos   a   partir   de,   por   exemplo,   tributos   e   investimentos   ou   as 
transferências  de  recursos  concedidas  ou  recebidas  em  transações  com  outros  governos,  órgãos 
governamentais ou organismos internacionais. A informação sobre os fluxos de caixa também pode 
subsidiar as avaliações sobre a conformidade da entidade com o que foi definido pelos responsáveis 
pela gestão financeira e informar a avaliação dos montantes e fontes prováveis de recursos para dar 
suporte aos objetivos da prestação de serviços. 
2.17  As  informações  sobre  a situação patrimonial,  sobre o  desempenho e  sobre os  fluxos de  caixa  são 
normalmente apresentadas nas demonstrações contábeis. Para auxiliar os usuários a entenderem, 
interpretarem e inserirem em contexto a informação apresentada nas demonstrações contábeis, os 
RCPGs  também  podem  fornecer  informações  financeiras  e  não  financeiras  que  aprimoram, 
complementam  e  suplementam  as  demonstrações  contábeis,  inclusive  as  informações  sobre 
questões relacionadas ao governo ou outra entidade do setor público, tais como: 
(a)  a  conformidade  com  os  orçamentos  aprovados  e  outra  regulamentação  relativa  às  suas 
operações; 
(b)  as atividades de prestação de serviços e os seus respectivos resultados durante o exercício; 
e 
(c)  as expectativas relacionadas às atividades da prestação de serviços e outras atividades no 
futuro, bem como as consequências, em longo prazo, das decisões tomadas e das atividades 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
17 
 
realizadas durante o exercício, inclusive aquelas que possam impactar as expectativas sobre 
o futuro. 
Essa informação pode ser apresentada nas notas explicativas às demonstrações contábeis ou em 
relatórios separados incluídos nos RCPGs. 
Informação orçamentária e cumprimento da legislação ou outra regulamentação relativa à captação e 
à utilização de recursos 
2.18 O governo elabora, aprova e divulga o orçamento anual. O orçamento aprovado fornece informação 
financeira aos interessados sobre os planos operacionais da entidade para o período futuro, as suas 
necessidades de capital e, frequentemente, os seus objetivos e as suas expectativas em relação à 
prestação  de  serviços.  O  orçamento  é  utilizado  para  justificar  a  captação  de  recursos  dos 
contribuintes e de outros provedores de recursos e estabelece os regramentos para os dispêndios 
de recursos. 
2.19  Alguns recursos para dar suporte às atividades das entidades do setor público podem ser recebidos 
de  doadores,  credores  por  empréstimos  ou  como  resultado  de  transações  com  contraprestação. 
Entretanto,  os  recursos  se  originam,  predominantemente,  de  transações  sem  contraprestação 
advindas  dos  contribuintes  e  de  outros,  de  acordo  com  as  expectativas  refletidas  no  orçamento 
aprovado. 
2.20  Os RCPGs fornecem informação sobre os resultados (sendo descritos como “superávit ou déficit”, 
“lucro ou prejuízo”, ou por outros termos cabíveis), o desempenho e os fluxos de caixa da entidade 
durante o  exercício,  os  ativos  e  os  passivos na  data  do relatório  e  as  alterações  realizadas nesses 
itens  durante  o  período  (situação  patrimonial),  bem  como  os  resultados  obtidos  na  prestação  de 
serviços. 
2.21  A  inclusão  nos  RCPGs  de  informação  que  auxilia  os  usuários  na  avaliação  da  extensão  na  qual  as 
receitas,  as  despesas,  os  fluxos  de  caixa  e  os  resultados  financeiros  da  entidade  devem  estar  em 
conformidade com as estimativas refletidas nos orçamentos aprovados, bem como a aderência da 
entidade à legislação ou outra regulamentação acerca da captação e da utilização dos recursos, é 
importante  para  a  determinação  de  quão  bem  a  entidade  do  setor  público  alcançou  os  seus 
objetivos financeiros.  Tal  informação é necessária  para  a prestação  de  contas  e  responsabilização 
(accountability) do governo ou de outra entidade do setor público perante os administrados, para o 
aprimoramento da avaliação do desempenho da entidade e para a tomada de decisão. 
Resultado da prestação de serviços 
2.22  O objetivo principal dos governos e da maioria das entidades do setor público é prestar os serviços 
necessários  para  a  sociedade.  Consequentemente,  o  desempenho  dos  governos  e  da  maioria  das 
entidades  do  setor  público  não  está  total  ou  adequadamente  refletido  em  qualquer  medida  de 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
18 
 
resultados financeiros. Portanto, os resultados financeiros necessitam ser avaliados no contexto dos 
resultados da prestação de serviços à sociedade. 
2.23  Em  alguns  casos,  as  mensurações  quantitativas  dos  produtos  e  resultados  das  atividades  de 
prestação  de  serviços  da  entidade  durante  o  exercício  fornecem  informações  relevantes  sobre  o 
cumprimento dos objetivos da prestação de serviços – por exemplo, a informação sobre o custo, o 
volume e a frequência da prestação de serviços e a relação dos serviços prestados com a quantidade 
de recursos da entidade. Em outros casos, pode ser necessário comunicar a realização dos objetivos 
da prestação de serviços por meio da explicação da qualidade de determinados serviços prestados 
ou do resultado de determinados programas. 
2.24  A  divulgação  de  informações  não  financeiras  e  de  informações  financeiras  das  atividades  de 
prestação de serviços, desempenho e/ou os resultados durante o exercício, fornecem insumos para 
avaliações  da  economicidade,  da  eficiência  e  da eficácia das  operações da  entidade.  A divulgação 
dessas  informações  é  necessária  para  que  o  governo  ou  outra  entidade  do  setor  público  cumpra 
com suas obrigações de prestação de contas e responsabilização (accountability) – isto é, justificar 
a  utilização dos recursos  captados  da  sociedade ou em nome dela. Decisões de doadores  sobre  a 
alocação de  recursos para  entidades e programas  específicos  são  também  tomadas  com base  em 
informação  sobre  os  resultados  da  prestação  de  serviços  durante  o  período  e  os  objetivos  da 
prestação de serviços no futuro (pelo menos em parte). 
Informações financeiras e não financeiras prospectivas 
2.25  Dada  a  longevidade  das  entidades  do  setor  público  e  de  muitos  programas  governamentais,  os 
efeitos  financeiros  de  muitas  decisões  tomadas  no  exercício  somente  podem  se  tornar  evidentes 
vários  anos  depois.  As  demonstrações  contábeis  que  apresentam  informação  sobre  a  situação 
patrimonial em um ponto no tempo e sobre o desempenho e os fluxos de caixa durante o exercício 
precisam ser avaliadas no contexto de longo prazo. 
2.26 As decisões tomadas pelo governo ou por outra entidade do setor público em determinado período 
sobre programas para a prestação e financiamento de serviços no futuro podem ter consequências 
significativas para: 
(a) os usuários que são dependentes desses serviços no futuro; e 
(b) as gerações atuais e futuras de contribuintes e outros provedores involuntários que recolhem 
tributos  e  taxas  para  financiar  as  atividades  planejadas  de  prestação  de  serviços  e  os 
compromissos financeiros relacionados. 
2.27 As informações sobre os objetivos e atividades previstas de prestação de serviços futuros, bem como 
o impacto provável nas necessidades futuras de recursos pela entidade e as fontes de financiamento 
prováveis, são necessárias como subsídio para qualquer avaliação da capacidade do governo ou de 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
19 
 
outra entidade do setor público em satisfazer os seus compromissos financeiros e de prestação de 
serviços   no   futuro.   A   evidenciação   de   tais   informações   nos   RCPGs   permite   avaliações   da 
sustentabilidade  da  prestação  de  serviços  pelo  governo  ou  outra  entidade do  setor  público, 
aprimora  a  prestação  de  contas  e  responsabilização  (accountability)  e  fornece  informação  útil 
adicional para fins de tomada de decisão. 
Informação explicativa 
2.28  As  informações  sobre  os  principais  fatores  relacionados  ao  desempenho  e  aos  resultados  da 
prestação  de  serviços  da  entidade  durante  o  exercício  e  sobre  as  premissas  que  corroboram  as 
expectativas  sobre  esses  fatores  que  provavelmente  irão  influenciar o desempenho  futuro  da 
entidade podem ser apresentadas nos RCPGs em notas explicativas às demonstrações contábeis ou 
em relatórios separados. Tal informação irá auxiliar os usuários a entenderem melhor, e no contexto 
adequado, as informações financeiras e não financeiras incluídas nos RCPGs e, ainda, aprimorar o 
papel  dos  RCPGs,  no  sentido  de  fornecer  informação  útil  para  fins  de  prestação  de  contas  e 
responsabilização (accountability) e tomada de decisão. 
Demonstrações contábeis e a informação que as aprimore, complemente e suplemente 
2.29  O alcance da elaboração e da divulgação da informação contábil estabelece o limite das transações, 
outros eventos e atividades que podem ser reportadas nos RCPGs. Para responder às necessidades 
de  informação  dos usuários,  esta  Estrutura  Conceitual  reflete  o  alcance  da  elaboração  e  da 
divulgação   da   informação   contábil,   que   é   mais   abrangente   do   que   é   evidenciado   pelas 
demonstrações  contábeis.  Ela  fornece  a  apresentação  nos  RCPGs  de  informação  adicional  que 
aprimore, complemente e suplemente essas demonstrações. 
2.30  Mesmo  que  a  estrutura  conceitual  preveja  que  o  alcance  da  elaboração  e  da  divulgação  da 
informação contábil seja mais abrangente do que aquela evidenciada nas demonstrações contábeis, 
a informação apresentada nestas últimas permanece sendo o núcleo da elaboração e da divulgação 
da informação contábil. A forma na qual os elementos das demonstrações contábeis são definidos, 
reconhecidos e mensurados e as formas de apresentação e comunicação que podem ser adotadas 
para  a  informação  incluída  nos  RCPGs  são consideradas  em  outros  capítulos  desta  Estrutura 
Conceitual, e no desenvolvimento de outras normas, quando for apropriado. 
Outras fontes de informação 
2.31  Os  RCPGs  têm  papel  significativo  em  fornecer  a  informação  necessária  para  dar  suporte  ao 
cumprimento  da  obrigação  do  governo  ou  de  outra  entidade do  setor  público  em  prestar  contas, 
assim como o de fornecer informação útil para a tomada de decisão. Entretanto, é improvável que 
os  RCPGs  forneçam  todas  as  informações  que  os  usuários  necessitem  para  fins  de  prestação  de 
contas   e   responsabilização   (accountability)   e   tomada   de   decisão. Por   exemplo,   embora   a 
comparação  entre  as  informações  orçamentárias  atual  e  a  do  período  anterior  possa  ser  incluída 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
20 
 
nos  RCPGs,  os  orçamentos  e  outros  relatórios  emitidos  pelos  governos  fornecem  informações 
financeiras e não financeiras mais detalhadas sobre as características financeiras de curto e médio 
prazos dos planos dos governos e de outras entidades do setor público. Os governos e as agências 
independentes também emitem relatórios sobre a necessidade e a sustentabilidade das iniciativas 
existentes  de  prestação  de  serviços  e  das  condições  econômicas  previstas  e  das  mudanças  na 
demografia da jurisdição a médio e longo prazos que influenciarão os orçamentos e as necessidades 
de prestação de serviços no futuro. Consequentemente, os usuários dos serviços e os provedores 
de recursos podem também considerar informação de outras fontes, inclusive os relatórios sobre as 
condições  econômicas  atuais  e  projetadas,  orçamentos  e  conjunturas  governamentais,  além  de 
informação sobre as iniciativas de políticas governamentais não relatadas nos RCPGs. 
Capítulo 3 – Características Qualitativas 
Introdução 
3.1  Os  RCPGs  apresentam  informações  financeiras  e  não  financeiras  sobre  fenômenos  econômicos, 
além  de  outros  fenômenos.  As  características  qualitativas  da  informação  incluída  nos  RCPGs  são 
atributos  que  tornam  a  informação  útil  para  os  usuários  e  dão  suporte  ao  cumprimento  dos 
objetivos da elaboração e da divulgação da informação contábil. Esse objetivo é fornecer informação 
para fins de prestação de contas e responsabilização (accountability) e tomada de decisão. 
3.2  As características qualitativas da informação incluída nos RCPGs são a relevância, a representação 
fidedigna, a compreensibilidade, a tempestividade, a comparabilidade e a verificabilidade. 
3.3  As restrições inerentes à informação contida nos RCPGs são a materialidade, o custo-benefício e o 
alcance do equilíbrio apropriado entre as características qualitativas. 
3.4  Cada  uma  das  características  qualitativas  é  integrada  e  funciona  em  conjunto  com  as  outras 
características,  de  modo  a  fornecer  informação  útil  nos  RCPGs  para  cumprir  os  objetivos  da 
elaboração e a divulgação da  informação  contábil.  Entretanto,  na prática, talvez  não  seja  possível 
alcançar todas as características qualitativas e, nesse caso, um equilíbrio ou uma compensação entre 
algumas delas poderá ser necessário. 
3.5  As  características  qualitativas  se  aplicam  a  todas  as  informações  financeiras  e  não  financeiras 
apresentadas  nos  RCPGs,  inclusive  às  informações  histórica  e  prospectiva,  além  da  informação 
explicativa.  Contudo,  pode  haver  variação  no  grau  que  as  características  qualitativas  podem  ser 
alcançadas,  dependendo  do  nível  de  incerteza  e  de  avaliação  subjetiva  envolvidos  na  compilação 
das   informações   financeiras   e   não   financeiras.   A   necessidade   de   orientação   adicional   na 
interpretação e aplicação das características qualitativas àquilo que estende o alcance da elaboração 
e   da   divulgação   da   informação   contábil   para   além   das   demonstrações   contábeis   deve   ser 
considerada no desenvolvimento de qualquer NBC TSP ou de outras disposições do CFC inerentes 
às entidades do setor público e que tratam de tais questões. 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
21 
 
Relevância 
3.6  As  informações  financeiras  e  não  financeiras  são  relevantes  caso  sejam  capazes  de  influenciar 
significativamente  o  cumprimento  dos  objetivos  da  elaboração  e  da  divulgação  da  informação 
contábil. Elas são capazes de exercer essa influência quando têm valor confirmatório, preditivo ou 
ambos. A informação pode ser capaz de influenciar e, desse modo, ser relevante, mesmo se alguns 
usuários decidirem não considerá-la ou já estiverem cientes dela. 
3.7  As informações financeiras e não financeiras têm valor confirmatório se confirmarem ou alterarem 
expectativas passadas (ou presentes). Por exemplo, a informação é relevante, para fins de prestação 
de  contas  e  responsabilização  (accountability)  e  tomada  de  decisão,  se  confirmar  as  expectativas 
sobre questões, tais como: a extensão na qual os gestores cumpriram as suas responsabilidades pelo 
uso eficiente e eficaz dos recursos; a realização dos objetivos especificados da prestação de serviços; 
e o cumprimento da legislação e de regulamentos orçamentários, além de outros. 
3.8  Os  RCPGs  podem  apresentar  informação  acerca  dos  objetivos,  custos  e  atividades  previstas  de 
prestação de serviços, além do montante e das fontes de recursos que se destinam a serem alocadas 
na  prestação  de  serviços  no  futuro.  Tal  informação  voltada  para  o futuro  tem  valor  preditivo  e  é 
relevante para fins de prestação de contas e responsabilização (accountability) e tomada de decisão. 
A informação sobre fenômenos econômicos e outros que existam ou já tenham ocorrido também 
pode ter valor preditivo ao auxiliar a formar expectativas sobre o futuro. Por exemplo, a informação 
que  confirma  ou  refuta  expectativas  passadas  pode  reforçar  ou  alterar  expectativas  sobre  o 
desempenho e os resultados da prestação de serviços que possam ocorrer no futuro. 
3.9  As  funções  confirmatória  e  preditiva  da  informação  são  inter-relacionadas,  por  exemplo,  a 
informação  sobre  o  nível  e  a  estrutura  atual  dos  recursos  da  entidade  e  as  demandas  por  esses 
recursos auxilia os usuários a confirmarem o resultado das estratégias de gestão durante o período, 
além de preverem a capacidade da entidade em responder às mudanças e às necessidades previstas 
relacionadas à prestação de serviços no futuro. A mesma informação auxilia a confirmar ou a corrigir 
as expectativas e previsões passadas dos usuários acerca da capacidade da entidade de responder 
a  tais  alterações.  Auxilia  também  a  confirmar  ou  corrigir  as  informações  financeiras  prospectivas 
incluídas nos RCPGs anteriores. 
Representação fidedigna 
3.10  Para ser útil na elaboração e na divulgação da informação contábil, a informação deve corresponder 
à  representação  fidedigna  dos  fenômenos  econômicos  e  outros  que  se  pretenda  representar.  A 
representação  fidedigna  é  alcançada quando  a  representação do fenômeno  é  completa,  neutra e 
livre de erro material. A informação que representa fielmente um fenômeno econômico ou outro 
fenômeno retrata a substância da transação, a qual pode não corresponder, necessariamente, à sua 
forma jurídica. 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
22 
 
3.11  Na prática, pode não ser possível ter certeza ou saber se a informação apresentada nos RCPGs está 
completa, neutra e livre de erro material. Entretanto, a informação deve estar completa, neutra e 
livre de erro material tanto quanto possível. 
3.12  A omissão de algumas informações pode fazer com que a representação do fenômeno econômico 
ou outro qualquer seja falsa ou enganosa, não sendo útil para os usuários dos RCPGs. Por exemplo, 
a descrição completa de item do imobilizado nos RCPGs deve incluir a representação numérica do 
montante  agregado  do  item  juntamente  com  outras  informações  quantitativas,  descritivas  e 
explicativas necessárias para representar fielmente essa classe de ativo. Em alguns casos, isso pode 
incluir  a  evidenciação  de  informação  sobre  questões,  tais  como:  as  classes  importantes  do 
imobilizado;  os  fatores  que  afetaram  a  sua  utilização  no  passado  ou  que  podem  impactar  a  sua 
utilização  no  futuro;  e  a  base  e  o  processo  para  determinar  a  sua  representação  numérica.  Do 
mesmo  modo,  as  informações  financeiras  e  não  financeiras  prospectivas  e  a  informação  sobre  o 
cumprimento  dos  objetivos  e  dos  resultados  incluídos  nos  RCPGs  devem  ser  apresentadas  em 
conjunto com as premissas-chave e quaisquer explicações que sejam necessárias para assegurar que 
a sua representação seja completa e útil para os usuários. 
3.13  A  neutralidade  na  elaboração  e  na  divulgação  da  informação  contábil  corresponde  à  ausência  de 
viés. Isso significa que a seleção e a apresentação das informações financeiras e não financeiras não 
devem ser feitas com a intenção de se atingir um resultado particular predeterminado, por exemplo, 
para  influenciar  a  avaliação  dos  usuários  acerca  da  prestação  de  contas  e  responsabilização 
(accountability) por parte da entidade, para uma decisão ou julgamento que está para ser feito, ou, 
ainda, para induzir a determinado comportamento. 
3.14  A informação neutra representa fielmente os fenômenos econômicos e outros fenômenos que ela 
se  propõe  a  representar.  Contudo,  exigir  que  a  informação  incluída  nos  RCPGs  seja  neutra  não 
significa que não haja propósito ou que não influencie algum comportamento. A relevância é uma 
característica  qualitativa,  e,  por  definição,  a  informação  relevante  é  capaz  de  influenciar  as 
avaliações e as decisões dos seus usuários. 
 3.14A A neutralidade é apoiada pelo exercício da prudência. Prudência é o exercício de cautela ao fazer 
julgamentos sob condições de incerteza. O exercício da prudência significa que os ativos e as receitas 
não  são  superavaliados  e  os  passivos  e  as  despesas  não  são  subavaliados.  Da  mesma  forma,  o 
exercício  da  prudência  não  permite  a  subavaliação  de  ativos  ou  receitas  ou  a  superavaliação  de 
passivos ou despesas. Essas distorções podem levar à superavaliação ou subavaliação de receitas ou 
despesas em períodos futuros.  
 3.14B  O  exercício  de  prudência  não  implica  necessidade  de  assimetria,  por  exemplo,  a  necessidade 
sistemática de evidência mais persuasiva para apoiar o reconhecimento de ativos ou receitas do que 
o   reconhecimento   de   passivos   ou   despesas.   Normas   específicas podem   conter   requisitos 
assimétricos se isso for consequência de decisões que se destinam a selecionar as informações mais 
relevantes que representam fidedignamente o que se pretende representar.  

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
23 
 
3.15  Os  fenômenos  econômicos  e  outros  fenômenos  representados  nos  RCPGs  ocorrem  normalmente 
sob  condições  de  incerteza.  Desse  modo,  a  informação  incluída  nos  RCPGs  frequentemente 
apresenta  estimativas  que  incorporam  o  julgamento  de  valor  dos  gestores.  Para  representar 
fielmente o fenômeno econômico ou de outra natureza, a estimativa deve ser baseada em dados 
apropriados e cada um deles precisa refletir a melhor informação disponível. Deve-se ter o devido 
cuidado   ao   se   lidar   com   condições   de   incerteza.   Às   vezes,   pode   ser   necessário   divulgar 
explicitamente o nível de incerteza das informações financeiras e não financeiras para representar 
fielmente fenômenos econômicos ou de outra natureza. 
3.16  Estar livre de erro material não significa exatidão completa em todos os aspectos. Estar livre de erro 
material  significa  que  não  há  erros  ou  omissões  que  sejam  individualmente  ou  coletivamente 
relevantes  na  descrição  do  fenômeno,  e  que  o  processo  utilizado  para  produzir  a  informação 
relatada foi aplicado conforme descrito. Em alguns casos, pode ser possível determinar a exatidão 
de   alguma   informação   incluída   nos   RCPGs,   por   exemplo,   o   montante   da   transferência   de 
disponibilidades para outra esfera de governo, o volume dos serviços prestados ou o valor pago pela 
aquisição de item do imobilizado. Entretanto, em outros casos pode não ser possível determinar a 
exatidão  da  informação,  por  exemplo,  pode  não  ser  possível  estimar  a  eficácia  de  programa  de 
prestação de serviços com exatidão ou o valor ou custo do item. Nesses casos, a estimativa está livre 
de erro material se o montante for descrito claramente como sendo uma estimativa, se a natureza 
e  as  limitações  do  processo  de  estimativa  forem  explicadas  e  se  nenhum  erro  material  tiver  sido 
identificado na seleção e na aplicação do processo de elaboração da estimativa. 
Compreensibilidade 
3.17  A  compreensibilidade  é  a  qualidade  da  informação  que  permite  que  os  usuários  compreendam  o 
seu  significado.  Os  RCPGs  devem  apresentar  a  informação  de  maneira  que  corresponda  às 
necessidades  e  à  base  do  conhecimento  dos  usuários,  bem  como  a  natureza  da  informação 
apresentada. Por exemplo, as explicações acerca das informações financeiras e não financeiras e as 
informações adicionais acerca da prestação de serviços e outros resultados durante o exercício, além 
das expectativas para os períodos futuros, devem ser escritas em linguagem simples e apresentadas 
de maneira que sejam prontamente compreensíveis pelos usuários. A compreensão é aprimorada 
quando  a  informação  é  classificada  e  apresentada  de  maneira  clara  e  sucinta.  A  comparabilidade 
pode também aprimorar a compreensibilidade. 
3.18  Espera-se que os usuários dos RCPGs tenham conhecimento razoável das atividades da entidade e 
do  ambiente  no  qual  ela  funciona,  além  de  serem  capazes  e  preparados  para  lerem  os  RCPGs  e 
revisarem e analisarem a informação apresentada com a diligência apropriada. Alguns fenômenos 
econômicos e de outra natureza são particularmente complexos e difíceis de serem representados 
nos  RCPGs,  e  alguns  usuários  podem  precisar  de  ajuda  de  assistente  para  auxiliá-los  em  sua 
compreensão. Todos os esforços devem ser realizados para representar os fenômenos econômicos 
e  de  outra  natureza  incluídos  nos  RCPGs  de  maneira  que  seja  compreensível  para uma  ampla 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
24 
 
variedade de usuários. Contudo, a informação não deve ser excluída dos RCPGs somente pelo fato 
de ser muito complexa ou ser difícil para alguns usuários compreenderem sem a devida assistência. 
Tempestividade 
3.19  Tempestividade  significa  ter  informação  disponível  para  os  usuários  antes  que  ela  perca  a  sua 
capacidade de ser útil para fins de prestação de contas e responsabilização (accountability) e tomada 
de  decisão.  Ter  informação  disponível  mais  rapidamente  pode  aprimorar  a  sua  utilidade  como 
insumo para processos de avaliação da prestação de contas e responsabilização (accountability) e a 
sua  capacidade  de  informar  e  influenciar  os  processos  decisórios.  A  ausência  de  tempestividade 
pode tornar a informação menos útil. 
3.20  Alguns itens de informação podem continuar sendo úteis por bastante tempo após a publicação do 
relatório  ou  após  o  encerramento  do  exercício.  Por  exemplo,  para  fins  de  prestação  de  contas  e 
responsabilização  (accountability)  e  tomada  de  decisão,  os  usuários  dos  RCPGs  podem  precisar 
avaliar as projeções do desempenho e da prestação de serviços da entidade e a sua conformidade 
com  os  orçamentos  por  vários  exercícios.  Adicionalmente,  o  resultado  e  os  efeitos  de  alguns 
programas de  prestação  de  serviços  podem  não  ser  determináveis  até  períodos  futuros,  por 
exemplo,  em  relação  aos  programas  em  que  se  tenha  a  intenção  de  aprimorar  o  bem-estar 
econômico  da  sociedade,  reduzir  a  incidência  de  determinada  doença  ou  aumentar  os  níveis  de 
alfabetização de determinados grupos etários. 
Comparabilidade 
3.21  Comparabilidade é a qualidade da informação que possibilita aos usuários identificar semelhanças 
e diferenças entre dois conjuntos de fenômenos. A comparabilidade não é uma qualidade de item 
individual de informação, mas, antes, a qualidade da relação entre dois ou mais itens de informação. 
3.22 A comparabilidade difere da consistência. A consistência se refere à utilização dos mesmos princípios 
ou políticas contábeis e da mesma base de elaboração, seja de período a período dentro da entidade 
ou de um único período entre duas ou mais entidades. A comparabilidade é o objetivo, enquanto a 
consistência auxilia a atingi-lo. Em alguns casos, os princípios ou políticas contábeis adotadas pela 
entidade  podem  ser  revisados  para  melhor  representar  determinada  transação  ou  evento  nos 
RCPGs. Nesses casos, a inclusão de evidenciação ou explicação adicional pode ser necessária para 
satisfazer as características da comparabilidade. 
3.23  A comparabilidade também difere da uniformidade. Para que a informação seja comparável, coisas 
semelhantes  devem  parecer  semelhantes  e  coisas  distintas  devem  parecer  distintas.  A  ênfase 
demasiada  na  uniformidade  pode  reduzir  a  comparabilidade  ao  fazer  com que  coisas  distintas 
pareçam semelhantes. A comparabilidade da informação nos RCPGs não é aprimorada ao se fazer 
com que coisas distintas pareçam semelhantes, assim como ao fazer com que coisas semelhantes 
pareçam distintas. 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
25 
 
3.24  A  informação  sobre  a  situação  patrimonial  da  entidade,  o  desempenho,  os  fluxos  de  caixa,  a 
conformidade com os orçamentos aprovados ou com outra legislação relevante ou com os demais 
regulamentos relacionados à captação e à utilização dos recursos, o desempenho da prestação de 
serviços e os seus planos futuros, é necessária para fins de prestação de contas e responsabilização 
(accountability)  e  tomada  de  decisão.  A  utilidade  de  tal  informação  é  aprimorada  se  puder  ser 
comparada com, por exemplo: 
(a)  informações  financeiras  e  não  financeiras  prospectivas  anteriormente  apresentadas  para 
aquele exercício ou data do relatório; 
(b)  informação  similar  sobre  a  mesma  entidade referente  a  algum outro  exercício  ou  a  algum 
outro momento no tempo; e 
(c)  informação  similar  sobre  outras  entidades  (por  exemplo,  entidades  do  setor  público 
prestando serviços semelhantes em jurisdições distintas) para o mesmo exercício. 
3.25  A  aplicação  consistente  dos  princípios  contábeis,  das  políticas  e  da  base  de  elaboração  para  as 
informações   financeiras   e   não   financeiras   prospectivas   aprimora   a   utilidade   de   qualquer 
comparação  entre  os  resultados  projetados  e  os  reais.  A  comparabilidade com  outras  entidades 
pode  ser  menos  significativa  para  as  explicações da  percepção ou opinião  dos  gestores  acerca  de 
fatores relacionados ao desempenho atual da entidade. 
Verificabilidade 
3.26  A verificabilidade é a qualidade da informação que ajuda a assegurar aos usuários que a informação 
contida  nos  RCPGs  representa  fielmente  os  fenômenos  econômicos  ou  de  outra  natureza  que  se 
propõe a representar. A suportabilidade, ou seja, a qualidade referente àquilo que dá suporte a algo, 
algumas vezes é utilizada para descrever esta qualidade, quando aplicada em relação à informação 
explicativa e à informação quantitativa financeira e não financeira prospectiva divulgada nos RCPGs. 
Quer  referida  como  verificabilidade  ou  como  suportabilidade,  a  característica  implica  que  dois 
observadores   esclarecidos   e   independentes   podem   chegar   ao   consenso   geral,   mas   não 
necessariamente à concordância completa, em que: 
(a) a informação representa os fenômenos econômicos e de outra natureza, os quais se pretende 
representar sem erro material ou viés; ou 
(b) o reconhecimento apropriado, a mensuração ou o método de representação foi aplicado sem 
erro material ou viés. 
3.27  Para  ser  verificável,  a  informação  não  precisa  ser  um  ponto  único  estimado.  Um  intervalo  de 
possíveis valores e suas probabilidades relacionadas também pode ser utilizado. 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
26 
 
3.28  A  verificação  pode  ocorrer  de  forma  direta  ou  indireta.  Com  a  verificação  direta,  o  montante  ou 
outra representação podem ser verificados em si mesmos, tais como: pela contagem de caixa, pela 
observação de títulos negociáveis e suas cotações de preço, ou pela confirmação de que os fatores 
identificados que influenciaram o desempenho passado estejam presentes e relacionados com os 
efeitos  identificados.  Com  a  verificação  indireta,  o  montante  ou  outra  representação  podem  ser 
verificados  ao  se  checar  os dados  e  recalcular  os  resultados  utilizando  a  mesma  convenção  ou 
metodologia contábil. Um exemplo corresponde à verificação do valor contábil do estoque por meio 
da  conferência  das  entradas  (quantidades  e  custos)  e  do  recálculo  do  estoque  final  utilizando o 
mesmo método de mensuração (por exemplo, custo médio ou “primeiro que entra, primeiro que 
sai” (PEPS)). 
3.29  A  qualidade  da  verificabilidade  (ou  suportabilidade,  se  tal termo  for utilizado  para descrever  essa 
característica) não é absoluta – alguma informação pode ser mais ou menos passível de verificação 
do  que  outra.  Contudo,  quanto  mais  verificável  for  a  informação  incluída  nos  RCPGs,  mais  se  irá 
assegurar aos usuários de que a informação representa fielmente os fenômenos econômicos, ou de 
outra natureza os quais se pretende representar. 
3.30  Os RCPGs podem incluir informação financeira e outra informação quantitativa, além de explicação 
sobre  (a)  as  influências-chave  a  respeito  do  desempenho  da  entidade  durante  o  período;  (b)  os 
efeitos ou resultados futuros projetados dos programas de prestação de serviços realizados durante 
o  período;  e  (c)  informações  financeiras  e  não  financeiras  prospectivas.  Pode  não  ser  possível 
verificar  a  exatidão  de  todas  as  representações  quantitativas  e  explicações  de  tal  informação  até 
período futuro. 
3.31  Para  ajudar  a  assegurar  aos  usuários  que  a  informação  quantitativa  financeira  e  não  financeira 
(prospectivas)   e   as   explicações   incluídas   nos   RCPGs   representam   fielmente   os   fenômenos 
econômicos ou de outra natureza os quais se pretende representar, deve haver transparência nas 
premissas   observadas   em   relação   à   informação   divulgada,   nas metodologias   adotadas   na 
compilação  dessa  informação  e  nos  fatores  e  nas  circunstâncias  que  apoiam  quaisquer  opiniões 
expressas   ou   evidenciações   feitas.   Isso   possibilita aos   usuários   formarem   opinião   sobre   a 
adequabilidade dessas  premissas  e  sobre  o  método de  compilação, mensuração,  representação  e 
interpretação da informação. 
Restrições acerca da informação incluída nos RCPGs 
Materialidade 
3.32  A informação é material se a sua omissão ou distorção puder influenciar o cumprimento do dever 
de prestação de contas e responsabilização (accountability), ou as decisões que os usuários tomam 
com base nos RCPGs elaborados para aquele exercício. A materialidade depende tanto da natureza 
quanto do montante do item analisado dentro das particularidades de cada entidade.  

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
27 
 
3.33  As  avaliações  de  materialidade  são  feitas  no  contexto  do  ambiente  legislativo,  institucional  e 
operacional dentro do qual as entidades funcionam e, em relação às informações financeiras e não 
financeiras prospectivas, o conhecimento de quem as elabora e as expectativas acerca do futuro. A 
evidenciação  da  informação  sobre  a  conformidade,  ou  não,  com  a  legislação,  regulamentação  ou 
outro  normativo  pode  ser  material  devido  à  sua  natureza,  independentemente  da  magnitude  de 
quaisquer dos montantes envolvidos. Nesse contexto, ao se determinar se um item é material, deve-
se levar em consideração questões, tais como a natureza, a legalidade, a sensibilidade e os efeitos 
de  eventos  e  transações  passados  ou  previstos;  as  partes  envolvidas  em  tais  transações;  e  as 
circunstâncias que deram origem a essas transações. 
3.3A  Os RCPGs  podem  englobar  informação  qualitativa  e  quantitativa  acerca  do  cumprimento  da 
prestação  de  serviços  durante  o  período  de  referência  e  das  expectativas  sobre  a  prestação  de 
serviço  e  o  desempenho  no  futuro.  Consequentemente,  não  é  possível  especificar um  limite 
quantitativo uniforme no qual determinada informação se torna material.  
3.34  De  acordo  com  esta Estrutura Conceitual,  a  materialidade  é  classificada  como  uma  restrição  na 
informação  incluída  nos  RCPGs.  Ao  se  desenvolver  as  NBCs  TSP  e  outras  disposições,  deve-se 
considerar a materialidade dos efeitos da aplicação de uma política contábil específica. Sujeitas aos 
requisitos  de  quaisquer  NBCs  TSP,  a  entidade,  ao  elaborar  os  RCPGs,  deve  considerar  também  a 
materialidade, por exemplo, da aplicação de uma política contábil específica e da evidenciação em 
separado de determinados itens da informação. 
Custo-benefício 
3.35 A  elaboração  e  a  divulgação da  informação  contábil  impõem  custos,  e  seus  benefícios  devem 
justificá-los.  Avaliar  se os  benefícios  da elaboração  e  da divulgação da  informação  justificam  seus 
custos é, com frequência, uma questão de julgamento de valor, pois não é possível identificar todos 
os custos e todos os benefícios da informação incluída nos RCPGs. 
3.36  Os custos, para fornecerem a informação, incluem os de coleta, de processamento e de verificação 
e/ou  de  apresentação  das  premissas  e  das  metodologias  que  dão  suporte  a  elas,  além  dos  de 
disseminação. Os usuários incorrem nos custos da análise e interpretação. A omissão da informação 
útil  também  impõe  custos,  inclusive  aqueles  em  que  os  usuários  incorrem  na  obtenção  de 
informação  necessária  de  terceiros,  além  dos  custos  advindos  da  tomada  de  decisão  utilizando 
dados incompletos fornecidos pelos RCPGs. 
3.37  Os responsáveis pelos RCPGs envidam a maior parte dos seus esforços para agregar informação aos 
relatórios. Entretanto, os usuários dos serviços e os provedores de recursos acabam por assumir os 
custos desses esforços, uma vez que os recursos são redirecionados da prestação de serviços para a 
elaboração da informação dos RCPGs. 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
28 
 
3.38  Os  usuários  em  geral  obtêm  a  maior  parte dos benefícios  das  informações  fornecidas  nos  RCPGs. 
Contudo,  a  informação  elaborada  para  os  RCPGs  também  pode  ser  utilizada  internamente  pela 
administração, influenciando o processo decisório por parte dela. A evidenciação da informação nos 
RCPGs,  consistente  com  os  conceitos  desta Estrutura Conceitual  e  das  NBCs  TSP  e  com  outras 
disposições do CFC, deve aprimorar e reforçar as percepções da transparência da elaboração e da 
divulgação da informação contábil pelos governos e por outras entidades do setor público, além de 
contribuir para a avaliação mais precisa da dívida pública. Portanto, as entidades do setor público 
podem beneficiar-se de diversas maneiras da informação fornecida nos RCPGs. 
3.39  A  aplicação  da  restrição custo-benefício  envolve avaliar  se  os  benefícios de divulgar  a  informação 
provavelmente justificam os custos incorridos para fornecê-la e utilizá-la. Ao fazer essa avaliação, é 
necessário considerar se uma ou mais características qualitativas podem ser sacrificadas até certo 
ponto para reduzir o custo. 
3.40  Ao se desenvolverem as NBCs TSP, leva-se em consideração a informação obtida dos responsáveis 
pelas  demonstrações,  dos  usuários,  da  academia  e  de  outros  atores,  acerca  da  natureza  e  dos 
benefícios  esperados,  bem  como  dos  custos  dos  requisitos  propostos. A  divulgação  e  outros 
requisitos que resultem na apresentação de informação útil aos usuários dos RCPGs para efeitos do 
dever  de  prestação  de  contas  e  responsabilização  (accountability)  e  de  tomada  de  decisão  e  que 
satisfaçam  as  características  qualitativas  são  prescritos  pelas  NBCs  TSP  quando  os  benefícios  do 
cumprimento  dessas  divulgações  e  outros  requisitos  são  avaliados  pelo  CFC  para  justificar  seus 
custos.  
Equilíbrio entre as características qualitativas 
3.41  As  características  qualitativas  funcionam,  conjuntamente,  para  contribuir  com  a  utilidade  da 
informação. Por exemplo, nem a descrição que represente fielmente um fenômeno irrelevante, nem 
a descrição que represente de modo não fidedigno um fenômeno relevante resultam em informação 
útil. Do mesmo modo, para ser relevante, a informação precisar ser tempestiva e compreensível. 
3.42  Em alguns casos, o equilíbrio ou a compensação (trade-off) entre as características qualitativas pode 
ser necessário para se alcançar os objetivos da elaboração e da divulgação da informação contábil. 
A  importância  relativa  das  características  qualitativas  em  cada  situação  é  uma  questão  de 
julgamento  profissional.  A  meta  é  alcançar  o  equilíbrio  apropriado  entre  as  características  para 
satisfazer os objetivos da elaboração e da divulgação da informação contábil. 
Capítulo 4 – Entidade que Reporta a Informação Contábil 
Introdução 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
29 
 
4.1  A entidade do setor público que reporta a informação contábil é um ente governamental ou outra 
organização, programa ou outra área identificável de atividade (doravante referida como entidade 
ou entidade do setor público) que elabora os RCPGs. 
4.2  A  entidade  do  setor  público  que  reporta  a  informação  contábil  pode  compreender  duas  ou  mais 
entidades que apresentem os RCPGs como se fossem uma única entidade – tal entidade é referida 
como grupo de entidades que reportam a informação contábil. 
Características-chave de entidade do setor público que reporta a informação contábil 
4.3  As características-chave de entidade do setor público que reporta a informação contábil são: 
(a) ser uma entidade que capta recursos da sociedade ou em nome dessa e/ou utiliza recursos 
para realizar atividades em benefício dela; e 
(b) existir usuários de serviços ou provedores de recursos dependentes de informações contidas 
nos RCPGs para fins de prestação de contas e responsabilização (accountability) e tomada 
de decisão. 
4.4  O  governo  pode  estabelecer  e/ou  funcionar  por  meio  de  unidades  administrativas  como,  por 
exemplo,  ministérios,  secretarias  ou  departamentos.  Ele  pode  funcionar  também  por  meio  de 
fundos,  autoridades  estatutárias,  empresas  estatais  e  outras  entidades  com  identidade  jurídica 
própria  ou  autonomia  operacional  para  realizar,  ou  de  outra  maneira  dar  suporte  à  prestação  de 
serviços à sociedade. Outras organizações do setor público, inclusive organizações internacionais do 
setor  público  e  autoridades  municipais,  podem  realizar  também  determinadas  atividades  por 
intermédio  das  entidades  com  identidade  jurídica  própria  ou  autonomia  operacional  e  podem 
beneficiar-se e estarem sujeitas a encargo financeiro ou perda resultante das atividades. 
4.5  Os RCPGs são elaborados para reportar informação útil aos usuários para fins de prestação de contas 
e responsabilização (accountability) e tomada de decisão. Os usuários de serviços ou os provedores 
de recursos são os usuários primários dos RCPGs. Consequentemente, uma característica-chave da 
entidade  do  setor  público  que  reporta  a  informação,  inclusive  de  grupo  dessas  entidades,  é  a 
existência de usuários de serviços ou provedores de recursos que são dependentes dos RCPGs para 
fins de prestação de contas e responsabilização (accountability) e tomada de decisão. 
4.6  Os RCPGs englobam as demonstrações contábeis e a informação que as aprimore, complemente e 
suplemente. As demonstrações contábeis apresentam informação sobre os recursos e as demandas 
sobre esses, além dos fluxos de caixa da entidade ou grupo de entidades que reportam a informação 
durante  o  exercício.  Portanto,  para  possibilitar  a  elaboração  das  demonstrações  contábeis,  a 
entidade  que  reporta  a  informação  deve  captar  recursos  e/ou  deve  utilizar recursos  captados 
anteriormente para realizar atividades em benefício da sociedade ou em nome dela. 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
30 
 
4.7  A existência de usuários dos RCPGs de entidade do setor público ou grupo de entidades pressupõe 
a existência de entidade que tenha a responsabilidade ou a capacidade de captar ou utilizar recursos, 
adquirir  ou  administrar  bens  públicos,  incorrer  em  passivos  ou  realizar  atividades  para  atingir  os 
objetivos  da  prestação  de  serviços.  Quanto  maiores  os  recursos  que  a  entidade  do  setor  público 
capta, administra e/ou tem a capacidade de utilizar, e quanto maiores as obrigações que incorre e 
maior o impacto econômico ou social das suas atividades, é mais provável que existam usuários de 
serviços ou provedores de recursos que sejam dependentes dos RCPGs para obter informação para 
fins de prestação de contas e responsabilização (accountability) e tomada de decisão. Na ausência 
desses fatores, em que eles não sejam significativos, é improvável que existam usuários dos RCPGs 
dessas entidades. 
4.8  A elaboração dos RCPGs não é um processo sem custos. Portanto, se a imposição de requisitos para 
a  elaboração  e  a  divulgação  da  informação  contábil  pressupõe  que  estas  devam  ser  eficientes  e 
eficazes, é importante que seja exigido que os RCPGs sejam elaborados somente pelas entidades do 
setor público para as quais existam usuários. 
4.9  Em muitos casos, é clara a existência, ou não, de usuários de serviços ou de provedores de recursos 
que   dependam   dos   RCPGs   para   fornecer   informação   para   fins   de   prestação   de   contas   e 
responsabilização (accountability) e tomada de decisão. Por exemplo, tais usuários, provavelmente, 
existem para os RCPGs de governo em nível nacional, estadual ou municipal e para as organizações 
internacionais  do  setor  público.  Isso  porque  esses  governos  e  organizações  normalmente  têm  a 
capacidade de captar recursos substanciais e/ou empregar esses recursos em nome da sociedade, 
incorrer em responsabilidades e impactar o bem-estar econômico e/ou social das comunidades que 
dependem deles para a prestação de serviços. 
4.10  Contudo,  nem  sempre  está  claro  se  há  usuários  de  serviços  ou  provedores  de  recursos  que 
dependam   dos   RCPGs   de,   por   exemplo,   departamentos   ou   órgãos   individuais   do   governo, 
programas especiais ou áreas identificáveis de atividades com informação para fins de prestação de 
contas e responsabilização (accountability) e tomada de decisão. Determinar se essas organizações, 
programas  ou  atividades  devem  ser  identificados  como  entidades  que  reportam  a  informação  e, 
consequentemente,  serem  exigidas  a  elaborarem  os  RCPGs  envolve  o  exercício  de  julgamento 
profissional. 
4.11  O  governo  e  algumas  outras  entidades  do  setor  público  têm  identidade  e  enquadramento  legal 
específicos  (personalidade  jurídica).  Entretanto, as  organizações,  os  programas  e  as  atividades  do 
setor público sem personalidade jurídica também podem captar ou empregar recursos, adquirir e 
administrar ativos, incorrer em obrigações, realizar atividades para atingir os objetivos da prestação 
de serviços ou, de outra maneira, implementar a política governamental. Os usuários de serviços e 
os  provedores  de  recursos  podem  depender  dos  RCPGs  para  obter  informação  para  os  fins  de 
prestação de contas e responsabilização (accountability) e tomada de decisão. Consequentemente, 
a  entidade  que  reporta  a  informação  contábil  do  setor  público  pode  ter  personalidade  jurídica 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
31 
 
específica ou ser, por exemplo, organização, acordo administrativo ou programa sem personalidade 
jurídica. 
Capítulo 5 – Elementos das Demonstrações Contábeis 
Introdução 
Propósito 
5.1  Este  capítulo  define  os  elementos  utilizados  nas  demonstrações  contábeis  e  fornece  explicação 
adicional acerca dessas definições. 
Elementos e sua importância 
5.2  As  demonstrações  contábeis  retratam  os  efeitos  financeiros  e  não  financeiros  das  transações  e 
outros  eventos  ao  agrupá-los  em  classes  amplas  que  compartilham  características  econômicas 
comuns.  Essas  classes  amplas  são  denominadas  elementos  das  demonstrações  contábeis.  Os 
elementos correspondem às estruturas básicas a partir das quais as demonstrações contábeis são 
elaboradas. Essas estruturas fornecem um ponto inicial para reconhecer, classificar e agregar dados 
e atividades econômicas de maneira a fornecer aos usuários informação que satisfaça os objetivos 
e atinja as características qualitativas da elaboração e da divulgação da informação contábil, levando 
em consideração as restrições sobre a informação incluída nos RCPGs. 
5.3  Os  elementos  definidos neste  capítulo  não  se  referem  aos  itens  individuais  que  são  reconhecidos 
como  resultado  de  transações  e  eventos.  As  subclassificações  dos  itens  individuais  dentro  de  um 
elemento  e  as  agregações  de  itens  são  utilizadas  para  aprimorar a  compreensibilidade  das 
demonstrações   contábeis.   A   apresentação   dos   RCPGs   é   tratada   no   Capítulo   8,   intitulado 
Apresentação  de  Informação  no  Relatório  Contábil  de  Propósito  Geral  das  Entidades  do  Setor 
Público. 
5.4  Em algumas circunstâncias, para assegurar que as demonstrações contábeis forneçam informação 
útil  para  uma  avaliação  significativa  do  desempenho  e  da  situação  patrimonial  da  entidade,  o 
reconhecimento  de  fenômenos  econômicos  não  capturados  pelos  elementos definidos  neste 
capítulo pode ser necessário. Consequentemente, a identificação dos elementos neste capítulo não 
impede as NBCs TSP de exigirem ou permitirem o reconhecimento de recursos ou obrigações que 
não  satisfaçam  a  definição  de  elemento  identificada  neste  capítulo  (doravante  referidos  como 
“outros recursos” ou “outras obrigações”), quando necessário no sentido de se alcançarem os 
objetivos da elaboração e da divulgação da informação contábil. 
Elementos 
5.5  Os elementos definidos neste capítulo são: 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
32 
 
(a) ativo; 
(b) passivo; 
(c) receita; 
(d) despesa; 
(e) contribuição dos proprietários; e  
(f) distribuição aos proprietários. 
Definições de ativo e recurso  
5.6  Ativo é um recurso controlado no presente pela entidade como resultado de evento passado. 
5.6A  Um recurso é um direito ao potencial de serviço ou à capacidade de gerar benefícios económicos, 
ou um direito a ambos.  
5.6B Esta seção discute três componentes dessas definições:  
 (a) direitos (itens 5.7A–5.7G);  
 (b) potencial de serviço e benefícios económicos (itens 5.8-5.10); e  
 (c) controle atual como resultado de eventos passados (itens 5.11 a 5.13).  
5.7 (Eliminado)  
Direitos  
5.7A  Os direitos ao potencial de serviço ou à capacidade de gerar benefícios económicos assumem muitas 
formas, incluindo:  
 (a) direitos que correspondem a uma obrigação de outra parte (ver item 5.16C), por exemplo:  
 (i) direitos de receber caixa;  

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
33 
 
 (ii) direitos de receber bens ou serviços
3
;  
(iii) direitos de permutar recursos com outra parte em condições favoráveis. Esses direitos 
incluem,  por  exemplo,  um  contrato  a  prazo  para  comprar  um  recurso  em  condições 
que sejam atualmente favoráveis; e  
 (iv) direitos de se beneficiar de uma obrigação de outra parte de transferir um recurso se 
ocorrer um evento futuro incerto especificado (ver item 5.16A);  
 (b) direitos que não correspondem a uma obrigação de outra parte, por exemplo:  
 (i) direitos  sobre  objetos  físicos,  tais  como  imobilizados  ou  estoques.  Exemplos  de  tais 
direitos são o direito de usar um objeto físico ou o direito de beneficiar de um objeto 
arrendado; e  
 (ii) direitos de uso de propriedade intelectual.  
 5.7B Muitos direitos são estabelecidos por acordos vinculantes, legislação ou meios semelhantes. Por 
exemplo, uma entidade pode obter direitos por meio da posse ou locação de um objeto físico, da 
posse de um instrumento de dívida, tal como um empréstimo estudantil, ou da posse de software 
ou do direito de utilização de propriedade intelectual. Contudo, uma entidade também pode obter 
direitos de outras formas, por exemplo:  
 (a) adquirindo ou criando conhecimento que não seja do domínio público, como um plano de 
gestão de tráfego; ou  
 (b) por  meio de  uma  obrigação  de  outra  parte  que  surge  porque  essa  última  tem  pouca  ou 
nenhuma alternativa realista para evitar uma transferência de recursos (ver item 5.15).  
5.7C Alguns  serviços – por  exemplo,  serviços  prestados  por  empregados  e  serviços  voluntários – são 
recebidos e imediatamente consumidos. O direito de uma entidade de obter o potencial de serviço 
ou os benefícios econômicos  produzidos por  esses  serviços  existe  muito  brevemente,  até que  a 
entidade consuma os serviços.  
5.7D  Nem todos os direitos de uma entidade são ativos dessa entidade. Para serem ativos da entidade, 
os direitos devem (i) ter potencial de serviço ou benefícios econômicos além daqueles disponíveis 
para todas as outras partes (ver itens 5.8 a 5.10) e (ii) ser controlados pela entidade (ver itens 5.11 
a 5.12A). Os direitos disponíveis a todas as partes sem custos significativos – por exemplo, direitos 
 
3
 As referências subsequentes a “serviços” na estrutura conceitual abrangem “bens”, a menos que o contexto indique o 
contrário. 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
34 
 
de acesso a bens públicos, como direitos públicos de passagem sobre a terra, ou conhecimento que 
seja do domínio público – normalmente não são ativos para as entidades que detêm esses direitos.  
 5.7E  Em  princípio,  cada  um  dos  direitos  de  uma  entidade  é  um  ativo  separado.  Contudo,  para  fins 
contábeis, os direitos relacionados são frequentemente tratados como uma única unidade de conta 
que é um único ativo (ver itens 5.26A-5.26J). Por exemplo, a propriedade legal de um objeto físico 
pode dar origem a vários direitos, incluindo o direito de:  
 (a) usar o objeto;  
 (b) alienar direitos sobre o objeto; e  
 (c) penhorar direitos sobre o objeto.  
5.7F  Em  muitos  casos,  o  conjunto  de  direitos  decorrentes  da  propriedade  legal  de  um  objeto  físico  é 
contabilizado  como  um único  ativo.  Conceitualmente, o  recurso  é  o  conjunto de  direitos, e não o 
objeto  físico.  No  entanto,  descrever  o  conjunto  de  direitos  como o  objeto  físico  proporcionará 
muitas vezes uma representação fiel desses direitos da forma mais concisa e compreensível.  
5.7G A relação entre direitos soberanos, recursos e um ativo é discutida no item 5.13.  
Potencial de serviço e benefícios econômicos  
5.8  O  potencial  de  serviços é  a  capacidade de  um  recurso  para  prestar  serviços  que  contribuam  para 
alcançar  os  objetivos  da  entidade.  O  potencial  de  serviços  possibilita  a  entidade  alcançar  os  seus 
objetivos sem, necessariamente, gerar entrada líquida de caixa. 
5.9  Os ativos do setor público que ensejam potencial de serviços podem ser representados pelos ativos 
de recreação, do patrimônio cultural, comunitários, de defesa nacional e outros que sejam mantidos 
pelos governos e por outras entidades do setor público e que sejam utilizados para a prestação de 
serviços  a  terceiros.  Tais  serviços  podem  ser  para  consumo  coletivo  ou  individual.  Vários  serviços 
podem ser fornecidos em áreas onde não haja concorrência de mercado ou concorrência limitada 
de mercado. A utilização e a alienação de tais ativos podem ser restritas, já que muitos ativos que 
ensejam potencial de serviços são especializados por natureza. 
5.10  Os benefícios econômicos correspondem a entradas de caixa ou a reduções das saídas de caixa. As 
entradas de caixa (ou as reduções das saídas de caixa) podem derivar, por exemplo: 
(a) da utilização do ativo na produção e na venda de serviços;  
(b) da troca direta do ativo por caixa ou por outros recursos; ou  

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
35 
 
(c) da extinção ou redução de um passivo por meio da transferência de um ativo.  
Controlado no presente pela entidade e derivado de um evento passado  
5.11  A entidade deve ter o controle do recurso. O controle do recurso envolve a capacidade da entidade 
em  utilizar  o  recurso  (ou  controlar  terceiros  na  sua  utilização)  de  modo  que  haja  a  geração  do 
potencial de serviços ou dos benefícios econômicos originados do recurso para o cumprimento dos 
seus objetivos de prestação de serviços, entre outros. 
5.12  Para  avaliar  se  a  entidade  controla  o  recurso  no  presente,  deve  ser  observada  a  existência  dos 
seguintes indicadores de controle: 
(a) propriedade legal; 
(b) acesso ao recurso ou a capacidade de negar ou restringir o acesso a esses; 
(c) meios que assegurem que o recurso seja utilizado para alcançar os seus objetivos; ou 
(d)  a  existência  de  direito  legítimo  ao  potencial  de  serviços  ou  à  capacidade  para  gerar  os 
benefícios econômicos advindos do recurso. 
Embora  esses  indicadores  não  sejam  determinantes  conclusivos  acerca  da  existência  do  controle,  sua 
identificação e análise podem subsidiar essa decisão. 
5.12A  Às  vezes,  uma  parte  (o  principal)  contrata  outra  parte  (um  agente)  para  agir  em  nome  e  em 
benefício  do  principal.  Por  exemplo,  um  principal  pode  contratar  um  agente  para  organizar  a 
distribuição  de  bens  controlados  pelo  principal  aos  beneficiários  elegíveis.  Se  um  agente  tiver  a 
custódia de um recurso controlado pelo principal, esse recurso não será um ativo do agente.  
5.12 B e 5.12C (Eliminados).  
5.13  A  definição  de  ativo  exige  que  o  recurso  controlado  pela  entidade  no  presente  tenha  surgido  de 
transação ou outro evento passado. Podem existir diversas transações passadas ou outros eventos 
que resultem no ganho do controle do recurso pela entidade e, por conseguinte, o caracterize como 
ativo.  As  entidades  podem  obter  ativos  por  intermédio  da  sua  compra  em  transação  com 
contraprestação,  bem  como  pelo  seu  desenvolvimento.  Os  ativos  também  podem  surgir  de 
transações sem contraprestação, inclusive por meio do exercício dos direitos soberanos. O poder de 
tributar ou emitir licenças, acessar, restringir ou negar acesso aos benefícios oriundos de recursos 
intangíveis como, por exemplo, o espectro eletromagnético (bandas de frequência de transmissões 
de  telecomunicações),  são  exemplos  dos  poderes  específicos  do  setor  público  e  dos  direitos  que 
podem  dar  origem  a  ativos.  Ao  se  avaliar  o  surgimento  do  direito  de  controle  de  recursos,  os 
seguintes  eventos  devem  ser  considerados:  (a)  a  capacidade  geral  para  exercer  o  poder;  (b)  a 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
36 
 
constituição de poder por meio de lei, estatuto ou instrumento congênere; (c) o exercício do poder 
de criar um direito; e (d) o evento que dá origem ao direito de receber recursos de terceiros. O ativo 
surge quando o poder for exercido e os direitos de receber recursos existirem. 
Passivo 
Definição 
5.14  Passivo é uma obrigação presente de transferir recursos, derivada de evento passado. 
5.14A Para que exista um passivo, três critérios devem ser satisfeitos:  
 (a) a entidade tem uma obrigação (itens 5.15 a 5.15F);  
 (b) a obrigação é para transferir recursos (itens 5.16A–5.16F); e  
 (c) a obrigação é uma obrigação presente decorrente de um ou mais eventos passados (itens 
5.17 a 5.17D).  
Obrigações  
5.15  As  entidades  do  setor  público  podem  ter  uma  série  de  obrigações. As obrigações são  vinculantes 
quando a entidade tem pouca ou nenhuma alternativa realista para evitá-las.  
5.15A As obrigações vinculantes podem ser obrigações legais ou obrigações não legalmente vinculantes. 
Obrigações  vinculantes  podem  surgir  tanto  de  transações  com  contraprestação  quanto  das  sem 
contraprestação. A obrigação deve estar relacionada com uma parte externa para dar origem a um 
passivo.   A   entidade   não   pode   estar   obrigada   para   consigo   mesma,   mesmo   quando   tenha 
comunicado publicamente a intenção de se comportar de um determinado modo. A identificação 
de uma parte externa é uma indicação da existência de uma obrigação que dá origem a um passivo. 
Contudo, não é essencial conhecer a identidade da parte externa antes do momento da liquidação
4
 
para que exista uma obrigação e um passivo.  
5.15B  Muitos acordos que dão origem a uma obrigação incluem datas de liquidação. A inclusão de uma 
data de liquidação pode fornecer uma indicação de que uma obrigação envolve uma transferência 
de recursos e dá origem a um passivo. No entanto, existem muitos acordos que não contêm datas 
de liquidação. A ausência de uma data de liquidação não impede que uma obrigação dê origem a 
um passivo.  
 
4
 Para  os  fins  desta Estrutura Conceitual,  os  termos  “liquidado”  ou  “liquidação”  não  se  confundem  com  os  termos 
correspondentes utilizados na execução orçamentária, conforme legislação brasileira sobre orçamento. 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
37 
 
Obrigações legais  
5.15C  A  obrigação  legal  é  exigível  por  força  de  lei.  Essas  obrigações  executórias  podem  surgir  de  uma 
variedade de dispositivos legais. As transações com contraprestação são geralmente de natureza 
contratual e, portanto, exigíveis por meio de leis ou equivalentes. Para alguns tipos de transações 
sem contraprestação, é necessário julgamento profissional para determinar se uma obrigação é 
legalmente  exigível.  Quando  for  determinado  que  uma  obrigação  é  legalmente  exigível,  não  há 
dúvida  de  que  a  entidade  tem pouca  ou  nenhuma  alternativa  realista  para  evitar  a  obrigação  e 
que, consequentemente, o passivo existe.  
5.15D  Algumas  obrigações  relacionadas  a  transações  com  contraprestação  não  são  estritamente 
exigíveis por uma parte externa na data de apresentação das informações contábeis, mas serão 
exigíveis no transcurso do tempo, sem que a parte externa tenha que cumprir condições adicionais 
– ou ter que realizar qualquer ação adicional – antes da liquidação. As demandas que são exigíveis 
incondicionalmente  em  razão  do  transcurso  do  tempo  são  obrigações  exigíveis  no  contexto  da 
definição de um passivo.  
5.15E  O poder soberano é a autoridade máxima de um governo para criar, alterar e revogar disposições 
legais. O poder soberano não é uma justificativa para concluir que uma obrigação não atende à 
definição  de  passivo  conforme  esta Estrutura Conceitual.  A  situação  legal  deve  ser  avaliada  em 
cada apresentação da informação contábil para determinar se a obrigação já não é vinculante e 
não satisfaz a definição de passivo.  
Obrigações não legalmente vinculantes  
5.15F Os passivos podem surgir de obrigações não legalmente vinculantes. Essas diferem das obrigações 
legais, pois a parte para a qual existe a obrigação não pode tomar medidas legais (ou equivalentes) 
para fazer liquidá-las. As obrigações não legalmente vinculantes que dão origem a passivos têm as 
seguintes características:  
 (a) a entidade indica a outras partes, por meio de um padrão estabelecido de práticas passadas, 
políticas publicadas ou declaração específica, que aceitará certas responsabilidades;  
 (b) como resultado de tal indicação, a entidade cria uma expectativa válida dessas outras partes 
de que cumprirá essas responsabilidades; e  
 (c)  a  entidade  tem  pouca  ou  nenhuma  alternativa  realista  para  evitar  liquidar  a  obrigação 
decorrente dessas responsabilidades.  
Transferência de recursos da entidade 
5.16 (Eliminado).  

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
38 
 
5.16A Para  satisfazer  a  definição  de  passivo,  a  obrigação  deve  ter  o  potencial  de  exigir  que  a  entidade 
transfira recursos para outra parte (ou partes). Para que esse potencial exista, não é necessário 
que haja certeza, ou mesmo probabilidade, de que a entidade será obrigada a transferir recursos 
– a  transferência  pode,  por  exemplo,  ser  exigida  apenas  se  ocorrer  um  acontecimento  futuro 
incerto específico. É apenas necessário que a presente obrigação exista e que, pelo menos em uma 
circunstância, exija que a entidade transfira recursos. 
5.16B  A obrigação pode atender à definição de passivo mesmo que a probabilidade de transferência de 
recursos  seja  baixa.  No  entanto,  essa  baixa  probabilidade  pode  afetar  as  decisões  sobre  as 
informações fornecidas sobre o passivo e a forma como as informações são fornecidas. O Capítulo 
6   fornece   orientações   sobre   reconhecimento   e   o   Capítulo   7   fornece   orientações   sobre 
mensuração.  
 5.16C As obrigações para transferência de recursos incluem, por exemplo:  
 (a) obrigações de pagamento em dinheiro;  
 (b) obrigações de prestação de serviços ou entrega de bens;  
 (c) obrigações de trocar recursos com outra parte em condições desfavoráveis. Tais obrigações 
incluem, por exemplo, um contrato a prazo para vender em condições que são atualmente 
desfavoráveis ou uma opção que dá direito a outra parte de comprar recursos da entidade;  
 (d) obrigações de transferir recursos caso ocorra um evento futuro incerto específico; e  
 (e)  obrigações  de  emitir  um  instrumento  financeiro  se  esse  instrumento  financeiro  obrigar  a 
entidade a transferir recursos.  
5.16D  Em vez de cumprir a obrigação de transferir recursos para a outra parte, as entidades podem, em 
algumas circunstâncias:  
 (a) liquidar a obrigação negociando a liberação da obrigação;  
 (b) transferir a obrigação a terceiro; ou  
 (c)  substituir  a  obrigação  de  transferir  recursos  por  outra  obrigação,  celebrando  uma  nova 
transação.  
5.16E  Nas situações identificadas no item 5.16D, a entidade tem a obrigação de transferir recursos até 
que tenha liquidado, transferido ou substituído essa obrigação.  

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
39 
 
5.16F Em um relacionamento principal-agente (ver item 5.12A), se o agente tiver a obrigação de transferir 
recursos controlados pelo principal para um terceiro, essa obrigação não é uma responsabilidade do 
agente. Nesse caso, os recursos que seriam transferidos são os recursos do principal.  
Obrigação presente e derivada de um evento passado  
5.17 A  obrigação  presente  é  vinculante. Para  satisfazer  a  definição  de  passivo,  é  necessário  que  a 
obrigação presente surja como resultado de transação ou de outro evento passado e tenha potencial 
de exigir que a entidade transfira recursos da entidade para outra parte.  
5.17A  A obrigação presente existe como resultado de eventos passados somente se:  
 (a) a entidade já obteve potencial de serviço ou benefícios econômicos ou tomou uma medida
5
; 
e  
 (b) como consequência, a entidade irá ou poderá ter de transferir recursos que de outra forma 
não teria.  
5.17B  No  setor  público,  as  obrigações  podem  surgir  em  uma  série  de  momentos.  Por  exemplo,  na 
implementação de um programa ou serviço, a obrigação pode decorrer:  
 (a) da realização de promessa política, tal como um compromisso eleitoral;  
 (b) do anúncio de uma política;  
 (c) da proposta (e aprovação) do orçamento (que podem ser dois eventos distintos); e 
 (d) da entrada em vigor do orçamento (em algumas situações o orçamento não será eficaz até 
que uma dotação seja utilizada).  
É  pouco  provável  que  as  fases  iniciais  de  implementação  de  novos  gastos  deem  origem  a  obrigações 
presentes que atendem à definição de passivo. Fases posteriores, como o cumprimento dos critérios de 
elegibilidade para o serviço a ser prestado, podem dar origem a obrigações que atendem à definição de 
passivo. Conforme observado no item 5.15A, a entidade não tem uma obrigação consigo mesma como 
resultado de uma comunicação pública.  
5.17C O  momento  no  qual  a  obrigação  dá  origem  ao  passivo  depende  da  natureza  da  obrigação.  Os 
fatores que provavelmente terão impacto nos julgamentos de que outras partes podem concluir 
 
5
 No setor público, uma obrigação presente pode surgir de uma obrigação imposta por outro nível de governo. 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
40 
 
validamente que a obrigação é tal que a entidade tem pouca ou nenhuma alternativa realista para 
evitar uma transferência de recursos incluem:  
 (a) a natureza do evento ou eventos passados que deram origem à obrigação. Por exemplo, é 
pouco provável que uma promessa feita durante uma eleição dê origem a uma obrigação 
presente  porque  um  compromisso  eleitoral  muito  raramente  cria  uma  expectativa  válida 
para as partes externas de que a entidade tem uma obrigação, ou seja, que tem pouca ou 
nenhuma alternativa realista para evitar a liquidação. Contudo, um anúncio relativo a um 
evento  ou  circunstância  ocorrida  pode  ter  apoio  político  tal  que  o  governo  tenha  poucas 
opções de desistir. Quando o governo se comprometeu a orçar e assegurar a aprovação da 
dotação  necessária,  tal  anúncio  pode  dar  origem  a  uma  obrigação  não  legalmente 
vinculante;  
 (b) a capacidade da entidade de modificar ou alterar a obrigação antes que ela se confirme. Por 
exemplo,  o  anúncio  de  uma  política  geralmente  não  dará  origem  a  uma  obrigação  não 
legalmente vinculante, que não possa ser modificada antes de ser implementada; e  
 (c)  pode haver uma correlação entre a disponibilidade de fundos para liquidar uma obrigação 
específica e a criação de uma obrigação presente. Por exemplo, quando uma dotação tiver 
sido aprovada e o financiamento vinculado for assegurado por meio de disponibilidades, de 
uma reserva de contingência ou de uma transferência de nível diferente de governo, pode 
existir  uma  obrigação  não  legalmente  vinculante.  Contudo,  a  ausência  da  dotação  não 
significa, por si só, que não tenha surgido a obrigação presente.  
5.17D  A “coerção econômica”, a “necessidade política” ou outras circunstâncias podem dar origem a 
situações em que, embora a entidade do setor público não seja legalmente obrigada a incorrer em 
uma transferência de recursos, as consequências econômicas ou políticas da recusa em fazê-lo são 
tais que a entidade pode ter pouca ou nenhuma alternativa realista para evitar a transferência de 
recursos. A coerção econômica, a necessidade política ou outras circunstâncias podem levar a um 
passivo decorrente de uma obrigação não legalmente vinculante.  
5.18 ao 5.26 (Eliminados).  
Ativos e passivos  
Unidade contábil  
5.26A  A unidade contábil é o direito ou o grupo de direitos, a obrigação ou o grupo de obrigações, ou o 
grupo  de  direitos  e  obrigações  aos  quais  são  aplicados  os  critérios  de  reconhecimento  e  os 
conceitos de mensuração.  

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
41 
 
5.26B  A  unidade  contábil  é  selecionada  para  um  ativo  ou  passivo  ao  considerar  como  os  critérios  de 
reconhecimento e os conceitos de mensuração serão aplicados a esse ativo ou passivo e às receitas 
e despesas relacionadas. Em algumas circunstâncias, pode ser apropriado selecionar uma unidade 
contábil para reconhecimento e outra unidade contábil para mensuração. Por exemplo, os acordos 
podem, por  vezes, ser  reconhecidos  individualmente,  mas  mensurados  como  parte  de  uma 
carteira  de  acordos  vinculantes.  Para  apresentação  e  divulgação,  os  ativos,  passivos,  receitas  e 
despesas podem necessitar de ser agregados ou separados em componentes.  
5.26C  Se a entidade transferir parte de um ativo ou parte de um passivo, a unidade contábil pode mudar 
nesse  momento,  de  modo  que  o  componente  transferido  e  o  componente  retido  se  tornem 
unidades contábeis separadas.  
5.26D  A unidade de conta é selecionada para fornecer informações úteis, o que implica que:  
 (a)  as informações fornecidas sobre o ativo ou passivo e sobre quaisquer receitas e despesas 
relacionadas  devem  ser  relevantes.  Tratar  um  grupo  de  direitos  e  obrigações  como  uma 
única  unidade  contábil  pode  fornecer  informações  mais  relevantes  do  que  tratar  cada 
direito ou obrigação como uma unidade contábil separada se, por exemplo, esses direitos e 
obrigações:  
 (i) não pode ser ou é improvável que sejam objeto de transações separadas;  
 (ii) não podem ou são improváveis de vencer em tempos diferentes;  
 (iii) possuem características e riscos semelhantes; ou  
 (iv) são utilizados em conjunto nas atividades operacionais conduzidas por uma entidade 
para prestar serviços ou para produzir fluxos de caixa e são mensurados por referência 
a  estimativas  do  seu  potencial  de  serviço  interdependente  ou  dos  fluxos  de  caixa 
futuros;  
 (b)  as  informações  fornecidas  sobre  o  ativo  ou  passivo  e  sobre  qualquer  receita  ou  despesa 
relacionada devem representar fielmente a substância de uma transação ou outro evento 
do   qual   surgiram.   Portanto,   pode   ser   necessário   tratar   os   direitos   ou   obrigações 
provenientes de diferentes fontes como uma única unidade de conta, ou separar os direitos 
ou  obrigações  decorrentes  de  uma  única  fonte.  Da  mesma  forma,  para  fornecer  uma 
representação  fiel  de  direitos  ou  obrigações  não  relacionados,  pode  ser  necessário 
reconhecê-los e medi-los separadamente.  
5.26E Ao selecionar a unidade contábil, também é importante considerar a restrição de custo-benefício 
da elaboração e da divulgação da informação contábil discutida no Capítulo 3. Em geral, os custos 
associados ao reconhecimento e mensuração de ativos, passivos, receitas e despesas aumentam 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
42 
 
à medida que o tamanho da unidade contábil diminui. Assim, em geral, os direitos ou obrigações 
decorrentes  da  mesma  fonte  só  são  separados  se  a  informação  resultante  for  mais  útil  e  os 
benefícios superarem os custos.  
5.26F Um exemplo de direitos e obrigações decorrentes da mesma fonte são os acordos vinculantes, 
que estabelecem direitos e obrigações para cada uma das partes. Se esses direitos e obrigações 
forem  interdependentes  e  não  puderem  ser  separados,  constituem  um  único  ativo  ou  passivo 
inseparável e, portanto, formam uma única unidade contábil.  
5.26G  Por outro lado, se os direitos forem separáveis das obrigações decorrentes da mesma fonte, às 
vezes  pode  ser  apropriado  agrupar  os  direitos  separadamente  das  obrigações,  resultando  na 
identificação  de  um  ou  mais  ativos  e  passivos  separados. Em outros  casos,  poderá  ser  mais 
apropriado agrupar direitos e obrigações separáveis em uma única unidade contábil, tratando-
os como um único ativo ou um único passivo.  
5.26H  Tratar um conjunto de direitos e obrigações presentes como uma única unidade contábil difere 
da compensação de ativos e passivos. A compensação ocorre quando uma entidade reconhece 
e mensura tanto um ativo como um passivo como unidades contábeis separadas, mas os agrupa 
em um único montante líquido na demonstração da posição financeira. A compensação classifica 
itens diferentes juntos e, portanto, geralmente não é apropriada.  
Acordos vinculantes que são igualmente não executados  
5.26I  Alguns  acordos  vinculantes,  ou  partes  desses,  podem  ser  igualmente  não  executados,  caso 
nenhuma  das  partes  tenha  cumprido  qualquer  uma  das  suas  obrigações  ou  ambas  as  partes 
tenham  cumprido  parcialmente  as  suas  obrigações  em  igual  medida.  Esses  acordos  vinculantes 
estabelecem um direito e uma obrigação combinados de trocar recursos. O direito e a obrigação 
são interdependentes e não podem ser separados. Portanto, o direito e a obrigação combinados 
constituem um único ativo ou passivo. A entidade possui um ativo se os termos da troca forem 
atualmente favoráveis; ele tem um passivo se os termos da troca forem atualmente desfavoráveis. 
A  inclusão  de  tal  ativo  ou  passivo  nas  demonstrações  contábeis  depende  tanto  dos  critérios  de 
reconhecimento (ver Capítulo 6) como da base de mensuração selecionada para o ativo e passivo 
(ver Capítulo 7).  
5.26J Na medida em que qualquer uma das partes cumpra suas obrigações sob o acordo vinculante, esse 
muda de caráter. Se a entidade que relata executa primeiro o acordo vinculante, esse desempenho 
é o acontecimento que altera o direito e a obrigação da entidade que relata de trocar recursos em 
um direito  de  receber  recursos.  Esse  direito  é um  ativo.  Se  a  outra parte  executar  primeiro,  esse 
desempenho é o acontecimento que altera o direito e a obrigação da entidade que relata de trocar 
recursos em uma obrigação de transferir recursos. Essa obrigação é um passivo.  
Situação patrimonial líquida, outros recursos e outras obrigações 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
43 
 
5.27  Conforme  o  item  5.4,  em  alguns  casos,  ao  se  desenvolver  ou  revisar  uma  NBC  TSP,  pode-se 
determinar  que,  para  alcançar  os  objetivos  da  elaboração  e  da  divulgação  informação  contábil,  o 
recurso  ou  a  obrigação  que  não  satisfaça  a  definição  de  elemento  definido  nesta Estrutura 
Conceitual precise ser reconhecido nas demonstrações contábeis. Nesses casos, as NBCs TSP podem 
exigir ou permitir que esses recursos ou obrigações sejam reconhecidos como outros recursos ou 
outras  obrigações,  os  quais  são  itens  adicionais  aos  seis  elementos  definidos  nesta  estrutura 
conceitual. 
5.28  A situação patrimonial líquida é a diferença entre os ativos e os passivos após a inclusão de outros 
recursos e a dedução de outras obrigações, reconhecida na demonstração que evidencia a situação 
patrimonial como patrimônio líquido. A situação patrimonial líquida pode ser um montante residual 
positivo ou negativo. 
Receita e despesa 
5.29  Receita  corresponde  a  aumentos  na  situação  patrimonial  líquida  da  entidade  não  oriundos  de 
contribuições dos proprietários. 
5.30  Despesa  corresponde  a  diminuições  na  situação  patrimonial  líquida  da  entidade  não  oriundas  de 
distribuições aos proprietários. 
5.31  Receitas  e  despesas  originam-se  de  transações  com  contraprestação  e  sem  contraprestação,  de 
outros eventos, tais como: aumentos e decréscimos não realizados de ativos e passivos; do consumo 
dos ativos por meio da depreciação; e da redução do potencial de serviços e da capacidade de gerar 
benefícios econômicos por meio da redução ao valor recuperável. Receitas e despesas podem ser 
originadas de transações individuais ou de grupos de transações. 
Superávit ou déficit do exercício 
5.32  O superávit ou o déficit da entidade para o exercício é a diferença entre as receitas e as despesas 
que constam na demonstração que evidencia o desempenho das entidades do setor público. 
Contribuição dos proprietários e distribuição aos proprietários 
Definições 
5.33  Contribuição  dos  proprietários  corresponde à entrada  de  recursos  para  a  entidade  a  título  de 
contribuição  de  partes  externas,  que  estabelece  ou  aumenta  a  participação  delas  no  patrimônio 
líquido da entidade. 
 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
44 
 
5.34  Distribuição aos proprietários corresponde à saída de recursos da entidade a título de distribuição a 
partes  externas, que representa  retorno  sobre  a participação  ou  a  redução  dessa participação no 
patrimônio líquido da entidade. 
 
5.35  É  importante  distinguir  os  conceitos  de  despesa  e  receita  dos  conceitos  de  distribuição  aos 
proprietários e contribuição dos proprietários, inclusive as entradas que estabelecem inicialmente 
suas  participações  na  entidade.  Além  do  aporte  de  recursos  e  do  pagamento  de  dividendos  que 
podem ocorrer,  é  relativamente  comum que  ativos  e passivos  sejam  transferidos entre  entidades 
do  setor  público.  Sempre  que  tais  transferências  satisfizerem  as  definições  de  contribuição  dos 
proprietários ou de distribuição aos proprietários, elas devem ser contabilizadas como tal. 
 
5.36  As  participações  dos  proprietários  podem  surgir  na  criação  da  entidade  quando  outra  entidade 
contribui com recursos para dar à nova entidade a capacidade de iniciar suas operações. No setor 
público,  as  contribuições  ou  as  distribuições  de  recursos  são,  algumas  vezes,  relacionadas  à 
reestruturação do governo e irão tomar a forma de transferências de ativos e passivos em vez de 
transações  em  espécie.  As  participações  dos  proprietários  podem  tomar  diferentes  formas, 
podendo não ser evidenciadas por meio de instrumento de capital próprio. 
 
5.37  A  contribuição  dos  proprietários  pode  tomar  a  forma  de  aporte  inicial  de  recursos  na  criação  da 
entidade ou de aporte de recursos subsequente, inclusive quando da reestruturação da entidade. 
Já a distribuição aos proprietários pode ser: (a) o retorno sobre investimento; (b) o retorno total ou 
parcial  de  investimentos;  ou  (c)  no  caso da  extinção  ou  reestruturação  da  entidade,  o  retorno de 
qualquer recurso residual. 
Capítulo 6 – Reconhecimento nas Demonstrações Contábeis 
Critérios de reconhecimento e sua relação com a evidenciação 
6.1  Este   capítulo   identifica   os   critérios   que  devem   ser   satisfeitos   para   que   um  elemento   seja 
reconhecido  nas  demonstrações  contábeis.  O  reconhecimento  é  o  processo  de  incorporar  e  de 
incluir  um  item,  expresso  em  valores  a  serem  demonstrados  no  corpo  da  demonstração  contábil 
apropriada, que satisfaça a definição de elemento e possa ser mensurado de maneira que observe 
as  características  qualitativas,  levando  em  consideração  as  restrições  sobre  a  informação  incluída 
nos RCPGs. 
6.2  O item deve ser reconhecido nas demonstrações contábeis quando: 
(a) satisfizer a definição de elemento; e 
(b)  puder  ser  mensurado  de  maneira  que  observe  as  características  qualitativas,  levando  em 
consideração as restrições sobre a informação incluída nos RCPGs. 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
45 
 
6.3 Todos  os  itens  que  satisfaçam  os  critérios  de  reconhecimento  são  inseridos  nas  demonstrações 
contábeis.  Em  algumas  circunstâncias,  determinada  NBC  TSP  pode  também  especificar  que,  para 
alcançar  os  objetivos  da  elaboração  e  da  divulgação  da  informação  contábil,  um  recurso  ou 
obrigação  que  não  satisfaça  a  definição  de  elemento  deve  ser  reconhecido  nas  demonstrações 
contábeis desde que possa ser mensurado de maneira que satisfaça as características qualitativas e 
as  restrições  sobre  a  informação  incluída  nos  RCPGs.  Outros  recursos  e  outras  obrigações  são 
discutidos no Capítulo 5. 
6.4  O  reconhecimento  envolve  a  avaliação  da  incerteza  relacionada  à  existência  e  à  mensuração  do 
elemento.  As  condições  que  dão  origem  à  incerteza,  se  existirem,  podem  mudar.  Portanto,  é 
importante que a incerteza seja avaliada em cada data de divulgação do relatório. 
Definição de elemento 
6.5  Para  ser  reconhecido  como  elemento,  o  item  precisa  satisfazer  a  definição  de  um  dos  elementos 
descritos no Capítulo 5. A incerteza sobre a existência de um elemento é examinada ao considerar 
a evidência disponível para emitir julgamento neutro sobre se o item satisfaz todas as características 
essenciais  da  definição  de  elemento,  considerando  todos  os  fatos  e  circunstâncias  disponíveis  na 
data do relatório. 
6.6  Caso se determine que o elemento, de fato, existe, a incerteza sobre o montante do potencial de 
serviços ou da capacidade de gerar benefícios econômicos representados por ele deve ser levado 
em  consideração  na  sua  mensuração  (ver  itens  6.7  e  6.8).  Os  responsáveis  pela  elaboração  dos 
RCPGs revisam e avaliam toda a evidência disponível ao determinarem se o elemento existe e deve 
ser reconhecido, se aquele elemento continua a se qualificar para o reconhecimento (ver item 6.9), 
ou se houve mudança em elemento existente. 
Incerteza quanto à mensuração 
6.7  Para se reconhecer um item nas demonstrações contábeis, é necessário atribuir um valor monetário 
a ele. Isso requer escolher a base de mensuração apropriada e determinar se a mensuração do item 
cumpre   as   características   qualitativas,   levando-se   em   consideração   as   restrições   acerca   da 
informação    nos    RCPGs,    inclusive    que    a    mensuração    seja    suficientemente    relevante    e 
fidedignamente  representativa  para  o  item  a  ser  reconhecido  nas  demonstrações  contábeis.  A 
seleção da base de mensuração adequada é considerada no Capítulo 7. 
6.8 Pode  haver  incerteza  associada  à  mensuração  de  montantes  apresentados  nas  demonstrações 
contábeis.  O uso  de  estimativas  é  parte  essencial  da  contabilidade  sob  o regime de  competência. 
Uma  decisão  acerca  da  relevância  e  da  representação  fidedigna  da  mensuração  envolve  a 
consideração  de  técnicas  como,  por  exemplo,  utilizar  intervalos  de  resultados  e  estimativas 
pontuais,  e  se  uma  evidência  adicional  sobre  as  circunstâncias  econômicas  existentes  na  data  do 
relatório  está  disponível.  A  evidenciação  pode  fornecer  informação  útil  sobre  as  técnicas  de 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
46 
 
estimativa empregadas. Pode haver raras circunstâncias nas quais o nível de incerteza em um único 
ponto da estimativa é tão grande que a relevância e a representação fidedigna da medida utilizada 
são  questionáveis,  mesmo  que  haja  a  evidenciação  das  técnicas  de  estimativa  utilizadas.  Nessas 
circunstâncias, o item não deve ser reconhecido. 
Evidenciação e reconhecimento 
6.9  A   falha   ao   se   reconhecer   itens   que   satisfazem   a   definição   de   elemento  e  os   critérios  de 
reconhecimento  utilizados  não  é  convalidada  pela  evidenciação  das  políticas  contábeis,  notas  ou 
outro  detalhe  explicativo.  Contudo,  a  evidenciação  pode  fornecer  informação  sobre  os  itens  que 
satisfazem  muitas  características  que  definem  o  elemento,  mas  nem  todas.  A  evidenciação  pode 
também fornecer informação sobre os itens que satisfazem a definição de elemento, mas que não 
podem ser mensurados de maneira que satisfaça suficientemente as características qualitativas e ir 
de  encontro  aos  objetivos  da  elaboração  e  divulgação  da  informação  contábil.  A  evidenciação  é 
apropriada  quando  o  conhecimento  sobre  o  item  é  considerado  relevante  para  a  avaliação  da 
situação patrimonial líquida da entidade e, portanto, satisfaz os objetivos da elaboração e divulgação 
da informação contábil. 
Desreconhecimento 
6.10  O  desreconhecimento  é  o  processo  de  avaliar  se  ocorreram  mudanças,  desde  a  data  do  relatório 
anterior,  que  justifiquem  a  remoção  de  elemento  que  tenha  sido  previamente  reconhecido  nas 
demonstrações contábeis, bem como remover esse item se tais mudanças ocorrerem. Ao se avaliar 
a  incerteza  sobre  a  existência  do  elemento,  os  mesmos  critérios  devem  ser  utilizados  para  o 
desreconhecimento, tais como aqueles utilizados no reconhecimento inicial. 
Capítulo 7 – Mensuração de Ativos e Passivos nas Demonstrações Contábeis 
Introdução 
7.1  Este capítulo identifica os conceitos que orientam a seleção das bases de mensuração de ativos e 
passivos,  mais  comumente  utilizadas  pelas  NBCs  TSP  e  pelos  responsáveis  pela  elaboração  das 
demonstrações contábeis quando não existirem regramentos específicos constantes das NBCs TSP. 
Objetivo da mensuração 
7.2  O  objetivo  da  mensuração  é  selecionar  bases  que  reflitam  de  modo  mais  adequado  o  custo  dos 
serviços, a capacidade operacional e a capacidade financeira da entidade de forma que seja útil para 
a prestação de contas e responsabilização (accountability) e tomada de decisão. 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
47 
 
7.3  A seleção da base de mensuração para ativos e passivos contribui para satisfazer aos objetivos da 
elaboração  e  divulgação  da  informação  contábil  pelas  entidades  do  setor  público  ao  fornecer 
informação que possibilita os usuários avaliarem: 
(a) o custo dos serviços prestados no período, em termos históricos ou atuais; 
(b) a capacidade operacional – a capacidade da entidade em dar suporte à prestação de serviços 
no futuro por meio de recursos físicos e outros; e 
(c) a capacidade financeira – a capacidade da entidade em financiar as suas próprias atividades. 
7.4 A  seleção  da  base  de  mensuração  também  pressupõe  a  avaliação  do  grau  de  observância  das 
características  qualitativas  enquanto  considera  as  restrições  sobre  a  informação  nos  RCPGs. As 
subseções a seguir fornecem orientação sobre mensuração no reconhecimento (mensuração inicial) 
e mensuração subsequente ao reconhecimento (mensuração subsequente).  
Mensuração inicial  
7.5 A  mensuração  inicial  de  um  ativo  é  feita  pelo  preço  de  transação  mais  os  custos  de  transação,  a 
menos que não haja dados confiáveis sobre o preço de transação, ou haja outra base de mensuração 
mais  representativamente  fiel.  O  preço  de  transação  é  a  contraprestação  dada  para  adquirir, 
construir  ou desenvolver  um  ativo.  Os  custos de  transação de  ativos  são  custos  incrementais que 
são diretamente atribuíveis à aquisição, construção ou desenvolvimento de um ativo e não teriam 
sido incorridos se a entidade não tivesse adquirido, construído ou desenvolvido o ativo. O preço de 
transação mais os custos de transação é o custo histórico de um ativo.  
7.6 A mensuração inicial de um passivo é feita pelo preço de transação menos os custos de transação, 
a  menos  que  não  haja  dados  confiáveis  sobre  preços  de  transação,  ou  haja  outra  base  de 
mensuração mais representativamente fiel. O preço da transação é a contraprestação recebida para 
assumir  uma  obrigação.  Os  custos  de  transação  para  passivos  são  custos  incrementais  que  são 
diretamente atribuíveis à ocorrência de um passivo e não teriam sido incorridos se a entidade não 
tivesse incorrido no passivo. O preço de transação menos os custos de transação é o custo histórico 
de um passivo.  
7.7 Tanto para ativos quanto para passivos, quando não houver dados sobre o preço da transação ou se 
o preço da transação não apresentar fielmente informações relevantes sobre o ativo e o passivo da 
entidade   de   uma   maneira   que   seja   útil   para   a   prestação   de   contas   e   responsabilização 
(accountability) da entidade e tomada de decisão, é utilizado um custo atribuído. 
Mensuração subsequente  
7.8 Após a mensuração inicial, existem três níveis de mensuração:  

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
48 
 
(a) modelos de mensuração;  
(b) bases de mensuração; e  
(c) técnicas de mensuração.  
7.9 Os modelos de mensuração são as abordagens amplas para mensurar ativos e passivos para inclusão 
nas demonstrações contábeis.  
7.10 De  acordo  com  o  modelo  de  custo  histórico,  os  ativos  e  passivos  são  mensurados  por  valores 
baseados historicamente. As alterações de valor devido a alterações de preços não são refletidas, 
exceto  no  caso  de  redução  ao  valor  recuperável  para  ativos  e  quando uma  obrigação  se  torna 
onerosa para passivos.  
7.11 De  acordo  com  o  modelo  de  valor  corrente,  os  ativos  e  passivos  são  mensurados  usando 
informações atualizadas para refletir as alterações de preço na data de mensuração.  
Nível de agregação ou desagregação para fins de mensuração 
7.12  As bases  de  mensuração são  formas  específicas  de  mensurar  ativos  e  passivos  no  modelo  de 
mensuração selecionado. As bases de mensuração fornecem informações que melhor atendem às 
características  qualitativas,  ao  mesmo  tempo  em  que  levam  em  consideração  as  restrições  de 
informação nos RCPGs.  
7.13 A mensuração subsequente pode ser feita com base na mensuração do custo histórico ou em uma 
das bases de mensuração do modelo de valor corrente (ver item 7.15).  
7.14 As  técnicas  de  mensuração  são  métodos  para  estimar  o  valor  pelo  qual  um  ativo  ou  passivo  é 
mensurado  sob  a  base  de  mensuração  selecionada.  A  seleção  de  uma  técnica  de  mensuração 
depende  de  fatores  como  as  características  de  um  ativo  ou  passivo  e  a  disponibilidade  de  dados 
observáveis. Orientações sobre técnicas de mensuração são fornecidas pelas NBCs TSP.  
Seleção de modelos e de bases de mensuração  
7.15 Não é possível identificar um único modelo ou base de mensuração que melhor atenda ao objetivo 
de  mensuração  em  nível  conceitual  para todas  as  circunstâncias.  Portanto,  a  estrutura  conceitual 
não  propõe  um  único  modelo  ou  base  de  mensuração  (ou  combinação de  bases)  para  todas  as 
transações, eventos e condições. A estrutura conceitual fornece orientação sobre a seleção de um 
modelo e de uma base de mensuração para ativos e passivos a partir das bases mais comumente 
utilizadas para atingir o objetivo de mensuração. Pode ser necessário selecionar bases de diferentes 
modelos para atingir o objetivo de mensuração.  

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
49 
 
7.16 As  seguintes  bases  de  mensuração  para  ativos  são  identificadas  e  discutidas  em  termos  das 
informações  que  fornecem  sobre  (a)  o  custo  dos  serviços  prestados  por  uma  entidade,  (b)  a 
capacidade operacional e a capacidade financeira de uma entidade; e (c) até que ponto fornecem 
informação  que  cumpre  as  características  qualitativas,  tendo  simultaneamente  em  conta  as 
restrições à informação nos RCPGs:  
 (a) custo histórico;  
 (b) valor corrente operacional; e  
 (c) valor justo.  
7.17 O  valor  em  uso  é  empregado  exclusivamente  para  redução  ao  valor  recuperável  de  ativos  e, 
portanto, é discutido separadamente nos itens 7.57 a 7.62.  
 7.18 As seguintes bases de mensuração para passivos são identificadas e discutidas:  
 (a) custo histórico;  
 (b) custo de cumprimento da obrigação; e  
 (c) valor justo.  
7.19 Nas  próximas  duas  subseções, são  discutidas  as  classificações  das  bases  de  mensuração  como 
específicas ou não da entidade e a como valores de entrada ou de saída.  
Mensurações específicas e não específicas da entidade  
7.20 As bases de mensuração podem ser classificadas conforme sejam “específicas da entidade” ou “não 
específicas da entidade”. As bases de mensuração específicas da entidade refletem as restrições 
econômicas,  legais  e  outras  que  afetam  os  possíveis  usos  de  um  ativo  ou  o  cumprimento  de  um 
passivo  por  uma  entidade.  As  medidas  específicas  da  entidade  podem  refletir  oportunidades 
econômicas que não estão disponíveis para outras entidades e riscos aos quais outras entidades não 
estão expostas. As medidas não específicas da entidade refletem oportunidades e riscos gerais do 
mercado. A decisão sobre usar uma base de mensuração específica ou não específica da entidade é 
tomada  tendo  como  referências  o  objetivo  de  mensuração  e  as  características  qualitativas.  Os 
quadros  1  e  2  classificam  as  bases  de  mensuração  de  ativos  e  passivos  como  específicas  ou  não 
específicas da entidade.  
Valores de entrada e de saída  

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
50 
 
7.21 As bases de mensuração fornecem valores de entrada ou de saída. Para ativos, os valores de entrada 
refletem o custo de aquisição, construção ou desenvolvimento. Os valores de saída baseiam-se nos 
benefícios  econômicos  da  venda.  O  valor corrente  operacional e  o  custo  histórico  são  medidas 
específicas da entidade para ativos e são valores de entrada. O valor justo é uma medida baseada 
no mercado, não específica da entidade, e é um valor de saída.  
 7.22 Para  os  passivos,  os  valores  de  entrada  referem-se  à  transação  ou ao evento  sob  o  qual  uma 
obrigação é incorrida. Os valores de saída refletem o valor necessário para cumprir ou transferir uma 
obrigação. Por exemplo, o custo histórico é uma medida específica da entidade para passivos e é um 
valor de entrada, o custo de cumprimento da obrigação é uma medida específica da entidade e o 
valor justo é uma medida baseada no mercado e não específica da entidade; ambas as medidas são 
valores de saída.  
7.23 Identificar   se   as   bases   de   mensuração   fornecem   valores   de   entrada   ou   de   saída   apoia   a 
determinação  da  abordagem  aos  custos  de  transação.  As  bases  de  mensuração  baseadas  em 
entradas normalmente incluem custos de transação na aquisição, construção ou desenvolvimento 
de  um  ativo  e  na  ocorrência  de  um  passivo.  As  bases  de  mensuração  baseadas  em  saída 
normalmente   incluem  custos  de  transação  na   venda  de   um   ativo  ou  no   cumprimento   ou 
transferência de um passivo.  
 Nível de agregação ou desagregação para mensuração  
7.24 Para   apresentar   ativos   e   passivos   nas   demonstrações   contábeis  de   um   modo   que   forneça 
informações   que   melhor   atendam   ao   objetivo   de   mensuração   e   atinjam   as   características 
qualitativas, pode ser necessário agregá-los ou desagregá-los para fins de mensuração. Ao avaliar se 
tal agregação ou desagregação é apropriada, deve-se considerar:  
 (a) as orientações sobre unidade contábil no Capítulo 5;  
 (b) a materialidade da agregação ou desagregação; e  
 (c)  os  custos  de  agregação  ou  desagregação  comparados  com  os  benefícios  em  termos  da 
medida  em  que  a  agregação  ou  desagregação  cumpre  os  objetivos  da  elaboração  e  da 
divulgação da informação contábil.  
Bases de mensuração para os ativos  
7.25 Nesta seção, são discutidas as seguintes bases de mensuração para ativos:  
 (a) custo histórico;  
 (b) valor corrente operacional; e  

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
51 
 
 (c) valor justo.  
Custo histórico  
7.26  O  custo  histórico  de  um  ativo  é  a  contraprestação  dada  para  adquirir,  construir  ou  desenvolver  o 
ativo  no  momento  de  sua  aquisição,  construção  ou  desenvolvimento,  acrescida  dos  custos  de 
transação.  
7.27 A contraprestação é o caixa ou equivalentes de caixa, ou o valor de outros recursos dados. O custo 
histórico  é  uma  base  de  mensuração  específica  da  entidade  que  reflete  os  custos  incorridos  na 
aquisição, construção ou desenvolvimento de um ativo. Após a mensuração inicial, o custo histórico 
de  determinados  ativos  pode  ser  imputado  como  despesa  aos  períodos,  a  que  se  referem  as 
demonstrações  contábeis,  sob  a  forma  de  depreciação  ou  amortização.  A  depreciação  e  a 
amortização  representam  o  consumo  do  potencial  de  serviço  ou  capacidade  de  geração  de 
benefícios econômicos proporcionados por tais ativos ao longo de sua vida útil. Consistente com o 
modelo  de  custo  histórico,  após  a  mensuração  inicial,  a  quantia  escriturada  de  um  ativo  não  é 
alterada  para  refletir  alterações  nos  preços,  exceto  quando  relacionado  com  a  redução  ao  valor 
recuperável (ver item 7.28).  
7.28 De  acordo  com  o  modelo  de  custo  histórico,  o  valor  de  um  ativo  pode  ser  reduzido por  meio do 
reconhecimento  de  perda  por  redução  ao  valor  recuperável.  Essa  perda  é  a  medida  em  que  o 
potencial  de  serviço  ou  a  capacidade  de  gerar  benefícios  econômicos  fornecidos  por  um  ativo 
diminuiu devido a alterações nas condições econômicas ou outras, o que é distinto do consumo de 
um  ativo.  Isso  envolve  uma  avaliação  do  valor  recuperável  de  um  ativo.  A  depreciação,  a 
amortização  e  a  redução  ao  valor  recuperável  também  podem  ser  relevantes  para  as  bases  de 
mensuração segundo o modelo do valor corrente (ver item 7.35). Inversamente, o valor de um ativo 
pode  ser  aumentado  para  refletir  o  custo  de  adições  e  melhorias  ou  outros  eventos,  tais  como  a 
acumulação de juros sobre um ativo financeiro.  
 Custo dos serviços  
7.29  Quando o custo histórico é utilizado, o custo dos serviços reflete o valor dos recursos despendidos 
para  adquirir,  construir  ou  desenvolver  ativos  consumidos  na  prestação  de  serviços.  O  custo 
histórico  geralmente  é  baseado  nas  transações  efetivamente  realizadas  pela  entidade.  Como  os 
custos utilizados são os transportados de um período anterior sem ajustamento para alterações de 
preços, não  refletem  o  custo  corrente dos  ativos  quando  eles  são  consumidos.  Como o  custo  dos 
serviços é evidenciado utilizando preços passados, a informação histórica sobre custos não facilitará 
a avaliação do custo futuro da prestação de serviços se as alterações acumuladas nos preços desde 
a  aquisição,  construção  ou  desenvolvimento  forem  significativas.  Quando  os  orçamentos são 
preparados  com base nos  custos históricos,  a  informação histórica  dos  custos demonstra  até que 
ponto o orçamento foi executado.  

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
52 
 
Capacidade operacional  
7.30  Se um ativo foi adquirido, construído ou desenvolvido em uma transação com contraprestação, o 
custo histórico fornece informações sobre os recursos disponíveis para prestar serviços em períodos 
futuros, com base no seu custo de aquisição. No momento em que um ativo é adquirido, construído 
ou desenvolvido, pode-se presumir que o valor para a entidade do seu potencial de serviço é pelo 
menos igual ao custo da sua aquisição, construção ou desenvolvimento. Quando a depreciação ou 
amortização é reconhecida, reflete até que ponto o potencial de serviço de um ativo foi consumido. 
As informações históricas sobre custos mostram que os recursos disponíveis para serviços futuros 
são  pelo  menos  iguais  ao  valor  pelo  qual  são  declarados.  Quando  um  ativo  tiver  sido  adquirido, 
construído  ou  desenvolvido em uma  transação  sem  contraprestação,  o  preço  da  transação  não 
fornecerá informações sobre a capacidade operacional que cumpra as características qualitativas, 
tendo simultaneamente em conta as restrições à informação nos RCPGs (ver também o item 7.7).  
Capacidade financeira  
7.31  O valor pelo qual os ativos são apresentados nas demonstrações contábeis auxilia na avaliação da 
capacidade  financeira.  O  custo  histórico,  menos  depreciação  ou  amortização,  e  quaisquer  perdas 
por  redução  ao  valor  recuperável  acumuladas podem fornecer  informações  sobre  o  montante de 
ativos que podem ser utilizados como garantia efetiva para empréstimos. A avaliação da capacidade 
financeira também requer informações sobre o montante que poderia ser derivado da utilização do 
ativo  e  recebido  na  venda  de um  ativo  e  reinvestido  em  outros  ativos  para  fornecer  serviços 
diferentes.  O  custo  histórico  não  fornece  essa  informação  quando  difere  significativamente  dos 
valores correntes.  
Aplicação das características qualitativas  
7.32 Os itens 7.29 a 7.31 explicam as áreas onde o custo histórico fornece informações relevantes com 
valor  confirmatório  ou  preditivo.  A  aplicação  do  custo  histórico  costuma  ser  simples  porque  as 
informações   da   transação   geralmente   estão   prontamente   disponíveis.   Como   resultado,   os 
montantes  derivados  do  modelo  de  custo  histórico  são  geralmente  representativamente  fiéis  na 
medida em que representam o que pretendem representar – isto é, o custo para adquirir, construir 
ou desenvolver um ativo com base em transações reais. Como a aplicação do custo histórico reflete 
geralmente os recursos consumidos por referência a transações reais, as medidas de custo histórico 
são geralmente verificáveis e compreensíveis, e podem ser preparadas tempestivamente. 
7.33 As informações do custo histórico são comparáveis na medida em que os ativos tenham datas de 
aquisição,  construção  ou  desenvolvimento  iguais  ou  semelhantes.  O  custo  histórico  não  reflete  o 
impacto das alterações de preços, assim não é possível comparar significativamente as quantias de 
ativos  que  foram  adquiridos,  construídos  ou  desenvolvidos  em  momentos  diferentes  quando  os 
preços diferiam. 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
53 
 
7.34 Em certas circunstâncias, a aplicação do custo histórico exige o uso de apropriações – por exemplo, 
quando:  
 (a) vários ativos são adquiridos em uma única transação;  
 (b)  os  ativos  são  construídos  ou  desenvolvidos  pela  própria  entidade  e  as  despesas  gerais  e 
outros custos têm de ser atribuídos; e  
 (c)  a  utilização  de  um  pressuposto  de  fluxo,  tal  como  o  primeiro  a  entrar,  primeiro  a  sair,  é 
necessário quando são detidos muitos ativos semelhantes.  
Na  medida  em  que  tais  apropriações  são  arbitrárias,  elas  reduzem  a  extensão  em  que  a  mensuração 
resultante atinge as características qualitativas.  
Bases de mensuração para ativos no modelo de valor corrente  
7.35  As mensurações segundo o modelo de valor corrente refletem o ambiente econômico prevalecente 
na  data  a  que  se  referem  as  demonstrações  contábeis.  A  depreciação,  amortização  e  redução  ao 
valor recuperável, que são discutidas no contexto do modelo de mensuração do custo histórico nos 
itens  7.27  e  7.28,  também  são  relevantes  para  as  bases  de  mensuração  do  valor  corrente  em 
determinadas circunstâncias. Adições e melhorias podem afetar as mensurações do valor corrente 
operacional e do valor justo.  
7.36  Quando  um  ativo  é  usado  para  prestação  de  serviços  e  também  gera  benefícios  econômicos,  a 
entidade que está usando o modelo de valor corrente julga se um ativo é mantido principalmente 
para capacidade operacional ou capacidade financeira, e seleciona a base de mensuração do valor 
corrente operacional, ou a base de mensuração do valor justo de acordo com essa análise. Ao fazer 
tal  julgamento,  a  entidade  tem  em  conta  a  unidade  contábil  apropriada.  As  orientações  sobre  a 
unidade contábil são fornecidas no Capítulo 5.  
Valor corrente operacional  
7.37 O valor corrente operacional é o valor que a entidade pagaria pelo potencial de serviço remanescente 
de um ativo na data de mensuração.  
7.38  O  valor  corrente  operacional  apresenta  uma  mensuração  específica  da  entidade  de  um  ativo 
existente mantido para sua capacidade operacional. O valor corrente operacional reflete:  
(a) o montante que a entidade pagaria pelo potencial de serviço remanescente do ativo da forma 
menos onerosa;  
(b) o potencial de serviço restante do ativo, tendo em conta a condição atual do ativo;  e 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
54 
 
(c) o uso e a localização nas condições atuais de um ativo.  
7.39  Um ativo apoia a entidade que presta serviços em seu uso existente. ‘Uso existente’ é a forma como 
um  ativo  existente  é  utilizado,  em  vez  de  uma  utilização  alternativa,  e  geralmente  reflete  os 
objetivos políticos da entidade que opera o ativo. O valor corrente operacional pressupõe, portanto, 
que um ativo continuará a ser utilizado para a prestação de serviços em vez de ser vendido.  
Custo dos serviços  
7.40  O  custo  dos  serviços  é  apresentado  em  termos  correntes  quando  baseado  no  valor corrente 
operacional.  Assim,  a  quantidade  de  ativos  consumidos  está  relacionada  ao  valor  dos  ativos  no 
momento em que são consumidos – e não, como acontece com o custo histórico, no momento em 
que foram adquiridos, construídos ou desenvolvidos. Isso fornece uma base para uma comparação 
entre o custo dos serviços e o montante dos impostos e outras receitas recebidas no período – que 
são geralmente transações do período corrente e mensuradas a preços correntes – e para avaliar se 
os recursos foram utilizados de forma econômica e eficiente. Pode também fornecer uma base útil 
para  comparação  com  outras  entidades  que  evidenciam  na  mesma  base,  uma  vez  que  os  valores 
dos ativos não serão afetados por diferentes datas de aquisição, construção ou desenvolvimento, e 
para  avaliar  o  custo  de  prestação  de  serviços  no  futuro  e  a  necessidade  de  recursos  futuros.  Isso 
ocorre  porque  é  mais  provável  que  os  custos  futuros  se  assemelhem  aos  custos  atuais  do  que 
aqueles incorridos no passado, quando os preços eram diferentes.  
Capacidade operacional  
7.41  Conforme  indicado  no  item  7.40,  o  valor corrente  operacional fornece  uma  medida  dos  recursos 
disponíveis para  prestar serviços  em  períodos  futuros  com base na  política  atual,  uma  vez que  se 
concentra no valor corrente dos ativos e no seu potencial de serviço remanescente para a entidade.  
Capacidade financeira  
7.42  O  valor  corrente  operacional  não  fornece  informações  sobre  a  capacidade  de  um  ativo  de  gerar 
benefícios  econômicos  ou  os  valores  que  seriam  recebidos  em  sua  venda.  Portanto,  pode  não 
facilitar uma avaliação da capacidade financeira.  
Aplicação das características qualitativas  
7.43 O valor corrente operacional concentra-se no valor que a entidade pagaria pelo potencial de serviço 
remanescente de um ativo que apoia a realização dos objetivos políticos de uma entidade. O valor 
operacional atual fornece, portanto, informações que são relevantes e fielmente representativas.  
7.44  As informações sobre o valor corrente operacional são comparáveis dentro de uma entidade, uma 
vez  que  os  ativos  que  fornecem  potencial  de  serviço  equivalente  são  demonstrados  por  valores 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
55 
 
semelhantes,  independentemente  de  quando  esses  ativos  foram  adquiridos,  construídos  ou 
desenvolvidos.  Diferentes  entidades  podem  relatar  ativos  semelhantes  em  montantes  diferentes 
porque  o   valor corrente   operacional é  uma  medida   específica   da  entidade   que   reflete   as 
oportunidades disponíveis para a entidade obter um ativo para atingir seus objetivos políticos. Essas 
oportunidades   podem  ser   iguais   ou   semelhantes  para   entidades   diferentes.   Quando   forem 
diferentes,  a  vantagem  econômica  de  uma  entidade  que  é  capaz  de  adquirir,  construir  ou 
desenvolver  ativos  a  um  custo  mais  baixo  é  relatada  nas  demonstrações  contábeis por  meio de 
valores  de  ativos  mais  baixos  e  de  um  custo  de  serviços  mais  baixo.  Isso  reforça  a  capacidade  do 
valor   operacional  atual   de   fornecer   informações   relevantes  e  fielmente   representativas. As 
mensurações   correntes   de   valor   operacional   satisfazem   as   características   qualitativas   de 
tempestividade,  compreensibilidade  e  verificabilidade.  Isso depende da  natureza  do  ativo  e  das 
técnicas de estimativa utilizadas.  
Valor justo  
7.45  O valor justo de um ativo é o preço que seria recebido pela venda de um ativo  em uma transação 
ordenada entre participantes do mercado na data de mensuração.  
7.46 O  valor  justo  é  apropriado quando  o ativo é  mantido  principalmente  por  sua  capacidade  de  gerar 
benefícios econômicos ou com vistas à venda. O justo valor cumpre os objetivos da elaboração e da 
divulgação  da  informação  contábil, e  as  necessidades  de  informação  dos  usuários  depende 
parcialmente da qualidade da evidência de mercado. A evidência de mercado, por sua vez, depende 
das características do mercado em que o ativo é negociado.  
7.47   Em   princípio,   as   mensurações   do   valor   justo   fornecem   informações   úteis   porque   refletem 
adequadamente o valor do ativo para a entidade. Em um mercado ordenado (ver item 7.49), o ativo 
não pode ser avaliado por menos do que o valor justo, uma vez que, desconsiderando os custos de 
transação, a entidade pode obter pelo menos o valor justo por meio da venda do ativo. O ativo não 
pode ser avaliado por mais do que o valor justo, pois a entidade pode obter a mesma capacidade de 
gerar benefícios econômicos adquirindo o mesmo ativo ou similar no mercado.  
7.48  A utilidade do valor justo pode ser mais questionável quando a suposição de que os mercados são 
ordenados não é válida. Nessas circunstâncias, não se pode presumir que o ativo possa ser vendido 
pelo mesmo preço pelo qual pode ser adquirido. Embora a compra de um ativo forneça evidência 
de que seu valor para a entidade é pelo menos igual ao seu preço de compra nesse momento, fatores 
operacionais podem significar que o valor para a entidade pode ser maior. Assim, o valor justo pode 
não  refletir  o  valor para  a  entidade  do  ativo,  representado  pela  sua  capacidade  operacional. 
Portanto,  o  valor  justo  pode  não  ser  útil  para  ativos  operacionais  que  uma  entidade  pretende 
continuar a utilizar para a prestação de serviços.  
Mercados ordenados  

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
56 
 
7.49 Os mercados ordenados têm as seguintes características:  
 (a) não há barreiras que impeçam a entidade de realizar transações no mercado;  
 (b) há frequência e volume de transações suficientes para fornecer informações sobre preços; 
e  
 (c)  há  muitos  compradores  e  vendedores  bem  informados  que  atuam  sem  coação,  pelo  que 
existe uma garantia de ‘justiça’ na determinação dos preços correntes – incluindo  que  os 
preços não representam vendas de emergência.  
Um  mercado  ordenado  é  aquele  administrado  de  maneira  confiável,  segura,  precisa  e  eficiente.  Esses 
mercados  negociam  ativos  que  são  idênticos  e,  portanto,  mutuamente  intercambiáveis,  tais  como 
mercadorias, moedas e títulos cujos preços estão disponíveis publicamente. Na prática, poucos mercados, 
se houver, apresentam plenamente todas estas características, mas alguns podem aproximar-se de um 
mercado ordenado.  
Valor justo no qual os mercados não podem ser considerados ordenados  
7.50  É pouco provável que os mercados de ativos únicos e raramente transacionados sejam ordenados: 
quaisquer compras e vendas são negociadas individualmente e pode haver uma grande variedade 
de preços pelos quais uma transação pode ser acordada. Portanto, os participantes incorrerão em 
custos significativos para comprar ou vender um ativo. Quando os mercados não são ordenados, é 
necessário  utilizar  uma  técnica  de  mensuração  para  estimar  o  preço  ao  qual  uma  transação 
ordenada  de  venda  do  ativo  ocorreria  entre  os participantes  do  mercado  na  data de  mensuração 
sob as condições atuais de mercado. Tais técnicas de mensuração requerem dados que sejam direta 
ou   indiretamente   observáveis,   sempre   que   possível,   ou   não   observáveis   quando   os   dados 
observáveis não puderem ser identificados. 
7.51  O valor justo permite que o retorno sobre os ativos seja evidenciado. Contudo, as entidades do setor 
público geralmente não realizam atividades com o objetivo principal de gerar lucros, e os serviços 
são  frequentemente  prestados  em  transações  sem  contraprestação  ou  em  termos  subsidiados. 
Consequentemente,  pode  haver  relevância  limitada  na  evidenciação  de  um  retorno  derivado  da 
aplicação do valor justo.  
Custos dos serviços  
7.52  O valor justo reflete a capacidade do ativo de gerar benefícios econômicos e o preço que se espera 
receber  na  venda.  Portanto,  quando  um  ativo  é  mantido  principalmente  pela  sua  capacidade 
operacional,  o  valor  justo  proporciona  informação  menos  útil  para  o custo  dos  serviços  do  que  o 
valor corrente operacional, que pode refletir o valor de um ativo no seu uso existente.  

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
57 
 
Capacidade operacional  
7.53  A utilidade das informações sobre o valor justo dos ativos mantidos para a prestação de serviços é 
limitada.  Se  o  valor  justo  for  significativamente inferior  ao  custo histórico,  é provável  que  o  valor 
justo seja menos relevante do que o custo histórico de tais ativos no fornecimento de informações 
sobre a capacidade operacional. O valor justo também será provavelmente menos relevante do que 
o valor corrente operacional, uma vez que o princípio de maior e melhor utilização financeira que 
sustenta  o   valor   justo   é   inadequado  para   ativos   mantidos   principalmente   para   capacidade 
operacional.  
Capacidade financeira  
7.54  A avaliação da capacidade financeira requer informações sobre a capacidade de um ativo de gerar 
benefícios econômicos  e  o  valor  que  seria recebido na  venda  de  um  ativo.  Essas  informações  são 
fornecidas pelo valor justo. O valor justo é, portanto, uma base de mensuração apropriada quando 
os ativos são mantidos para venda ou quando os ativos anteriormente mantidos pela sua capacidade 
operacional são excedentes às necessidades operacionais.  
Aplicação das características qualitativas  
7.55  Os  valores  determinados  em  mercados  ordenados  podem  ser  facilmente  utilizados  para  fins  da 
elaboração  e  da  divulgação  da  informação  contábil.  A  informação  atenderá  às  características 
qualitativas – isto  é,  será  relevante,  representativamente  fiel,  compreensível,  comparável  e 
verificável. Como essas informações podem estar disponíveis rapidamente, também é provável que 
sejam tempestivas.  
7.56  A extensão em que as mensurações do valor justo atendem às características qualitativas diminuirá 
à  medida  que  a  qualidade  da  evidência  de  mercado  diminuir  e  a  determinação  de  tais  valores 
depender  de  técnicas  de  estimativa.  Tal  como  indicado  anteriormente,  o  valor  justo  só  será 
provavelmente relevante para avaliações da capacidade financeira e não para avaliações do custo 
dos serviços e da capacidade operacional.  
Valor em uso  
7.57 O valor em uso é aplicável para avaliações de redução ao valor recuperável. O teste de redução ao 
valor recuperável envolve determinar se a quantia pela qual um ativo é declarado na demonstração 
da posição financeira é recuperável.  
7.58  O valor em uso de um ativo gerador de caixa é o valor presente dos fluxos de caixa futuros estimados 
que se espera que sejam derivados do uso continuado do ativo e de sua venda no final de sua vida 
útil. Isso requer o desconto dos fluxos de caixa a um valor presente.  

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
58 
 
7.59  O valor em uso de um ativo não gerador de caixa é o potencial de serviço remanescente do ativo na 
data  de  mensuração.  A  estimativa  do  potencial  de  serviço  requer  a  utilização  de  técnicas,  que 
dependem  da  natureza  do  ativo  e,  devido  à  sua  aplicabilidade  à  redução  do  valo  recuperável,  do 
indicador utilizado com essa finalidade.  
7.60  O valor em uso para ativos geradores de caixa é complexo e subjetivo, pois requer a projeção dos 
fluxos  de  caixa  da  perspectiva  da  entidade.  Complexidade  adicional  surge  quando  os  ativos  são 
implementados  em  combinação  com  outros  ativos.  Nesses  casos,  o  valor  em  uso  só  pode  ser 
estimado por meio do cálculo do valor presente dos fluxos de caixa de um grupo de ativos, e não 
em uma base individual. As apropriações são então feitas para ativos individuais. Tais apropriações 
podem ser arbitrárias, tendo assim um impacto adverso na representação fiel.  
7.61  O  valor  em  uso  para  ativos  não  geradores  de  caixa  também  é  complexo,  pois  requer  estimativas 
específicas da entidade sobre o potencial de serviço remanescente de um ativo.  
7.62  O item 7.36 discute a situação em que um ativo é usado para prestação de serviços e também gera 
benefícios  econômicos,  observando  que  a  entidade  que  está  usando  o  modelo  de  valor  corrente 
julga se um ativo é mantido principalmente para capacidade operacional ou capacidade financeira, 
e seleciona a base de mensuração do valor corrente operacional ou a base de mensuração do valor 
justo  em  conformidade.  Este  fator  e  a  complexidade  e  subjetividade  discutidas  anteriormente 
significam que o valor em uso, tanto em um contexto gerador de caixa como em um contexto não 
gerador de caixa, será provavelmente aplicável apenas à contabilização de perdas ou reversões de 
perdas relacionadas com a redução ao valor recuperável.  
Bases de mensuração para passivos  
7.63  Esta seção discute as bases de mensuração dos passivos. Esta seção não repete toda a discussão da 
seção sobre ativos. Considera as seguintes bases de mensuração:  
 (a) custo histórico;  
 (b) custo de cumprimento da obrigação; e  
 (c) valor justo.  
Custo histórico  
7.64  O custo histórico de um passivo é a contraprestação recebida para assumir uma obrigação menos 
os custos de transação, no momento em que o passivo é incorrido.  

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
59 
 
7.65  A contraprestação é o caixa ou equivalentes de caixa, ou o valor de outra contraprestação dada. No 
modelo  de  custo  histórico,  as  medidas  iniciais  são  ajustadas  utilizando  uma  técnica  que  reflete 
fatores como a acumulação de juros, a acumulação de descontos ou a amortização de prêmios.  
7.66  Quando o valor temporal de um passivo for material – por exemplo, quando o período de tempo 
antes da liquidação ocorrer for significativo – o valor futuro do pagamento é descontado de modo 
que, no momento em que um passivo é inicialmente mensurado, ele represente o valor presente do 
montante devido. A diferença entre o valor futuro do pagamento e o valor presente do passivo é 
amortizada  ao  longo  da  vida  do  passivo,  de  modo  que  o  passivo  é  contabilizado  pelo  valor  do 
pagamento exigido no vencimento.  
7.67  O  custo  histórico  é  apropriado  quando  é  provável  que  os  passivos  sejam  liquidados  nos  termos 
estabelecidos. No entanto, o custo histórico não pode ser aplicado a passivos que não resultem de 
uma transação, como o pagamento futuro de indenizações por um ato ilícito ou danos civis. É pouco 
provável  que  forneça  informações  relevantes  quando  o  passivo  tenha  sido  incorrido em uma 
transação sem contraprestação, porque não proporciona uma representação fiel das reivindicações 
contra  os  recursos  da  entidade.  Também  é  difícil  aplicar  o  custo  histórico  a  passivos  que  podem 
variar em montante, tais como as relacionadas com pensões de benefícios definidos.  
Custo de cumprimento da obrigação  
7.68   O   custo  de   cumprimento   da   obrigação  representa   os   custos  que   a  entidade   incorrerá   no 
cumprimento  das  obrigações  representadas  pelo  passivo,  assumindo  que  o  faz  da  forma  menos 
onerosa à data de mensuração.  
7.69  Quando  o  custo  do  cumprimento  da  obrigação  depende  de  eventos  futuros  incertos,  todos  os 
resultados  possíveis  são  levados  em  conta  para  estimar  esse  custo,  que  visa  refletir  todos  esses 
resultados possíveis de forma imparcial.  
7.70  Quando  o  cumprimento  exige  a  realização  de  trabalho – por  exemplo,  quando  a  obrigação  é  de 
corrigir danos ambientais – os custos relevantes são aqueles em que a entidade incorrerá. Esse pode 
ser  o  custo  da  entidade  realizar  ela  própria  o  trabalho  de  reparação  ou  de  contratar  uma  parte 
externa para realizar o trabalho. No entanto, os custos de contratação com uma parte externa só 
são relevantes quando a contratação de um empreiteiro for a forma menos onerosa de cumprir a 
obrigação.  
 7.71  Quando  o  cumprimento  da  obrigação  for feito  pela  própria  entidade,  o  custo  não  inclui  qualquer 
excedente, porque tal excedente não representa um uso dos recursos da entidade. Quando o custo 
de  cumprimento  da  obrigação  se  basear  no  custo  de  contratação  de  um  fornecedor,  o  montante 
incluirá implicitamente o lucro exigido pelo contratante, uma vez que o montante total cobrado pelo 
contratante será uma reinvindicação sobre os recursos da entidade.  

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
60 
 
7.72  Quando  o  cumprimento  da  obrigação  ocorrer  a  longo  prazo,  os  fluxos  de  caixa  precisam  ser 
descontados para refletir o valor do passivo na data de mensuração.  
7.73  O custo de cumprimento é geralmente relevante para mensurar passivos, exceto em circunstâncias 
em  que  a  entidade  possa  obter  a  liberação  de  uma  obrigação  por  um  valor  inferior  ao  custo  de 
cumprimento dessa.  
Valor justo  
7.74  O valor justo de um passivo é o preço que seria pago para transferir um passivo em uma transação 
ordenada entre participantes do mercado na data de mensuração.  
7.75  O  valor  justo  pode  ser  apropriado,  por  exemplo,  quando  o  passivo  for  atribuível  a  alterações  em 
uma taxa, preço ou índice especificado cotado em um mercado ordenado. Contudo, nos casos em 
que a capacidade de transferir um passivo é restrita e os termos em que tal transferência pode ser 
feita  não  são  claros,  a  relevância  do  valor  justo  é  mais  fraca.  Esse  é  particularmente  o  caso  dos 
passivos decorrentes de obrigações em transações sem contraprestação porque é improvável que 
exista um mercado ordenado para tais passivos.  
7.76 ao 7.91 (Eliminados).  
Capítulo  8 – Apresentação  de  Informação  no  Relatório  Contábil  de  Propósito  Geral  das  Entidades  do 
Setor Público  
Introdução 
8.1 Este capítulo estabelece os conceitos aplicáveis à apresentação da informação nos RCPGs, inclusive 
nas demonstrações contábeis dos governos e de outras entidades do setor público. 
8.2 A apresentação das informações nos RCPGs possui conexão com os capítulos 1 a 4 – os objetivos da 
elaboração e da divulgação da informação contábil, as necessidades dos usuários, as características 
qualitativas, as restrições na informação incluída nos RCPGs e a entidade que reporta a informação 
contábil influenciam  as  decisões  relativas  à  apresentação  das  informações.  Para  a  informação 
evidenciada nas demonstrações contábeis, a apresentação é relacionada também às definições dos 
elementos,  critérios de reconhecimento e bases de  mensuração  identificados nos  capítulos  5 a  7, 
por exemplo: 
(a)  a  definição  dos elementos afeta  os  itens  que  podem  ser  apresentados  nas  demonstrações 
contábeis; 
(b) a aplicação dos critérios de reconhecimento afeta a localização da informação; e 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
61 
 
(c) a seleção das bases de mensuração impacta a informação apresentada nas metodologias de 
mensuração. 
Idioma no qual as demonstrações contábeis e outros RCPGs são divulgados 
8.3 O  idioma  (ou  idiomas)  no  qual  as  demonstrações  contábeis  e  outros  RCPGs  são  divulgados  dá 
suporte  à  realização  dos  objetivos  da  elaboração  e  da  divulgação  da  informação  contábil  e  as 
características  qualitativas.  Todas  as  versões  traduzidas  precisam  ser  fiéis  à  versão  do  idioma 
original.  A  versão  traduzida  é  disponibilizada  para  satisfazer  as  necessidades  dos  usuários  em 
referência a: 
(a) dispositivos legais na jurisdição da entidade; e 
(b) relação custo-benefício da tradução. 
Apresentação 
8.4 A  apresentação  corresponde  à  seleção,  à  localização  e  à  organização  da  informação  que  é 
evidenciada nos RCPGs. 
8.5 A  apresentação  visa  fornecer  informação  que  contribua  com  os  objetivos  da  elaboração  e  da 
divulgação da informação contábil e alcança as características qualitativas, enquanto considera as 
restrições  na  informação  incluída  nos  RCPGs.  As  decisões  sobre  a  seleção,  a  localização  e  a 
organização da informação são tomadas em resposta às necessidades dos usuários pela informação 
sobre os fenômenos econômicos, financeiros e de outra natureza. 
8.6 O Capítulo 1 explica que os RCPGs compreendem relatórios múltiplos, cada um respondendo mais 
diretamente a determinados aspectos dos objetivos da elaboração e da divulgação da informação 
contábil ou no alcance dessas informações. Adicionalmente às demonstrações contábeis, os RCPGs 
fornecem  informação  relevante,  por  exemplo,  para  avaliações  do  desempenho  dos  serviços  da 
entidade  e  a  sustentabilidade  das  suas  finanças.  Os  objetivos  da  elaboração  e  da  divulgação  da 
informação contábil aplicados à área coberta por determinado relatório orientam as decisões sobre 
a apresentação daquele relatório. 
8.7 As decisões sobre a apresentação podem: 
(a)  resultar  no  desenvolvimento  de  novo  RCPG,  na  movimentação  da  informação  entre  os 
relatórios ou na fusão dos relatórios existentes; ou 
(b)  ser  decisões  detalhadas  sobre  a  seleção,  a  localização  e  a  organização  da  informação  no 
RCPG. 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
62 
 
Decisões sobre a apresentação que estão interligadas 
8.8 As  decisões  sobre  a  seleção,  a  localização  e  a  organização  da  informação  estão  interligadas  e,  na 
prática,  provavelmente  são  consideradas  em  conjunto.  O  montante  ou  o  tipo  de  informação 
selecionada  pode  ter  implicações  sobre  se  relatório  é  elaborado  em  separado  ou  organizado  em 
quadros  ou  tabelas  separados.  As  três  seções  seguintes  focam  separadamente  em  cada  decisão 
sobre a apresentação. 
Seleção da informação 
8.9 As decisões sobre a seleção da informação tratam da informação que é evidenciada: 
(a) nas demonstrações contábeis; e 
(b) nos RCPGs que não correspondam às demonstrações contábeis (outros RCPGs). 
8.10 Como explica o Capítulo 2, os objetivos da elaboração e da divulgação da informação contábil são o 
de  fornecer  informação  sobre  a  entidade  que  seja  útil  para  os  usuários  dos  RCPGs  para  fins  de 
prestação de contas e responsabilização (accountability) e tomada de decisão. O Capítulo 2 descreve 
os tipos de informações que os usuários necessitam para satisfazer esses objetivos. Aquela descrição 
orienta as decisões sobre se determinados tipos de relatórios são necessários. Esse capítulo foca na 
seleção da informação a ser apresentada nos RCPGs, incluindo as demonstrações contábeis e outros 
relatórios. 
Seleção e natureza da informação 
Natureza da informação nas demonstrações contábeis 
8.11 As  necessidades de  informação  dos usuários  identificados no  Capítulo  2 corroboram  a  seleção da 
informação  para  as  demonstrações  contábeis.  Essas  necessidades  incluem  a  informação  sobre  a 
situação patrimonial, o desempenho e os fluxos de caixa da entidade para: 
(a)  possibilitar  aos  usuários  identificarem  os  recursos  da  entidade  e  as  demandas  por  esses 
recursos na data do relatório; 
(b) informar as avaliações de questões como se a entidade adquiriu recursos com economicidade 
e  os  utilizou  de  forma  eficiente  e  eficaz  para  alcançar  os  seus  objetivos  na  prestação  de 
serviços; e 
(c) informar as avaliações do desempenho e a liquidez e solvência da entidade. 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
63 
 
8.12 As  demonstrações  contábeis  podem  fornecer  também  informação  que  auxilia  os  usuários  na 
avaliação da extensão na qual: 
(a) a entidade satisfez os seus objetivos financeiros; 
(b)  as  receitas,  as  despesas,  os  fluxos  de  caixa  e  o  desempenho  da  entidade  estão  em 
conformidade com os orçamentos aprovados; e 
(c) a entidade observou a legislação vigente e outros regulamentos que regem a captação e a 
utilização de recursos públicos. 
8.13  As demonstrações contábeis não evidenciam de modo abrangente o desempenho dos serviços da 
entidade. Contudo, a informação nas demonstrações contábeis pode fornecer informação relevante 
aos aspectos financeiros do desempenho dos serviços, como informação sobre: 
(a) receita, despesa e fluxos de caixa relativos aos serviços; e 
(b)  os  ativos  e  os  passivos  que  orientam  as  avaliações  dos  usuários  em  relação  à  capacidade 
operacional da entidade ou aos riscos financeiros que podem impactar no fornecimento do 
serviço. 
8.14 Outros  RCPGs  apresentam  informação  adicional  às  demonstrações  contábeis.  Tal  informação 
poderia, por exemplo, incluir: 
(a) informação sobre a sustentabilidade das finanças públicas da entidade; 
(b) discussão e análise das demonstrações contábeis; ou 
(c) informação sobre o desempenho dos serviços. 
Informação selecionada para exposição ou evidenciação 
8.15  A  informação  é  selecionada  para  exposição  ou  para  evidenciação  nos  RCPGs.  A  informação 
selecionada   para   exposição   comunica   mensagens-chave   no   RCPG,   enquanto   a   informação 
selecionada  para  evidenciação  torna  a  informação  exposta  mais  útil  ou  fornece  detalhes  que 
auxiliam os usuários a entenderem a informação exposta. A evidenciação não substitui a exposição. 
8.16 A repetição da informação no RCPG geralmente precisa ser evitada. Contudo, a mesma informação 
pode  ser  tanto  exposta como  evidenciada.  Por  exemplo,  o montante  exposto nas  demonstrações 
contábeis pode ser repetido nas notas explicativas quando tais notas fornecem o detalhamento do 
total exposto. Do mesmo modo, a mesma informação pode ser apresentada em RCPGs diferentes 
para tratar diferentes propósitos. 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
64 
 
Informação selecionada para exposição 
8.17 Todos os RCPGs contêm mensagens-chave que são comunicadas, uma vez que todos eles contêm 
informação exposta. A informação exposta observa um nível conciso e compreensível de modo que 
os  usuários  possam  focar  nas  mensagens-chave  apresentadas  e  não  serem  distraídos  por  algum 
detalhe  que,  de  outra  maneira,  poderia  obscurecer  essas  mensagens.  A  informação  exposta  é 
destacadamente    apresentada    utilizando-se    técnicas    de    apresentação    apropriadas,    como 
classificações, margens, quadros e gráficos. 
8.18 Os  itens  expostos  nas  demonstrações  contábeis  fornecem  informação  sobre  questões  como,  por 
exemplo,  a  situação  patrimonial,  o  desempenho  e  os  fluxos  de  caixa  da  entidade  que  reporta  a 
informação. 
8.19 A avaliação se o item satisfaz os critérios de reconhecimento é um dos principais mecanismos para 
se  determinar  se  a  informação  deve  ser  exposta  no  demonstrativo  que  evidencia  a  situação 
patrimonial ou no demonstrativo que evidencia o desempenho das entidades do setor público e/ou 
divulgada  nas  notas  explicativas  ou  em  outro  lugar  nos  RCPGs.  Em  outros  casos,  por  exemplo,  a 
demonstração dos fluxos de caixa apoia também o cumprimento dos objetivos da elaboração e da 
divulgação da informação contábil. 
8.20  O desenvolvimento de requisitos para a exposição das rubricas dos relatórios e os respectivos totais 
envolve equilibrar a padronização da informação exposta (a qual facilita a compreensibilidade) com 
a informação que é elaborada para os fatores específicos à entidade. O objetivo tanto dos requisitos 
da exposição padronizada como da informação específica à entidade é assegurar que a informação 
necessária para satisfazer os objetivos da elaboração e da divulgação da informação contábil esteja 
disponível para todas as entidades, ao permitir que a informação seja exposta de maneira que reflita 
a natureza e as operações de entidades específicas. 
Informação selecionada para evidenciação 
8.21 A informação evidenciada deve incluir: 
(a) a base para a informação exposta como, por exemplo, políticas e metodologias aplicáveis; 
(b) o detalhamentos da informação exposta; e 
(c)  itens  que  compartilham  alguns,  mas  nem  todos  os  aspectos  da  informação  exposta,  por 
exemplo, evidenciações de itens que satisfaçam algumas, mas nem todas as características 
da  definição  de  elemento  ou  evidenciações  sobre  itens  que  satisfaçam  a  definição  de 
elemento,  mas  não  os  critérios  de  reconhecimento.  O  Capítulo  5  explica  quais  os  outros 
recursos e outras obrigações que não satisfazem a definição de elementos e que podem ser 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
65 
 
reconhecidos para contribuir com os objetivos da elaboração e da divulgação da informação 
contábil. 
(Incluído no texto da alínea “c” do item 8.21) 
8.22  O nível de detalhe fornecido pela informação exposta contribui para a realização dos objetivos da 
elaboração  e  da  divulgação  da  informação  contábil,  desde  que  não  seja  excessivo.  A  informação 
evidenciada,  assim  como  a  informação  exposta,  é  necessária  para a  realização  dos  objetivos  da 
elaboração e da divulgação da informação contábil. 
8.23  A informação evidenciada nas notas explicativas às demonstrações contábeis: 
(a) é necessária para a compreensão dos usuários das demonstrações contábeis; 
(b) fornece informação que apresenta as demonstrações contábeis no contexto da entidade e o 
seu ambiente operacional; e 
(c) geralmente tem relação clara e demonstrável com a informação exposta nas demonstrações 
contábeis às quais ela pertence. 
8.24  A informação evidenciada nas notas explicativas pode incluir também: 
(a)  os  fatores  relacionados  à  entidade  que  podem  influenciar  as  opiniões  sobre  a  informação 
evidenciada (por exemplo, informação sobre as partes relacionadas e entidades controladas 
ou participações em outras entidades); 
(b)  a  fundamentação  para  o  que  é  exposto  (por  exemplo,  a  informação  sobre  as  políticas 
contábeis  e  critérios  de  mensuração,  inclusive  os  métodos  e  as  incertezas  quanto  à 
mensuração, quando aplicáveis); 
(c)  os  detalhamentos  dos  montantes  expostos  nas  demonstrações  (por  exemplo,  a  divisão  do 
imobilizado em classes diferentes); 
(d) os itens que não satisfazem a definição de elemento ou os critérios de reconhecimento, mas 
são  importantes  para  a  devida  compreensão  das  finanças  e  da  capacidade  de  prestar 
serviços  da  entidade,  por  exemplo,  a  informação  sobre  os  eventos  e  as  condições que 
podem afetar fluxos de caixa ou potencial de serviços futuros, inclusive as suas naturezas, 
os efeitos possíveis sobre os fluxos de caixa ou potencial de serviços, as probabilidades de 
ocorrência e as sensibilidades a mudanças nas condições; e 
(e) a informação que pode explicar as tendências subjacentes afetando os totais expostos. 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
66 
 
Princípios aplicáveis à seleção da informação 
8.25 As decisões sobre qual informação precisa ser exposta e evidenciada envolve considerar: 
(a) os objetivos da elaboração e da divulgação da informação contábil; 
(b) as características qualitativas e as restrições das informações contidas nos RCPGs; e 
(c) os fenômenos econômicos relevantes e outros fenômenos sobre os quais a informação seja 
necessária. 
8.26  A  seleção da  informação  contribui  para  satisfazer  aos  objetivos  da elaboração  e  da  divulgação  da 
informação contábil, uma vez que deve ser aplicada à informação coberta por relatório em particular 
e  fornecer  o  nível  de  detalhe  apropriado.  As  decisões  sobre a  seleção  da  informação  envolvem 
priorizar  e  resumir  e  evita  a  sobrecarga  de  informação,  a  qual  reduz  a  compreensibilidade. 
Informação em demasia pode dificultar a compreensão das mensagens-chave por parte dos usuários 
e,  consequentemente,  comprometer  a  realização  dos  objetivos  da  elaboração  e  da  divulgação  da 
informação contábil. 
8.27 Os  responsáveis  pela  elaboração  das  demonstrações  contábeis,  que  aplicam  as  normas  e  o 
julgamento profissional, são responsáveis por assegurar que a informação que satisfaça os objetivos 
da elaboração e da divulgação da informação contábil e que alcance as características qualitativas 
fornecidas nos RCPGs. 
8.28  As  decisões  sobre  a  seleção  da  informação  exigem  revisão  contínua  e  crítica.  A  informação 
identificada  para  possível  seleção  é  revisada  à  medida  que  for  desenvolvida  e  considerada  para 
apresentação,  com  referência  especial  à  sua  relevância,  materialidade  e  custo-benefício,  embora 
todas  as  características  qualitativas  e  restrições  sejam  aplicadas  às  decisões  sobre  a  seleção  da 
informação.  As  decisões  passadas  podem  exigir  reconsideração  porque  nova  informação  pode 
tornar  redundante  a  informação  existente,  fazendo  com  que  esses  itens  não  alcancem  mais  as 
características qualitativas e/ou as restrições. 
8.29  Todas as transações materiais, eventos e outros itens reportados são apresentados de maneira que 
transmitam  a  sua  essência  em  vez  da  sua  forma  jurídica  ou  outra  forma,  de  modo  que  as 
características qualitativas da relevância e da representação fidedigna sejam alcançadas. 
8.30 Os benefícios para os usuários ao receberem a informação precisam justificar os custos das entidades 
em coletar e apresentar a informação. Ao se fazer essa avaliação, é importante considerar como os 
itens individuais impactam o quadro geral apresentado e a natureza da informação apresentada. Os 
itens  que  aparentarem  gerar  pouco  benefício  quando  vistos  isoladamente,  podem  contribuir 
significativamente para o conjunto completo da informação apresentada. 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
67 
 
8.31  A  informação  precisa  ser  apresentada  em  base  suficientemente tempestiva  para  possibilitar  aos 
usuários   manterem a   administração   sujeita   à   prestação   de   contas   e   responsabilização 
(accountability) e para subsidiar a tomada de decisão por parte dos usuários. 
8.32 Os RCPGs podem incluir informação adicional derivada de fontes distintas do sistema de informação 
financeira.  As  características  qualitativas  se  aplicam  a  essa  informação  e  a  data  da  entrega  dela 
precisa ser mais próxima possível da data da divulgação das demonstrações contábeis, de modo que 
seja tempestiva. 
Princípios para a seleção da informação para a exposição ou evidenciação 
8.33 As decisões sobre a exposição e a evidenciação se aplicam tanto às demonstrações contábeis quanto 
aos outros RCPGs. Os objetivos da elaboração e da divulgação da informação contábil são aplicados 
à área coberta por relatório em particular para orientar a identificação da informação para exposição 
ou  evidenciação.  A  identificação  da  informação  para  exposição  e  evidenciação  em  RCPG  em 
particular pode envolver o desenvolvimento de: 
(a) princípios de classificação; 
(b) lista de tipos gerais de informações que são expostas e de lista semelhante de tipos gerais de 
informações que são evidenciadas; e/ou 
(c) listas de informação específica que aqueles que elaboram a informação precisam expor ou 
evidenciar. 
8.34 As decisões sobre a seleção da informação a ser exposta e evidenciada são tomadas: 
(a) com referência umas às outras, em vez de isoladamente; e 
(b) para comunicar efetivamente o conjunto integrado de informação. 
8.35  As  decisões  sobre  a  seleção  da  informação  em  outros  RCPGs  são  tomadas  após  considerar, 
cuidadosamente, a relação dos outros RCPGs com as demonstrações contábeis. 
Localização da informação 
8.36 As decisões sobre a localização da informação são tomadas sobre: 
(a) o local no qual a informação é contida no relatório; e 
(b) o local no qual o componente do relatório está localizado. 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
68 
 
8.37 A localização da informação tem impacto sobre a contribuição da informação para a realização dos 
objetivos  da  elaboração  e  da  divulgação  da  informação  contábil  e  para  o  atendimento  das 
características  qualitativas.  A  localização  pode  afetar  a  maneira  que  os  usuários  interpretam  a 
informação e a comparabilidade da informação. A localização pode ser utilizada para: 
(a) transmitir a importância relativa da informação e as suas conexões com os outros itens da 
informação; 
(b) transmitir a natureza da informação; 
(c) conectar itens de informação diferentes que se combinam para satisfazer a necessidade de 
um usuário em particular; e 
(d)  distinguir  entre  a  informação  selecionada  para  exposição  e  a  informação  selecionada para 
evidenciação. 
Princípios para a alocação da informação entre diferentes relatórios 
8.38 Os fatores relevantes para as decisões sobre alocar a informação entre as demonstrações contábeis 
e outros RCPGs incluem: 
(a) natureza: se a natureza da informação – por exemplo, histórica versus prospectiva – indica a 
inclusão  da  informação  no  mesmo  ou  em  RCPG  diferente  em  razão  das  considerações 
relacionadas a, por exemplo, comparabilidade e/ou compreensibilidade; 
(b) especificidade  à  jurisdição:  se  os  fatores  específicos  à  jurisdição,  como,  por  exemplo,  os 
dispositivos legais vigentes, especificarem regras acerca da localização da informação; e 
(c) conexão:  se  a  informação  adicional  considerada  precisa  ou  não  estar  conectada  de  modo 
estreito  com  a  informação  já  incluída  em  relatório  existente.  As  conexões  entre  todas  as 
informações  precisam  ser  avaliadas,  não  se  restringindo  somente  à  conexão  entre  a 
informação nova e a já existente. 
8.39  Os fatores expostos anteriormente, os quais representam a perspectiva de se adicionar informação 
ao conjunto de informação já existente, também se aplicam à consideração se o agrupamento da 
informação  existente  pode  ser  aprimorado,  o  que  é  discutido  na  seção  sobre  a  organização  da 
informação. 
8.40 Um RCPG específico pode ser necessário quando: 
(a) necessidades adicionais de informação do usuário, não satisfeitas por relatório existente, são 
identificadas; e 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
69 
 
(b)  um  RCPG  específico  para  satisfazer  essas  necessidades  é  mais  adequado  ao  alcance  dos 
objetivos  da  elaboração  e  da  divulgação  da  informação  contábil  e  do  cumprimento  das 
características qualitativas do que a inclusão da informação em relatório já existente. 
Princípios para a localização da informação dentro do relatório 
8.41  O item 8.17 afirma que a informação exposta é destacadamente apresentada utilizando-se técnicas 
de  apresentação  apropriadas – a  localização  é  o  modo  de  se  alcançar  isso.  A  localização  da 
informação dentro do relatório assegura que a informação exposta tenha o destaque apropriado e 
não fique obscurecida por informação evidenciada com mais detalhe e extensão. 
8.42  A localização da informação nas demonstrações contábeis contribui para representar um panorama 
financeiro mais abrangente da entidade. 
8.43  Para as demonstrações contábeis, a informação exposta é mostrada na demonstração apropriada, 
enquanto as evidenciações encontram-se nas notas explicativas. Distinguir a informação exposta e 
a informação evidenciada por meio da localização assegura que esses itens, os quais se relacionam 
diretamente  a  questões  de  comunicação,  como,  por  exemplo,  os  itens  da  demonstração  que 
evidencia  a  situação  patrimonial,  o  desempenho  e  os  fluxos  de  caixa  da  entidade,  podem  ser 
realçados,  com  informação  ainda  mais  detalhada  fornecida  por  meio  da  evidenciação  em  notas 
explicativas. 
8.44  Para  outros  RCPGs,  a  informação  exposta  pode  estar  localizada  separadamente  da  informação 
evidenciada ou no mesmo local, mas difere-se da informação evidenciada e do destaque dado por 
meio de outra técnica de apresentação. 
Organização da informação 
8.45  A   organização   da   informação   trata   da   disposição, do agrupamento   e do ordenamento   da 
informação, a qual inclui decisões sobre: 
(a) como a informação está disposta no RCPG; e  
(b) a estrutura geral do RCPG. 
8.46  A organização da informação envolve uma série de decisões incluindo as decisões sobre a utilização 
de  referência  cruzada,  quadros, tabelas,  gráficos,  cabeçalhos,  numeração  e  a  disposição  dos  itens 
dentro  de  determinado  componente  de  relatório,  incluindo  decisões  sobre  a  ordem  dos  itens.  A 
forma na qual a informação está organizada pode afetar a sua interpretação por parte dos usuários. 
Natureza da informação relevante para fins de organização 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
70 
 
8.47  As decisões sobre a organização da informação levam em consideração: 
(a) relacionamentos importantes entre a informação; e 
(b) se a informação é para exposição ou para evidenciação. 
Tipos de relacionamentos 
8.48 Os relacionamentos importantes incluem, mas não se restringem a: 
(a) aprimoramento; 
(b) similaridade; e 
(c) propósito comum. 
8.49  Aprimoramento:  a  informação  em  determinado  lugar  no  RCPG  pode  ser  aprimorada  por  meio  de 
informação  fornecida  em  outro  local.  Por  exemplo,  o  orçamento,  a  informação  prospectiva  e  do 
desempenho  de  serviços  aprimoram  a  informação  das  demonstrações  contábeis. As  tabelas,  os 
quadros e os gráficos podem ser utilizados para aprimorar a compreensão da informação narrativa. 
As conexões com a informação evidenciada fora dos RCPGs podem aprimorar a compreensibilidade 
da informação evidenciada pelos RCPGs. 
8.50  Similaridade:  a  relação  de  similaridade  existe  quando  a  informação  evidenciada  em  um  lugar  se 
baseia na informação relatada em outro local nos RCPGs, e a informação ou não foi ajustada ou teve 
ajustes relativamente menores. Por exemplo, caso a informação do desempenho dos serviços inclua 
o  custo  dos  serviços,  ou  o  valor  dos  ativos  utilizados  em  diferentes  serviços,  pode  auxiliar  a 
demonstrar   como   aqueles   totais   se   relacionam   à   despesa   e   aos   ativos   evidenciados   nas 
demonstrações  contábeis.  Outro  exemplo  é  a  relação  entre  a  despesa  total  evidenciada  no 
orçamento  e  o  total  da  despesa  evidenciada  na  demonstração  de  desempenho.  A  conciliação  ou 
aproximação,  na  medida  do  possível,  entre  os  dois  montantes  diferentes,  pode  aprimorar  a 
compreensão dos usuários sobre as finanças da entidade. 
8.51  Propósito comum: o relacionamento de propósito comum existe quando a informação relatada em 
locais   diferentes   contribui   para   os   mesmos   fins.   Um   exemplo   é   quando   demonstrações   e 
evidenciações  diferentes  fornecem  informação  necessária  para  avaliações  de  responsabilização 
pelos serviços prestados. As informações sobre (a) o custo real e orçado de serviços diferentes, (b) 
os  recursos  financeiros  e  não  financeiros  utilizados  na  prestação  de  serviços  diferentes  e  (c)  o 
fornecimento futuro de serviços diferentes pode ser incluído em locais diferentes. Para tornar clara 
a  relação  entre  a  informação  em  locais  diferentes,  é  adequado  organizar  a  informação  por 
intermédio da utilização de técnicas como cabeçalhos e referências. 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
71 
 
8.52  Podem existir relações entre informações expostas em diferentes: 
(a) RCPGs; 
(b) componentes dentro do RCPG; e 
(c) partes de um único componente. 
Agrupamento da informação 
8.53  Os  três  fatores  constantes  do  item  8.38  da  seção  sobre  localização  da  informação – natureza, 
especificidade à jurisdição e conexão – se aplicam também às considerações se o agrupamento da 
informação   existente   puder   ser   aprimorado.   As   decisões   sobre   o   agrupamento   efetivo   da 
informação consideram as conexões entre os conjuntos de informações, a natureza dos diferentes 
conjuntos  de  informações  e,  na  extensão  apropriada,  os  fatores  específicos  à  determinada 
jurisdição. 
Princípios aplicáveis à organização da informação 
8.54  A organização da informação: 
(a) dá suporte ao alcance dos objetivos da elaboração e da divulgação da informação contábil; e 
(b) auxilia a informação evidenciada a satisfazer as características qualitativas. 
8.55  A organização da informação: 
(a) busca assegurar que as mensagens-chave sejam compreensíveis; 
(b) identifica claramente as relações importantes; 
(c) fornece o destaque apropriado à informação que transmite mensagens-chave; e 
(d) facilita as comparações. 
8.56  A informação evidenciada está conectada por meio da utilização de cabeçalhos consistentes, ordem 
de apresentação e/ou outros métodos apropriados à relação e ao tipo de informação. Quando há 
conexões com informações evidenciadas fora dos RCPGs é importante que: 
(a) as conexões com a informação proveniente de outras fontes não prejudiquem o alcance das 
características qualitativas do RCPG; e 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
72 
 
(b) a data de emissão de qualquer informação conectada seja tão próxima quanto possível à data 
da divulgação das demonstrações contábeis, de modo que a informação evidenciada seja 
tempestiva. 
Comparabilidade 
8.57  A  organização  da  informação  leva  em  consideração  os  benefícios da  apresentação  consistente  no 
decorrer  do  tempo.  A  apresentação  consistente  dá  suporte  à  capacidade  dos  usuários  em 
entenderem  a  informação  e facilitam o  seu  acesso.  Além  disso,  auxilia o alcance  da  característica 
qualitativa da comparabilidade. 
Princípios da organização da informação nas demonstrações contábeis 
8.58 A informação exposta nas demonstrações contábeis, usualmente, é organizada em totais e subtotais. 
A  sua  organização  fornece  um  resumo  estruturado  de  tais  parâmetros  por  meio  dos  itens  das 
demonstrações que evidenciam a situação patrimonial, o desempenho e os fluxos de caixa. 
8.59 Nas demonstrações contábeis, algumas relações podem existir entre: 
(a) subconjuntos de montantes expostos ou mudanças nos montantes expostos e o seu impacto 
nos  itens  das  demonstrações  que evidenciam  a  situação  patrimonial,  o desempenho  e  os 
fluxos de caixa da entidade; 
(b) os diferentes montantes expostos em demonstrações contábeis diferentes, os quais refletem 
o   impacto   de   determinado   evento   externo   comum   ou   contribuem   juntos   para   a 
compreensão  de  aspecto  das  demonstrações  que  evidenciam  a  situação  patrimonial,  o 
desempenho e os fluxos de caixa da entidade; e 
(c) os montantes expostos e as evidenciações respectivas nas notas explicativas que explicam ou 
podem,  de  outra  maneira,  dar  suporte  à  compreensão  dos  usuários  acerca  dos  itens 
expostos. 
8.60 A organização da informação nas demonstrações contábeis inclui decisões sobre: 
(a) o tipo e o número de demonstrações; 
(b) o detalhamento dos totais em subcategorias significativas; 
(c) o ordenamento e o agrupamento de itens expostos em cada demonstração; 
(d) a identificação de agregados (aditivos ou subtrativos); e 

 
 
SAUS – Quadra 5 – Lote 3 – Bloco J – Edifício CFC 
Telefone: (61) 3314-9600 – CEP: 70070-920 – Brasília/DF 
cfc@cfc.org.br – www.cfc.org.br 
73 
 
(e) a identificação de outra informação para inclusão na demonstração. 
8.61  A informação evidenciada nas notas explicativas às demonstrações contábeis é organizada de modo 
que  as  relações  com  os  itens  evidenciados  nas  demonstrações  contábeis  sejam  claras.  As  notas 
explicativas são parte integrante das demonstrações contábeis. 
Princípios para a organização da informação em outros RCPGs 
8.62  A organização da informação em outros RCPGs, assim como para as demonstrações contábeis, busca 
assegurar   que   as   mensagens-chave   que   são   transmitidas   pela   informação   exposta   são 
compreensíveis.  A  apresentação  que  identifica  claramente  as  relações  relevantes aprimora  a 
extensão na qual o relatório: 
(a) satisfaça os objetivos da elaboração e da divulgação da informação contábil; e 
(b) alcance as características qualitativas. 
8.63  Conectar  informações  relacionadas  auxilia  os  usuários a  encontrarem informações  importantes. 
Algumas informações são mais compreensíveis quando organizadas em gráficos, quadros, tabelas, 
percentuais ou indicadores-chave de desempenho. Outra informação pode ser representada mais 
efetivamente de forma narrativa. A organização da informação apoia a compreensão por parte dos 
usuários acerca das conexões entre as informações no mesmo RCPG. 
8.64  A  organização  da  informação  facilita  as  comparações  ao  tornar  mais  claro  quando  determinados 
itens são semelhantes ou não. A comparabilidade intertemporal é facilitada ao se evitar alterações 
no modo em que a informação é organizada, para a mesma entidade, ano após ano, a menos que 
tais  mudanças  aprimorem  a  relevância  e  a  compreensibilidade.  A  comparação  entre  entidades  é 
facilitada quando diferentes entidades que reportam a informação contábil organizam de maneira 
semelhante a informação que apresentam. 
Vigência 
 
Esta Norma entra em vigor na data de sua publicação, aplicando-se aos exercícios iniciados a partir de 
1º  de  janeiro  de  2027,  e  revoga  a  NBC  TSP Estrutura  Conceitual,  publicada  no  DOU,  Seção  1,  de 
04/10/2016,  salvo  na  existência  de  algum  normativo  em  âmbito  nacional  que  estabeleça  prazos 
específicos – casos em que estes prevalecem. 
Brasília, 13 de novembro de 2025.  
CONTADOR AÉCIO PRADO DANTAS JÚNIOR  
Presidente 
Ata CFC nº 1.125.
