# Aprova a Revisão NBC 12.

- Código externo: 2021/revisãonbc12
- Fonte: CFC 2021/REVISÃONBC12 — DOU 28/10/2021
- URL fonte: https://www2.cfc.org.br/sisweb/sre/detalhes_sre.aspx?Codigo=2021/REVIS%C3%83ONBC12&arquivo=Revis%C3%A3o_NBC_12.doc
- Arquivo original: https://www1.cfc.org.br/sisweb/SRE/docs/Revis%c3%a3o_NBC_12.pdf
- Nome do arquivo: Revisão_NBC_12.pdf
- Tags: Contábil, NBC, Revisão NBC
- Atualizado em: 2026-10-10 14:27:55.232717+00

## Resumo

Aprova a Revisão NBC 12.

## Texto integral extraído

NORMA BRASILEIRA DE CONTABILIDADE, REVISÃO NBC 12, DE 7 DE OUTUBRO DE 2021 
 
 
Aprova  a  Revisão  NBC 12,  que  altera  as 
seguintes  normas: NBC TG 37 (R5), NBC 
TG 48, NBC  TG 29(R2), NBC  TG 27(R4), 
NBC TG 25(R2) e NBC TG15(R4). 
 
 
O CONSELHO FEDERAL DE CONTABILIDADE, no exercício de suas atribuições legais 
e  regimentais  e com  fundamento  no  disposto  na  alínea  “f”  do  Art.  6º  do  Decreto-Lei  n.º 
9.295/1946,  alterado  pela  Lei  n.º  12.249/2010,  faz  saber  que  foi  aprovada  em  seu  Plenário  a 
Revisão NBC 12, que altera as Normas Brasileiras de Contabilidade (NBC): 
 
 
1. Inclui os itens 39AG e  o  novo  D13A,  altera a  alínea  (f)  do  item  D1 e renumera  o  item 
D13A para  D13B na NBC  TG 37  (R5) - Adoção  Inicial  das  Normas  Internacionais  de 
Contabilidade, que passam a vigorar com as seguintes redações: 
 
39AG. A Revisão NBC 12, aprovada pelo Conselho Federal de Contabilidade em 7 de outubro de 
2021, alterou o item D1 (f), renumerou o item D13A e adicionou novo item D13A. A vigência 
desta  Revisão  deve  ser  estabelecida  pelos  órgãos  reguladores que  a  aprovarem,  sendo 
que,  para  o  pleno  atendimento  às  normas  internacionais  de  contabilidade,  a  entidade  deve 
aplicar estas alterações para períodos anuais com início em, ou após, 1º de janeiro de 2022.  
 
D1. A entidade pode optar por uma ou mais das seguintes isenções: 
(...) 
 
(f) diferenças acumuladas de conversão (itens de D12 a D13A D13B); 
 
D13A. Em  vez  de  aplicar  o  item  D12  ou  o  item  D13, a  controlada  que  usa  a  isenção  do  item 
D16(a)   pode   escolher,   em   suas   demonstrações   contábeis,   mensurar   as   diferenças 
acumuladas  de  conversão  para  todas  as  operações  no  exterior  no  valor  contábil  que  seria 
incluído  na  demonstração  consolidada  da  controladora,  com  base  na  data  de  transição  da 
controladora  para as NBCs,  caso  nenhum  ajuste  for  feito  para  os  procedimentos de 
consolidação e para os efeitos da combinação de negócios na qual a controladora adquiriu a 
controlada. Uma opção semelhante está disponível para entidade controlada em conjunto ou 
coligada que opta pela isenção do item D16(a).  
 
D13B.  Como  decorrência dos  itens  D12  e  D13, por  força  da  vigência dada  a NBC  TG  02(R3) - 
Efeitos das Mudanças nas Taxas de Câmbio e Conversão de Demonstrações Contábeis, a 
reconhecer  esses  ganhos  ou  perdas  por  diferenças  de  conversão  provavelmente  em  data 
anterior ao da data de transição para as IFRSs, as adotantes pela primeira vez devem zerar 
os saldos dessas diferenças acumuladas de conversão existentes nas suas demonstrações 
contábeis  elaboradas  de  acordo  com a NBC  TG  02,  à  data  da  transição,  transferindo-os 
para  lucros ou  prejuízos  acumulados,  bem  como  divulgar  a  política  de  distribuição  de 
resultados aplicável a tais saldos. 
 
 
2. Inclui os itens 7.1.9, 7.2.35, e seu título, e B3.3.6A e altera o item B3.3.6 na NBC TG 48 
– Instrumentos Financeiros, que passam a vigorar com as seguintes redações: 
 
7.1.9 A Revisão NBC 12, aprovada pelo Conselho Federal de Contabilidade em 7 de outubro de 
2021, adicionou os itens 7.2.35 e B3.3.6A e alterou o item B3.3.6. A vigência desta Revisão 
deve ser estabelecida pelos órgãos reguladores que a aprovarem, sendo que, para o pleno 

 
atendimento  às  normas  internacionais  de  contabilidade,  a  entidade  deve  aplicar  estas 
alterações para períodos anuais com início em, ou após, 1º de janeiro de 2022.  
 
Transição para alterações anuais aos pronunciamentos 
 
7.2.35 A entidade pode aplicar a Revisão NBC 12 para passivos financeiros que são modificados 
ou  trocados no  início  ou  depois  do  início  do  período  de  relatório  anual,  em  que  a  entidade 
pela primeira vez aplica a revisão.  
 
B3.3.6 Para  a  finalidade  do item 3.3.2,  os  termos  são  substancialmente  diferentes  se  o  valor 
presente  descontado  dos  fluxos  de  caixa  de  acordo  com  os  novos  termos,  incluindo 
quaisquer taxas pagas líquidas de quaisquer taxas recebidas e descontados usando a taxa 
de  juros  efetiva original, for  pelo  menos  10%  diferente  do  valor  presente  descontado  dos 
fluxos  de  caixa  restantes  do  passivo  financeiro  original.  Ao  determinar  essas  taxas  pagas 
líquidas  de  taxas  recebidas,  o  devedor  inclui  apenas  taxas  pagas  ou  recebidas  entre  o 
devedor e  o credor,  incluindo  taxas  pagas  ou  recebidas  pelo  devedor  ou  pelo  credor  em 
nome do outro.   
 
B3.3.6A Se  a  troca  de  instrumentos  de  dívida  ou  modificação  de  termos  for  contabilizada 
como extinção, quaisquer custos ou taxas incorridos devem ser reconhecidos como parte do 
ganho ou perda na extinção. Se a troca ou modificação não for contabilizada como extinção, 
quaisquer custos ou taxas incorridos devem ajustar o valor contábil do passivo e devem ser 
amortizados ao longo do prazo restante do passivo modificado. 
 
3. Altera  o  item  22  e  inclui  o  item  65  na  NBC TG 29 (R2) – Ativo  Biológico  e  Produto 
Agrícola, que passam a vigorar com as seguintes redações: 
 
22. A  entidade  não  deve  incluir  na  estimativa  de  fluxo  de  caixa  quaisquer  expectativas  de 
financiamento de ativos, tributos ou restabelecimento do ativo biológico após a colheita (por 
exemplo, o custo de replantio de árvores em plantação após a colheita). 
 
65. A Revisão NBC 12, aprovada pelo Conselho Federal de Contabilidade em 7 de outubro de 
2021,  alterou o item 22.  A vigência  desta  Revisão  deve  ser  estabelecida  pelos  órgãos 
reguladores   que   a   aprovarem,   sendo   que,   para   o   pleno   atendimento   às   normas 
internacionais de contabilidade, a entidade deve aplicar esta alteração para períodos anuais 
com início em, ou após, 1º de janeiro de 2022. 
 
4. Altera os itens 17 e 74 e inclui os itens 20A, 74A, 80D e 81N na NBC TG 27(R4) – Ativo 
Imobilizado, que passam a vigorar com as seguintes redações: 
 
17. Exemplos de custos diretamente atribuíveis são: 
 (...) 
(e) custos  com testes  para verificar  se  o  ativo  está  funcionando  corretamente  (ou  seja,  avaliar 
se  o  desempenho  técnico  e  físico  do  ativo  é  capaz  de  ser  usado  na  produção  ou 
fornecimento  de  bens  ou  serviços,  para  aluguel  a  terceiros  ou  para  fins administrativos); 
após  dedução das  receitas  líquidas  provenientes  da  venda  de  qualquer  item  produzido 
enquanto se coloca o ativo nesse local e condição (tais como amostras produzidas quando 
se testa o equipamento); e 
 
20A. Os  itens  podem  ser  produzidos  ao  trazer  um  item  do  imobilizado para  o local  e  condição 
necessários para que seja capaz de operar da maneira pretendida pela administração (como 
amostras  produzidas  ao  testar  se  o  ativo  está funcionando  corretamente).  A  entidade  deve 
reconhecer o produto da venda de tais itens, e o custo desses itens, no resultado de acordo 
com  as  normas  contábeis  aplicáveis.  A  entidade  deve  mensurar  o  custo  desses  itens 
aplicando os requisitos de mensuração da NBC TG 16(R2) – Estoques. 
 
74. As demonstrações contábeis também devem divulgar: 

 
 (...) 
(b) o  valor  dos  gastos  reconhecidos  no  valor  contábil de  item  do  ativo  imobilizado  durante  a sua 
construção; e 
(c) o valor dos compromissos contratuais advindos da aquisição de ativos imobilizados.; e  
(d)  se  não  for  divulgada  separadamente  no  corpo  da  demonstração  do resultado,  o  valor  das 
indenizações  de  terceiros  por  itens  do  ativo  imobilizado  que  tenham  sido  desvalorizados, 
perdidos ou abandonados, incluído no resultado. (Eliminado) 
 
74A. Se  não  for  apresentado  separadamente  na  demonstração  do  resultado abrangente, as 
demonstrações contábeis também devem divulgar: 
(a) o valor de compensação de terceiros para itens do ativo imobilizado que foram danificados, 
perdidos ou cedidos que estejam incluídos no resultado; e 
(b) os valores de receitas e de custos incluídos no resultado, de acordo com o item 20A, que se 
relacionam  com  itens  produzidos  que  não  são  uma  saída  das  atividades  ordinárias  da 
entidade, e que item da demonstração do resultado abrangente inclui tais receitas e custos.  
 
80D. A Revisão NBC 12, aprovada pelo Conselho Federal de Contabilidade em 7 de outubro de 
2021,  alterou  os  itens  17  e  74  e  adicionou  os  itens  20A  e  74A.A  entidade  deve  aplicar 
retrospectivamente, mas apenas aos itens do ativo imobilizado que são colocados no local e 
na  condição necessária  para  que  sejam  capazes  de  operar  da  maneira  pretendida  pela 
administração no, ou após o, início do período mais antigo apresentado nas demonstrações 
contábeis  nas  quais  a  entidade  aplica  a  revisão  pela  primeira  vez.  A  entidade  deve 
reconhecer  o efeito cumulativo  da  aplicação  inicial  das  alterações  como  ajuste  ao  saldo 
inicial  dos  lucros  acumulados  (ou  outro  componente  do  patrimônio  líquido,  conforme 
apropriado) no início do período mais antigo apresentado.  
 
81N. A Revisão NBC 12, aprovada pelo Conselho Federal de Contabilidade em 7 de outubro de 
2021,  alterou  os  itens  17  e  74  e  adicionou  os  itens  20A,  74A  e  80D.  A  vigência  desta 
Revisão deve ser estabelecida pelos órgãos reguladores que a aprovarem, sendo que, para 
o  pleno  atendimento  às  normas internacionais de  contabilidade,  a  entidade  deve  aplicar 
estas alterações para períodos anuais com início em, ou após, 1º de janeiro de 2022. 
 
 
5. Inclui  os  itens  68A,  94A  e  108  e  altera  o  item  69  na NBC  TG 25(R2) – Provisões, 
Passivos   Contingentes   e   Ativos   Contingentes,   que   passam   a   vigorar   com   as 
seguintes redações: 
 
68A. O custo de cumprimento de contrato compreende os custos que se relacionam diretamente 
com o contrato. Os custos que se relacionam diretamente com o contrato consistem em: 
(a) os custos incrementais de cumprimento desse contrato, por exemplo, mão de obra direta e 
materiais; e 
(b) a  alocação  de  outros  custos  que  se  relacionam  diretamente  com  o  cumprimento  de 
contratos,  por  exemplo,  a  alocação  do  encargo  de  depreciação  para item  do  imobilizado 
utilizado no cumprimento desse contrato, entre outros. 
 
69. Antes  de  ser  estabelecida  uma  provisão  separada  para  contrato  oneroso,  a  entidade  deve 
reconhecer  qualquer  perda  decorrente  de  desvalorização  que  tenha  ocorrido  nos  ativos 
relativos a esse utilizados no cumprimento do contrato (ver o Pronunciamento Técnico CPC 
01 – Redução ao Valor Recuperável de Ativos). 
 
94A. A Revisão NBC 12, aprovada pelo Conselho Federal de Contabilidade em 7 de outubro de 
2021,  acrescentou  o  item  68A  e  alterou  o  item 69.  Uma  entidade  deve  aplicar  essas 
alterações  aos  contratos  para  os  quais  ainda  não  cumpriu  todas  as  suas  obrigações  no 
início  do  primeiro  período  em  que  aplicar  as  alterações  (data  da  aplicação  inicial).  A 
entidade  não  deve  reapresentar  informações comparativas.  Em vez  disso,  a  entidade  deve 
reconhecer  o efeito  cumulativo  da  aplicação  inicial  das  alterações  como  ajuste  ao  saldo 

 
inicial dos   lucros   acumulados   ou   outro   componente   do   patrimônio   líquido,   conforme 
apropriado, na data da aplicação inicial.  
 
108. A Revisão NBC 12, aprovada pelo Conselho Federal de Contabilidade em 7 de outubro de 
2021, adicionou os itens 68A e 94A e alterou o item 69. A vigência desta Revisão deve ser 
estabelecida   pelos   órgãos   reguladores   que   a   aprovarem,   sendo   que,   para   o   pleno 
atendimento às  normas  internacionais  de  contabilidade,  a  entidade  deve  aplicar  estas 
alterações para períodos anuais com início em, ou após, 1º de janeiro de 2022. 
 
 
6. Altera os itens 11, 14, 21, 22 e 23 e inclui os itens 21A, 21B, 21C, 23A e 64Q na NBC TG 
15 (R4) – Combinação de Negócios, que passam a vigorar com as seguintes redações: 
 
11. Para   se  qualificarem  para  reconhecimento,  como   parte  da   aplicação  do   método  de 
aquisição,  os  ativos  identificáveis  adquiridos  e  os  passivos  assumidos  devem  atender, na 
data  da  aquisição, às  definições  de  ativo  e  de  passivo dispostas na  NBC  TG Estrutura 
Conceitual  para  a  Elaboração  e  Divulgação  de  Relatório  Contábil-Financeiro.  Por  exemplo, 
os  custos  que  o  adquirente  espera,  porém  não  está  obrigado  a  incorrer  no  futuro, para 
efetivar  um  plano  para  encerrar  uma  atividade da  adquirida,  ou  os  custos  para realocar  ou 
desligar empregados da adquirida não constituem passivo na data da aquisição. Portanto, o 
adquirente  não  deve  reconhecer  tais  custos  como  parte  da  aplicação  do método  de 
aquisição. Em vez disso, o adquirente deve reconhecer tais custos em suas demonstrações 
contábeis  pós-combinação,  de  acordo  com  o  disposto  em  outras  Normas  Brasileiras  de 
Contabilidade do Conselho Federal de Contabilidade. 
 
14. Os  itens  de  B31  a B40  fornecem orientações  para  o  reconhecimento  de  ativos  intangíveis. 
Os  itens  de  2221A  a  28B  especificam  os  tipos  de  ativos  identificáveis  e  os  passivos,  os 
quais  incluem  itens  para  os  quais  este  Pronunciamento  prevê  limitadas  exceções  ao 
princípio e às condições de reconhecimento. 
 
21. Este Revisão prevê limitadas exceções aos princípios de reconhecimento e de mensuração. 
Os  itens  de  2221A  a  31A  determinam  os  itens  específicos  para  os  quais  são  previstas 
exceções  e  também  a  natureza  dessas  exceções.  O  adquirente  deve contabilizar  esses 
itens pela aplicação das exigências dispostas nos itens de 2221A a 31A, o que vai resultar 
em alguns itens sendo:  
(a) reconhecidos  pela  aplicação  de  condições  de  reconhecimento  adicionais  àquelas  previstas 
nos  itens  11  e  12,  ou  pela  aplicação das  exigências  de  outras  normas,  com  resultados 
diferentes  dos  que  seriam  obtidos  mediante  aplicação  do  princípio  e  das  condições  de 
reconhecimento;  
(b) mensurados por montante diferente do seu valor justo na data da aquisição. 
  
21A. O item 21B aplica-se a passivos e passivos contingentes que estejam dentro do alcance da 
NBC TG 25 (R2) - Provisões, Passivos Contingentes e Ativos Contingentes ou da ITG 19 - 
Tributos se  fossem  incorridos  separadamente  em  vez  de  assumidos  em  combinação  de 
negócios.  
 
21B. A Estrutura  Conceitual  para  Relatórios  Financeiros  define  passivo  como  "uma  obrigação 
presente  da  entidade  de  transferir  um  recurso  econômico  como  resultado  de  eventos 
passados". Para provisão ou passivo contingente que esteja dentro do alcance do NBC TG 
25(R2), a adquirente deve aplicar os itens de 15 a 22 do NBC TG 25 para determinar se na 
data  de  aquisição  existe  uma  obrigação  presente  como resultado  de  eventos  passados. 
Para  tributo  que  esteja  dentro  do  alcance  da  ITG 19,  o  adquirente deve  aplicar a  ITG 19 
para  determinar  se  o  evento  que  gera  a  obrigação  de  pagar  a  taxa  ocorreu  até  a  data  de 
aquisição. 
  

 
21C. A obrigação presente identificada, de acordo com o item 21B, pode corresponder à definição 
de passivo contingente estabelecida no item 22(b). Nesse caso, o item 23 aplica-se a esse 
passivo contingente.  
 
22. A  NBC  TG  25  (R2) – Provisões,  Passivos  Contingentes  e  Ativos  Contingentes  define 
“passivo contingente” como:  
(a) uma possível obrigação que resulta de eventos passados e cuja existência será confirmada 
apenas  pela  ocorrência  ou não  de  um  ou  mais  eventos  futuros  incertos  não  totalmente 
controlados pela entidade; ou  
(b) uma  obrigação  presente  que  resulta  de  eventos  passados,  mas  que  não  é  reconhecida 
porque:  
(i) não  é  provável que  uma  saída de  recursos  que  incorporam  benefícios econômicos  seja 
exigida para liquidar a obrigação; ou  
(ii) o montante da obrigação não pode ser mensurado com suficiente confiabilidade. 
 
23. As exigências da NBC TG 25(R2) - Provisões, Passivos Contingentes e Ativos Contingentes 
não se aplicam na determinação de quais passivos contingentes devem ser reconhecidos na 
data  da  aquisição.  Em  vez  disso  O  adquirente  deve  reconhecer,  na  data  da  aquisição,  um 
passivo  contingente  assumido  em  combinação  de  negócios se  ele  for  uma  obrigação 
presente que surge de eventos passados e se o seu valor justo puder ser mensurado com 
confiabilidade. Portanto, de forma contrária aos itens 14(b), 23, 27, 29 e 30 da NBC TG 25, o 
adquirente  deve  reconhecer,  na  data  da  aquisição, um  passivo  contingente  assumido  em 
combinação  de  negócios,  mesmo  se  não  for  provável  que  sejam  requeridas  saídas  de 
recursos (incorporando benefícios econômicos) para liquidar a obrigação. O item 56 orienta 
a contabilização subsequente de passivos contingentes. 
 
23A. A NBC  TG 25  define  ativo  contingente  como “um ativo possível que resulta de eventos 
passados e cuja existência será confirmada apenas pela ocorrência ou não de um ou mais 
eventos futuros incertos não totalmente sob controle da entidade”. A adquirente  não  deve 
reconhecer um ativo contingente na data de aquisição.  
 
64Q. A Revisão NBC 12, aprovada pelo Conselho Federal de Contabilidade em 7 de outubro de 
2021,  alterou  os  itens  11, 14,  21,  22  e  23  e  adicionou  os  itens  21A,  21B,  21C  e  23A.  A 
vigência  desta  Revisão  deve ser  estabelecida  pelos  órgãos reguladores  que  a  aprovarem, 
sendo que, para o pleno atendimento às normas internacionais de contabilidade, a entidade 
deve aplicar estas alterações para períodos anuais com início em, ou após, 1º de janeiro de 
2022.   
 
 
Essas alterações, inclusões e exclusões serão incorporadas nas respectivas normas e entram em 
vigor na data de sua publicação, devendo ser aplicadas aos relatórios de auditoria emitidos sobre 
as demonstrações contábeis referentes aos exercícios ou períodos que se iniciam em, ou após, 1º 
de janeiro de 2022. 
  
Brasília, 7 de outubro de 2021. 
 
 
Contador Zulmir Ivânio Breda 
Presidente 
 
Ata CFC n.º 1.079.
